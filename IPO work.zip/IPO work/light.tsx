//Market Screen and Components styling

export const marketScreen = StyleSheet.create({
  marketContainer: {
    backgroundColor: "#FFFFFF",
    flex: 1,
    // borderBottomColor: root.color_primary,
  },
  marketHeaderView: {
    width: "100%",
    height: 56,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: root.color_primary,
    paddingLeft: 17,
    paddingRight: 16,
  },
  marketHeaderIcon: {
    width: 15,
    backgroundColor: "#303030",
    height: 1.8,
    marginVertical: 1.5,
  },
  marketHeaderText: {
    color: root.color_text,
    fontSize: 16,
    marginLeft: 20,
    fontFamily: Cfont.rubik_medium,
  },
  scrollBarBackgroundView: {
    width: "100%",
    paddingHorizontal: 13,
    flexDirection: "row",
    // alignSelf: 'center',
  },
  scrollBarView: {
    flexDirection: "row",
    borderRadius: 25,
    // alignItems:"center",
    // justifyContent:"center",
    height: 32,
  },
  scrollView: {
    borderRadius: 25,
    overflow: "hidden",
    backgroundColor: "rgba(0,0,0,0.10)",
    marginVertical: 0,
    marginLeft: 0,
    height: 32,
  },
  scrollBarTextBg: {
    paddingHorizontal: 10,
    height: 32,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 25,
    // backgroundColor: index == 0 ? root.color_textual : 'transparent',
  },
  scrollBarText: {
    fontSize: 11,
    marginHorizontal: 9,
    fontFamily: Cfont.rubik_medium,
  },
  whatsNewHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 14,
  },
  WhatsNewFlatlistFooter: {
    width: 16,
  },
  WhatsNewContentContainer: {
    marginLeft: 16,
  },
  newProductHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newProductFlatList: {
    marginLeft: 16,
  },
  indicesHeadView: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingRight: 15,
  },
  indicesHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 17,
  },
  indicesViewAllBtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
    marginTop: 15,
  },
  indicesFlateList: {
    marginLeft: 16,
  },
  myScreenerHeadView: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingRight: 15,
  },
  myScreenerHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 9,
    marginBottom: 3,
  },
  myScreenerViewAllbtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  myScreenerScrollView: {
    marginLeft: 13,
  },
  newsAndAnnounceHeadView: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingRight: 15,
  },
  newAndAnnounceHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newAndAnnounceSearchBtn: {
    color: root.color_text,
    paddingTop: 16,
  },
  newAndAnnounceFlatListFooter: {
    width: 16,
  },
  newAndAnnounceFlatlist: {
    marginTop: -10,
  },
  newAndAnnounceBottomListView: {
    marginTop: 18,
  },
  viewAllNews: {
    color: root.color_textual,
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    textAlign: "center",
    marginTop: 20,
    marginBottom: 33,
  },
  eventHeadView: {
    ...alignment.row_alingC_SpaceB,
    ...p.r_15,
  },
  eventHeadText: {
    ...color.text,
    ...size_family.rm_16,
    ...p.l_16,
    ...m.t_5,
  },
  eventDateView: {
    backgroundColor: root.calendar_bg,
    height: 60,
    width: "100%",
    ...m.t_5,
    ...alignment.row_alingC_SpaceB,
  },
  eventCurrentDate: {
    ...color.text,
    ...size_family.rm_15,
    ...m.m_l_16,
  },
  eventCalendarIcon: {
    ...m.r_15,
  },
  eventCalendar: {
    width: "100%",
  },
  eventCalendarTheme: {
    calendarBackground: root.color_chipFilter,
    dayTextColor: root.color_text,
    textDayFontWeight: "800",
    textDayFontSize: 17,
    textSectionTitleColor: root.color_text,
    textSectionTitleFontWeight: "800",
    textDayHeaderFontSize: 17,
    textDayHeaderFontWeight: "800",
  },
  eventFlatList: {
    ...m.t_15,
    ...m.b_30,
  },
  noEventView: {
    ...alignment.alignC_justifyC,
  },
  noEventImage: {
    height: 110,
    width: 115,
    ...m.t_10,
  },
  emptyEventText: {
    ...color.subtext,
    ...size_family.rr_14,
    ...m.b_60,
    ...m.t_13,
  },
  ipoHeadText: {
    ...color.text,
    ...size_family.rm_16,
    ...p.l_16,
    ...m.t_10,
  },
  ipoFlatList: {
    ...m.m_l_13,
    ...p.r_10,
  },
  ipoFooter: {
    height: 135,
  },
  ipoHeadView: {
    ...alignment.row_alingC_SpaceB,
    ...p.r_15,
  },
  ipoViewAllbtn: {
    ...color.client_background,
    ...size_family.rm_11,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...p.l_16,
    ...p.t_18,
    ...m.b_12,
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
  },
  filterTagData: {
    ...size_family.rm_9,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
  eventBtnView: {
    ...alignment.row_alignC,
    ...p.t_19,
    ...m.b_7,
  },
  eventSearchBtn: {
    ...color.text,
    fontSize: 24,
  },
  eventFilterBtn: {
    ...color.text,
    fontSize: 24,
    ...m.m_l_10,
  },
});

// Replace IPO Comp

export const ipoComp = StyleSheet.create({
  container: {
    ...bgColor.color_active,
    height: 238,
    width: 195,
    borderRadius: 8,
    ...m.t_20,
    ...m.v_10,
    ...m.r_13,
    ...m.m_l_3,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: "hidden",
  },
  innerView: {
    ...m.m_l_13,
  },
  imageView: {
    backgroundColor: "#FF6700",
    height: 39,
    width: 39,
    borderRadius: 25,
    ...m.t_10,
    opacity: 0.7,
    justifyContent: "center",
  },
  title: {
    ...color.text,
    ...size_family.rm_11,
    width: "60%",
    ...m.t_10,
    ...m.m_l_6,
  },
  subTitle: {
    ...color.active,
    ...size_family.rm_9,
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: "center",
    borderRadius: 25,
    ...m.t_12,
    alignSelf: "flex-start",
  },
  pricerRange: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_36,
  },
  issueDate: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  date: {
    ...color.text,
    ...size_family.rr_11,
  },
  minQty: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  qty: {
    ...color.text,
    ...size_family.rr_11,
  },
  minAmount: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  amount: {
    ...color.text,
    ...size_family.rr_11,
  },
  titleAndImgView: {
    ...alignment.row,
  },
  minQtyAndAmmountView: {
    ...alignment.row_SpaceB,
    ...m.r_25,
  },
});

// add new styles

// IPO Modal

export const ipoModal = StyleSheet.create({
  modal: {
    width: Dimensions.get("window").width,
    height: Dimensions.get("window").height,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  mainView: {
    ...p.h_15,
    flex: 1,
  },
  closeIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    marginTop: 21,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_23,
  },
  imgAndTitleView: {
    ...alignment.row_alignC,
  },
  imageView: {
    backgroundColor: "#FF6700",
    height: 49,
    width: 49,
    borderRadius: 50,
    opacity: 0.7,
    justifyContent: "center",
  },
  title: {
    ...color.text,
    ...size_family.rm_14,
    ...m.m_l_13,
    width: "52%",
  },
  status: {
    ...color.active,
    ...size_family.rm_9,
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: "center",
    borderRadius: 25,
    ...m.t_20,
    alignSelf: "flex-start",
  },
  pricerRange: {
    ...color.text,
    ...size_family.rr_14,
  },
  detailsView: {
    ...m.t_25,
    ...alignment.row_alignC,
  },
  row: {
    ...alignment.row_alignC,
    ...m.t_20,
  },
  detailsText: {
    ...size_family.rm_11,
    ...color.text,
  },
  detailsTextData: {
    ...size_family.rm_13,
    ...color.text,
    ...m.t_2,
  },
  mLeft: {
    ...m.m_l_70,
  },
  mTop: {
    ...m.t_15,
  },
  botton: {
    width: "92%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    borderRadius: 7,
    ...p.p_10,
    ...m.t_14,
    ...m.b_14,
    alignSelf: "center",
  },
  bottonText: {
    ...size_family.rm_14,
    ...color.active,
  },
});

// IPO View All screen

export const ipoViewAll = StyleSheet.create({
  mainView: {
    flex: 1,
    // paddingHorizontal: 15,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    height: 56,
    width: "100%",
    ...bgColor.color_active,
    elevation: 5,
    ...p.h_15,
  },
  backIconHeaderView: {
    ...alignment.row_alignC,
  },
  headerText: {
    ...size_family.rm_17,
    ...color.text,
    ...p.l_20,
  },
  headerBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  headerSearchIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  longHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
    ...m.t_15,
  },
  longHeaderView: {
    width: "100%",
    ...bgColor.color_active,
    elevation: 5,
    ...p.h_15,
  },
  longHeaderText: {
    ...size_family.rm_27,
    ...color.text,
  },
  longHeaderTextView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_35,
    ...m.b_23,
  },
  sectionText: {
    ...size_family.rm_17,
    ...color.client_background,
    ...m.t_12,
    ...m.b_20,
  },
  viewMoreView: {
    ...alignment.row_alignC,
    ...m.b_18,
    ...m.t_15,
    alignSelf: "flex-start",
  },
  viewMoreText: {
    ...size_family.rm_11,
    color: root.color_textual,
  },
  viewMoreIcon: {
    fontSize: 11,
    color: root.color_textual,
    ...m.m_l_5,
  },
});

// Ipo card

export const ipoCard = StyleSheet.create({
  mainView: {
    ...bgColor.color_active,
    width: "100%",
    height: 142,
    borderRadius: 10,
    ...m.t_10,
    ...p.h_12,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_10,
  },
  imgAndTitleView: {
    ...alignment.row_alignC,
  },
  imageView: {
    backgroundColor: "#EC6F32",
    height: 35,
    width: 35,
    borderRadius: 50,
    opacity: 0.7,
    justifyContent: "center",
  },
  title: {
    ...color.text,
    ...size_family.rm_12,
    ...m.m_l_15,
    ...m.r_30,
  },
  priceRange: {
    ...color.text,
    ...size_family.rr_12,
  },
  rowCenter: {
    ...alignment.row_alignC,
  },
  dateStatusView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_35,
  },
  minQtyAndAmmountView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_12,
  },
  detailsText: {
    ...size_family.rm_11,
    ...color.text,
  },
  detailsTextData: {
    ...size_family.rr_11,
    ...color.text,
  },
  status: {
    ...color.active,
    ...size_family.rm_10,
    backgroundColor: "#4CAF50",
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: "center",
    borderRadius: 25,
  },
});

// Ipo search Modal

export const ipoSearchModal = StyleSheet.create({
  modal: {
    width: Dimensions.get("window").width,
    backgroundColor: "#f6f6f6",
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
    fontSize: 21,
    ...color.text,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: "center",
    ...m.t_100,
  },
});

// extra content

const padding = {
  16: {
    padding: 16,
  },
  l_25: {
    paddingLeft: 25,
  },
  l_20: {
    paddingLeft: 20,
  },
  r_15: {
    paddingRight: 15,
  },
  r_10: {
    paddingRight: 10,
  },
  h_3: {
    paddingHorizontal: 3,
  },
  l_5: {
    paddingLeft: 5,
  },
  l_4: {
    paddingLeft: 4,
  },
  l_8: {
    paddingLeft: 8,
  },
  l_16: {
    paddingLeft: 16,
  },
  h_6: {
    paddingHorizontal: 6,
  },
  h_5: {
    paddingHorizontal: 5,
  },
  h_8: {
    paddingHorizontal: 8,
  },
  v_2: {
    paddingVertical: 2,
  },
  t_3: {
    paddingTop: 3,
  },
  t_1: {
    paddingTop: 1,
  },
  t_8: {
    paddingTop: 8,
  },
  h_7: {
    paddingHorizontal: 7,
  },
  h_10: {
    paddingHorizontal: 10,
  },
  h_12: {
    paddingHorizontal: 12,
  },
  v_8: {
    paddingVertical: 8,
  },
  v_10: {
    paddingVertical: 10,
  },
  h_16: {
    paddingHorizontal: 16,
  },
  t_20: {
    paddingTop: 20,
  },
  h_14: {
    paddingHorizontal: 14,
  },
  h_15: {
    paddingHorizontal: 15,
  },
  h_18: {
    paddingHorizontal: 18,
  },
  h_20: {
    paddingHorizontal: 20,
  },
  t_40: {
    paddingTop: 40,
  },
  t_35: {
    paddingTop: 35,
  },
  t_36: {
    paddingTop: 36,
  },
  t_37: {
    paddingTop: 37,
  },
  t_18: {
    paddingTop: 18,
  },
  t_19: {
    paddingTop: 19,
  },
  b_17: {
    paddingBottom: 17,
  },
  b_2: {
    paddingBottom: 2,
  },
  b_30: {
    paddingBottom: 30,
  },
  t_5: {
    paddingTop: 10,
  },
  t_10: {
    paddingTop: 10,
  },
  p_11: {
    padding: 11,
  },
  p_10: {
    padding: 10,
  },
  p_6: {
    padding: 6,
  },
  p_5: {
    padding: 5,
  },
  p_7: {
    padding: 7,
  },
  p_1: {
    padding: 1,
  },
  p_3: {
    padding: 3,
  },
  p_2: {
    padding: 2,
  },
  l_10: {
    paddingLeft: 10,
  },
  t_12: {
    paddingTop: 12,
  },
  l_12: {
    paddingLeft: 12,
  },
  h_24: {
    paddingHorizontal: 24,
  },
  v_12: {
    paddingVertical: 12,
  },
};

export const margin = {
  m_l_5: {
    marginLeft: 5,
  },
  m_l_6: {
    marginLeft: 6,
  },
  m_l_4: {
    marginLeft: 4,
  },
  m_l_3: {
    marginLeft: 3,
  },
  m_l_10: {
    marginLeft: 10,
  },
  m_l_9: {
    marginLeft: 9,
  },
  m_l_15: {
    marginLeft: 15,
  },
  m_l_13: {
    marginLeft: 13,
  },
  m_l_16: {
    marginLeft: 16,
  },
  m_l_70: {
    marginLeft: 70,
  },
  t_26: {
    marginTop: 26,
  },
  t_25: {
    marginTop: 25,
  },
  t_18: {
    marginTop: 18,
  },
  t_20: {
    marginTop: 20,
  },
  t_21: {
    marginTop: 21,
  },
  t_17: {
    marginTop: 17,
  },
  t_23: {
    marginTop: 23,
  },
  t_22: {
    marginTop: 22,
  },
  t_28: {
    marginTop: 28,
  },
  t_10: {
    marginTop: 10,
  },
  t_11: {
    marginTop: 11,
  },
  t_58: {
    marginTop: 58,
  },
  t_14: {
    marginTop: 14,
  },
  t_15: {
    marginTop: 15,
  },
  t_12: {
    marginTop: 12,
  },
  t_13: {
    marginTop: 13,
  },
  t_30: {
    marginTop: 30,
  },
  t_31: {
    marginTop: 30,
  },
  t_34: {
    marginTop: 30,
  },
  t_35: {
    marginTop: 35,
  },
  t_36: {
    marginTop: 36,
  },
  t_42: {
    marginTop: 42,
  },
  t_40: {
    marginTop: 40,
  },
  t_41: {
    marginTop: 41,
  },
  t_45: {
    marginTop: 45,
  },
  t_8: {
    marginTop: 8,
  },
  t_48: {
    marginTop: 48,
  },
  t_50: {
    marginTop: 50,
  },
  t_100: {
    marginTop: 50,
  },
  t_16: {
    marginTop: 16,
  },
  t_6: {
    marginTop: 6,
  },
  t_5: {
    marginTop: 5,
  },
  t_2: {
    marginTop: 2,
  },
  b_8: {
    marginBottom: 8,
  },
  b_7: {
    marginBottom: 7,
  },
  b_12: {
    marginBottom: 12,
  },
  b_16: {
    marginBottom: 16,
  },
  b_18: {
    marginBottom: 18,
  },
  b_20: {
    marginBottom: 20,
  },
  b_23: {
    marginBottom: 23,
  },
  b_30: {
    marginBottom: 30,
  },
  b_5: {
    marginBottom: 5,
  },
  b_32: {
    marginBottom: 32,
  },
  b_35: {
    marginBottom: 35,
  },
  b_60: {
    marginBottom: 60,
  },
  b_15: {
    marginBottom: 15,
  },
  b_14: {
    marginBottom: 14,
  },
  b_6: {
    marginBottom: 6,
  },
  b_9: {
    marginBottom: 9,
  },
  h_13: {
    marginHorizontal: 13,
  },
  h_16: {
    marginHorizontal: 16,
  },
  h_35: {
    marginHorizontal: 35,
  },
  r_12: {
    marginRight: 12,
  },
  r_13: {
    marginRight: 13,
  },
  r_15: {
    marginRight: 12,
  },
  r_25: {
    marginRight: 25,
  },
  r_30: {
    marginRight: 30,
  },
  r_10: {
    marginRight: 10,
  },
  v_20: {
    marginVertical: 20,
  },
  v_10: {
    marginVertical: 10,
  },

  v_16: {
    marginVertical: 16,
  },
};

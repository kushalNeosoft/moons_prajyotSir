import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import IPOComponent from '../Component/IpoComponent';
import {marketScreen} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
export const ipoData = [
  {
    title: 'Life Insurance Of India',
    range: '₹902 - ₹949',
    date: `01 OCT '22 - 01 OCT '25`,
    minQty: '15(1 Lots)',
    minAmount: '13,530',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Acceleratebs India Ltd',
    range: '₹90',
    date: `06 JUL '23 - 11 JUL '23`,
    minQty: '1600(1 Lots)',
    minAmount: '1,44,000',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'KaKa Industries Ltd',
    range: '₹55 - ₹58',
    date: `10 JUL '23 - 12 JUL '23`,
    minQty: '2000(1 Lots)',
    minAmount: '1,10,000',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Ahasolar Technologies Ltd',
    range: '₹157',
    date: `10 JUL '23 - 13 JUl '23`,
    minQty: '800(1 Lots)',
    minAmount: '1,25,600',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Utkarsh Small Finance Bank Ltd',
    range: '₹23 - ₹25',
    date: `12 JUL '23 - 14 JUl '23`,
    minQty: '600(1 Lots)',
    minAmount: '13,800',
    status: 'UPCOMING',
    issueSize: '500 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Senco Gold Ltd',
    range: '₹301 - ₹317',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Tridhya Gold Ltd',
    range: '₹35 - ₹42',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'AphaLogic Tecg Ltd',
    range: '₹96',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Pkh Ventures Ltd',
    range: '₹140 -148',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Global Pet Ltd',
    range: '₹265',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Pentagon Rubber Ltd',
    range: '₹70',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
];
const IPO = () => {
  const navigation = useNavigation();
  const renderIpoItem = ({item}) => {
    return <IPOComponent data={item} />;
  };
  return (
    <View>
      <View style={marketScreen.ipoHeadView}>
        <Text style={marketScreen.ipoHeadText}>IPO</Text>
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('IpoViewAll');
          }}>
          <Text style={marketScreen.ipoViewAllbtn}>View All</Text>
        </TouchableOpacity>
      </View>
      <View>
        <FlatList
          data={ipoData.slice(0, 4)}
          renderItem={renderIpoItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          contentContainerStyle={marketScreen.ipoFlatList}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
      <View style={marketScreen.ipoFooter}></View>
    </View>
  );
};
export default IPO;

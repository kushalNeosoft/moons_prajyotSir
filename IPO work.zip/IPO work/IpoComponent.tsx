import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
import {ipoComp} from '../../../theme/light';
import IpoModal from '../IpoViewAll/Component/IpoModal';

const IPOComponent = props => {
  const [modalVisible, setModalVisible] = useState(false);
  return (
    <TouchableOpacity
      style={ipoComp.container}
      onPress={() => {
        setModalVisible(true);
      }}>
      <View style={ipoComp.innerView}>
        <View style={ipoComp.titleAndImgView}>
          <View>
            <Image
              resizeMode="contain"
              // source={require('../../../assets/demo.jpeg')}
              style={ipoComp.imageView}
            />
          </View>
          <Text style={ipoComp.title}>{props.data.title}</Text>
        </View>
        <Text
          style={[
            ipoComp.subTitle,
            {
              backgroundColor:
                props.data.status === 'ONGOING'
                  ? root.color_positive
                  : props.data.status === 'UPCOMING'
                  ? '#FFB13B'
                  : root.color_subtext,
            },
          ]}>
          {props.data.status}
        </Text>
        <Text style={ipoComp.pricerRange}>{props.data.range}</Text>
        <Text style={ipoComp.issueDate}>Issue Date</Text>
        <Text style={ipoComp.date}>{props.data.date}</Text>
        <View style={ipoComp.minQtyAndAmmountView}>
          <View>
            <Text style={ipoComp.minQty}>Min. Qty</Text>
            <Text style={ipoComp.qty}>{props.data.minQty}</Text>
          </View>
          <View>
            <Text style={ipoComp.minAmount}>Min. Amount</Text>
            <Text style={ipoComp.amount}>₹{props.data.minAmount}</Text>
          </View>
        </View>
      </View>
      <IpoModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={props.data}
      />
    </TouchableOpacity>
  );
};
export default IPOComponent;

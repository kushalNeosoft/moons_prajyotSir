import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import {TextInput} from 'react-native';
import {ipoSearchModal} from '../../../../theme/light';
import IpoCard from './IpoCard';

const IpoSearchModal = ({modalVisible, setModalVisible, data}) => {
  const [filterData, setFilterData] = useState<any>(''); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter(item =>
        item.title.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
      console.log('f...', filterData);
    } else {
      setFilterData([]);
    }
  };
  const renderItem = ({item}) => {
    return <IpoCard data={item} />;
  };
  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={ipoSearchModal.modal}>
        <View style={ipoSearchModal.headerView}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(false);
              setTextInputValue('');
              setFilterData([]);
            }}>
            <AntIcon name="close" style={ipoSearchModal.crossIcon} />
          </TouchableOpacity>
          <TextInput
            style={ipoSearchModal.textInput}
            placeholder="Search Your IPO Name"
            placeholderTextColor={'#979797'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={ipoSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>

        <View>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={ipoSearchModal.noDataText}>No IPO's available</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={renderItem}
              style={{paddingHorizontal: 15}}
            />
          )}
        </View>
      </View>
    </Modal>
  );
};
export default IpoSearchModal;

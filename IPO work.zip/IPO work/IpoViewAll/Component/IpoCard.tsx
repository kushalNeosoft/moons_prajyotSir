import React, {useState} from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import {root} from '../../../../styles/colors';
import {ipoCard} from '../../../../theme/light';
import IpoModal from './IpoModal';

const IpoCard = ({data}) => {
  const [modalVisible, setModalVisible] = useState(false);
  return (
    <TouchableOpacity
      activeOpacity={1}
      style={ipoCard.mainView}
      onPress={() => {
        setModalVisible(true);
      }}>
      <View style={ipoCard.headerView}>
        <View style={ipoCard.imgAndTitleView}>
          <Image
            resizeMode="contain"
            // source={require('../../../assets/demo.jpeg')}
            style={ipoCard.imageView}
          />
          <Text style={ipoCard.title}>{data.title}</Text>
        </View>
        <Text style={ipoCard.priceRange}>{data.range}</Text>
      </View>
      <View style={ipoCard.dateStatusView}>
        <View style={ipoCard.rowCenter}>
          <Text style={ipoCard.detailsText}>Issue Date: </Text>
          <Text style={ipoCard.detailsTextData}> {data.date}</Text>
        </View>
        <Text
          style={[
            ipoCard.status,
            {
              backgroundColor:
                data.status === 'ONGOING'
                  ? root.color_positive
                  : data.status === 'UPCOMING'
                  ? '#FFB13B'
                  : root.color_text,
            },
          ]}>
          {data.status}
        </Text>
      </View>
      <View style={ipoCard.minQtyAndAmmountView}>
        <View style={ipoCard.rowCenter}>
          <Text style={ipoCard.detailsText}>Min Qty: </Text>
          <Text style={ipoCard.detailsTextData}> {data.minQty}</Text>
        </View>
        <View style={ipoCard.rowCenter}>
          <Text style={ipoCard.detailsText}>Min Amount:</Text>
          <Text style={ipoCard.detailsTextData}>₹{data.date}</Text>
        </View>
      </View>
      <IpoModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={data}
      />
    </TouchableOpacity>
  );
};
export default IpoCard;

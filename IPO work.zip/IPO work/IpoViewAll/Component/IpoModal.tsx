import React, {useState} from 'react';
import {FlatList, Image, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';
import {ipoModal} from '../../../../theme/light';

const IpoModal = ({modalVisible, setModalVisible, data}) => {
  return (
    <Modal
      style={ipoModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={ipoModal.mainView}>
        <TouchableOpacity
          onPress={() => {
            setModalVisible(false);
          }}>
          <AntDesign name="close" style={ipoModal.closeIcon} />
        </TouchableOpacity>
        <View style={ipoModal.headerView}>
          <View style={ipoModal.imgAndTitleView}>
            <Image
              resizeMode="contain"
              // source={require('../../../assets/demo.jpeg')}
              style={ipoModal.imageView}
            />
            <Text style={ipoModal.title}>{data.title}</Text>
          </View>

          <Text style={ipoModal.pricerRange}>{data.range}</Text>
        </View>
        <Text
          style={[
            ipoModal.status,
            {
              backgroundColor:
                data.status === 'ONGOING'
                  ? root.color_positive
                  : data.status === 'UPCOMING'
                  ? '#FFB13B'
                  : root.color_text,
            },
          ]}>
          {data.status}
        </Text>

        <View style={ipoModal.detailsView}>
          <View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Issue Date</Text>
              <Text style={ipoModal.detailsTextData}>{data.date}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Min Qty:</Text>
              <Text style={ipoModal.detailsTextData}>{data.minQty}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Issue Type</Text>
              <Text style={ipoModal.detailsTextData}>{data.issueType}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Bid Timings</Text>
              <Text style={ipoModal.detailsTextData}>{data.bidTimings}</Text>
            </View>
          </View>
          <View style={ipoModal.mLeft}>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Issue Size</Text>
              <Text style={ipoModal.detailsTextData}>₹{data.issueSize}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Face Value</Text>
              <Text style={ipoModal.detailsTextData}>₹{data.faceValue}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Listing</Text>
              <Text style={ipoModal.detailsTextData}>{data.listing}</Text>
            </View>
            <View style={ipoModal.mTop}>
              <Text style={ipoModal.detailsText}>Registrar Name</Text>
              <Text style={ipoModal.detailsTextData}>{data.RegistrarName}</Text>
            </View>
          </View>
        </View>
      </View>
      {data.status === 'ONGOING' ? (
        <TouchableOpacity style={ipoModal.botton} onPress={() => {}}>
          <Text style={ipoModal.bottonText}>Place Bid</Text>
        </TouchableOpacity>
      ) : (
        <></>
      )}
    </Modal>
  );
};
export default IpoModal;

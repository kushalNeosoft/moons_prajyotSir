import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Animated,
  Easing,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import {ipoViewAll} from '../../../theme/light';
import IpoCard from './Component/IpoCard';
import {ScrollView} from 'react-native-gesture-handler';
import IpoSearchModal from './Component/IpoSearchModal';
import AntDesign from 'react-native-vector-icons/AntDesign';

export const ipoData = [
  {
    title: 'Life Insurance Of India',
    range: '₹902 - ₹949',
    date: `01 OCT '22 - 01 OCT '25`,
    minQty: '15(1 Lots)',
    minAmount: '13,530',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Acceleratebs India Ltd',
    range: '₹90',
    date: `06 JUL '23 - 11 JUL '23`,
    minQty: '1600(1 Lots)',
    minAmount: '1,44,000',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'KaKa Industries Ltd',
    range: '₹55 - ₹58',
    date: `10 JUL '23 - 12 JUL '23`,
    minQty: '2000(1 Lots)',
    minAmount: '1,10,000',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Ahasolar Technologies Ltd',
    range: '₹157',
    date: `10 JUL '23 - 13 JUl '23`,
    minQty: '800(1 Lots)',
    minAmount: '1,25,600',
    status: 'ONGOING',
    issueSize: '5.69 Cr.',
    faceValue: '10 Per Share',
    issueType: 'Book Building',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Utkarsh Small Finance Bank Ltd',
    range: '₹23 - ₹25',
    date: `12 JUL '23 - 14 JUl '23`,
    minQty: '600(1 Lots)',
    minAmount: '13,800',
    status: 'UPCOMING',
    issueSize: '500 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Senco Gold Ltd',
    range: '₹301 - ₹317',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Tridhya Gold Ltd',
    range: '₹35 - ₹42',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'AphaLogic Tecg Ltd',
    range: '₹96',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Pkh Ventures Ltd',
    range: '₹140 -148',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Global Pet Ltd',
    range: '₹265',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
  {
    title: 'Pentagon Rubber Ltd',
    range: '₹70',
    date: `04 JUL '23 - 06 JUl '23`,
    minQty: '47(1 Lots)',
    minAmount: '14147',
    status: 'CLOSED',
    issueSize: '405 Cr.',
    faceValue: '10 Per Share',
    issueType: '(Book Built Portion)',
    listing: '',
    bidTimings: '-',
    RegistrarName: '-',
  },
];

const IpoViewAll = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [ongoingData, setOngoingData] = useState([]);
  const [closedData, setClosedData] = useState([]);
  const [viewMore, setViewMore] = useState(false);
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  const [show, setShow] = useState(false);

  const navigation = useNavigation();

  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      setShow(false);
    }
  }, [scrollValue]);

  const filterData = () => {
    let arr2 = [...ipoData];
    arr2 = arr2.filter((item, index) => {
      return item.status === 'ONGOING' || item.status === 'UPCOMING';
    });
    setOngoingData(arr2);

    let arr = [...ipoData];
    arr = arr.filter((item, index) => {
      return item.status === 'CLOSED';
    });
    setClosedData(arr);
  };

  useEffect(() => {
    filterData();
  }, []);

  const renderItem = ({item}) => {
    return <IpoCard data={item} />;
  };

  return (
    <View style={ipoViewAll.mainView}>
      {/* Header */}
      {scrollValue == 1 ? (
        <View style={ipoViewAll.headerView}>
          <View style={ipoViewAll.backIconHeaderView}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Ionicons name="arrow-back" style={ipoViewAll.headerBackIcon} />
            </TouchableOpacity>
            <Text style={ipoViewAll.headerText}>IPO</Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(true);
            }}>
            <Ionicons name="search-sharp" style={ipoViewAll.headerSearchIcon} />
          </TouchableOpacity>
        </View>
      ) : (
        <View style={ipoViewAll.longHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <Ionicons name="arrow-back" style={ipoViewAll.longHeaderBackIcon} />
          </TouchableOpacity>
          <View style={ipoViewAll.longHeaderTextView}>
            <Text style={ipoViewAll.longHeaderText}>IPO</Text>
            <TouchableOpacity
              onPress={() => {
                setModalVisible(true);
              }}>
              <Ionicons
                name="search-sharp"
                style={ipoViewAll.headerSearchIcon}
              />
            </TouchableOpacity>
          </View>
        </View>
      )}

      <ScrollView
        onScroll={evt => {
          if (evt?.nativeEvent?.contentOffset.y == 0) {
            setScrollValue(0);
          } else {
            if (evt?.nativeEvent?.contentOffset.y > 100) {
              setScrollValue(1);
            }
          }
        }}
        showsVerticalScrollIndicator={false}
        style={{paddingHorizontal: 15}}>
        <Text style={ipoViewAll.sectionText}>Ongoing IPO's</Text>
        <FlatList
          data={ongoingData}
          renderItem={renderItem}
          keyExtractor={(_, index) => `item-${index}`}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
        <Text style={ipoViewAll.sectionText}>Closed IPO's</Text>
        <FlatList
          data={viewMore ? closedData : closedData?.slice(0, 3)}
          renderItem={renderItem}
          keyExtractor={(_, index) => `item-${index}`}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
        <TouchableOpacity
          style={ipoViewAll.viewMoreView}
          onPress={() => {
            setViewMore(!viewMore);
          }}>
          <Text style={ipoViewAll.viewMoreText}>
            {viewMore ? 'View less' : 'View More'}
          </Text>
          <AntDesign
            name={viewMore ? 'caretup' : 'caretdown'}
            style={ipoViewAll.viewMoreIcon}
          />
        </TouchableOpacity>
      </ScrollView>
      <IpoSearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={ipoData}
      />
    </View>
  );
};
export default IpoViewAll;

import React, {useState} from 'react';
import {FlatList, ScrollView, Text, TouchableOpacity, View} from 'react-native';
import {
  Contactdata,
  contractdata,
  PartofIndices,
} from '../../../assets/demoData';

import {CompanyStyle, text} from '../../../theme/light';

const Contractinformation: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [selectedItem, setSelectedItem] = useState(0);

  const renderItem = ({item, index}: any) => (
    <TouchableOpacity onPress={() => setSelectedItem(index)}>
      {selectedItem === index ? (
        <>
          <View style={CompanyStyle.menuitem}>
            <Text style={CompanyStyle.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={CompanyStyle.menuitemtwo}>
            <Text style={CompanyStyle.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  return (
    <ScrollView
      style={CompanyStyle.maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      {contractdata.map(item => {
        return (
          <>
            <View style={[CompanyStyle.securitycon]}>
              <Text style={CompanyStyle.sectxtstyle}>{item.title}</Text>
            </View>

            {item.Data.map(item => {
              return (
                <View style={CompanyStyle.listone}>
                  <Text style={CompanyStyle.txtstyle}>{item.field}</Text>
                  <Text style={CompanyStyle.txtstyle}>{item.value}</Text>
                </View>
              );
            })}
          </>
        );
      })}
      <Text style={[text.text_12, text.text_color, text.text_famaly_regular]}>
        Part of Indices
      </Text>
      <View style={{flexDirection: 'row', flexWrap: 'wrap'}}>
        {PartofIndices.map(item => {
          return (
            <View style={CompanyStyle.partconatiner}>
              <Text style={CompanyStyle.txtstyleindes}>{item.title}</Text>
            </View>
          );
        })}
      </View>

      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Contact Information</Text>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Contactdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>
      <View style={{flex: 1}}>
        {Contactdata.map((events, i) => {
          if (selectedItem == i) {
            return (
              <FlatList
                scrollEnabled={false}
                showsHorizontalScrollIndicator={false}
                data={events.data}
                horizontal
                nestedScrollEnabled
                renderItem={({item}) => {
                  return (
                    <>
                      <View>
                        {item.RegName == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Register Name
                            </Text>
                            {item.RegName == '' ? (
                              <Text style={CompanyStyle.detaistxt}>-</Text>
                            ) : (
                              <Text style={CompanyStyle.detaistxt}>
                                {item.RegName}
                              </Text>
                            )}
                          </View>
                        )}
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Address</Text>
                          {item.addvalue == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.addvalue}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>
                            Telephone
                          </Text>
                          {item.telephone == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.telephone}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Fax</Text>
                          {item.fax == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.fax}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Email</Text>
                          {item.email == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.email}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Website</Text>
                          {item.website == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.website}
                            </Text>
                          )}
                        </View>
                        {item.author == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Author
                            </Text>
                            {item.author == '' ? (
                              <Text style={CompanyStyle.detaistxt}>-</Text>
                            ) : (
                              <Text style={CompanyStyle.detaistxt}>
                                {item.author}
                              </Text>
                            )}
                          </View>
                        )}
                      </View>
                    </>
                  );
                }}
              />
            );
          }
        })}
      </View>
    </ScrollView>
  );
};

export default Contractinformation;

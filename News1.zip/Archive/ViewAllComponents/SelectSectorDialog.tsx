import React, {useEffect, useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  Modal,
  TouchableNativeFeedback,
  ScrollView,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import CloseIcon from '../../../assets/CloseIcon';
import {TouchableHighlight} from '@gorhom/bottom-sheet';
import {TextInput} from 'react-native-gesture-handler';
import SearchIcon from '../../../assets/SearchIcon';
import {ExDialog, SelectSector, sectorDialog} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';

const SelectSectorDialog = ({
  visible,
  onClose,
  query,
  setQuery,
  sectors,
  onSectorSelected,
  selectedSector,
}: any) => {
  return (
    <Modal
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={SelectSector.main}
        onPress={() => onClose()}
        activeOpacity={1}></TouchableOpacity>

      <View style={SelectSector.MainView}>
        <View style={SelectSector.modal}>
          <Text style={SelectSector.Choose}>Choose Sectors</Text>
          <TouchableNativeFeedback
            onPress={() => {
              // props.onClose();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View style={ExDialog.closeMain}>
              <CloseIcon style={ExDialog.closeIcon} />
            </View>
          </TouchableNativeFeedback>
          <View style={sectorDialog.searchMain}>
            <SearchIcon style={sectorDialog.searchIcon} />
            <TextInput
              style={sectorDialog.textInput}
              placeholder="Search eg. AutoMobile"
              onChangeText={value => {
                setQuery(value);
              }}
              defaultValue={query}
            />
          </View>

          <FlatList
            style={{flex: 1}}
            data={sectors?.filter((item: any) =>
              item.SectorName.toUpperCase().includes(query.toUpperCase()),
            )}
            renderItem={({item}: any) => {
              return (
                <TouchableOpacity
                  key={item.SectorName}
                  onPress={() => {
                    console.log('Here');
                    // setQuery('');
                    onSectorSelected(item);
                  }}>
                  <View style={ExDialog.mainTxt}>
                    <View style={ExDialog.mainTxt2}>
                      {selectedSector.SectorName === item.SectorName && (
                        <View style={ExDialog.border} />
                      )}
                    </View>
                    <Text style={ExDialog.txt}>{item.SectorName}</Text>
                  </View>
                </TouchableOpacity>
              );
            }}
            keyExtractor={(_, index) => `item-${index}`}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          />
        </View>
      </View>
    </Modal>
  );
};
export default SelectSectorDialog;

import {useEffect, useState} from 'react';
import {FlatList, View} from 'react-native';
import {linkOne, marketScreen} from '../../../theme/light';
import NewsComponent from '../Component/NewsComponent';
import NewsListComponent from '../Component/NewsListComponent';
import React from 'react';
import HotPursuitDialog from './HotPursuitDialog';
import { ScrollView } from 'react-native-gesture-handler';

const HotPersuitComponent = () => {
  const [newsCard, setNewsCard] = useState([]);
  const [newsList, setNewsList] = useState([]);
  const [dialog, setDialog] = useState(false);
  const [HotModalVisible, setHotModalVisible] = useState(false);

  const HotModalToggle = () => {
    setDialog(prevState => !prevState);
  };


  const renderNewsItem = ({item}: any) => {
    return (
      <NewsComponent
        title={item?.Heading}
        subTitle={item.Caption}
        onPress={() => {
          setDialog(true);
        }}
      />
    );
  };

  const renderNewsListItem = ({item}: any) => {
    return (
      <NewsListComponent
        title={item.Heading}
        stockName={item.ScripData_NSE.Symbol}
        price={'123.20'}
        change={'-2.05 (-17%)'}
        time={item.Time}
        clickLeft={() => {
          setDialog(true);
        }}
      />
    );
  };

  const loadNewsCard = async () => {
    const headers = new Headers();
      headers.append('jTenantToken', '1');
      headers.append('jTenantid', '1404');
    fetch(
      'https://pre-prod1.odinwave.com/cds/1404/v1/NSE_EQ/2885/5/GetScripWiseNewsData',
      {
        method: 'GET',
        headers: headers,
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setNewsCard(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };

  const loadNewsList = async () => {
    const headers = new Headers();
      headers.append('jTenantToken', '1');
      headers.append('jTenantid', '1404');
    fetch('https://pre-prod1.odinwave.com/cds/1404/v1/10/GetHotPursuitData', {
      method: 'GET',
      headers: headers,
    })
      .then(response => {
        return response.json();
      })
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setNewsList(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadNewsCard();
    loadNewsList();
  }, []);
  return (
    <ScrollView>

    <View>
      <FlatList
        data={newsCard}
        renderItem={renderNewsItem}
        horizontal={true}
        keyExtractor={(_, index) => `item-${index}`}
        ListFooterComponent={() => {
          return (
            <View style={marketScreen.newAndAnnounceFlatListFooter}></View>
          );
        }}
        showsVerticalScrollIndicator={false}
        showsHorizontalScrollIndicator={false}
        style={marketScreen.newAndAnnounceFlatlist}
      />
      <View style={marketScreen.newAndAnnounceBottomListView}>
        <FlatList
          data={newsList?.slice(0, 4)}
          renderItem={renderNewsListItem}
          keyExtractor={(_, index) => `item-${index}`}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
      <HotPursuitDialog
        onClose={HotModalToggle}
        visible={dialog}
        
      />
    </View>
    </ScrollView>
  );
};

export default HotPersuitComponent;

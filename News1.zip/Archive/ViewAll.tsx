import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList, Alert} from 'react-native';
import {newsData, newsListData} from './MarketScreenComponent/SampleData';
import NewsListComponent from './Component/NewsListComponent';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
import {ViewAll1, linkOne, marketScreen} from './../../theme/light';
import BackIcon from '../../assets/BackIcon';
import {Cfont, root} from '../../styles/colors';
import HotPersuitComponent from './ViewAllComponents/HotPersuitComponent';
import NewsComponent from './ViewAllComponents/NewsComponent';
import AnnouncementComponent from './ViewAllComponents/AnnouncementComponent';
import AnnouncementSearchDialog from './ViewAllComponents/AnnouncementSearchDialog';

const ViewAll = (props: any) => {
  const [searchModal, setSearchModal] = useState(false);

  const navigation = useNavigation();
  const [categories, setCategories] = useState([
    'Hot Persuit',
    'News',
    'Announcements',
  ]);
  const [selectedCategory, setSelectedCategory] = useState('Hot Persuit');

  return (
    <View style={ViewAll1.flex}>
      <View style={marketScreen.newsAndAnnounceHeadView}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={ViewAll1.back} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => {
            // navigation.navigate('SearchMarketNewsScreen');
            setSearchModal(true);
          }}>
          <MaterialIcons
            name="search"
            size={24}
            color={'black'}
            style={marketScreen.newAndAnnounceSearchBtn}
          />
        </TouchableOpacity>
      </View>

      <View>
        <FlatList
          style={ViewAll1.FlatMain}
          horizontal={true}
          data={categories}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <TouchableOpacity
                key={item}
                onPress={() => {
                  setSelectedCategory(item.item);
                }}>
                <View
                  style={[
                    ViewAll1.main1,
                   { backgroundColor:
                      selectedCategory == item.item
                        ? root.client_background
                        : 'transparent',}
                  ]}>
                  <Text
                    style={{
                      color:
                        selectedCategory == item.item
                          ? 'white'
                          : root.color_text,
                      fontFamily: Cfont.rubik_regular,
                    }}>
                    {item.item}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      </View>
      {selectedCategory === 'Hot Persuit' && <HotPersuitComponent />}
      {selectedCategory === 'News' && <NewsComponent />}
      {selectedCategory === 'Announcements' && <AnnouncementComponent />}

      <AnnouncementSearchDialog
        visible={searchModal}
        onClose={() => {
          setSearchModal(false);
        }}
        category={selectedCategory}
      />
    </View>
  );
};
export default ViewAll;

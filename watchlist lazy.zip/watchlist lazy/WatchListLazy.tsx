import React, {useEffect, useState, useCallback, useRef, useMemo} from 'react';
import {
  Alert,
  BackHandler,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  Image,
  Pressable,
  ScrollView,
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Dimensions,
  Modal,
} from 'react-native';

import DotModal from './ThreeDotDrawer/ThreeDotDrawer';
import Header from '../../../components/IndicesHeader/IndicesHeader';
import NorModal from './WatchlistDrawer/WatchlistDrawer';
import TrendModal from './TrendDrawer/TrendDrawer';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import DeleteModal from '../../../components/DeleteModal/DeleteModal';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import Fontisto from 'react-native-vector-icons/Fontisto';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {demoData} from '../../../components/replacement-svg/demoData';
import BottomSheet, {BottomSheetBackdrop} from '@gorhom/bottom-sheet';
import {
  CommonActions,
  useFocusEffect,
  useNavigation,
} from '@react-navigation/native';
import CarouselList from './CarouselList/CarouselList';
import {ListItemProps} from './CarouselList/type';
import RNExitApp from 'react-native-exit-app';
import {texts} from './CommonText/text';
import {Cfont, Font} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useDispatch, useSelector} from 'react-redux';
import {
  bottomTabshowhide,
  constituentsFilter,
  filterOrders,
  resetIndicesViewAllFilter,
} from '../../../redux/Action';
import CustomHeader from '../../../components/IndicesHeader/CustomHeader';
import Filtercom from './filtercom/Filtercom';
import {
  CloseModal,
  localScreen,
  screenFilter,
  SortModal,
} from '../../../theme/light';
import StockListView from '../../../components/StockListView/StockListView';
import SortFilterBottomSheet from '../../../components/BottomSheet/SortFilterBottomSheet';
import Renamemodal from './Renamemodal/Renamemodal';
import Done from '../Scrips/Removescrip/Done';
import ConstituentsFilter from '../../Indices/Constituents/components/Filter/Filter';
import ScreenFilter from '../../Market/IndicesViewAll/Component/ScreenFilter';
const screenHeight = Dimensions.get('window').height;
import NortabsStyle from '../../../styles/Views/NortabsStyel';
import WatchlistdataStyle from '../../../styles/Views/WatchlitsdataStyle';
import Theme from '../../../theme/Theme';
const StockLazy = () => {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const {nortabstyles} = NortabsStyle();
  const {watchlistdata} = WatchlistdataStyle();
  const {root} = Theme();
  const [selectedFilter, setSelectedFilter] = useState(1);
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState<ListItemProps[]>([]);
  const [norModalVisible, setNorModalVisible] = useState(false);
  const [trendModalVisible, setTrendModalVisible] = useState(false);
  const [dotModalVisible, setDotModalVisible] = useState(false);
  const [renamemodal, setRenamemodal] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [colorChange, setColorChange] = useState(false);
  const [carouselView, setCarouselView] = useState(false);
  const [visibleBottom, setvisibleBottom] = useState(false);
  const [visiblno, setvisibleno] = useState<number>(-1);
  const navigation = useNavigation();
  const listRef = useRef(0);
  const dispatch = useDispatch();
  const toggleRef = useRef(true);
  const bottomSheetRef = useRef<BottomSheet>(null);
  const [isvisible, setIsvisible] = useState(true);
  const [isstickdisable, setIsstickdisable] = useState(true);
  const [newdone, setNewdone] = useState(false);
  const [rename, setRename] = useState(texts.NOR);
  const [filteredArr, setfilteredArr] = useState<any>();
  const [filteredArrdemo, setfilteredArrdemo] = useState<any>();

  const filter = useSelector(state => state?.Reducer?.constituentsFilter);
  const [combo, setCombo] = useState([]);

  const [alpha, setAlpha] = useState('');
  const [type, setType] = useState('');

  const scrollRef = useRef();

  const onFabPress = () => {
    scrollRef.current?.scrollTo({
      y: 0,
      animated: true,
    });
  };

  const setAlphafilter = (value: string) => {
    setAlpha(value);
  };

  const setTypefilter = (value: string) => {
    setType(value);
  };

  const alphabetNewFilter = (data: any) => {
    if (alpha === 'A-Z') {
      return [...data].sort((a, b) =>
        a.companyName.localeCompare(b.companyName),
      );
    } else {
      return [...data].sort((a, b) =>
        b.companyName.localeCompare(a.companyName),
      );
    }
  };
  // console.log("datafilter======>>>>>>",filteredArr[0].companyName);

  const pressDelete = (i: any) => {
    console.log('new log===>>>');
    const del = [...combo];
    del.splice(i, 1);
    setCombo(del);
  };

  const min = 1;
  const max = 6;

  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  const pressalert = () => {
    Alert.alert('Work in Progress');
  };
  React.useEffect(() => {
    if (newdone == true) {
      dispatch(bottomTabshowhide(false));
      setTimeout(() => {
        setNewdone(false);
        dispatch(bottomTabshowhide(true));
      }, 2000);
    }
  }, [newdone]);
  useEffect(() => {
    pushStockData();
    dispatch(
      filterOrders({
        alphabet: '',
        order: '',
        minAmount: '',
        maxAmount: '',
        orderStats: '',
      }),
    );
    // dispatch(constituentsFilter({SortBy: '', Type: ''}));
  }, []);

  var randomStock = [
    'BRITANIA',
    'AXISBANK',
    'TCS',
    'ULTRACEMCO',
    'BPCL',
    'DIVISLAB',
    'MARUTI',
    'LT',
  ];
  var randomPrice = ['295.03', '443.05', '220.54', '577.94', '000.00'];
  var gainerLoser = ['Vol.Gainer', 'Pr.Loser', ''];
  var showIcon = [true, false];
  var nindex = ['NSE', 'BSE'];

  var iconName = ['crown-circle', 'pie-chart-2'];
  var colors = ['#FF0000', '#D60707', '#4CAF50', '#B70404'];
  var date = [
    {day: '25 MAY', value: 'FUT', strickprice: '', optiontype: ''},
    {day: '25 MAY', value: '', strickprice: '3200.00', optiontype: 'CE'},
  ];
  var future = [true, false];
  // var eqity=[true,false]

  const pushStockData = () => {
    let StockArraydata = [];
    for (let i = 0; i < 6; i++) {
      StockArraydata.push({
        companyName:
          randomStock[Math.floor(Math.random() * randomStock.length)],
        title: gainerLoser[Math.floor(Math.random() * gainerLoser.length)],

        value: randomPrice[Math.floor(Math.random() * randomPrice.length)],
        changes: '+3.65(+0.44%)',
        showIcon: showIcon[Math.floor(Math.random() * showIcon.length)],
        iconName: iconName[Math.floor(Math.random() * iconName.length)],
        colors: colors[Math.floor(Math.random() * colors.length)],
        future: future[Math.floor(Math.random() * future.length)],
        date: date[Math.floor(Math.random() * date.length)],
        nindex: nindex[Math.floor(Math.random() * nindex.length)],

        // eqity: eqity[Math.floor(Math.random() * eqity.length)],
      });
    }
    setStockData(StockArraydata);
    setfilteredArr(StockArraydata);
  };

  useEffect(() => {
    let result = stockData;
    if (alpha !== '') {
      result = alphabetNewFilter(result);
    }
    setfilteredArr(result);
  }, [alpha, type]);
  useFocusEffect(
    React.useCallback(() => {
      BackHandler.addEventListener('hardwareBackPress', handleBackButton);

      return () => {
        BackHandler.removeEventListener('hardwareBackPress', handleBackButton);
      };
    }, []),
  );

  // for sorting data.

  useEffect(() => {
    pushStockData();
    // console.log(searchModal, 'status');
    return () => {
      dispatch(constituentsFilter({SortBy: '', Type: ''}));
    };
  }, []);

  function applyFilter() {
    const arr = [...filteredArr];
    if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'Z-A') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.companyName.toUpperCase();
        const titleB = b.companyName.toUpperCase();
        if (titleA > titleB) {
          return -1;
        }
        if (titleA < titleB) {
          return 1;
        }
        return 0;
      });

      // newData.filter(a => a.nindex == 'NSE');

      if (combo.length > 0) {
        const newOnedata = arr?.filter(a => a.nindex == 'BSE');
        setfilteredArrdemo(newOnedata);
        console.log(
          'new array formed===========>',
          arr?.filter(a => a.nindex == 'BSE'),
        );
      }

      setfilteredArr(newData);
    } else if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'A-Z') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.companyName.toUpperCase();
        const titleB = b.companyName.toUpperCase();
        if (titleA < titleB) {
          return -1;
        }
        if (titleA > titleB) {
          return 1;
        }
        return 0;
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'High to Low') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA > priceB) {
          return -1;
        } else if (priceA < priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'Low to High') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA < priceB) {
          return -1;
        } else if (priceA > priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'Low to High'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA < percentB) {
          return -1;
        } else if (percentA > percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'High to Low'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA > percentB) {
          return -1;
        } else if (percentA < percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    }
  }
  useEffect(() => {
    if (filter.Type !== '' && filter.SortyBy !== '') {
      applyFilter();
    }
  }, [filter?.Type, filter?.SortBy]);

  const cinfirmCLode = () => {
    RNExitApp.exitApp();
    setModalVisible(!modalVisible);
  };

  const handleBackButton = () => {
    setModalVisible(true);
    return true; // Returning true prevents the app from closing
  };

  const onPress = () => {
    // if(bottomSheetRef){
    bottomSheetRef.current?.snapToIndex(0);
    //  }

    dispatch(bottomTabshowhide(false));
    //  ref?.current?.scrollTo(-500);
  };

  const componentHeaderBlock = () => {
    return (
      <View style={nortabstyles.headerComponentView}>
        <TouchableOpacity
          onPress={() => setNorModalVisible(true)}
          style={nortabstyles.norflex}>
          <Text style={nortabstyles.Nortxt}>{rename}</Text>
          <View style={nortabstyles.downicon}>
            <Ionicons
              name="ios-caret-down-sharp"
              size={15}
              color={root.color_text}
            />
          </View>
        </TouchableOpacity>
        <View style={nortabstyles.headerFlexEndView}>
          <TouchableOpacity onPress={() => setTrendModalVisible(true)}>
            <MaterialIcons name="offline-bolt" color={'orange'} size={25} />
            <Text style={nortabstyles.lenght}>6</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              borderWidth: 1,
              borderRadius: 20,
              borderColor: root.color_text,
            }}
            onPress={pressalert}>
            <Text style={nortabstyles.addText}>{texts.ADD}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onPress}>
            <FontAwesome5
              name="sliders-h"
              color={root.color_text_icon}
              size={20}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setDotModalVisible(true)}>
            <Entypo
              name="dots-three-vertical"
              color={root.color_text_icon}
              size={20}
            />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const onPressItem = (index: any) => {
    listRef.current = index;
    dispatch(bottomTabshowhide(false));
    setCarouselView(true);
  };

  const renderItembox = ({item, index}: any) => {
    return (
      <StockListView
        companyName={item.companyName}
        nindex={item.nindex}
        price={item.value}
        changes={item.changes}
        colors={item.colors}
        // addToScripts={addToScripts}
      />
    );
  };

  const renderListView = useCallback(
    ({item, index}: any) => (
      <TouchableOpacity onPress={() => onPressItem(index)}>
        <StockListView
          stockName={item.companyName}
          stockTtile={item.title}
          price={item.value}
          changes={item.changes}
          nindex={item.nindex}
          title={item.title}
          showIcon={item.showIcon}
          iconName={item.iconName}
          future={item.future}
          date={item.date}
          // eqity={item.eqity}
          screenName="WatchList"
        />
      </TouchableOpacity>
    ),
    [],
  );
  const onNorClose = () => {
    setNorModalVisible(prevState => !prevState);
  };

  const onTrendClose = () => {
    setTrendModalVisible(prevState => !prevState);
  };

  const onDotModalClose = () => {
    setDotModalVisible(prevState => !prevState);
  };

  const onRenameClose = () => {
    setRenamemodal(prevState => !prevState);
  };

  const onDeleteClose = () => {
    setDeleteModal(prevState => !prevState);
  };

  const showDeleteModal = () => {
    setDeleteModal(prevState => !prevState);
  };

  const onCloseCarousel = () => {
    setCarouselView(false);
    dispatch(bottomTabshowhide(true));
  };

  const snapPoints = useMemo(() => ['50%', '100%'], []);

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', index);
    if (index === 1) {
      navigation.navigate('Btos');
      setTimeout(() => {
        bottomSheetRef.current?.close();
      }, 2000);
    } else if (index === -1) {
      dispatch(bottomTabshowhide(true));
    }
  }, []);

  // const renderBackdrop = useCallback(
  //   (props: any) => (
  //     <BottomSheetBackdrop
  //       {...props}
  //       disappearsOnIndex={-1}
  //       appearsOnIndex={0}
  //     />
  //   ),
  //   [],
  // );

  //GestureHandlerRootView Root was this dont know why
  return (
    <View style={watchlistdata.flexallign}>
      <Header />
      {componentHeaderBlock()}
      <View style={watchlistdata.flatallign}>
        {filter?.Type !== '' || filter?.SortBy !== '' || combo.length > 0 ? (
          <View
            style={watchlistdata.secondinner}
          >
            <Text style={watchlistdata.fittrtxt}>Filters :</Text>
            <ScrollView
              ref={scrollRef}
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{marginRight: 10}}>
              <View style={{flexDirection: 'row'}}>
                {filter?.Type !== '' || filter?.SortBy !== '' ? (
                  <>
                    <View style={screenFilter.filterDataViewtwo}>
                      <Text style={screenFilter.filterTag}>{filter?.Type}</Text>
                      <Text style={screenFilter.filterTagData}>
                        {filter?.SortBy}
                      </Text>
                      <TouchableOpacity
                        onPress={() => {
                          dispatch(resetIndicesViewAllFilter());
                          dispatch(constituentsFilter({SortBy: '', Type: ''}));
                          onFabPress;
                        }}>
                        <Ionicons
                          name="md-close-outline"
                          style={screenFilter.closeIcon}
                        />
                      </TouchableOpacity>
                    </View>
                  </>
                ) : (
                  <></>
                )}

                {combo.length > 0 ? (
                  <>
                    <View style={{flexDirection: 'row'}}>
                      {combo.map((person, i) => {
                        return (
                          <View style={screenFilter.filterDataViewtwo}>
                            <Text style={screenFilter.filterTag}>{person}</Text>
                            <TouchableOpacity
                              onPress={() => {
                                pressDelete(i);
                                onFabPress;
                              }}>
                              <Ionicons
                                name="md-close-outline"
                                style={screenFilter.closeIcon}
                              />
                              {/* <Text style={{marginHorizontal:10,}}>X</Text> */}
                            </TouchableOpacity>
                          </View>
                        );
                      })}
                    </View>
                  </>
                ) : (
                  <></>
                )}
              </View>
            </ScrollView>
          </View>
        ) : (
          <></>
        )}

        {/* <FlatList data={stockData} renderItem={renderListView} /> */}
        <FlatList
           key={selectedFilter}
          // numColumns={selectedFilter}
          data={filteredArr}
          renderItem={selectedFilter == 1 ? renderListView : renderItembox}
          keyExtractor={(_, index) => `item-${index}`}
          // keyExtractor={(_, index) => `item-${index}`}
          style={{backgroundColor: root.color_active}}
        />
        <TouchableOpacity
          onPress={() => {
            console.log('here');

            navigation.navigate('OrderCart');
          }}>
          <View
            style={{
              flexDirection: 'row',
              padding: 20,
              paddingBottom: 80
            }}>
            <View style={{flex: 2}}>
              <Text
                style={{fontSize: 18, color:root.client_background, 
                  fontFamily: Cfont.rubik_medium}}>
                Buy all these scrips in one go
              </Text>
              <View>
                <View
                  style={{
                    backgroundColor: root.client_background,
                    alignSelf: 'flex-start',
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 16,
                    marginTop: 16,
                  }}>
                  <Text
                    style={{fontSize: 12, color: 'white', fontFamily: Cfont.rubik_medium}}>
                    Convert To Order Card
                  </Text>
                </View>
              </View>
            </View>
            <View style={{flex: 1}}>
              <Image
                source={require('../../../assets/Broker.png')}
                style={{width: '100%', height: 80}}
              />
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {carouselView ? (
        <CarouselList
          listData={stockData}
          index={listRef.current}
          onCloseCarousel={onCloseCarousel}
          carouselView={carouselView}
        />
      ) : null}

      <NorModal
        visible={norModalVisible}
        onClose={onNorClose}
        isvisible={isvisible}
        showDeleteModal={showDeleteModal}
      />
      <TrendModal visible={trendModalVisible} onClose={onTrendClose} />
      <DotModal
        visible={dotModalVisible}
        onClose={onDotModalClose}
        stockDataList={stockData}
        onopenbottomsheet={onPress}
        watchListname={rename}
        callfun={(e: any) => {
          setRenamemodal(e);
        }}
        newDoneappear={(e: any) => {
          setNewdone(e);
        }}

      />
      <Renamemodal
        visible={renamemodal}
        onClose={onRenameClose}
        changerename={rename}
        renamefun={(e: any) => {
          setRename(e);
        }}
      />

      <SortFilterBottomSheet
        ref={bottomSheetRef}
        closesheet={closeSheet}
        index={-1}>
        <Filtercom
          bottomSheetRef={bottomSheetRef}
          closesheet={closeSheet}
          setAlpha={setAlphafilter}
          setType={setTypefilter}
          newData={(e: any) => {
            setCombo(e);
          }}
          combo={combo}
        />
      </SortFilterBottomSheet>
      <DeleteModal visible={deleteModal} onClose={onDeleteClose} />
      <Modal
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
        transparent={true}>
        <TouchableOpacity
          style={CloseModal.centeredView}
          onPress={() => setModalVisible(false)}
          activeOpacity={1}>
          <View style={CloseModal.modalView}>
            <View style={CloseModal.innermain}>
              <Text style={CloseModal.Wavetitle}>Wave 2</Text>
              <AntDesign name="exclamationcircle" size={40} color="grey" />
            </View>
            <View style={CloseModal.leftallign}>
              <Text style={CloseModal.modalText}>
                Do you want to exit the app?
              </Text>

              <View
                style={{flexDirection: 'row', justifyContent: 'space-around'}}>
                <Pressable style={[CloseModal.button]} onPress={cinfirmCLode}>
                  <Text style={CloseModal.textStyle}>Confirm</Text>
                </Pressable>
                <Pressable
                  style={[CloseModal.buttontwo]}
                  onPress={() => setModalVisible(!modalVisible)}>
                  <Text style={CloseModal.textStyletwo}>Cancle</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
      {newdone == true ? <Done /> : null}
    </View>
  );
};

export default React.memo(StockLazy);

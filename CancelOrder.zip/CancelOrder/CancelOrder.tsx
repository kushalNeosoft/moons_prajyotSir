import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList, StyleSheet} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import CancelList from './components/CancelList';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import CancelOrderModal from './components/CancelModal';
import {Cfont, Font, root} from '../../../styles/colors';

const CancelOrder = () => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [visibleModal, setVisibleModal] = useState(false);
  const overallData = [
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 0,
      excute: '5/5',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 1,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 2,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 3,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 4,
    },
  ];
  const navigation = useNavigation();

  const onItemPress = (pressedItem: any) => {
    let arr = [...selectedItems];

    let idx = arr.findIndex((itm, index) => itm.id == pressedItem.id);

    if (idx == -1) {
      arr.push(pressedItem);
    } else {
      arr.splice(idx, 1);
    }

    setSelectedItems([...arr]);
  };

  const renderItem = ({item}: any) => {
    return (
      <CancelList
        onPress={onItemPress}
        stockName={item.companyName}
        buy={item.buy}
        item={item}
        selectedItems={selectedItems}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };
  const onSelectAllPress = () => {
    if (selectedItems.length === overallData.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems([...overallData]);
    }
  };
  return (
    <View style={cancelOrder.container}>
      <View style={cancelOrder.subContainer}>
        <View style={cancelOrder.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="arrowleft" style={cancelOrder.backIcon} />
          </TouchableOpacity>
          <Text style={cancelOrder.cancelOrderText}>Cancel Orders</Text>
        </View>
        <View style={cancelOrder.orderHeadView}>
          <Text style={cancelOrder.orderText}>Orders(8)</Text>
          <TouchableOpacity
            onPress={onSelectAllPress}
            style={cancelOrder.selectAllTextIconView}>
            {selectedItems.length > 0 ? (
              <Text style={cancelOrder.selectAllText}>
                Selected ({selectedItems.length})
              </Text>
            ) : (
              <Text style={cancelOrder.selectAllText}>Select All</Text>
            )}
            {selectedItems.length === 0 ? (
              <MaterialIcons
                name="check-box-outline-blank"
                style={cancelOrder.selectAllIcon}
              />
            ) : selectedItems.length === overallData.length ? (
              <AntDesign name="checksquare" style={cancelOrder.selectAllIcon} />
            ) : (
              <AntDesign name="minussquare" style={cancelOrder.selectAllIcon} />
            )}
          </TouchableOpacity>
        </View>
        <View style={cancelOrder.headerBorder}></View>
        {/* FlateList code */}
        <FlatList
          data={overallData}
          renderItem={renderItem}
          contentContainerStyle={{
            marginTop: 13,
            paddingBottom: 70,
          }}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View style={cancelOrder.bottomView}>
        <View style={cancelOrder.bottominnerView}>
          <View>
            <Text style={cancelOrder.bottomcancelOrderText}>Cancel</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={cancelOrder.bottomSelectedText}>Selected Orders</Text>
              {selectedItems.length > 0 ? (
                <View style={cancelOrder.bottomCountView}>
                  <Text style={cancelOrder.bottomCountText}>
                    {selectedItems.length}
                  </Text>
                </View>
              ) : (
                <></>
              )}
            </View>
          </View>
          <TouchableOpacity
            style={cancelOrder.bottomDoneBtn}
            onPress={() => {
              setVisibleModal(true);
            }}>
            <Text
              style={[
                cancelOrder.bottomDoneText,
                {
                  color:
                    selectedItems.length > 0
                      ? root.color_textual
                      : root.color_subtext,
                },
              ]}>
              Done
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <CancelOrderModal
        visible={visibleModal}
        onClose={() => setVisibleModal(prev => !prev)}
        selectedItems={selectedItems}
      />
    </View>
  );
};

const cancelOrder = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
    width: '100%',
  },
  subContainer: {
    // paddingHorizontal: 18,
    flex: 1,
    width: '100%',
  },
  squareHeaderView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    paddingHorizontal: 16,
  },
  backIcon: {
    color: root.color_text,
    fontSize: 23,
  },
  cancelOrderText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    marginLeft: 15,
  },
  orderHeadView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  orderText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  selectAllTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectAllText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_five,
  },
  selectAllIcon: {
    color: root.color_text,
    fontSize: 24,
    marginLeft: 10,
  },
  headerBorder: {
    color: root.color_subtext,
    borderWidth: 0.2,
    opacity: 0.1,
    marginTop: 15,
    marginHorizontal: 16,
  },
  bottomView: {
    backgroundColor: root.color_textual,
    height: 71,
    width: '100%',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  bottominnerView: {
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomcancelOrderText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active,
  },
  bottomSelectedText: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    marginTop: 3,
  },
  bottomDoneBtn: {
    backgroundColor:root.color_active,
    borderRadius: 8,
    height: 43,
    width: 81,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomDoneText: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
  },
  bottomCountView: {
    backgroundColor: root.color_negative,
    height: 16,
    width: 20,
    borderRadius: 25,
    marginLeft: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 3,
  },
  bottomCountText: {
    color: root.color_active,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
});

export default CancelOrder;

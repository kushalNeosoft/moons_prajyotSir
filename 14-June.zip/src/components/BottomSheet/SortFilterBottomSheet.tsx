import React, {useCallback, useMemo, useState} from 'react';
import BottomSheet, {
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Text,
  View,
} from 'react-native';
import Header from './Header';
import {Cfont, Font, root} from '../../styles/colors';
import {useDispatch, useSelector} from 'react-redux';
import alignment from '../utils/alignment';
import {bottomTabshowhide} from '../../redux/Action';
import CustomHeader from '../IndicesHeader/CustomHeader';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {SortModal} from '../../theme/light';

const screenheight = Dimensions.get('window').height;

const SortFilterBottomSheet = React.forwardRef((props: any, ref) => {
 

  const snapPoints = useMemo(() => ['65%', '100%'], []);

  const [reachedTop, setReachedTop] = useState(false);
  const dispatch = useDispatch();

  const handleSheetChanges = useCallback((index: number) => {
    switch (index) {
      case 0:
        dispatch(bottomTabshowhide(false));
        break;
      case 1:
        setReachedTop(true);
        dispatch(bottomTabshowhide(false));
        break;
      default:
        setReachedTop(false);
        dispatch(bottomTabshowhide(true));
    }
  }, []);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
      />
    ),
    [],
  );

  //   const closeSheet = () => {
  //     props.closeSheet();
  //   };

  return (
    <BottomSheet
      {...props}
      backgroundComponent={null}
      handleIndicatorStyle={{display: reachedTop ? 'none' : 'flex'}}
      style={styles(reachedTop).container}
      snapPoints={snapPoints}
      onChange={handleSheetChanges}
      backdropComponent={renderBackdrop}
      enableHandlePanningGesture={reachedTop ? false : true}
      enableContentPanningGesture={reachedTop ? false : true}
      ref={ref}
      index={props.index}>
      <BottomSheetScrollView
        // contentContainerStyle={{paddingHorizontal: 10}}
        stickyHeaderIndices={[0]}
        scrollEnabled={false}
        stickyHeaderHiddenOnScroll={false}>
        {reachedTop ? (
          <CustomHeader
            title="Sort & Filter"
            leftComponent={
              <TouchableOpacity onPress={() => props.closesheet()}>
                <Ionicons name="arrow-back" size={25} color={'black'} />
              </TouchableOpacity>
            }
            rightComponent={
              <TouchableOpacity>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                    fontSize: Font.font_normal_two,
                    alignSelf: 'center',
                  }}>
                  Clear
                </Text>
              </TouchableOpacity>
            }
          />
        ) : (
          <View>
            <Text style={SortModal.Sorttitle}>Sort & Filter</Text>
          </View>
        )}
        {props.children}
      </BottomSheetScrollView>
    </BottomSheet>
  );
});

const styles = (reachedTop?: boolean) =>
  StyleSheet.create({
    container: {
      backgroundColor: 'white',
      borderTopRightRadius: reachedTop ? 0 : 20,
      borderTopLeftRadius: reachedTop ? 0 : 20,
      zIndex: 1,
    },
  });

export default SortFilterBottomSheet;

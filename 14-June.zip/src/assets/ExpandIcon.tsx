import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const ExpandIcon = (props: any) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 96 960 960"
    fill={'currentColor'}
    {...props}>
    <Path d="M480 699q-6 0-11-2t-10-7L261 492q-8-8-7.5-21.5T262 449q10-10 21.5-8.5T304 450l176 176 176-176q8-8 21.5-9t21.5 9q10 8 8.5 21t-9.5 22L501 690q-5 5-10 7t-11 2Z" />
  </Svg>
);
export default ExpandIcon;

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {recentTransactions} from '../../../theme/light';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import FilterModal from './components/FilterModal/FilterModal';
import CalendarModal from './components/CalendarModal/CalendarModal';

const RecentTransactions = () => {
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [calendarModalVisible, setCalendarModalVisible] = useState(false);
  const navigation = useNavigation();

  const onClose = () => {
    setFilterModalVisible(prevState => !prevState);
  };

  const transactions = [
    {
      title: 'Withdrawal',
      account: 'NSE EQUITIES',
      bank: 'HDFC',
      date: "08 Jun'23",
      time: '05:27 PM',
      amount: '- ₹ 1.00',
      status: 'Pending',
    },
  ];

  const calendarModalToggle = () => {
    setCalendarModalVisible(prevState => !prevState);
  };

  const onCalendarModalClose = () => {
    setCalendarModalVisible(prevState => !prevState);
    setFilterModalVisible(prevState=>!prevState)
  };

  const renderTransactions = ({item}) => {
    return (
      <View style={recentTransactions.transactionCard}>
        <View>
          <View style={recentTransactions.cardTitleContainer}>
            <Text style={recentTransactions.cardTitleTxt}>{item.title}</Text>
            <Text
              style={
                recentTransactions.accountTxt
              }>{` from ${item.account}`}</Text>
          </View>
          <View style={recentTransactions.cardTitleContainer}>
            <Text style={recentTransactions.bankTxt}>{item.bank}</Text>
            <Text
              style={
                recentTransactions.dateTime
              }>{` ${item.date} ${item.time}`}</Text>
          </View>
        </View>
        <View>
          <Text style={recentTransactions.amount}>{item.amount}</Text>
          <Text style={recentTransactions.status}>{item.status}</Text>
        </View>
      </View>
    );
  };

  return (
    <View style={recentTransactions.container}>
      <View style={recentTransactions.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={recentTransactions.titleContainer}>
          <Ionicons name="arrow-back" size={24} color={'black'} />
          <Text style={recentTransactions.titleTxt}>Transactions</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setFilterModalVisible(prevState => !prevState)}>
          <FontAwesome5 name="sliders-h" color={'black'} size={20} />
        </TouchableOpacity>
      </View>
      <FlatList data={transactions} renderItem={renderTransactions} />
      <FilterModal
        visible={filterModalVisible}
        onClose={onClose}
        calendarModalToggle={calendarModalToggle}
      />
      <CalendarModal
        visible={calendarModalVisible}
        onClose={onCalendarModalClose}
      />
    </View>
  );
};

export default RecentTransactions;

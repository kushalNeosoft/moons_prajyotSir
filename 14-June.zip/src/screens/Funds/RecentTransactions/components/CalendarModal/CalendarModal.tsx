import React, {useRef, useState} from 'react';
import {View, Text, Modal, StyleSheet, TouchableOpacity} from 'react-native';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import CalendarComponent from '../../../AvailableFunds/components/Calendar/Calendar';
import alignment from '../../../../../components/utils/alignment';

const CalendarModal = (props: any) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedFromDate, setSelectedFromDate] = useState<Date | string>('');
  const [selectedToDate, setSelectedToDate] = useState<Date | string>('');
  const calendarRef = useRef(null);
  const [selectionType, setSelectionType] = useState<string>('From');

  const convertDateFunction = (value: any) => {
    const date = new Date(value);
    const options = {day: 'numeric', month: 'short', year: '2-digit'};
    const formattedDate = date.toLocaleDateString('en-US', options);
    const parts = formattedDate.split(' ');
    const month = parts[0];
    const selectDate = parts[1].slice(0, -1).padStart(2, '0');
    const year = parts[2];
    const finalFormattedDate = ` ${selectDate}${month}'${year}`;
    return finalFormattedDate;
  };

  const selection = [
    {
      type: 'From',
      format:
        selectedFromDate === ''
          ? 'DD MM YY'
          : convertDateFunction(selectedFromDate),
    },
    {
      type: 'To',
      format:
        selectedToDate === ''
          ? 'DD MM YY'
          : convertDateFunction(selectedToDate),
    },
  ];

  const selectingFromDate = (value: any) => {
    setSelectedFromDate(value);
  };

  const selectingToDate = (value: any) => {
    setSelectedToDate(value);
  };

  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={false}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={()=>props.onClose()}>
            <AntDesign name="arrowleft" size={24} color={root.color_text} />
          </TouchableOpacity>
          <Text style={styles.titleTxt}>Custom Date</Text>
        </View>
        <View style={styles.selectionView}>
          {selection.map(item => (
            <TouchableOpacity
              onPress={() => setSelectionType(item.type)}
              style={
                selectionType === item.type
                  ? styles.cardSelected
                  : styles.cardUnselcted
              }>
              <View style={styles.selectionContainer}>
                <Text style={styles.type}>{item.type}</Text>
                <Text style={styles.format}>{item.format}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
        {selectionType === 'From' ? (
          <CalendarComponent
            selectingDate={selectingFromDate}
            selectedDate={selectedFromDate}
          />
        ) : (
          <CalendarComponent
            selectingDate={selectingToDate}
            selectedDate={selectedToDate}
          />
        )}
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    backgroundColor: root.color_active,
  },
  dayText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    maxWidth: 24,
  },
  selectedDayText: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_active,
    maxWidth: 24,
  },
  dayLabelContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 32,
  },
  selectionView: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  cardUnselcted: {
    borderWidth: 0.3,
    borderColor: 'grey',
    height: 40,
    borderRadius: 5,
    justifyContent: 'center',
    paddingHorizontal: 24,
    marginTop: 12,
    width: '50%',
  },
  cardSelected: {
    borderWidth: 0.3,
    borderColor: root.client_background,
    height: 40,
    borderRadius: 5,
    justifyContent: 'center',
    backgroundColor: root.color_chipFilter,
    paddingHorizontal: 24,
    marginTop: 12,
    width: '50%',
  },
  selectionContainer: {
    ...alignment.row_SpaceB,
  },
  dayLabelTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
  },
  type: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  format: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    height: 56,
    paddingHorizontal: 16,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingLeft: 25,
  },
  calenderContainer: {
    paddingTop: 32,
  },
  monthYear: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingLeft: 16,
  },
});

export default CalendarModal;

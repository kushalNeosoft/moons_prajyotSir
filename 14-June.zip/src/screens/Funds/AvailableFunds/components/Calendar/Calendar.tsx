import React, {useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  LayoutAnimation,
  StyleSheet,
  TouchableOpacity,
  Platform,
  UIManager,
} from 'react-native';
import {format} from 'date-fns';
import Calendar, {
  useCalendarContext,
  DayLabelComponentType,
  DayComponentType,
  HeaderComponentType,
} from 'react-native-swipe-calendar';
import alignment from '../../../../../components/utils/alignment';
import { Cfont, Font, root } from '../../../../../styles/colors';

if (Platform.OS === 'android') {
  UIManager.setLayoutAnimationEnabledExperimental &&
    UIManager.setLayoutAnimationEnabledExperimental(true);
}

const CalendarComponent = (props:any) => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const calendarRef = useRef(null);

  const DayLabelComponent: DayLabelComponentType = ({date}) => {
    const {theme} = useCalendarContext();

    const dayLabelText = format(date, theme.dayLabelDateFormat.slice(0, -1));
    return (
      <View style={styles.dayLabelContainer}>
        <Text style={styles.dayLabelTxt}>{dayLabelText}</Text>
      </View>
    );
  };

  const HeaderComponent: HeaderComponentType = ({startDate, endDate}) => {
    const {theme} = useCalendarContext();

    const month = format(startDate, theme.headerDateFormat.substring(0, 3));
    const year = format(endDate, theme.headerDateFormat.slice(-4));
    return <Text style={styles.monthYear}>{`${month} ${year}`}</Text>;
  };

  const DayComponent: DayComponentType = ({
    date,
    isInDisplayedMonth,
    isToday,
    isSelected,
  }) => {
    const ctx = useCalendarContext();
    return (
      <TouchableOpacity
        onPress={() => ctx.onDateSelect?.(date, {isSelected})}
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          opacity: isInDisplayedMonth ? 1 : 0,
          backgroundColor: isSelected ? root.client_background : 'none',
          borderRadius: 70,
        }}>
        <View
          style={{
            borderColor: isToday ? 'white' : 'transparent',
            alignItems: 'center',
            justifyContent: 'center',
            paddingVertical: 15,
          }}>
          <Text style={isSelected ? styles.selectedDayText : styles.dayText}>
            {date.getDate()}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
        <View style={styles.calenderContainer}>
          <Calendar
            ref={calendarRef}
            currentDate={currentDate}
            onDateSelect={(date, {isSelected}) =>
            props.selectingDate(isSelected ? null : date)
            }
            selectedDate={props.selectedDate}
            onPageChange={date => {
              setCurrentDate(date);
              LayoutAnimation.configureNext(
                LayoutAnimation.Presets.easeInEaseOut,
              );
            }}
            DayLabelComponent={DayLabelComponent}
            DayComponent={DayComponent}
            HeaderComponent={HeaderComponent}
          />
        </View>
  );
};

const styles = StyleSheet.create({
  dayText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    maxWidth: 24,
  },
  selectedDayText: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_active,
    maxWidth: 24,
  },
  dayLabelContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 32,
  },
  selectionView: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  cardUnselcted: {
    borderWidth: 0.3,
    borderColor: 'grey',
    height: 40,
    borderRadius: 5,
    justifyContent: 'center',
    paddingHorizontal: 24,
    marginTop: 12,
    width: '50%',
  },
  cardSelected: {
    borderWidth: 0.3,
    borderColor: root.client_background,
    height: 40,
    borderRadius: 5,
    justifyContent: 'center',
    backgroundColor: root.color_chipFilter,
    paddingHorizontal: 24,
    marginTop: 12,
    width: '50%',
  },
  selectionContainer: {
    ...alignment.row_SpaceB,
  },
  dayLabelTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
  },
  type: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  format: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    height: 56,
    paddingHorizontal: 16,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingLeft: 25,
  },
  calenderContainer: {
    paddingTop: 32,
  },
  monthYear: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingLeft: 16,
  },
});

export default CalendarComponent;

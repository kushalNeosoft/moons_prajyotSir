import React, {
  useCallback,
  useImperativeHandle,
  useState,
} from 'react';
import {View, Dimensions, StyleSheet, Text} from 'react-native';
import {Gesture, GestureDetector} from 'react-native-gesture-handler';
import Animated, {
  Extrapolate,
  interpolate,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import {useNavigation} from '@react-navigation/native';
import {Cfont} from '../../../../../styles/colors';
import {Font} from '../../../../../styles/colors';
import {root} from '../../../../../styles/colors';

const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

type BottomSheetProps = {
  onReturn: () => void;
  props: any;
};
export type BottomSheetRefProps = {
  scrollTo: (destination: number) => void;
  props: any;
};

const BottomSheet = React.forwardRef((props: any, ref) => {
  const [navigate, setNavigate] = useState(false);
  const translateY = useSharedValue(0);
  const navigation = useNavigation();
  const context = useSharedValue({
    y: 0,
  });

  const scrollTo = useCallback((destination: number) => {
    'worklet';
    translateY.value = withSpring(destination, {damping: 50});
  }, []);

  useImperativeHandle(ref, () => ({scrollTo}), [scrollTo]);

  const MAX_TRANSLATE_Y = -screenHeight;

  const setState=()=>{
    navigation.navigate('RecentTransactions')
  }

  const gesture = Gesture.Pan()
    .onStart(() => {
      'worklet';
      context.value = {y: translateY.value};
    })
    .onUpdate(event => {
      'worklet';
      translateY.value = event.translationY + context.value.y;
      translateY.value = Math.max(translateY.value, MAX_TRANSLATE_Y);
    })
    .onEnd(() => {
      'worklet';
      if (translateY.value <= -screenHeight / 1.5) {
        runOnJS(setState)();
      }
    });

  const reanimatedBottomSheetStyle = useAnimatedStyle(() => {
    const borderRadius = interpolate(
      translateY.value,
      [MAX_TRANSLATE_Y + 50, MAX_TRANSLATE_Y],
      [25, 5],
      Extrapolate.CLAMP,
    );
    return {
      borderRadius,
      transform: [{translateY: translateY.value}],
    };
  });
  return (
    <GestureDetector gesture={gesture}>
      <Animated.View
        style={[styles.bottomSheetContainer, reanimatedBottomSheetStyle]}>
        <View style={styles.line} />
        <Text style={styles.txt}>Recent Transaction</Text>
      </Animated.View>
    </GestureDetector>
  );
});

const styles = StyleSheet.create({
  bottomSheetContainer: {
    height: screenHeight,
    backgroundColor: 'white',
    position: 'absolute',
    top: screenHeight,
    borderRadius: 25,
    padding: 20,
    left: 0,
    right: 0,
  },
  line: {
    width: 40,
    height: 4,
    backgroundColor: 'grey',
    alignSelf: 'center',
    borderRadius: 2,
  },
  txt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingTop: 10,
  },
});

export default BottomSheet;

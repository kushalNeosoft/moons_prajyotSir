import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import {Cfont, Font, root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import {useFocusEffect, useNavigation} from '@react-navigation/native';
import BottomSheet, {
  BottomSheetRefProps,
} from './components/TransactionSheet/transactionSheet';
import PeriodicityModal from './components/Modal/PeriodicityModal';
import {availableFunds} from '../../../theme/light';
import alignment from '../../../components/utils/alignment';

const AvailableFunds = React.forwardRef(() => {
  const [card, setCard] = useState('TEST123');
  const ref = useRef<BottomSheetRefProps>(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [periodicityModal, setPeriodicityModal] = useState(false);
  const data = ['TEST123', 'BSE EQUITIES', 'NSE DERIVATIVE', 'NSE EQUITIES'];

  const navigation = useNavigation<any>();

  const onClose = () => {
    setPeriodicityModal(prevState => !prevState);
  };

  useFocusEffect(() => {
    ref?.current?.scrollTo(-200);
  });

  const periodiCityData = [
    {
      indicator: 'Deposit',
      value: '10,000.00',
    },
    {
      indicator: 'Limit Utilization',
      value: '-2,09,530.20',
    },
    {
      indicator: 'Funds Transferred Today',
      value: '0.00',
    },
    {
      indicator: 'Funds withdrawl/Allocation',
      value: '0.00',
    },
    {
      indicator: 'Collateral',
      value: '100000000000000.00',
    },
    {
      indicator: 'MTM Profit/Loss',
      value: '0.00',
    },
    {
      indicator: 'Credit For Sale',
      value: '0.00',
    },
    {
      indicator: 'Booked Profit/Loss',
      value: '0.00',
    },
    {
      indicator: 'Option CFS',
      value: '0.00',
    },
  ];

  const tradingData = [
    {
      title: 'Total Trading',
      value: '10,000.00 Cr',
    },
    {
      title: 'Total Utilization',
      value: '0.00',
    },
    {
      title: 'Multiplier',
      value: '1',
    },
    {
      title: 'Net Availbale',
      value: '10,000.00 Cr',
    },
  ];

  const renderCard = ({item}: any) => {
    return (
      <TouchableOpacity
        style={
          card === item
            ? availableFunds.cardActive
            : availableFunds.cardInactive
        }
        activeOpacity={1}
        onPress={() => setCard(item)}>
        <View style={availableFunds.cardContainer}>
          <Text
            style={
              card === item
                ? availableFunds.headingActive
                : availableFunds.headingInactive
            }>
            {item}
          </Text>
          <View style={availableFunds.add_withDraw_Funds}>
            <Text
              style={
                card === item
                  ? availableFunds.add_withdraw_ActiveTxt
                  : availableFunds.add_withdraw_InactiveTxt
              }>
              Add Funds
            </Text>
            <TouchableOpacity
              onPress={() => {
                console.log(item);
              }}>
              <Feather
                name="plus-circle"
                size={24}
                color={card === item ? root.color_active : root.color_text}
              />
            </TouchableOpacity>
          </View>
          <View style={availableFunds.add_withDraw_Funds}>
            <Text
              style={
                card === item
                  ? availableFunds.add_withdraw_ActiveTxt
                  : availableFunds.add_withdraw_InactiveTxt
              }>
              Withdraw Funds
            </Text>
            <TouchableOpacity onPress={() => {}}>
              <Feather
                name="minus-circle"
                size={24}
                color={card === item ? root.color_active : root.color_text}
              />
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const navigateViaMenu = (value: string) => {
    navigation.replace(value, {fundName: card});
    setMenuVisible(prevState => !prevState);
  };

  return (
    <GestureHandlerRootView style={{flex: 1}}>
      <View style={availableFunds.container}>
        <View style={availableFunds.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => setMenuVisible(prevState => !prevState)}>
            <Entypo name="dots-three-vertical" size={24} color={'black'} />
          </TouchableOpacity>
        </View>
        {menuVisible && (
          <View style={availableFunds.menuNav}>
            <TouchableOpacity
              style={availableFunds.menuItem}
              onPress={() => navigateViaMenu('AddFunds')}>
              <Text style={availableFunds.menuTxt}>Add Funds</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={availableFunds.menuItem}
              onPress={() => navigateViaMenu('WithDrawFunds')}>
              <Text style={availableFunds.menuTxt}>Withdraw Funds</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={availableFunds.menuItem}
              onPress={() => navigateViaMenu('RecentTransactions')}>
              <Text style={availableFunds.menuTxt}>Recent Transactions</Text>
            </TouchableOpacity>
          </View>
        )}
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={availableFunds.availableFundsTxt}>Available Funds</Text>
          <TouchableOpacity
            style={availableFunds.periodictyView}
            onPress={() => setPeriodicityModal(prevState => !prevState)}
            activeOpacity={1}>
            <Text
              style={
                availableFunds.periodicityValue
              }>{`All Exchange Combined ₹ 10,000.00 Cr`}</Text>
            <AntDesign name="caretdown" size={10} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={availableFunds.valueContainer}
            onPress={() =>
              navigation.navigate('FundDetails', {name: 'Deposit'})
            }
            activeOpacity={1}>
            <View style={availableFunds.utilisedContainer}>
              <View style={availableFunds.utilised_available_Container}>
                <Text style={availableFunds.utlised_available_Txt}>
                  Utlised
                </Text>
                <Text
                  style={
                    availableFunds.utilised_available_Value
                  }>{`₹ -2,09,530.20`}</Text>
              </View>
            </View>
            <View style={availableFunds.availableContainer}>
              <View style={availableFunds.utilised_available_Container}>
                <Text style={availableFunds.utlised_available_Txt}>
                  Available
                </Text>
                <Text
                  style={
                    availableFunds.utilised_available_Value
                  }>{`₹ 9,999,98 Cr.`}</Text>
              </View>
            </View>
          </TouchableOpacity>
          <FlatList
            style={availableFunds.cardView}
            data={data}
            renderItem={renderCard}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
          />
          <View>
            <FlatList
              contentContainerStyle={availableFunds.periodicityContainer}
              data={periodiCityData}
              numColumns={2}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={availableFunds.perodiCtyContainer}
                  onPress={() =>
                    navigation.navigate('FundDetails', {name: item.indicator})
                  }>
                  <View style={{width: '40%'}}>
                    <Text numberOfLines={1} style={availableFunds.indicatorTxt}>
                      {item.indicator}
                    </Text>
                  </View>
                  <View style={availableFunds.value}>
                    <Text style={availableFunds.valueTxt} numberOfLines={1}>
                      {item.value}
                    </Text>
                    <Ionicons
                      name="chevron-forward"
                      size={15}
                      color={root.client_background}
                    />
                  </View>
                </TouchableOpacity>
              )}
            />
          </View>
          <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
            <View style={availableFunds.perodiCtyContainer}>
              <View style={{width: '40%'}}>
                <Text
                  numberOfLines={1}
                  style={[
                    availableFunds.indicatorTxt,
                    {fontFamily: Cfont.rubik_medium},
                  ]}>
                  Total Trading
                </Text>
              </View>
              <View style={availableFunds.value}>
                <Text style={availableFunds.valueTxt} numberOfLines={1}>
                  10,000.00
                </Text>
                <Ionicons
                  name="chevron-forward"
                  size={15}
                  color={root.client_background}
                />
              </View>
            </View>
            <View style={availableFunds.perodiCtyContainer}>
              <View style={{width: '40%'}}>
                <Text
                  numberOfLines={1}
                  style={[
                    availableFunds.indicatorTxt,
                    {fontFamily: Cfont.rubik_medium},
                  ]}>
                  Total Utlilization
                </Text>
              </View>
              <View style={availableFunds.value}>
                <Text
                  style={[
                    availableFunds.valueTxt,
                    {color: root.color_negative},
                  ]}
                  numberOfLines={1}>
                  0.00
                </Text>
                <Ionicons
                  name="chevron-forward"
                  size={15}
                  color={root.client_background}
                />
              </View>
            </View>
          </View>
          <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
            <View style={availableFunds.perodiCtyContainer}>
              <View style={{width: '40%'}}>
                <Text
                  numberOfLines={1}
                  style={[
                    availableFunds.indicatorTxt,
                    {fontFamily: Cfont.rubik_medium},
                  ]}>
                  Multiplier
                </Text>
              </View>
              <View style={availableFunds.value}>
                <Text style={availableFunds.valueTxt} numberOfLines={1}>
                  1.00
                </Text>
                <Ionicons
                  name="chevron-forward"
                  size={15}
                  color={root.client_background}
                />
              </View>
            </View>
            <View style={availableFunds.perodiCtyContainer}>
              <View style={{width: '40%'}}>
                <Text
                  numberOfLines={1}
                  style={[
                    availableFunds.indicatorTxt,
                    {fontFamily: Cfont.rubik_medium},
                  ]}>
                  Net Available
                </Text>
              </View>
              <View style={availableFunds.value}>
                <Text
                  style={[
                    availableFunds.valueTxt,
                    {color: root.color_positive},
                  ]}
                  numberOfLines={1}>
                  10,0000.00
                </Text>
                <Ionicons
                  name="chevron-forward"
                  size={15}
                  color={root.client_background}
                />
              </View>
            </View>
          </View>
          <View style={{height: 200}} />
        </ScrollView>
      </View>
      <BottomSheet ref={ref} />
      <PeriodicityModal onClose={onClose} visible={periodicityModal} />
    </GestureHandlerRootView>
  );
});

export default AvailableFunds;

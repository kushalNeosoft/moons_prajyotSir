import {StyleSheet} from 'react-native';
import {TColors} from '../../../styles/colors';

export const createPhoneVerificationStyles = (colors: TColors) => {
  return StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
      padding: 16,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: 'grey',
    },
  });
};

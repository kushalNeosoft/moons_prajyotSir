import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
// import { Grid, LineChart, XAxis, YAxis,Path,AreaChart } from 'react-native-svg-charts'
import {FlatList, ScrollView, Text, TouchableOpacity, View} from 'react-native';
import {Analysisstyle, CompanyStyle} from '../../../theme/light';

import {root} from '../../../styles/colors';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import {
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLine,
  VictoryTheme,
} from 'victory-native';

import Chartline from './Charts/Chartline';
import {Contactdata, Puttdata, UserData} from '../../../assets/demoData';
import {Line} from 'react-chartjs-2';
import {Chart} from 'chart.js/auto';
import {BarChart, LineChart} from 'react-native-chart-kit';
import {Dimensions} from 'react-native';

// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   LineElement,
//   Title,
//   Tooltip,
//   Legend,
// } from 'chart.js';
// import {Line} from 'react-chartjs-2';

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   LineElement,
//   Title,
//   Tooltip,
//   Legend,
// );

// export const options = {
//   responsive: true,
//   plugins: {
//     legend: {
//       position: 'top' as const,
//     },
//     title: {
//       display: true,
//       text: 'Chart.js Line Chart',
//     },
//   },
// };

// const labels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];

// export const data = {
//   labels,
//   datasets: [
//     {
//       label: 'Dataset 1',
//       data: labels.map(() => ({min: -1000, max: 1000})),
//       borderColor: 'rgb(255, 99, 132)',
//       backgroundColor: 'rgba(255, 99, 132, 0.5)',
//     },
//     {
//       label: 'Dataset 2',
//       data: labels.map(() => ({min: -1000, max: 1000})),
//       borderColor: 'rgb(53, 162, 235)',
//       backgroundColor: 'rgba(53, 162, 235, 0.5)',
//     },
//   ],
// };

const Analysis: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  // const [checked, setChecked] = useState(false);
  // const [selectedItem, setSelectedItem] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(0);
  // const [modalVisible, setModalVisible] = useState(false);
  // const [stockData, setStockData] = useState([]);
  // const [handleRefresh, setHandleRefresh] = useState(false);
  // const navigation = useNavigation();
  const [selectedItem, setSelectedItem] = useState(0);


  const renderItem = ({ item, index }: any) => (
    <TouchableOpacity onPress={() => setSelectedItem(index)}>
      {selectedItem === index ? (
        <>
          <View style={CompanyStyle.menuitem}>
            <Text style={CompanyStyle.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={CompanyStyle.menuitemtwo}>
            <Text style={CompanyStyle.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );

  const [userData, setUserData] = useState({
    labels: UserData.map(data => data.year),
    datasets: [
      {
        label: 'Users Gained',
        data: UserData.map(data => data.userGain),
      },
    ],
  });

  // const data = [50, 10, 40, 95, -4, -24, 85, 91, 35, 53, -53, 24, 50, -20, -80];

  // const axesSvg = {fontSize: 10, fill: 'grey'};
  // const verticalContentInset = {top: 10, bottom: 10};
  // const xAxisHeight = 10;

  //   const Line = ({ line }) => (
  //     <Path
  //         key={ 'line ' }
  //         d={ line }
  //         stroke={ 'rgb(134, 65, 244)' }
  //         fill={ 'none' }
  //     />
  // )
  // const labels = Utils.months({count: 7});
  // const data = {
  //   labels: ['jan','jan','jan','jan','jan','jan','jan'],
  //   datasets: [{
  //     label: 'My First Dataset',
  //     data: [65, 59, 80, 81, 56, 55, 40],
  //     fill: false,
  //     borderColor: 'rgb(75, 192, 192)',
  //     tension: 0.1
  //   }]
  // };

  // const stackedLine = new Chart({}, {
  //     type: 'line',
  //     data: data,
  //     options: {
  //         scales: {
  //             y: {
  //                 stacked: true
  //             }
  //         }
  //     }
  // });
  const data = [
    {year: '2011', earnings: 5000, expenditure: 13000},
    {year: '2012', earnings: 17506, expenditure: 10000},
    {year: '2013', earnings: 14250, expenditure: 8000},
    {year: '2014', earnings: 19000, expenditure: 12000},
  ];

  const screenWidth = Dimensions.get('window').width;
  const chartConfig = {
    color: (opacity = 1) => `rgba(26, 255, 146, ${opacity})`,

    // barPercentage: 0.5,
    // useShadowColorFromDataset: false, // optional
  };
  // const data = {
  //   labels: ['January', 'February', 'March', 'April', 'May', 'June'],
  //   datasets: [
  //     {
  //       data: [20, 45, 28, 80, 99, 43],
  //       color: (opacity = 1) => `rgba(134, 65, 244, ${opacity})`, // optional
  //       strokeWidth: 2, // optional
  //     },
  //   ],
  //   legend: ['Rainy Days'], // optional
  // };

  // const data = {
  //   labels: ['January', 'February', 'March', 'April', 'May', 'June'],
  //   datasets: [
  //     {
  //       data: [20, 45, 28, 80, 99, 43],
  //     },
  //   ],
  // };

  return (
    <ScrollView
      style={Analysisstyle({selectedIndex}).maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Analysisstyle({selectedIndex}).switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).todaysView}>
          <Text style={Analysisstyle({selectedIndex}).todayText}>
            Technicals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).overallView}>
          <Text style={Analysisstyle({selectedIndex}).overallText}>
            Fundamentals
          </Text>
        </TouchableOpacity>
      </View>
      {selectedIndex === 0 ? (
        <>
          <View style={Analysisstyle({selectedIndex}).containerone}>
            <View style={Analysisstyle({selectedIndex}).containertwo}>
              <Text style={Analysisstyle({selectedIndex}).txtstyle}>
                Charts
              </Text>
              <View style={Analysisstyle({selectedIndex}).iconcon}>
                <SimpleLineIcons
                  name="frame"
                  size={15}
                  color={root.color_active}
                />
              </View>
            </View>
          </View>
          {/* <View style={{height: 200, padding: 20, flexDirection: 'row'}}> */}
          {/* <View style={{ flex: 1, marginLeft: 10 }}>
              <LineChart
                style={{ flex: 1}}
                data={data}
                contentInset={verticalContentInset}
                svg={{ stroke: root.color_text }}
              >
                <Grid />
              </LineChart>
              <XAxis
                style={{ marginHorizontal: -10, height: xAxisHeight }}
                data={data}
                formatLabel={(value: any, index: any) => value}
                contentInset={{ left: 10, right: 10 }}
                svg={axesSvg}
              />
            </View>
            <YAxis
              data={data}
              style={{ marginBottom: xAxisHeight,}}
              contentInset={verticalContentInset}
              svg={axesSvg}
            /> */}
          {/* </View> */}
          {/* <View style={{width: 100}}> */}
          <>{/* {stackedLine} */}</>
          {/* <Line  data={data} /> */}
          {/* <Chartline chartData={userData} /> */}
          {/* <Barcharts chartData={userData}/> */}
          {/* <BarChart
              data={data}
              width={screenWidth}
              height={220}
              yAxisLabel="$"
              chartConfig={chartConfig}
              verticalLabelRotation={30}
            /> */}
          {/* <LineChart
            style={{backgroundColor:'white'}}
              data={data}
              width={screenWidth}
              height={120}
              chartConfig={chartConfig}
              bezier
              verticalLabelRotation={30}
            /> */}
          {/* Barchart */}
         
          {/* </View> */}
          <View>
            {/* <VictoryChart theme={VictoryTheme.material}>
              <VictoryLine
              interpolation="natural"
                style={{
                  data: {stroke: '#c43a31'},
                  parent: {border: '1px solid #ccc'},
                }}
                data={[
                  {y: 1, x: 2},
                  {y: 2, x: 3},
                  {y: 3, x: 5},
                  {y: 4, x: 4},
                  {y: 5, x: 7},
                ]}
              />
            </VictoryChart> */}
            <VictoryChart>
              {/* <VictoryLine samples={15} y={d => Math.sin(5 * Math.PI * d.x)} /> */}
              <VictoryLine
                samples={100}
                style={{data: {stroke: 'red'}}}
                y={d => Math.cos(5 * Math.PI * d.x)}
                // x={d => Math.cos(5 * Math.PI * d.x)}
                
              />
            </VictoryChart>
          </View>
          <View style={Analysisstyle({selectedIndex}).supportcon}>
            <Text style={Analysisstyle({selectedIndex}).txtstyle}>
              Support & Resistance
            </Text>
          </View>
          <View
            style={{flexDirection: 'row', flex: 1, height: 30, width: '100%'}}>
            <View
              style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
              <Text>Support</Text>
            </View>
            <View
              style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
              <Text>Resistance</Text>
            </View>
          </View>
          <View style={{height:200}}>

          </View>
          <View style={Analysisstyle({selectedIndex}).supportcon}>
            <Text style={Analysisstyle({selectedIndex}).txtstyle}>
              Put Call Ratio
            </Text>
          </View>
         
          <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Puttdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>

      <View>
              <VictoryChart width={350} theme={VictoryTheme.material}>
                <VictoryAxis tickFormat={tick => tick} />
                <VictoryAxis dependentAxis />
                <VictoryGroup offset={20} colorScale={['green', 'red']}>
                  <VictoryBar
                    data={data}
                    x="year"
                    y="earnings"
                    labels={({datum}) => `$${datum.earnings}`}
                    animate={{
                      onLoad: {duration: 1000},
                      duration: 1000,
                      easing: 'bounce',
                    }}
                  />
                  <VictoryBar
                    data={data}
                    x="year"
                    y="expenditure"
                    labels={({datum}) => `$${datum.expenditure}`}
                    animate={{
                      onLoad: {duration: 2000},
                      duration: 2000,
                      easing: 'bounceIn',
                    }}
                  />
                </VictoryGroup>
              </VictoryChart>
            </View>
        </>
      ) : (
        <>
          <View
            style={{height: 60, width: 50, backgroundColor: 'yellow'}}></View>
        </>
      )}
      <View style={Analysisstyle({selectedIndex}).innercon} />
    </ScrollView>
  );
};

export default Analysis;

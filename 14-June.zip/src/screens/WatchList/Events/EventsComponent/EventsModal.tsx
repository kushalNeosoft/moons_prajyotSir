import React from 'react';
import {ScrollView} from 'react-native';
import {Touchable} from 'react-native';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import { root } from '../../../../styles/colors';
import {Eventmodaistyle, Eventstylecom} from '../../../../theme/light';

export const DateModal = (props: any) => {
  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>
      <View style={Eventmodaistyle.innercon}>
        <Text style={Eventmodaistyle.txtTitle}>{props.name}</Text>
      </View>
      {props.name == 'Dividend' ? null : (
        <>
          <View style={Eventmodaistyle.innercontwo}>
            <Text style={Eventmodaistyle.txtTitle}>{props.day}</Text>
            <Text style={Eventmodaistyle.yeartxt}>{props.year}</Text>
          </View>
        </>
      )}
      {props.name == 'Board Meeting' ? (
        // <View style={Eventmodaistyle.Maincon}>
        <ScrollView
          style={Eventmodaistyle.scrView}
          showsVerticalScrollIndicator={false}>
          <Text style={Eventmodaistyle.txtpara}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque animi
            recusandae ex suscipit, aliquam earum laboriosam itaque autem
            voluptates at voluptatem expedita ducimus deleniti eveniet fugit
            voluptate tempore repellendus est! Lorem ipsum dolor sit amet,
            consectetur adipisicing elit. Harum, error delectus tenetur a labore
            sit mollitia, corporis aliquam voluptas maiores aut enim accusantium
            magnam omnis neque quaerat deserunt possimus ipsam? Lorem ipsum
            dolor sit amet consectetur adipisicing elit. Atque animi recusandae
            ex suscipit, aliquam earum laboriosam itaque autem voluptates at
            voluptatem expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam?
          </Text>
        </ScrollView>
      ) : // </View>
      props.name == 'Book Closure' ? (
        <View style={Eventmodaistyle.Closurecon}>
          <View style={Eventmodaistyle.innerclousercon}>
            <Text style={Eventmodaistyle.durationtxt}>Duration</Text>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.duration == ''
                ? '/--/--'
                : props?.datainfo?.duration}
            </Text>
          </View>
          <View style={Eventmodaistyle.Closurebottom}>
            <Text style={[Eventmodaistyle.durationtxt, Eventmodaistyle.allign]}>
              Purpose
            </Text>
            <Text style={Eventmodaistyle.bottomtxtclosure}>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum nihil
              accusantium similique libero odit tempora doloribus, sunt
              doloremque facere inventore cupiditate praesentium officiis
              explicabo! Reprehenderit ab eaque exercitationem voluptate
              quibusdam. Lorem ipsum dolor sit amet consectetur adipisicing
              elit. Consequatur modi, tempore mollitia illo quidem reiciendis
              nemo dignissimos ipsam voluptatibus atque beatae repudiandae vero
              incidunt sapiente blanditiis accusamus! Magni, optio dicta!
            </Text>
          </View>
        </View>
      ) : props.name == 'AGM' || 'EGM' ? (
        <View style={Eventmodaistyle.AgmStyle}>
          <View style={Eventmodaistyle.Gmcontainer}>
            <Text style={Eventmodaistyle.gmtxt}>{props?.datainfo?.Gm}</Text>
            <Text style={Eventmodaistyle.gmtxt}>
              {props?.datainfo?.Gmvalue}
            </Text>
          </View>
          {props.name == 'EGM' ? null : (
            <View style={[Eventmodaistyle.innerclousercon, {marginBottom: 16}]}>
              <Text style={Eventmodaistyle.durationtxt}>Duration</Text>
              <Text style={Eventmodaistyle.durationtxt}>
                {props?.datainfo?.duration == ''
                  ? '/--/--'
                  : props?.datainfo?.duration}
              </Text>
            </View>
          )}
          <View>
            <ScrollView
              style={[Eventmodaistyle.scrView, {paddingHorizontal: -5}]}
              showsVerticalScrollIndicator={false}>
              <Text
                style={[Eventmodaistyle.durationtxt, Eventmodaistyle.allign]}>
                Purpose
              </Text>
              <Text style={Eventmodaistyle.txtpara}>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque
                animi recusandae ex suscipit, aliquam earum laboriosam itaque
                autem voluptates at voluptatem expedita ducimus deleniti eveniet
                fugit voluptate tempore repellendus est! Lorem ipsum dolor sit
                amet, consectetur adipisicing elit. Harum, error delectus
                tenetur a labore sit mollitia, corporis aliquam voluptas maiores
                aut enim accusantium magnam omnis neque quaerat deserunt
                possimus ipsam? Lorem ipsum dolor sit amet consectetur
                adipisicing elit. Atque animi recusandae ex suscipit, aliquam
                earum laboriosam itaque autem voluptates at voluptatem expedita
                ducimus deleniti eveniet fugit voluptate tempore repellendus
                est! Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Harum, error delectus tenetur a labore sit mollitia, corporis
                aliquam voluptas maiores aut enim accusantium magnam omnis neque
                quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
                consectetur adipisicing elit. Atque animi recusandae ex
                suscipit, aliquam earum laboriosam itaque autem voluptates at
                voluptatem expedita ducimus deleniti eveniet fugit voluptate
                tempore repellendus est! Lorem ipsum dolor sit amet, consectetur
                adipisicing elit. Harum, error delectus tenetur a labore sit
                mollitia, corporis aliquam voluptas maiores aut enim accusantium
                magnam omnis neque quaerat deserunt possimus ipsam? Lorem ipsum
                dolor sit amet consectetur adipisicing elit. Atque animi
                recusandae ex suscipit, aliquam earum laboriosam itaque autem
                voluptates at voluptatem expedita ducimus deleniti eveniet fugit
                voluptate tempore repellendus est! Lorem ipsum dolor sit amet,
                consectetur adipisicing elit. Harum, error delectus tenetur a
                labore sit mollitia, corporis aliquam voluptas maiores aut enim
                accusantium magnam omnis neque quaerat deserunt possimus ipsam?
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque
                animi recusandae ex suscipit, aliquam earum laboriosam itaque
                autem voluptates at voluptatem expedita ducimus deleniti eveniet
                fugit voluptate tempore repellendus est! Lorem ipsum dolor sit
                amet, consectetur adipisicing elit. Harum, error delectus
                tenetur a labore sit mollitia, corporis aliquam voluptas maiores
                aut enim accusantium magnam omnis neque quaerat deserunt
                possimus ipsam? Lorem ipsum dolor sit amet consectetur
                adipisicing elit. Atque animi recusandae ex suscipit, aliquam
                earum laboriosam itaque autem voluptates at voluptatem expedita
                ducimus deleniti eveniet fugit voluptate tempore repellendus
                est! Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                Harum, error delectus tenetur a labore sit mollitia, corporis
                aliquam voluptas maiores aut enim accusantium magnam omnis neque
                quaerat deserunt possimus ipsam?
              </Text>
            </ScrollView>
          </View>
        </View>
      ) : //   : props.name == 'EGM' ? (
      //     <View style={{width: '100%', backgroundColor: 'blue', height: 400}}>
      //       <Text>Iam date Modal Imran{props.day}</Text>
      //     </View>
      //   )
      props.name == 'splite' ? (
        <View style={{width: '100%', backgroundColor: 'orange', height: 400}}>
          <Text>Iam date Modal Imran{props.day}</Text>
        </View>
      ) : props.name == 'Dividend' ? (
        <View style={Eventmodaistyle.Dividendcontainer}>
          <View style={Eventmodaistyle.innerdiv}>
            <Text style={Eventmodaistyle.txtTitle}>
              {props?.datainfo?.percentage}
            </Text>
          </View>
          <View style={Eventmodaistyle.innerclousercontwo}>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Dividend_Type}
            </Text>
            <Text style={Eventmodaistyle.durationtxt}>Interim</Text>
          </View>

          <View style={Eventmodaistyle.innerclousercontwo}>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Recorded_Date}
            </Text>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Recorded_Date_value}
            </Text>
          </View>

          <View style={Eventmodaistyle.innerclousercontwo}>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Announcement}
            </Text>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Announcement_date}
            </Text>
          </View>

          <View style={Eventmodaistyle.innerclousercontwo}>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Ex_Date}
            </Text>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Ex_Datevalue}
            </Text>
          </View>

          <View style={Eventmodaistyle.innerclousercontwo}>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Amount}
            </Text>
            <Text style={Eventmodaistyle.durationtxt}>
              {props?.datainfo?.Avalue}
            </Text>
          </View>
        </View>
      ) : props.name == 'Buy Back' ? (
        <View style={{width: '100%', backgroundColor: 'cyan', height: 400}}>
          <Text>Iam date Modal Imran{props.day}</Text>
        </View>
      ) : (
        <>
          <View style={{width: '100%', backgroundColor: 'gold', height: 400}}>
            <Text>Iam date Modal Imran{props.day}</Text>
          </View>
        </>
      )}
      {/* {props.name.title=== 'Book Closure' && (
        <>
          <View style={{width: '100%', backgroundColor: 'yellow',height:400}}>
            <Text>Iam date Modal Imran{props.day}</Text>
          </View>
        </>
      )} */}
    </CommonModal>
  );
};

export const NewsModal = (props: any) => {

  return (
    <CommonModal visible={props.visible} onClose={props.onClose} iconvisible={props?.iconvisible}>
      <View style={{paddingHorizontal:6}}>
        <Text style={Eventmodaistyle.newsheader}>
          {props?.newsinfo?.headLine}
        </Text>
        <Text style={Eventmodaistyle.datetxt}>
          {props?.newsinfo?.newsdate} {props?.newsinfo?.time}
        </Text>
      </View>
      <ScrollView
          style={Eventmodaistyle.scrViewtwo}
          showsVerticalScrollIndicator={false}>
          <Text style={[Eventmodaistyle.txtpara]}>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Atque animi
            recusandae ex suscipit, aliquam earum laboriosam itaque autem
            voluptates at voluptatem expedita ducimus deleniti eveniet fugit
            voluptate tempore repellendus est! Lorem ipsum dolor sit amet,
            consectetur adipisicing elit. Harum, error delectus tenetur a labore
            sit mollitia, corporis aliquam voluptas maiores aut enim accusantium
            magnam omnis neque quaerat deserunt possimus ipsam? Lorem ipsum
            dolor sit amet consectetur adipisicing elit. Atque animi recusandae
            ex suscipit, aliquam earum laboriosam itaque autem voluptates at
            voluptatem expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam? Lorem ipsum dolor sit amet
            consectetur adipisicing elit. Atque animi recusandae ex suscipit,
            aliquam earum laboriosam itaque autem voluptates at voluptatem
            expedita ducimus deleniti eveniet fugit voluptate tempore
            repellendus est! Lorem ipsum dolor sit amet, consectetur adipisicing
            elit. Harum, error delectus tenetur a labore sit mollitia, corporis
            aliquam voluptas maiores aut enim accusantium magnam omnis neque
            quaerat deserunt possimus ipsam?
          </Text>
        </ScrollView>
              
    </CommonModal>
  );
};

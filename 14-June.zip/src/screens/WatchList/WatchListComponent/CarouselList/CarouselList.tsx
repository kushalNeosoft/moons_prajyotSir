import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  Dimensions,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Button,
  Modal,
  Animated,
} from 'react-native';
import Carousel from 'react-native-reanimated-carousel';
// import {colors} from '../../constants/colors';
import alignment from '../../../../components/utils/alignment';
import {CarouselProps} from './type';
import {buyData, sellData} from './constData';
import {useNavigation} from '@react-navigation/native';
import {Cfont, Font, root} from '../../../../styles/colors';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Entypo from 'react-native-vector-icons/Entypo';
import {
  courselDemodata,
  endDemodata,
  progressData,
} from '../../../../components/replacement-svg/demoData';
import Feather from 'react-native-vector-icons/Feather';
// import {
//   interpolate,
//   interpolateColor,
//   useAnimatedStyle,
//   TransformStyleTypes
// } from 'react-native-reanimated';

import {Courselstyles} from '../../../../theme/light';
// import { Modal } from 'react-native-paper';
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

function CarouselList(props: CarouselProps) {
  const navigation = useNavigation<any>();
  const [currentindex, setCurrentindex] = React.useState(props.index);
  const animationValue = useRef(new Animated.Value(0));
  const [animationState, setAnimationState] = useState(false);

  const gravity = Animated.timing(animationValue.current, {
    duration: 200,
    toValue: animationState ? 0 : 600,
    useNativeDriver: false,
  });

  useEffect(() => {
    gravity.start();
  }, [props.index]);
  const jump = () => {
    gravity.reset();
    gravity.start();
  };

  const buyView = () => {
    return (
      <View style={Courselstyles.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={Courselstyles.ordersHeaderText}>Qty</Text>
          <Text style={Courselstyles.ordersHeaderText}>Orders</Text>
          <Text style={Courselstyles.ordersHeaderText}>Bid</Text>
        </View>
        <FlatList
          data={buyData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={Courselstyles.buyText}>{item.qty}</Text>
              <Text style={Courselstyles.buyText}>{item.orders}</Text>
              <Text style={Courselstyles.buyText}>{item.bid}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  const sellView = () => {
    return (
      <View style={Courselstyles.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={Courselstyles.ordersHeaderText}>Ask</Text>
          <Text style={Courselstyles.ordersHeaderText}>Orders</Text>
          <Text style={Courselstyles.ordersHeaderText}>Qty</Text>
        </View>
        <FlatList
          data={sellData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={Courselstyles.sellText}>{item.ask}</Text>
              <Text style={Courselstyles.sellText}>{item.orders}</Text>
              <Text style={Courselstyles.sellText}>{item.qty}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  // const renderItemList = React.memo(({item, index}: any) => {
  //   return (
  //     <>
  //       <View style={Courselstyles.subContainer}>
  //         <TouchableOpacity
  //           style={{
  //             height: '31%',
  //             width: '100%',
  //             backgroundColor: 'transperent',
  //           }}
  //           onPress={() => props.onCloseCarousel()}
  //           activeOpacity={1}
  //         />
  //         <View
  //           style={[
  //             Courselstyles.subContainertwo,
  //             {
  //               width: index === currentindex ? screenWidth * 0.73 : '100%',
  //             },
  //           ]}>
  //           <View style={Courselstyles.headerView}>
  //             <TouchableOpacity
  //               activeOpacity={1}
  //               onPress={() => {
  //                 navigation.navigate('Detail', {
  //                   detail: {item},
  //                 });
  //                 props.onCloseCarousel();
  //               }}>
  //               <Text style={Courselstyles.companyName_Value_Text}>
  //                 {item.companyName}
  //               </Text>
  //               <View style={Courselstyles.bsesty}>
  //                 <Text style={Courselstyles.txtsty}>{item.index}</Text>
  //                 <Entypo
  //                   name="chevron-small-down"
  //                   size={10}
  //                   color={root.color_text}
  //                   style={{marginTop: 3}}
  //                 />
  //               </View>
  //             </TouchableOpacity>

  //             <View>
  //               <Text
  //                 style={[
  //                   Courselstyles.companyName_Value_Text,
  //                   {textAlign: 'right'},
  //                 ]}>
  //                 {item.value}
  //               </Text>
  //               <Text style={Courselstyles.chaval}>{item.changes}</Text>
  //               <View style={Courselstyles.iconall}>
  //                 <MaterialCommunityIcons
  //                   name="bell-outline"
  //                   color={'black'}
  //                   size={23}
  //                 />
  //                 <TouchableOpacity
  //                   style={{borderWidth: 1.5, borderRadius: 25}}>
  //                   <Feather name="bar-chart-2" size={20} color="black" />
  //                 </TouchableOpacity>
  //               </View>
  //             </View>
  //           </View>
  //           {index === currentindex && (
  //             <Animated.View
  //               style={{
  //                 height: animationValue.current,
  //                 width: '100%',

  //               }}>
  //               <ScrollView
  //                 overScrollMode="always"
  //                 showsVerticalScrollIndicator={false}
  //                 style={Courselstyles.scrillview}>
  //                 {/* Header View */}

  //                 {/* Button View */}

  //                 <View style={Courselstyles.buttonContainer}>
  //                   <TouchableOpacity style={Courselstyles.buysty}>
  //                     <Text style={Courselstyles.buy_sell_Text}>Buy</Text>
  //                   </TouchableOpacity>
  //                   <TouchableOpacity style={Courselstyles.sellsty}>
  //                     <Text style={Courselstyles.buy_sell_Text}>Sell</Text>
  //                   </TouchableOpacity>
  //                 </View>
  //                 {/* Button View Ends */}
  //                 {/* Orders List View */}
  //                 <View style={Courselstyles.ordersView}>
  //                   {buyView()}
  //                   {sellView()}
  //                 </View>
  //                 {/* Orders List View Ends */}
  //                 {/* Total Bids View */}
  //                 <View style={{...alignment.row_SpaceB, marginTop: '5%'}}>
  //                   <Text style={Courselstyles.Bidtxt}>Total Bids</Text>
  //                   <Text style={Courselstyles.Bidtxt}>Total Asks</Text>
  //                 </View>

  //                 <View style={Courselstyles.progressMain}>
  //                   <View style={Courselstyles.progressOuter}>
  //                     <Text style={Courselstyles.perplus}>10</Text>
  //                   </View>

  //                   <Text style={Courselstyles.negtxt}>30</Text>
  //                 </View>
  //                 <View style={Courselstyles.oneflex}>
  //                   {courselDemodata.map(item => {
  //                     return (
  //                       <View>
  //                         <Text style={Courselstyles.txttitle}>
  //                           {item.title}
  //                         </Text>
  //                         <Text style={Courselstyles.txtval}>{item.value}</Text>
  //                         <Text style={Courselstyles.txtval}>
  //                           {item.valuetwo}
  //                         </Text>
  //                       </View>
  //                     );
  //                   })}
  //                 </View>
  //                 <View style={Courselstyles.twoflex}>
  //                   {progressData.map(item => {
  //                     return (
  //                       <View style={Courselstyles.over}>
  //                         <Text style={Courselstyles.prtitle}>
  //                           {item.title}
  //                         </Text>
  //                         <View style={Courselstyles.prline} />
  //                         <View style={Courselstyles.txtallign}>
  //                           <Text style={Courselstyles.prval}>
  //                             {item.price}
  //                           </Text>
  //                           <Text style={Courselstyles.prval}>
  //                             {item.pricetwo}
  //                           </Text>
  //                         </View>
  //                       </View>
  //                     );
  //                   })}
  //                 </View>
  //                 <View style={Courselstyles.threeflex}>
  //                   {endDemodata.map(item => {
  //                     return (
  //                       <View style={Courselstyles.endstyle}>
  //                         <Text style={Courselstyles.txttitle}>
  //                           {item.title}
  //                         </Text>
  //                         <Text style={Courselstyles.txtval}>{item.value}</Text>
  //                       </View>
  //                     );
  //                   })}
  //                 </View>

  //                 {/* End total Bids View */}
  //                 {/* <Button title="Close" onPress={() => props.onCloseCarousel()} /> */}
  //               </ScrollView>
  //             </Animated.View>
  //           )}
  //         </View>
  //       </View>
  //     </>
  //   );
  // });

  const renderItemList = ({item, index}: any) => {
    return (
      <>
        <View style={Courselstyles.subContainer}>
          <TouchableOpacity
            style={{
              height: '31%',
              width: '100%',
              backgroundColor: 'transperent',
            }}
            onPress={() => props.onCloseCarousel()}
            activeOpacity={1}
          />
          <View
            style={[
              Courselstyles.subContainertwo,
              {
                width: index === currentindex ? screenWidth * 0.73 : '100%',
              },
            ]}>
            <View style={Courselstyles.headerView}>
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => {
                  navigation.navigate('Detail', {
                    detail: {item},
                  });
                  props.onCloseCarousel();
                }}>
                <Text style={Courselstyles.companyName_Value_Text}>
                  {item.companyName}
                </Text>
                <View style={Courselstyles.bsesty}>
                  <Text style={Courselstyles.txtsty}>{item.index}</Text>
                  <Entypo
                    name="chevron-small-down"
                    size={10}
                    color={root.color_text}
                    style={{marginTop: 3}}
                  />
                </View>
              </TouchableOpacity>

              <View>
                <Text
                  style={[
                    Courselstyles.companyName_Value_Text,
                    {textAlign: 'right'},
                  ]}>
                  {item.value}
                </Text>
                <Text style={Courselstyles.chaval}>{item.changes}</Text>
                <View style={Courselstyles.iconall}>
                  <MaterialCommunityIcons
                    name="bell-outline"
                    color={'black'}
                    size={23}
                  />
                  <TouchableOpacity
                    style={{borderWidth: 1.5, borderRadius: 25}}>
                    <Feather name="bar-chart-2" size={20} color="black" />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            {index === currentindex && (
              <Animated.View
                style={{
                  height: animationValue.current,
                  width: '100%',
                }}>
                <ScrollView
                  overScrollMode="always"
                  showsVerticalScrollIndicator={false}
                  style={Courselstyles.scrillview}>
                  {/* Header View */}

                  {/* Button View */}

                  <View style={Courselstyles.buttonContainer}>
                    <TouchableOpacity style={Courselstyles.buysty}>
                      <Text style={Courselstyles.buy_sell_Text}>Buy</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={Courselstyles.sellsty}>
                      <Text style={Courselstyles.buy_sell_Text}>Sell</Text>
                    </TouchableOpacity>
                  </View>
                  {/* Button View Ends */}
                  {/* Orders List View */}
                  <View style={Courselstyles.ordersView}>
                    {buyView()}
                    {sellView()}
                  </View>
                  {/* Orders List View Ends */}
                  {/* Total Bids View */}
                  <View style={{...alignment.row_SpaceB, marginTop: '5%'}}>
                    <Text style={Courselstyles.Bidtxt}>Total Bids</Text>
                    <Text style={Courselstyles.Bidtxt}>Total Asks</Text>
                  </View>

                  <View style={Courselstyles.progressMain}>
                    <View style={Courselstyles.progressOuter}>
                      <Text style={Courselstyles.perplus}>10</Text>
                    </View>

                    <Text style={Courselstyles.negtxt}>30</Text>
                  </View>
                  <View style={Courselstyles.oneflex}>
                    {courselDemodata.map(item => {
                      return (
                        <View>
                          <Text style={Courselstyles.txttitle}>
                            {item.title}
                          </Text>
                          <Text style={Courselstyles.txtval}>{item.value}</Text>
                          <Text style={Courselstyles.txtval}>
                            {item.valuetwo}
                          </Text>
                        </View>
                      );
                    })}
                  </View>
                  <View style={Courselstyles.twoflex}>
                    {progressData.map(item => {
                      return (
                        <View style={Courselstyles.over}>
                          <Text style={Courselstyles.prtitle}>
                            {item.title}
                          </Text>
                          <View style={Courselstyles.prline} />
                          <View style={Courselstyles.txtallign}>
                            <Text style={Courselstyles.prval}>
                              {item.price}
                            </Text>
                            <Text style={Courselstyles.prval}>
                              {item.pricetwo}
                            </Text>
                          </View>
                        </View>
                      );
                    })}
                  </View>
                  <View style={Courselstyles.threeflex}>
                    {endDemodata.map(item => {
                      return (
                        <View style={Courselstyles.endstyle}>
                          <Text style={Courselstyles.txttitle}>
                            {item.title}
                          </Text>
                          <Text style={Courselstyles.txtval}>{item.value}</Text>
                        </View>
                      );
                    })}
                  </View>

                  {/* End total Bids View */}
                  {/* <Button title="Close" onPress={() => props.onCloseCarousel()} /> */}
                </ScrollView>
              </Animated.View>
            )}
          </View>
        </View>
      </>
    );
  };

  return (
    <Carousel
      style={Courselstyles.container}
      width={screenWidth}
      defaultIndex={props.index}
      data={props.listData}
      renderItem={renderItemList}
      onSnapToItem={index => {
        setCurrentindex(index);
        jump();
      }}
      mode="parallax"
      modeConfig={{
        parallaxScrollingScale: 1,
        parallaxScrollingOffset: 40,
      }}
      panGestureHandlerProps={{
        activeOffsetX: [-50, 50],
      }}
    />
  );
}

export default CarouselList;

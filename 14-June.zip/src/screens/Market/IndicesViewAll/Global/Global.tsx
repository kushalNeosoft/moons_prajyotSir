import React, {useEffect} from 'react';
import {View, Text, FlatList, ScrollView} from 'react-native';
import BoxIndicesComponent from '../Component/BoxComponent';
import {globalScreen} from '../../../../theme/light';
import {useSelector, useDispatch} from 'react-redux';
import ScreenFilter from '../Component/ScreenFilter';
import {resetIndicesViewAllFilter} from '../../../../redux/Action';
import {useIsFocused} from '@react-navigation/native';
const Global = () => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const data = useSelector(state => state?.Reducer?.favouritesStock);
  const filter = useSelector(state => state?.Reducer?.indicesViewAllfilter);

  useEffect(() => {
    if (isFocused) {
    }
    return () => {
      dispatch(resetIndicesViewAllFilter());
    };
  }, [isFocused, dispatch]);
  const globalData = [
    {
      title: 'Nifty 50',
      price: '17600.75',
      changes: '-58.40(-0.34%)',
      percent: '-0.34%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'East Israel',
      indexId: 20,
    },
    {
      title: 'Nifty NEXT',
      price: '17600.75',
      changes: '+58.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'East Israel',
      indexId: 21,
    },
    {
      title: 'SENSEX',
      price: '12500.75',
      changes: '-42.40(-0.14%)',
      percent: '-0.14%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'Brazil',
      indexId: 22,
    },
    {
      title: 'Bovespa',
      price: '12500.75',
      changes: '-42.40(-0.38%)',
      percent: '-0.38%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'Brazil',
      indexId: 23,
    },
    {
      title: 'NIFTY MNC',
      price: '12500.75',
      changes: '-42.40(-0.24%)',
      percent: '-0.24%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'Sri Lanka',
      indexId: 24,
    },
    {
      title: 'ATX',
      price: '12500.75',
      changes: '-42.40(-0.64%)',
      percent: '-0.64%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'Sri Lanka',
      indexId: 25,
    },
    {
      title: 'NIFTY NEXT 50',
      price: '12500.75',
      changes: '-42.40(-0.74%)',
      percent: '-0.74%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'india',
      indexId: 26,
    },
    {
      title: 'NIFTY PHARMA',
      price: '12500.75',
      changes: '-42.40(-0.84%)',
      percent: '-0.84%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'india',
      indexId: 27,
    },
    {
      title: 'NIFTY BANK',
      price: '12500.75',
      changes: '-42.40(-0.28%)',
      percent: '-0.28%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 28,
    },
    {
      title: 'NIFTY MIDCAP',
      price: '12500.75',
      changes: '-42.40(-0.29%)',
      percent: '-0.29%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 29,
    },

    {
      title: 'NIFTY IT',
      price: '12500.75',
      changes: '-42.40(-0.31%)',
      percent: '-0.31%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 30,
    },
    {
      title: 'NIFTY INFRA',
      price: '16500.75',
      changes: '+42.40(+0.72%)',
      percent: '+0.72%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 31,
    },
    {
      title: 'NIFTY PSE',
      price: '16500.75',
      changes: '+42.40(+0.14%)',
      percent: '+0.14%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 32,
    },
    {
      title: 'NIFTY SECTORE',
      price: '16500.75',
      changes: '+42.40(+0.14%)',
      percent: '+0.14%',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      country: 'United States',
      indexId: 33,
    },
    {
      title: 'LCTMCI',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'United States',
      indexId: 34,
    },
    {
      title: 'BSEPBI',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'United States',
      indexId: 35,
    },
    {
      title: 'ALLCAP',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'Canada',
      indexId: 36,
    },
    {
      title: 'ENERGY',
      price: '12500.75',
      changes: '-42.40(-0.14%)',
      percent: '-0.14%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'Canada',
      indexId: 37,
    },

    {
      title: 'FINSER',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'Lanka',
      indexId: 38,
    },
    {
      title: 'INDSTR',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'Lanka',
      indexId: 39,
    },
    {
      title: 'MIDSEL',
      price: '16500.75',
      changes: '+42.40(+0.34%)',
      percent: '+0.34%',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      country: 'Lanka',
      indexId: 40,
    },
    {
      title: 'MSX7N10YIR',
      price: '12500.75',
      changes: '-42.40(-0.14%)',
      percent: '-0.14%',
      date: '19 APR 23 01:2421',
      chip: 'nsecds',
      country: 'Lanka',
      indexId: 41,
    },
    {
      title: 'MSX7N10YIR',
      price: '12500.75',
      changes: '-42.40(-0.14%)',
      percent: '-0.14%',
      date: '19 APR 23 01:2421',
      chip: 'nsecds',
      country: 'Canada',
      indexId: 42,
    },
  ];

  const groupedData = {};

  globalData.forEach(item => {
    const country = item.country;
    if (groupedData[country]) {
      groupedData[country].push(item);
    } else {
      groupedData[country] = [item];
    }
  });

  const sections = Object.keys(groupedData).map(country => ({
    title: country,
    data: groupedData[country],
  }));

  console.log('sections', sections);

  const renderItem2 = ({item}: any) => {
    return (
      <BoxIndicesComponent
        title={item.title}
        price={item.price}
        changes={item.changes}
        date={item.date}
        indexId={item.indexId}
      />
    );
  };
  const renderItem = ({item}: any) => (
    <View>
      <Text style={globalScreen.countryText}>{item.title}</Text>
      <FlatList
        data={item.data}
        renderItem={renderItem2}
        keyExtractor={item => item.indexId.toString()}
        numColumns={2}
        style={globalScreen.innerFlatlist}
      />
    </View>
  );
  return (
    <ScrollView style={globalScreen.mainView}>
      {filter.length != 0 ? (
        <View style={globalScreen.filterView}>
          {<ScreenFilter type={filter?.Type} sortBy={filter?.SortBy} />}
        </View>
      ) : (
        <></>
      )}
      <FlatList
        data={sections}
        numColumns={2}
        renderItem={renderItem}
        contentContainerStyle={globalScreen.outerFlatlist}
        keyExtractor={(_, index) => `item-${index}`}
        // style={{paddingHorizontal: 13}}
      />
    </ScrollView>
  );
};
export default Global;

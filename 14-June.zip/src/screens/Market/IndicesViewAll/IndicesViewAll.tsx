import React, {useRef, useState} from 'react';
import {View, Text, TouchableOpacity, TouchableHighlight} from 'react-native';
import {indicesViewAll} from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import MyFavourites from './MyFavourites/MyFavourites';
import Local from './Local/Local';
import Global from './Global/Global';
import SortFilterBottomSheet from '../../../components/BottomSheet/SortFilterBottomSheet';
import IndexFilter from './Component/IndexFilter';
import IndicesViewAllTopBar from './Component/TopTab';
const IndicesViewAll = () => {
  const navigation = useNavigation();
  const buttons = ['My Favourites', 'Local', 'Global'];
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const bottomSheetRef = useRef<BottomSheet>(null);
  const [sortData, setSortData] = useState('');

  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  const MyfavFunc = () => {
    return <MyFavourites />;
  };

  const LocalFunc = () => {
    return <Local />;
  };

  const GlobalFunc = () => {
    return <Global />;
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return MyfavFunc();
      case buttons[1]:
        return LocalFunc();
      case buttons[2]:
        return GlobalFunc();
    }
  };

  const renderBtn = () => {
    return (
      <View style={indicesViewAll.tabBarContainer}>
        {buttons &&
          buttons.map((btn, key) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? indicesViewAll.selectedTabBtns
                    : indicesViewAll.unSelectedTabBtns
                }
                // onPress={() => props.onPressSelectedBtn(key)}
                onPress={() => setSelectedBtn(key)}>
                <Text
                  style={
                    selectedBtn === key
                      ? indicesViewAll.selectedBtnText
                      : indicesViewAll.tabBtnsText
                  }>
                  {btn}
                </Text>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };
  return (
    <View style={indicesViewAll.mainView}>
      <View style={indicesViewAll.header}>
        <View style={indicesViewAll.headerTextIconView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="arrowleft" style={indicesViewAll.backIcon} />
          </TouchableOpacity>
          <Text style={indicesViewAll.headerText}>Indices</Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            bottomSheetRef?.current?.snapToIndex?.(0);
          }}>
          <Ionicons name="options-sharp" style={indicesViewAll.filterIcon} />
        </TouchableOpacity>
      </View>

      {/* {renderBtn()}
      {renderView(buttons[selectedBtn])} */}
      <IndicesViewAllTopBar />
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        index={-1}
        closesheet={closeSheet}>
        <IndexFilter bottomSheetRef={bottomSheetRef} />
      </SortFilterBottomSheet>
    </View>
  );
};
export default IndicesViewAll;

import React, {useEffect, useState} from 'react';
import {View, FlatList, ScrollView} from 'react-native';
import {myFavouritesScreen} from '../../../../theme/light';
import BoxIndicesComponent from '../Component/BoxComponent';
import {useSelector, useDispatch} from 'react-redux';
import ScreenFilter from '../Component/ScreenFilter';
import {resetIndicesViewAllFilter} from '../../../../redux/Action';
import {useIsFocused} from '@react-navigation/native';
import {DataTable} from 'react-native-paper';

const MyFavourites = () => {
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const data = useSelector(state => state?.Reducer?.favouritesStock);
  const filter = useSelector(state => state?.Reducer?.indicesViewAllfilter);
  const [filteredArr, setfilteredArr] = useState([...data]);
  console.log('filteredArr', filteredArr);
  console.log('filter.Type', filter?.Type);
  console.log('filter.sortBy', filter?.SortBy);
  // console.log('data', data);

  function applyFilter() {
    const arr = [...data];
    if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'Z-A') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.title.toUpperCase();
        const titleB = b.title.toUpperCase();
        if (titleA > titleB) {
          return -1;
        }
        if (titleA < titleB) {
          return 1;
        }
        return 0;
      });

      setfilteredArr(newData);
    } else if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'A-Z') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.title.toUpperCase();
        const titleB = b.title.toUpperCase();
        if (titleA < titleB) {
          return -1;
        }
        if (titleA > titleB) {
          return 1;
        }
        return 0;
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'High to Low') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA > priceB) {
          return -1;
        } else if (priceA < priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'Low to High') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA < priceB) {
          return -1;
        } else if (priceA > priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'Low to High'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA < percentB) {
          return -1;
        } else if (percentA > percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
      console.log('newdata', newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'High to Low'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA > percentB) {
          return -1;
        } else if (percentA < percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
      console.log('newdata', newData);
    }
  }
  useEffect(() => {
    setfilteredArr([...data]);
  }, [data]);

  useEffect(() => {
    applyFilter();
  }, [filter?.Type, filter?.SortBy]);

  useEffect(() => {
    if (isFocused) {
    }
    return () => {
      dispatch(resetIndicesViewAllFilter());
    };
  }, [isFocused, dispatch]);
  const renderItem = ({item}: any) => {
    return (
      <BoxIndicesComponent
        title={item?.title}
        price={item?.price}
        changes={item?.changes}
        date={item?.date}
        indexId={item.indexId}
        percent={item.percent}
      />
    );
  };
  return (
    <ScrollView style={myFavouritesScreen.mainView}>
      {filter.length != 0 ? (
        <View style={myFavouritesScreen.filterView}>
          {<ScreenFilter type={filter?.Type} sortBy={filter?.SortBy} />}
        </View>
      ) : (
        <></>
      )}
      <FlatList
        data={filteredArr}
        numColumns={2}
        renderItem={renderItem}
        contentContainerStyle={{
          marginTop: filter.length != 0 ? 31 : 41,
          paddingBottom: 20,
        }}
        keyExtractor={(_, index) => `item-${index}`}
        // style={{paddingHorizontal: 13}}
      />
    </ScrollView>
  );
};
export default MyFavourites;

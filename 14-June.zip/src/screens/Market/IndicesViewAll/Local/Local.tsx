import React, {useEffect, useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, ScrollView} from 'react-native';
import BoxIndicesComponent from '../Component/BoxComponent';
import {localScreen} from '../../../../theme/light';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useSelector, useDispatch} from 'react-redux';
import ScreenFilter from '../Component/ScreenFilter';
import {resetIndicesViewAllFilter} from '../../../../redux/Action';
import {useIsFocused} from '@react-navigation/native';

const localData = [
  {
    title: 'Nifty 50',
    price: '17600.75',
    changes: '+58.40(+0.34%)',
    percent: '+0.34%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 1,
  },
  {
    title: 'SENSEX',
    price: '12500.75',
    changes: '-42.40(-0.14%)',
    percent: '-0.14%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 2,
  },
  {
    title: 'NIFTY MNC',
    price: '12600.75',
    changes: '-43.40(-0.20%)',
    percent: '-0.20%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 3,
  },
  {
    title: 'NIFTY NEXT 50',
    price: '12700.75',
    changes: '-44.40(-0.30%)',
    percent: '-0.30%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 4,
  },
  {
    title: 'NIFTY PHARMA',
    price: '12800.75',
    changes: '-45.40(-0.50%)',
    percent: '-0.50%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 5,
  },
  {
    title: 'NIFTY BANK',
    price: '12900.75',
    changes: '-46.40(-0.60%)',
    percent: '-0.60%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 6,
  },
  {
    title: 'NIFTY MIDCAP',
    price: '12100.75',
    changes: '-47.40(-0.70%)',
    percent: '-0.70%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 7,
  },
  {
    title: 'NIFTY IT',
    price: '12200.75',
    changes: '-42.40(-0.80%)',
    percent: '-0.80%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 8,
  },
  {
    title: 'NIFTY INFRA',
    price: '16500.75',
    changes: '+42.40(+0.20%)',
    percent: '+0.20%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 9,
  },
  {
    title: 'NIFTY PSE',
    price: '16500.75',
    changes: '+43.40(+0.30%)',
    percent: '+0.30%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 10,
  },
  {
    title: 'NIFTY SECTORE',
    price: '16500.75',
    changes: '+44.40(+0.40%)',
    percent: '+0.40%',
    date: '19 APR 23 01:2421',
    chip: 'nse',
    indexId: 11,
  },
  {
    title: 'LCTMCI',
    price: '16500.75',
    changes: '+42.40(+0.10%)',
    percent: '+0.10%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 12,
  },
  {
    title: 'BSEPBI',
    price: '16500.75',
    changes: '+43.40(+0.25%)',
    percent: '+0.25%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 13,
  },
  {
    title: 'ALLCAP',
    price: '16500.75',
    changes: '+44.40(+0.35%)',
    percent: '+0.35%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 14,
  },
  {
    title: 'ENERGY',
    price: '12500.75',
    changes: '-42.40(-0.14%)',
    percent: '-0.14%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 15,
  },

  {
    title: 'FINSER',
    price: '16500.75',
    changes: '+42.40(+0.32%)',
    percent: '+0.32%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 16,
  },
  {
    title: 'INDSTR',
    price: '16500.75',
    changes: '+55.40(+0.42%)',
    percent: '+0.42%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 17,
  },
  {
    title: 'MIDSEL',
    price: '16500.75',
    changes: '+48.40(+0.62%)',
    percent: '+0.62%',
    date: '19 APR 23 01:2421',
    chip: 'bse',
    indexId: 18,
  },
  {
    title: 'MSX7N10YIR',
    price: '12500.75',
    changes: '-44.40(-0.34%)',
    percent: '-0.34%',
    date: '19 APR 23 01:2421',
    chip: 'nsecds',
    indexId: 19,
  },
];

const Local = () => {
  const chipData = ['NSE', 'BSE', 'NSECDS'];
  const [dropDownChip, setDropDownChip] = useState<string>(chipData[0]);
  const [dropDown, setDropDown] = useState<boolean>(false);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();
  const filter = useSelector(state => state?.Reducer?.indicesViewAllfilter);
  const [filteredArr, setfilteredArr] = useState([...localData]);

  useEffect(() => {
    if (isFocused) {
    }
    return () => {
      dispatch(resetIndicesViewAllFilter());
    };
  }, [isFocused, dispatch]);

  function applyFilter() {
    const arr = [...filteredArr];
    if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'Z-A') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.title.toUpperCase();
        const titleB = b.title.toUpperCase();
        if (titleA > titleB) {
          return -1;
        }
        if (titleA < titleB) {
          return 1;
        }
        return 0;
      });

      setfilteredArr(newData);
    } else if (filter?.Type == 'Alphabetically' && filter?.SortBy == 'A-Z') {
      const newData = arr?.slice().sort((a, b) => {
        const titleA = a.title.toUpperCase();
        const titleB = b.title.toUpperCase();
        if (titleA < titleB) {
          return -1;
        }
        if (titleA > titleB) {
          return 1;
        }
        return 0;
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'High to Low') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA > priceB) {
          return -1;
        } else if (priceA < priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (filter?.Type == 'Price' && filter?.SortBy == 'Low to High') {
      const newData = arr?.slice().sort((a, b) => {
        const priceA = parseFloat(a.price);
        const priceB = parseFloat(b.price);

        if (priceA < priceB) {
          return -1;
        } else if (priceA > priceB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'Low to High'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA < percentB) {
          return -1;
        } else if (percentA > percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
      console.log('newdata', newData);
    } else if (
      filter?.Type == 'Percentage' &&
      filter?.SortBy == 'High to Low'
    ) {
      const newData = arr?.slice().sort((a, b) => {
        const percentA = parseFloat(a.percent?.replace(/[^0-9.-]/g, ''));
        const percentB = parseFloat(b.percent?.replace(/[^0-9.-]/g, ''));

        if (percentA > percentB) {
          return -1;
        } else if (percentA < percentB) {
          return 1;
        } else {
          return 0;
        }
      });
      setfilteredArr(newData);
      console.log('newdata', newData);
    }
  }
  useEffect(() => {
    applyFilter();
  }, [filter?.Type, filter?.SortBy]);

  useEffect(() => {
    let arr = [...localData];
    arr = arr.filter((item, index) => {
      return item.chip.toLowerCase() == dropDownChip.toLowerCase();
    });

    setfilteredArr(arr);
  }, [dropDownChip]);

  const renderItem = ({item}: any) => {
    return (
      <BoxIndicesComponent
        title={item.title}
        price={item.price}
        changes={item.changes}
        date={item.date}
        indexId={item?.indexId}
        percent={item.percent}
      />
    );
  };

  const chipRenderItem = ({item}: any) => {
    return (
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          setDropDownChip(item);
          setDropDown(false);
        }}>
        <Text
          style={
            localScreen({dropDownChip: dropDownChip, Item: item}).dropDownItems
          }>
          {item}
        </Text>
      </TouchableOpacity>
    );
  };
  return (
    <ScrollView style={localScreen().mainView}>
      <View style={{zIndex: 100}}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <TouchableOpacity
            activeOpacity={0.6}
            onPress={() => {
              setDropDown(!dropDown);
            }}
            style={localScreen().dropDown}>
            <Text style={localScreen().dropDownText}>{dropDownChip}</Text>
            <MaterialIcons
              name="keyboard-arrow-down"
              style={localScreen().arrowIcon}
            />
          </TouchableOpacity>
          {filter.length != 0 ? (
            <View style={localScreen().filterView}>
              {<ScreenFilter type={filter?.Type} sortBy={filter?.SortBy} />}
            </View>
          ) : (
            <></>
          )}
        </View>
        {dropDown ? (
          <View style={localScreen().dropDownListView}>
            <FlatList
              data={chipData}
              renderItem={chipRenderItem}
              contentContainerStyle={{marginBottom: 2, paddingTop: 2}}
              keyExtractor={(_, index) => `item-${index}`}
            />
          </View>
        ) : (
          <></>
        )}
      </View>
      <FlatList
        data={filteredArr}
        numColumns={2}
        renderItem={renderItem}
        contentContainerStyle={{
          marginTop: 25,
          paddingBottom: 30,
        }}
        // keyExtractor={(_, index) => `item-${index}`}

        // style={{paddingHorizontal: 13}}
        // dropDownChip == 'NSE'
        // ? nseData
        // : dropDownChip == 'BSE'
        // ? bseData
        // : nsecdsData
      />
    </ScrollView>
  );
};
export default Local;

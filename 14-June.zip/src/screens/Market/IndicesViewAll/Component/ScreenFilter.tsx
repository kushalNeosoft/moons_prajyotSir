import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {screenFilter} from '../../../../theme/light';
import {useDispatch} from 'react-redux';
import {resetIndicesViewAllFilter} from '../../../../redux/Action';

const ScreenFilter = props => {
  const dispatch = useDispatch();
  return (
    <View style={screenFilter.mainView}>
      <Text style={screenFilter.filterText}>Filters: </Text>
      <View style={screenFilter.filterDataView}>
        <Text style={screenFilter.filterTag}>{props?.type}</Text>
        <Text style={screenFilter.filterTagData}>{props?.sortBy}</Text>
        <TouchableOpacity
          onPress={() => {
            dispatch(resetIndicesViewAllFilter());
          }}>
          <Ionicons name="md-close-outline" style={screenFilter.closeIcon} />
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default ScreenFilter;

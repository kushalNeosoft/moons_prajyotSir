import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View, Dimensions} from 'react-native';
import {indexFilter} from '../../../../theme/light';
import {useDispatch} from 'react-redux';
import {
  indicesViewAllFilter,
  resetIndicesViewAllFilter,
} from '../../../../redux/Action';

const IndexFilter = props => {
  const dispatch = useDispatch();
  const [filterData, setFilterData] = useState('');
  const [type, setType] = useState('');
  const alphabet = ['A-Z', 'Z-A'];
  const price = ['High to Low', 'Low to High'];
  const percentage = ['High to Low', 'Low to High'];

  return (
    <View style={indexFilter().Maincon}>
      <View style={indexFilter().contentView}>
        <View style={indexFilter().space}>
          <View style={indexFilter().spaceinner}>
            <Text style={indexFilter().titleText}>Alphabetically</Text>
          </View>
          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => {
                  setFilterData(item);
                  setType('Alphabetically');
                }}
                style={
                  indexFilter({selected: filterData === item})
                    .commonAlphaSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={indexFilter().spacetwo}>
          <View style={indexFilter().spacetwoinner}>
            <Text style={indexFilter().titleText}>Price</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => {
                  setFilterData(item);
                  setType('Price');
                }}
                style={
                  indexFilter({selected: filterData === item, type: type})
                    .commonPriceSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        <View style={indexFilter().spacetwo}>
          <View style={indexFilter().spacetwoinner}>
            <Text style={indexFilter().titleText}>Percentage</Text>
          </View>

          <FlatList
            horizontal={true}
            data={percentage}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => {
                  setFilterData(item);
                  setType('Percentage');
                }}
                style={
                  indexFilter({
                    selected: filterData === item,
                    type: type,
                  }).commonPercentageSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>

      <TouchableOpacity
        disabled={filterData == '' ? true : false}
        style={indexFilter().applyBtn}
        onPress={() => {
          // dispatch(resetIndicesViewAllFilter());
          dispatch(
            indicesViewAllFilter({
              Type: type,
              SortBy: filterData,
            }),
          );
          setFilterData(''), setType('');
          props.bottomSheetRef?.current?.forceClose();
        }}>
        <Text style={indexFilter({FilterData: filterData}).applyBottonText}>
          Apply
        </Text>
      </TouchableOpacity>
    </View>
  );
};
export default IndexFilter;

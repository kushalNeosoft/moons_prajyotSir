import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import MyFavourites from '../MyFavourites/MyFavourites';
import Local from '../Local/Local';
import Global from '../Global/Global';
import {indicesViewAll} from '../../../../theme/light';

const Tab = createMaterialTopTabNavigator();

function IndicesViewAllTopBar() {
  return (
    <Tab.Navigator
      //   scrollEnabled={false}
      swipeEnabled={false}
      screenOptions={{
        lazy: true,
        tabBarLabelStyle: indicesViewAll.tabBarLabelStyle,
        tabBarStyle: indicesViewAll.tabBarStyle,
        tabBarIndicatorStyle: indicesViewAll.tabBarIndicatorStyle,
        tabBarActiveTintColor: '#25335C',
        tabBarInactiveTintColor: '#979797',
      }}>
      <Tab.Screen
        name="MyFav"
        component={MyFavourites}
        options={{tabBarLabel: 'My Favourites'}}
      />
      <Tab.Screen
        name="Local"
        component={Local}
        options={{tabBarLabel: 'Local'}}
      />
      <Tab.Screen
        name="Global"
        component={Global}
        options={{tabBarLabel: 'Global'}}
      />
    </Tab.Navigator>
  );
}
export default IndicesViewAllTopBar;

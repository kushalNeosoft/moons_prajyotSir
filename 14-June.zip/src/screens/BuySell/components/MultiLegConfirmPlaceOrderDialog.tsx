import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
//import {View, Text, TouchableOpacity, ScrollView, Modal} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalFour from '../../../components/CommonModal/CommonModalFour';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import AddIcon from '../../../assets/AddIcon';
import CommonModaltwo from '../../../components/CommonModal/CommonModaltwo';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  TouchableNativeFeedback,
} from 'react-native';

const MultiLegConfirmPlaceOrderDialog = (props: any) => {
  const {item, visible, onClose} = props;
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          height: '100%',
          backgroundColor: 'white',
          paddingHorizontal: 18,
          paddingVertical: 40,
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
              }}>
              Confirm Your
            </Text>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
              }}>
              Multileg Order
            </Text>
          </View>
          <ScrollView style={{flex: 1}}>
            <View style={{flex: 1}}>
              <View style={{marginTop: 20}}>
                <Text
                  style={{
                    fontSize: 14,
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                  }}>
                  Validity :{' '}
                  <Text
                    style={{
                      fontSize: 14,
                      color: root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    IOC
                  </Text>
                </Text>
              </View>
              <View
                style={{marginTop: 32, flexDirection: 'row', width: '100%'}}>
                <Text
                  style={{
                    flex: 2.5,
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                  }}>
                  Script Name
                </Text>
                <Text
                  style={{
                    flex: 1,
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                    textAlign: 'center',
                  }}>
                  Qty
                </Text>
                <Text
                  style={{
                    flex: 1,
                    textAlign: 'center',
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                  }}>
                  Type
                </Text>
                <Text
                  style={{
                    flex: 1,
                    textAlign: 'right',
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                  }}>
                  Price
                </Text>
              </View>
              <View
                style={{
                  marginTop: 8,
                  height: 1,
                  backgroundColor: 'lightgrey',
                }}></View>
              {props.legs?.map((leg: any, index: any) => {
                return (
                  <View
                    key={index}
                    style={{
                      marginTop: 8,
                      flexDirection: 'row',
                      width: '100%',
                    }}>
                    <Text
                      style={{
                        flex: 2.5,
                        fontWeight: 'bold',
                        fontFamily: Cfont.rubik_regular,
                        color: root.color_text,
                      }}>
                      {leg.name}
                    </Text>
                    <View style={{flex: 1}}>
                      <Text
                        style={{
                          textAlign: 'center',
                          fontFamily: Cfont.rubik_regular,
                          color: root.color_text,
                        }}>
                        {leg.lots} Lots
                      </Text>
                      <Text style={{textAlign: 'center'}}>15</Text>
                    </View>
                    <Text
                      style={{
                        flex: 1,
                        color: leg.operation === 'BUY' ? 'green' : 'red',
                        textAlign: 'center',
                      }}>
                      {leg.operation}
                    </Text>
                    <Text
                      style={{
                        flex: 1,
                        textAlign: 'right',
                        fontFamily: Cfont.rubik_regular,
                        color: root.color_text,
                      }}>
                      {leg.price}
                    </Text>
                  </View>
                );
              })}
            </View>
          </ScrollView>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              props.onConfirm();
            }}>
            <Text
              style={{
                paddingHorizontal: 16,
                paddingVertical: 10,
                backgroundColor: root.client_background,
                fontSize: 16,
                color: 'white',
                borderRadius: 8,
                textAlign: 'center',
                marginTop: 16,
                fontFamily: Cfont.rubik_semibold,
              }}>
              Confirm Order
            </Text>
          </TouchableNativeFeedback>
        </View>
      </View>
    </Modal>
  );
};
export default MultiLegConfirmPlaceOrderDialog;

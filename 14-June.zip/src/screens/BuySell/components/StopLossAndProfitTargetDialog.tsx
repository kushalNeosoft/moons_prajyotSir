import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  TouchableNativeFeedback,
  TextInput,
} from 'react-native';
import InfoIcon from '../../../assets/InfoIcon';
import {Popable} from 'react-native-popable';

const StopLossAndProfitTargetDialog = (props: any) => {
  const {item, visible, onClose} = props;
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: '75%',
          backgroundColor: 'white',
          paddingHorizontal: 18,
          paddingVertical: 16,
          borderTopLeftRadius: 16,
          borderTopRightRadius: 16,
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View>
            <Text
              style={{
                fontSize: 20,
                fontWeight: 'bold',
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
              }}>
              Add Stop Loss And Profit Target
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontFamily: Cfont.rubik_medium,
                marginTop: 4,
              }}>
              Stop Loss and Profit Target helps secure your order and reduce
              margin
            </Text>
            <Text style={{marginTop: 4}}>Buy INFY1 @ 123 (1243)</Text>
          </View>
          <ScrollView style={{flex: 1}}>
            <View style={{flex: 1}}>
              <View style={{marginTop: 16}}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: root.color_text,
                      fontWeight: 'bold',
                      marginRight: 8,
                    }}>
                    Set limit for loss (Cover Order)
                  </Text>
                  <Popable
                    style={{
                      width: 300,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{
                        // marginLeft: 8,
                        width: 16,
                        height: 16,
                        color: 'black',
                        alignSelf: 'center',
                      }}
                    />
                  </Popable>
                </View>
                <View style={{flexDirection: 'row', marginTop: 8}}>
                  <View style={{flex: 1}}>
                    <Text
                      style={{
                        fontSize: 16,
                        color: root.color_text,
                        fontWeight: 'bold',
                      }}>
                      Trigger
                    </Text>
                    <TextInput
                      style={{
                        flex: 1,
                        borderBottomWidth: 2,
                        borderColor: 'lightgrey',
                        paddingVertical: 6,
                        paddingHorizontal: 0,
                        fontSize: 24,
                      }}
                      placeholder="0.00"
                      keyboardType="number-pad"
                    />
                    <Text
                      style={{
                        marginTop: 4,
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      Sell @ Market after Trigger
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      Range:{' '}
                      <Text style={{fontWeight: 'bold', color: 'black'}}>
                        12312-124
                      </Text>
                    </Text>
                  </View>
                  <View style={{width: 32}} />
                  <View style={{flex: 1}}>
                    <Text
                      style={{
                        fontSize: 16,
                        color: root.color_text,
                        fontWeight: 'bold',
                      }}>
                      Limit (Optional)
                    </Text>
                    <TextInput
                      style={{
                        flex: 1,
                        borderBottomWidth: 2,
                        borderColor: 'lightgrey',
                        paddingVertical: 6,
                        paddingHorizontal: 0,
                        fontSize: 24,
                      }}
                      placeholder="0.00"
                      keyboardType="number-pad"
                    />
                    <Text
                      style={{
                        marginTop: 4,
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      Sell upto limit after trigger
                    </Text>
                    <Text
                      style={{
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      Range:{' '}
                      <Text style={{fontWeight: 'bold', color: 'black'}}>
                        12312-124
                      </Text>
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: 16,
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: root.color_text,
                      fontWeight: 'bold',
                      marginRight: 8,
                    }}>
                    Move Stop Loss as per price (Trailing SL)
                  </Text>
                  <Popable
                    style={{
                      width: 300,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{
                        // marginLeft: 8,
                        width: 16,
                        height: 16,
                        color: 'black',
                        alignSelf: 'center',
                      }}
                    />
                  </Popable>
                </View>
                <View style={{flexDirection: 'row', marginTop: 8}}>
                  <View style={{flex: 1}}>
                    <Text
                      style={{
                        fontSize: 16,
                        color: root.color_text,
                        fontWeight: 'bold',
                      }}>
                      Price Change
                    </Text>
                    <TextInput
                      style={{
                        flex: 1,
                        borderBottomWidth: 2,
                        borderColor: 'lightgrey',
                        paddingVertical: 6,
                        paddingHorizontal: 0,
                        fontSize: 24,
                      }}
                      placeholder="0.00"
                      keyboardType="number-pad"
                    />
                    <Text
                      style={{
                        marginTop: 4,
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      If Price changed by
                    </Text>
                  </View>
                  <View style={{width: 32}} />
                  <View style={{flex: 1}}>
                    <Text
                      style={{
                        fontSize: 16,
                        color: root.color_text,
                        fontWeight: 'bold',
                      }}>
                      Trailing Stop Loss
                    </Text>
                    <TextInput
                      style={{
                        flex: 1,
                        borderBottomWidth: 2,
                        borderColor: 'lightgrey',
                        paddingVertical: 6,
                        paddingHorizontal: 0,
                        fontSize: 24,
                      }}
                      placeholder="0.00"
                      keyboardType="number-pad"
                    />
                    <Text
                      style={{
                        marginTop: 4,
                        fontSize: 12,
                        color: root.color_text,
                      }}>
                      then trail stop loss by
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    marginTop: 16,
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: root.color_text,
                      fontWeight: 'bold',
                      marginRight: 8,
                    }}>
                    Set Target To Profit (Bracket Order)
                  </Text>

                  <Popable
                    style={{
                      width: 300,
                      padding: 11,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{
                        // marginLeft: 8,
                        width: 16,
                        height: 16,
                        color: 'black',
                        alignSelf: 'center',
                      }}
                    />
                  </Popable>
                </View>
              </View>
            </View>
          </ScrollView>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              props.onConfirm();
            }}>
            <Text
              style={{
                paddingHorizontal: 16,
                paddingVertical: 10,
                backgroundColor: root.client_background,
                fontSize: 16,
                color: 'white',
                borderRadius: 8,
                textAlign: 'center',
                marginTop: 16,
                fontFamily: Cfont.rubik_semibold,
              }}>
              Add
            </Text>
          </TouchableNativeFeedback>
        </View>
      </View>
    </Modal>
  );
};
export default StopLossAndProfitTargetDialog;

import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  Modal,
  TouchableNativeFeedback,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalFour from '../../../components/CommonModal/CommonModalFour';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import AddIcon from '../../../assets/AddIcon';
import CommonModaltwo from '../../../components/CommonModal/CommonModaltwo';
import CloseIcon from '../../../assets/CloseIcon';

const OrderSuccessDialog = (props: any) => {
  const {item, visible, onClose, legs} = props;
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          height: '100%',
          backgroundColor: 'white',
          paddingHorizontal: 18,
          paddingVertical: 30,
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View style={{flex: 1}}>
            <View
              style={{
                flexDirection: 'column',
                height: '100%',
                justifyContent: 'center',
                position: 'relative',
              }}>
              <View
                style={{
                  padding: 8,
                  height: 48,
                  width: 48,
                  alignSelf: 'center',
                  backgroundColor: root.client_background,
                  borderRadius: 24,
                }}>
                <AddIcon
                  style={{
                    height: 32,
                    width: 32,
                    color: 'white',
                    alignSelf: 'center',
                  }}
                />
              </View>

              {legs ? (
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 20,
                    textAlign: 'center',
                    color: root.color_text,
                    marginTop: 16,
                  }}>
                  You Multileg Order Constisting Of{' '}
                  {legs
                    .map((leg: any) => {
                      return leg.name;
                    })
                    .join(' & ')}{' '}
                  Has Been Placed Successfully
                </Text>
              ) : (
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 20,
                    textAlign: 'center',
                    color: root.color_text,
                    marginTop: 16,
                  }}>
                  You have placed an order to Buy 1 Share(s) Of{' '}
                  {props.item.stockName} @ {props.item.price}
                </Text>
              )}

              <Text
                style={{
                  textAlign: 'center',
                  marginTop: 46,
                  color: root.color_text,
                  fontFamily: Cfont.rubik_regular,
                }}>
                Order Id: MAGNKJD123
              </Text>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                onPress={() => {
                  props.onClose();
                }}>
                <View
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                  }}>
                  <CloseIcon
                    style={{
                      height: 32,
                      width: 32,
                      color: 'black',
                      alignSelf: 'center',
                    }}
                  />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          <Text
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              borderWidth: 1,
              borderColor: root.client_background,
              fontSize: 16,
              color: root.client_background,
              borderRadius: 8,
              fontWeight: 'bold',
              textAlign: 'center',
              marginTop: 16,
              fontFamily: Cfont.rubik_semibold,
            }}>
            View Order Status
          </Text>
        </View>
      </View>
    </Modal>
  );
};
export default OrderSuccessDialog;

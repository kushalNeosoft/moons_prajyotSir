import {
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import DropDownIcon from '../../../assets/DropDownIcon';
import MinusIcon from '../../../assets/MinusIcon';
import AddIcon from '../../../assets/AddIcon';
import ChooseFrequencyDialog from './ChooseFrequencyDialog';
import {useReducer, useState} from 'react';
import DatePickerDialog from './DatePickerDialog';
import moment from 'moment';
import React from 'react';
import {Cfont, root} from '../../../styles/colors';
import ExpandIcon from '../../../assets/ExpandIcon';
import AddLegDialog from './AddLegDialog';
import EditIcon from '../../../assets/EditIcon';
import {MultiLegAction, multiLegReducer} from '../../../redux/MultiLegRedux';
import ConfirmPlaceOrderDialog from './ConfirmPlaceOrderDialog';
import MultiLegConfirmPlaceOrderDialog from './MultiLegConfirmPlaceOrderDialog';
import OrderSuccessDialog from './OrderSuccessDialog';

const data = [
  {
    id: 1,
    name: 'NIFTY 27 JUL23 FUT',
    operation: 'BUY',
    lots: 1,
    edit: false,
    priceType: 'MARKET_PRICE',
    price: 1223,
  },
  {
    id: 2,
    name: 'NIFTY 27 JUL23 FUT',
    operation: 'SELL',
    lots: 2,
    edit: false,
    priceType: 'YOUR_PRICE',
    price: 1223,
  },
];

const MultilegOrder = ({operation, item}: any) => {
  const [chooseFrequencyVisible, setChooseFrequencyVisible] = useState(false);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [addLegVisible, setAddLegVisible] = useState(false);

  const [date, setDate] = useState<Date>();

  const [legs, dispatch] = useReducer(multiLegReducer, data);
  const [confirmOrderVisible, setConfirmOrderVisible] = useState(false);

  const [orderSuccessVisible, setOrderSuccessVisible] = useState(false);

  return (
    <View
      style={{
        flexDirection: 'column',
        flex: 1,
        // marginTop: 22,
        backgroundColor: '#FAFAFA',
      }}>
      <ScrollView style={{flex: 1, padding: 18}}>
        <View>
          {legs.map((leg: any, index: number) => {
            return (
              <View
                key={leg.id}
                style={{
                  backgroundColor: 'white',
                  padding: 16,
                  borderRadius: 8,
                  position: 'relative',
                  marginTop: index != 0 ? 16 : 0,
                }}>
                <View style={{flexDirection: 'row'}}>
                  <Text
                    style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                    {leg.name}
                  </Text>
                  <View style={{alignSelf: 'center', marginLeft: 16}}>
                    <Text
                      style={{
                        backgroundColor: '#EEE7E7',
                        color: root.client_background,
                        fontFamily: Cfont.rubik_medium,
                        paddingHorizontal: 1,
                        paddingVertical: 1,
                        fontSize: 8,
                      }}>
                      NSE
                    </Text>
                  </View>
                </View>
                {!leg.edit ? (
                  <Text style={{fontSize: 14}}>
                    <Text
                      style={{color: leg.operation == 'BUY' ? 'green' : 'red'}}>
                      {leg.operation}:{' '}
                    </Text>
                    {leg.lots}Lot (50) @{leg.price}
                  </Text>
                ) : (
                  <View style={{marginTop: 16}}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}>
                      <View
                        style={{
                          flexDirection: 'row',
                          borderWidth: 1,
                          borderColor: 'lightgrey',
                          borderRadius: 16,
                        }}>
                        <View style={{borderRadius: 15, overflow: 'hidden'}}>
                          <TouchableNativeFeedback
                            background={TouchableNativeFeedback.Ripple(
                              '#90CAF9',
                              false,
                            )}
                            onPress={() => {
                              // navigation.goBack();
                              dispatch({
                                type: MultiLegAction.UPDATE_OPERATION,
                                payload: {
                                  id: leg.id,
                                  operation: 'BUY',
                                },
                              });
                            }}>
                            <View>
                              <Text
                                style={{
                                  fontSize: 11,
                                  fontFamily: Cfont.rubik_medium,
                                  paddingVertical: 6,
                                  paddingHorizontal: 12,
                                  backgroundColor:
                                    leg.operation == 'BUY'
                                      ? root.color_positive
                                      : 'transparent',
                                  borderRadius: 16,
                                  color:
                                    leg.operation == 'BUY'
                                      ? 'white'
                                      : root.color_text,
                                }}>
                                BUY
                              </Text>
                            </View>
                          </TouchableNativeFeedback>
                        </View>

                        <View
                          style={{
                            borderRadius: 15,
                            overflow: 'hidden',
                          }}>
                          <TouchableNativeFeedback
                            background={TouchableNativeFeedback.Ripple(
                              '#90CAF9',
                              false,
                            )}
                            onPress={() => {
                              // setOperation('SELL');
                              // navigation.goBack();
                              dispatch({
                                type: MultiLegAction.UPDATE_OPERATION,
                                payload: {
                                  id: leg.id,
                                  operation: 'SELL',
                                },
                              });
                            }}>
                            <View>
                              <Text
                                style={{
                                  fontSize: 11,
                                  fontFamily: Cfont.rubik_medium,
                                  paddingVertical: 6,
                                  paddingHorizontal: 8,
                                  borderRadius: 16,
                                  backgroundColor:
                                    leg.operation == 'SELL'
                                      ? root.color_negative
                                      : 'transparent',
                                  color:
                                    leg.operation == 'SELL'
                                      ? 'white'
                                      : root.color_text,
                                }}>
                                SELL
                              </Text>
                            </View>
                          </TouchableNativeFeedback>
                        </View>
                      </View>
                      <View
                        style={{flexDirection: 'row', alignItems: 'center'}}>
                        <Text style={{marginRight: 8}}>Lots</Text>
                        <TouchableNativeFeedback
                          background={TouchableNativeFeedback.Ripple(
                            '#90CAF9',
                            false,
                          )}
                          onPress={() => {
                            dispatch({
                              type: MultiLegAction.UPDATE_LOT,
                              payload: {
                                id: leg.id,
                                lots: leg.lots - 1,
                              },
                            });
                          }}>
                          <View style={{padding: 4}}>
                            <MinusIcon
                              style={{width: 16, height: 16, color: 'black'}}
                            />
                          </View>
                        </TouchableNativeFeedback>
                        <Text style={{marginHorizontal: 16}}>{leg.lots}</Text>
                        <TouchableNativeFeedback
                          background={TouchableNativeFeedback.Ripple(
                            '#90CAF9',
                            false,
                          )}
                          onPress={() => {
                            dispatch({
                              type: MultiLegAction.UPDATE_LOT,
                              payload: {
                                id: leg.id,
                                lots: leg.lots + 1,
                              },
                            });
                          }}>
                          <View style={{padding: 4}}>
                            <AddIcon
                              style={{width: 16, height: 16, color: 'black'}}
                            />
                          </View>
                        </TouchableNativeFeedback>
                      </View>
                    </View>
                    <Text style={{textAlign: 'right'}}>(1lot = 15)</Text>
                    <View
                      style={{
                        flexDirection: 'row',
                        borderWidth: 1,
                        borderColor: 'darkblue',
                        marginTop: 16,
                        borderRadius: 4,
                      }}>
                      <TouchableNativeFeedback
                        background={TouchableNativeFeedback.Ripple(
                          '#90CAF9',
                          false,
                        )}
                        onPress={() => {
                          dispatch({
                            type: MultiLegAction.UPDATE_PRICE_TYPE,
                            payload: {
                              id: leg.id,
                              priceType: 'MARKET_PRICE',
                            },
                          });
                        }}>
                        <View
                          style={{
                            flex: 1,
                            paddingVertical: 4,
                            backgroundColor:
                              leg.priceType == 'MARKET_PRICE'
                                ? root.client_background
                                : 'transparent',
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              color:
                                leg.priceType == 'MARKET_PRICE'
                                  ? 'white'
                                  : 'darkblue',
                              fontSize: 14,
                            }}>
                            Market Price
                          </Text>
                        </View>
                      </TouchableNativeFeedback>

                      <TouchableNativeFeedback
                        background={TouchableNativeFeedback.Ripple(
                          '#90CAF9',
                          false,
                        )}
                        onPress={() => {
                          dispatch({
                            type: MultiLegAction.UPDATE_PRICE_TYPE,
                            payload: {
                              id: leg.id,
                              priceType: 'YOUR_PRICE',
                            },
                          });
                        }}>
                        <View
                          style={{
                            flex: 1,
                            paddingVertical: 4,
                            backgroundColor:
                              leg.priceType == 'YOUR_PRICE'
                                ? root.client_background
                                : 'transparent',
                          }}>
                          <Text
                            style={{
                              textAlign: 'center',
                              fontSize: 14,
                              color:
                                leg.priceType == 'YOUR_PRICE'
                                  ? 'white'
                                  : 'darkblue',
                            }}>
                            Your Price(Limit)
                          </Text>
                        </View>
                      </TouchableNativeFeedback>
                    </View>
                    {leg.priceType === 'MARKET_PRICE' ? (
                      <View style={{marginTop: 8}}>
                        <Text style={{fontSize: 14}}>
                          Price:
                          <Text style={{fontWeight: 'bold', color: 'black'}}>
                            {leg.price}
                          </Text>
                        </Text>
                      </View>
                    ) : (
                      <View style={{flexDirection: 'row', marginTop: 8}}>
                        <View
                          style={{
                            borderBottomColor: 'lightgrey',
                            borderBottomWidth: 1,
                            paddingHorizontal: 8,
                            paddingVertical: 4,
                            width: 100,
                          }}>
                          <Text>{leg.lots}</Text>
                        </View>
                        <Text style={{alignSelf: 'flex-end', fontSize: 12}}>
                          (tick: 0.5)
                        </Text>
                      </View>
                    )}
                  </View>
                )}

                <View style={{position: 'absolute', top: 16, right: 16}}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      dispatch({
                        type: MultiLegAction.EDIT_LEG,
                        payload: {
                          id: leg.id,
                          edit: !leg.edit,
                        },
                      });
                    }}>
                    <View style={{padding: 4}}>
                      <EditIcon
                        style={{width: 16, height: 16, color: 'black'}}
                      />
                    </View>
                  </TouchableNativeFeedback>
                </View>
              </View>
            );
          })}

          <View style={{marginTop: 16}}>
            <Text
              style={{
                fontSize: 12,
                fontFamily: Cfont.rubik_regular,
                color: root.color_text,
              }}>
              Validity: IOC
            </Text>
          </View>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              setAddLegVisible(true);
            }}>
            <View style={{flexDirection: 'row', marginTop: 18}}>
              <View
                style={{
                  padding: 4,
                  borderRadius: 16,
                  borderWidth: 2,
                  borderColor: root.client_background,
                }}>
                <AddIcon
                  style={{
                    width: 12,
                    height: 12,
                    color: root.client_background,
                    fontFamily: Cfont.rubik_medium,
                  }}
                />
              </View>
              <Text
                style={{
                  fontSize: 13,
                  fontFamily: Cfont.rubik_medium,
                  color: root.client_background,
                  alignSelf: 'center',
                  marginLeft: 16,
                }}>
                Add Leg
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </ScrollView>
      <View
        style={{
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 4,
          },
          shadowOpacity: 0.3,
          shadowRadius: 4.65,
          backgroundColor: 'white',
          elevation: 8,
          padding: 16,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontSize: 11,
              color: root.client_background,
              fontFamily: Cfont.rubik_medium,
            }}>
            Brokerage and charges
          </Text>
          <ArrowForwardIcon
            style={{width: 28, height: 24, color: root.client_background}}
          />
        </View>

        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => {
            setConfirmOrderVisible(true);
          }}>
          <Text
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor:
                operation == 'BUY' ? root.client_background : 'red',
              fontSize: 16,
              color: 'white',
              borderRadius: 8,
              textAlign: 'center',
              marginTop: 16,
              fontFamily: Cfont.rubik_semibold,
            }}>
            Place Order
          </Text>
        </TouchableNativeFeedback>
      </View>
      <ChooseFrequencyDialog
        visible={chooseFrequencyVisible}
        onClose={() => {
          setChooseFrequencyVisible(false);
        }}
      />
      <DatePickerDialog
        visible={datePickerVisible}
        onClose={() => {
          setDatePickerVisible(false);
        }}
        onChange={(d: Date) => {
          setDatePickerVisible(false);

          console.log('Date', moment(d).format('DD/mm/YYYY'));

          setDate(d);
        }}
      />
      <AddLegDialog
        visible={addLegVisible}
        onClose={() => {
          setAddLegVisible(false);
        }}
        item={item}
      />
      <MultiLegConfirmPlaceOrderDialog
        visible={confirmOrderVisible}
        onClose={() => {
          setConfirmOrderVisible(false);
        }}
        item={item}
        legs={legs}
        onConfirm={() => {
          setConfirmOrderVisible(false);
          setOrderSuccessVisible(true);
        }}
      />
      <OrderSuccessDialog
        visible={orderSuccessVisible}
        onClose={() => {
          setOrderSuccessVisible(false);
        }}
        item={item}
        legs={legs}
      />
    </View>
  );
};
export default MultilegOrder;

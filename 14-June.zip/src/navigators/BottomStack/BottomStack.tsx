import React from 'react';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import MarketScreen from '../../screens/Market/MarketScreen';
import WatchlistScreen from '../../screens/WatchList/WatchlistScreen';
import Portfolio from '../../screens/Portfolio/Portfolio';
import TabBar from './Tabbar/Tabbar';
import Orders from '../../screens/Orders/Orders';

interface Tab {
  id: string;
  label: string;
  icon: string;
  screen: React.FC;
}

const TABS: Tab[] = [
  {id: 'tab1', label: 'Tab 1', icon: 'ios-home', screen: WatchlistScreen},
  {id: 'tab2', label: 'Tab 2', icon: 'ios-list', screen: MarketScreen},
  {id: 'tab4', label: 'Tab 4', icon: 'ios-settings', screen: Orders},
  {id: 'tab5', label: 'Tab 5', icon: 'ios-settings', screen: Portfolio},
];

const Tab = createBottomTabNavigator();
const BottomTab = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {display: 'none'},
        lazy: true,
        unmountOnBlur: false,
      }}
      tabBar={props => <TabBar {...props} />}>
      {TABS.map(tab => (
        <Tab.Screen
          key={tab.id}
          name={tab.id}
          component={tab.screen}
          options={{
            title: tab.label,
          }}
        />
      ))}
    </Tab.Navigator>
  );
};

export default BottomTab;

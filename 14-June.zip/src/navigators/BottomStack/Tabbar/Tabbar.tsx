import React from 'react';

import {
  View,
  Pressable,
  Dimensions,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import Fontisto from 'react-native-vector-icons/Fontisto';
import {Cfont, Font, root} from '../../../styles/colors';
import Tabnew from '../../../assets/tab-background-latest.svg';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import {useSelector} from 'react-redux';
import { custombottomstyle } from '../../../theme/light';

const CustomButton = () => (
  <View
    style={custombottomstyle.customtabone}>
    <View style={custombottomstyle.customtab}>
      <Fontisto
        name="search"
        size={25}
        style={{transform: [{rotate: '-45deg'}]}}
        color={'white'}
      />
    </View>
  </View>
);

const TabBar = ({state, descriptors, navigation}: any) => {
  const isShow = useSelector((s: any) => s.Reducer.isBottmtabShow);

  return (
    <>
      {isShow === true ? (
        <>
          <View style={custombottomstyle.mainContainer}>
            <Tabnew
              width={'100%'}
              height={128}
              style={{
                position: 'absolute',
                alignSelf: 'center',
                backgroundColor: '#0000000',
                bottom: -31,
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.23,
                shadowRadius: 2.62,

                elevation: 24,
              }}
            />
            {state.routes.map((route: any, index: number) => {
              const {options} = descriptors[route.key];
              const label =
                options.tabBarLabel !== undefined
                  ? options.tabBarLabel
                  : options.title !== undefined
                  ? options.title
                  : route.name;

              const isFocused = state.index === index;

              const onPress = () => {
                setTimeout(() => {
                  const event = navigation.emit({
                    type: 'tabPress',
                    target: route.key,
                  });

                  if (!isFocused && !event.defaultPrevented) {
                    navigation.navigate(route.name);
                  }
                }, 10);
              };

              return (
                <View key={index} style={[custombottomstyle.mainItemContainer]}>
                  <Pressable onPress={onPress}>
                    {route.name == 'tab1' ? (
                      <>
                        <View style={[custombottomstyle.taballign, {marginRight: 10}]}>
                          <FontAwesome5
                            name="list-alt"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? custombottomstyle.tabtxt : custombottomstyle.tabtxt2}>
                            Watchlist
                          </Text>
                        </View>
                      </>
                    ) : route.name == 'tab2' ? (
                      <>
                        <View style={custombottomstyle.taballigntwo}>
                          <Entypo
                            name="bar-graph"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? custombottomstyle.tabtxt : custombottomstyle.tabtxt2}>
                            Market
                          </Text>
                        </View>
                      </>
                    ) : route.name == 'tab4' ? (
                      <>
                        <View style={custombottomstyle.taballignthree}>
                          <FontAwesome5
                            name="book"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? custombottomstyle.tabtxt : custombottomstyle.tabtxt2}>
                            Order
                          </Text>
                        </View>
                      </>
                    ) : (
                      <>
                        <View style={[custombottomstyle.taballign, {marginLeft: 10}]}>
                          <FontAwesome5
                            name="chart-pie"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? custombottomstyle.tabtxt : custombottomstyle.tabtxt2}>
                            Portfolio
                          </Text>
                        </View>
                      </>
                    )}
                  </Pressable>
                </View>
              );
            })}
            <View
              style={custombottomstyle.searchicon}>
              <TouchableOpacity
                onPress={() => navigation.navigate('Screen3')}
                activeOpacity={1}>
                <CustomButton />
              </TouchableOpacity>
            </View>
          </View>
        </>
      ) : null}
    </>
  );
};


export default TabBar;

import React from 'react';
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import CommonModaltwo from '../../../../components/CommonModal/CommonModaltwo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../../../styles/colors';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import alignment from '../../../../components/utils/alignment';

const ContactUsModal = (props: any) => {
  const data = [
    {
      name: 'phone',
      type: 'Customer Support',
      number: '9167396666',
    },
    {
      name: 'phone',
      type: 'Tech Support',
      number: '9167396666',
    },
    {
      name: 'email',
      type: 'Email your Query',
      number: 'presalesteam@63moons.com',
    },
  ];
  return (
    <CommonModaltwo visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity style={contactUsModal.closeButton} onPress={()=>props.onClose()}>
        <AntDesign name="close" size={24} color={root.color_text} />
        </TouchableOpacity>
        <Text style={contactUsModal.titleTxt}>Contact Us</Text>
        <FlatList
          data={data}
          renderItem={({item}) => (
            <View style={contactUsModal.typeContainer}>
              <MaterialCommunityIcons
                name={item.name}
                size={24}
                color={'black'}
              />
              <Text style={contactUsModal.typeTxt}>{item.type}</Text>
              <Text style={contactUsModal.typeTxt}>{item.number}</Text>
            </View>
          )}
        />
    </CommonModaltwo>
  );
};

const contactUsModal = StyleSheet.create({
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  typeTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
    paddingLeft:16
  },
  typeContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: 16,
  },
  closeButton:{
    alignItems:'flex-end'
  }
});

export default ContactUsModal;

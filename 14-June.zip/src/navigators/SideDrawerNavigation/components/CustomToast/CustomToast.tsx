import React from 'react';
import {Text, View} from 'react-native';
import alignment from '../../../../components/utils/alignment';

export const toastConfig = {
  versionDetailsToast: ({text1}: any) => (
    <View style={{...alignment.row, alignItems: 'center',backgroundColor:'black',height:50}}>
      <Text style={{color:'white'}}>{`You are ${text1} click away from advance feature`}</Text>
    </View>
  ),
};

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import CommonModalFour from '../../../../components/CommonModal/CommonModalFour';
import {Cfont, Font, root} from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import StarRating from 'react-native-star-rating-widget';

const RateUsModal = (props: any) => {
  const [rating, setRating] = useState(0);

  return (
    <CommonModalFour visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity
        style={rateUsModal.closeButton}
        onPress={() => props.onClose()}>
        <AntDesign name={'close'} size={24} color={root.color_text} />
      </TouchableOpacity>
      <Text style={rateUsModal.titleTxt}>Rate Us</Text>
      <View style={rateUsModal.infoView}>
      <Text style={rateUsModal.infoText}>
        Rate your experience on this app.We will work on
      </Text>
      <Text style={rateUsModal.infoText}>the feedback provided by you</Text>
      </View>
      <View style={rateUsModal.ratingView}>
        <StarRating
          rating={rating}
          onChange={setRating}
          color={root.color_text}
          enableHalfStar={false}
          animationConfig={{scale: 1}}
        />
      </View>
      <View style={rateUsModal.buttonContainer}>
        <TouchableOpacity style={rateUsModal.buttonView}>
          <Text style={rateUsModal.feedbackTxt}>Feedback</Text>
        </TouchableOpacity>
        <TouchableOpacity style={rateUsModal.buttonView}>
          <Text style={rateUsModal.feedbackTxt}>Share App</Text>
        </TouchableOpacity>
      </View>
    </CommonModalFour>
  );
};

const rateUsModal = StyleSheet.create({
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  infoText: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    alignSelf: 'center',
  },
  ratingView: {
    alignItems:'center',
    paddingTop:32
  },
  storeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_six,
  },
  feedbackTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
    fontSize: Font.font_normal_three,
  },
  buttonContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop:52
  },
  buttonView: {
    width: '45%',
    height: 38,
    borderWidth: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
  },
  closeButton: {
    alignItems: 'flex-end',
  },
  infoView:{
    paddingTop:32
  }
});

export default RateUsModal;

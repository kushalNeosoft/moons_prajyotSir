import {
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
  Modal,
  Animated,
} from 'react-native';
// import { ListRenderItem } from 'react-native';
// import { Drawerstyling} from '../../../../Theme/Light';
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
// import Banner from '../Sidercomonent/Banner/Banner';
import Entypo from 'react-native-vector-icons/Entypo';
import Toast from 'react-native-toast-message';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Funds from '../Fund/Funds';
import {RadioButton} from 'react-native-paper';
import {Needtxt} from '../Needhelp/Needtxt';
import {useFocusEffect, useNavigation} from '@react-navigation/native';
import {useTranslation} from 'react-i18next';
import dynamicDrawerData from './dynamicmenu.json';
import {Dimensions} from 'react-native';
import Carousel from 'react-native-reanimated-carousel';
import {useSelector} from 'react-redux';
import {BannerData} from './Bannerdata';
import Profileinfo from '../../../../components/Profileinfo/Profileinfo';
import {Cfont, Font, root} from '../../../../styles/colors';
import {CompanyStyle, SideDrawerstyling} from '../../../../theme/light';
import ContactUsModal from '../ContactUsModal/ContactUsModal';
import RateUsModal from '../RateUsModal/RateUsModal';
import alignment from '../../../../components/utils/alignment';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useIsFocused} from '@react-navigation/native';

const DrawerMenu = () => {
  const [contactUsModalVisible, setContactUsModalVisible] = useState(false);
  const [rateUsModalVisible, setRateUsModalVisible] = useState(false);
  const {t} = useTranslation();
  const navigation = useNavigation();
  const [checked, setChecked] = React.useState('Light');
  const [versionDetailsVisibilityCount, setVersionDetailsVisibilityCount] =
    useState(3);
  const [versionDetailsVisibility, setVersionDetailsVisibility] =
    useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const isFocused = useIsFocused();

  const fadeOut = () => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 200,
      useNativeDriver: true,
    }).start();
  };

  const fadeIn = () => {
    setVersionDetailsVisibilityCount(prevState => prevState - 1);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
    const timer = setTimeout(() => {
      fadeOut();
    }, 2000);

    return () => clearTimeout(timer);
  };

  useEffect(() => {
    console.log(
      versionDetailsVisibility,
      versionDetailsVisibilityCount,
      'this',
    );
  }, [versionDetailsVisibility, versionDetailsVisibilityCount]);

  useEffect(() => {
    if (versionDetailsVisibilityCount === 0) {
      setVersionDetailsVisibility(prevState => !prevState);
    }
  }, [versionDetailsVisibilityCount]);

  useEffect(() => {
    if (versionDetailsVisibility === true) {
      const timer = setTimeout(() => {
        setVersionDetailsVisibility(false);
        setVersionDetailsVisibilityCount(3);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [versionDetailsVisibility]);

  const storeimg = useSelector(state => state.Login.imgstore);
  const newfont = useSelector(state => state.Login.counter);
  const urldf = 'https://reactnative.dev/img/tiny_logo.png';

  const data = [
    {
      title: 'Status Time',
      value: '13:49:37',
    },
    {
      title: 'Url',
      value: 'Url',
    },
    {
      title: 'BCest',
      value: 'BCest',
    },
    {
      title: 'Msg',
      value: 'Msg',
    },
    {
      title: 'Socket Cache',
      value: 'false',
    },
    {
      title: 'Tenant',
      value: '1404',
    },
    {
      title: 'App Version',
      value: '8.2.21',
    },
    {
      title: 'App Package',
      value: 'com.wave.dev',
    },
    {
      title: 'Build Version',
      value: '01.03.22',
    },
    {
      title: 'Build Date',
      value: '01/03/2022',
    },
    {
      title: 'Environment',
      value: 'UAT',
    },
  ];

  const contactUsModalToggle = () => {
    setContactUsModalVisible(prevState => !prevState);
  };

  const rateUsModalToggle = () => {
    setRateUsModalVisible(prevState => !prevState);
  };

  const navtoScreen = () => {
    // navigation.navigate('Settings');
  };
  const navtoProfile = () => {
    // navigation.navigate('Profile');
  };
  const navToAvailableFunds = () => {
    navigation.navigate('AvailableFunds');
  };

  const navtoNeedHelp = (value: any) => {
    navigation.navigate('NeedHelp', {index: value});
  };

  const navtoLazyLoading = () => {
    console.log('Came to laz loading');
    // navigation.navigate('DataLazyLoading');
  };

  const navtoWebview = () => {
    // navigation.navigate('Webview');
  };

  const navtoSql = () => {
    // navigation.navigate('MainScreen');
  };
  const width = Dimensions.get('window').width;

  const functions = (name: any) => {
    console.log(name, 'name');
    if (name === 'Rate Us') {
      setRateUsModalVisible(prevState => !prevState);
    }
  };

  const Footer = () => {
    if (versionDetailsVisibility) {
      return (
        <View style={CompanyStyle.Startcon}>
          {data.map(item => {
            return renderVersionDetails(item);
          })}
        </View>
      );
    } else {
      return null;
    }
  };

  type ItemProps = {displayName: string; name: string};

  const renderVersionDetails = (item: any) => {
    return (
      <View style={{paddingHorizontal: 16}}>
        {item.title === 'Status Time' ? (
          <View style={{...alignment.row_SpaceB}}>
            <View style={{...alignment.row, alignItems: 'center'}}>
              <Text
                style={{
                  fontFamily: Cfont.rubik_regular,
                  fontSize: Font.font_normal_one,
                  color: root.color_text,
                }}>
                {item.title}
              </Text>
              <TouchableOpacity>
                <MaterialIcons
                  name="refresh"
                  size={15}
                  color={'black'}
                  style={{paddingLeft: 16}}
                />
              </TouchableOpacity>
            </View>
            <Text
              style={{
                fontFamily: Cfont.rubik_regular,
                fontSize: Font.font_normal_one,
                color: root.color_text,
              }}>
              {item.value}
            </Text>
          </View>
        ) : (
          <View style={{...alignment.row_SpaceB}}>
            <Text
              style={{
                fontFamily: Cfont.rubik_regular,
                fontSize: Font.font_normal_one,
                color: root.color_text,
              }}>
              {item.title}
            </Text>
            <Text style={{color: item.value === 'BCest' ? 'red' : 'black'}}>
              {item.value}
            </Text>
          </View>
        )}
      </View>
    );
  };

  const ListHeader = () => {
    return (
      <>
        <View>
          <Carousel
            loop
            width={width}
            height={width / 2.5}
            autoPlay={true}
            data={BannerData}
            scrollAnimationDuration={1000}
            pagingEnabled={true}
            renderItem={({item}) => (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <View style={SideDrawerstyling.slideimgcon}>
                  <Image
                    source={{
                      uri: item.url,
                    }}
                    style={SideDrawerstyling.slideimgcontwo}
                  />
                </View>
              </View>
            )}
          />
        </View>
        <TouchableOpacity onPress={navtoProfile}>
          <Profileinfo
            rightComponent={
              <Entypo
                name="chevron-small-right"
                size={30}
                color={root.client_background}
              />
            }
          />
        </TouchableOpacity>
      </>
    );
  };

  const Item = ({displayName, name}: ItemProps) => (
    <View style={SideDrawerstyling.Maincon}>
      {displayName == 'Funds' ? (
        <>
          <TouchableOpacity onPress={navToAvailableFunds}>
            <View style={SideDrawerstyling.Innercotwo}>
              <View style={SideDrawerstyling.Innertwoone}>
                <Text
                  style={[
                    SideDrawerstyling.texticon,
                    {
                      fontSize: newfont,
                    },
                  ]}>
                  {t(name)}
                </Text>
                <Entypo
                  name="chevron-small-right"
                  size={30}
                  color={root.client_background}
                />
              </View>
              <Funds />
            </View>
          </TouchableOpacity>
        </>
      ) : displayName == 'Need Help' ? (
        <>
          <TouchableOpacity
            style={SideDrawerstyling.Innercothree}
            onPress={navtoNeedHelp}>
            <View style={SideDrawerstyling.Innertwoone}>
              <Text
                style={[
                  SideDrawerstyling.texticon,
                  {
                    fontSize: newfont,
                  },
                ]}>
                {t(name)}
              </Text>
              <Entypo
                name="chevron-small-right"
                size={30}
                color={root.client_background}
              />
            </View>

            <Needtxt navigate={navtoNeedHelp} />
          </TouchableOpacity>
        </>
      ) : displayName == 'Usage Guide' ? (
        <>
          <View>
            <TouchableOpacity
              style={{alignItems: 'center', justifyContent: 'center'}}
              onPress={navtoLazyLoading}>
              <View style={SideDrawerstyling.usagecon}>
                <Text style={SideDrawerstyling.styleb}>{t(name)}</Text>
              </View>
            </TouchableOpacity>
          </View>
        </>
      ) : displayName == 'Contact Us' ? (
        <>
          <View style={SideDrawerstyling.newcontact}>
            <TouchableOpacity
              style={{alignItems: 'center', borderEndWidth: 1}}
              onPress={() => setContactUsModalVisible(prevState => !prevState)}>
              <View style={SideDrawerstyling.usagecon}>
                <Text style={SideDrawerstyling.styleb}>{t(name)}</Text>
              </View>
            </TouchableOpacity>
          </View>
        </>
      ) : displayName == 'Settings' ? (
        <>
          <View style={SideDrawerstyling.Innercotwo}>
            <TouchableOpacity onPress={navtoScreen}>
              <View style={SideDrawerstyling.Innertwoone}>
                <Text
                  style={[
                    SideDrawerstyling.texticon,
                    {
                      fontSize: newfont,
                    },
                  ]}>
                  {t(name)}
                </Text>
                <Entypo
                  name="chevron-small-right"
                  size={30}
                  color={root.client_background}
                />
              </View>
            </TouchableOpacity>
            <View style={SideDrawerstyling.radio}>
              <RadioButton
                value="Light"
                status={checked === 'Light' ? 'checked' : 'unchecked'}
                onPress={() => setChecked('Light')}
              />
              <Text style={SideDrawerstyling.Lighttxt}>{t('Light Theme')}</Text>
              <RadioButton
                value="Dark"
                status={checked === 'Dark' ? 'checked' : 'unchecked'} //if the value of checked is Dark, then select this button
                onPress={() => setChecked('Dark')} //when pressed, set the value of the checked Hook to 'Apple'
              />
              <Text style={SideDrawerstyling.Darktxt}>{t('Dark Theme')}</Text>
            </View>
          </View>
        </>
      ) : displayName == 'e-Kyc System' ? (
        <>
          <View style={SideDrawerstyling.Innercokyc}>
            <TouchableOpacity onPress={navtoSql}>
              <View style={SideDrawerstyling.Innertwoone}>
                <Text
                  style={[
                    SideDrawerstyling.texticon,
                    {
                      fontSize: newfont,
                    },
                  ]}>
                  {t(name)}
                </Text>
                <Entypo
                  name="chevron-small-right"
                  size={30}
                  color={root.client_background}
                />
              </View>
            </TouchableOpacity>
            <View style={SideDrawerstyling.Buttomtxtcon}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <TouchableOpacity onPress={() => fadeIn()}>
                  <Text style={SideDrawerstyling.versiontxt}>Version</Text>
                </TouchableOpacity>
                <Text style={SideDrawerstyling.versiontxt}>
                  Last Login : 2023-Mar-10 10:45:53
                </Text>
              </View>
              <Text style={SideDrawerstyling.buttontxt}>
                Powered by 63 moons technologies limited
              </Text>
            </View>
          </View>
        </>
      ) : displayName === 'Account Statement' ||
        displayName === 'eDIS Permission' ||
        displayName === 'Invite Friends' ||
        displayName === 'Theme' ||
        displayName === 'Close' ? null : (
        <>
          <TouchableOpacity onPress={() => functions(name)}>
            <View style={SideDrawerstyling.Innercon}>
              <Text
                style={[
                  SideDrawerstyling.texticon,
                  {
                    fontSize: newfont,
                  },
                ]}>
                {t(name)}
              </Text>
              {name == 'Log Out' ? (
                <>
                  <MaterialCommunityIcons
                    name="logout"
                    size={30}
                    color={root.client_background}
                  />
                </>
              ) : name == 'Rate Us' ? (
                <>
                  <MaterialCommunityIcons
                    name="star-outline"
                    size={30}
                    color={root.client_background}
                  />
                </>
              ) : (
                <>
                  <Entypo
                    name="chevron-small-right"
                    size={30}
                    color={root.client_background}
                  />
                </>
              )}
            </View>
          </TouchableOpacity>
        </>
      )}
    </View>
  );

  return (
    <>
      <Animated.View
        style={{
          backgroundColor: 'yellow',
          position: 'absolute',
          height: 40,
          top: -20,
          left: 20,
          right: 20,
          zIndex: 1,
          opacity: fadeAnim,
        }}>
        {!versionDetailsVisibility ? (
          <Text>{`You are ${versionDetailsVisibilityCount} click away from advance feature`}</Text>
        ) : (
          <Text>Advance feature enabled now</Text>
        )}
      </Animated.View>
      <FlatList
        data={dynamicDrawerData}
        renderItem={({item}) => (
          <Item displayName={item.displayName} name={item.name} />
        )}
        ListHeaderComponent={ListHeader}
        keyExtractor={item => String(item.id)}
        ListFooterComponent={Footer}
      />
      <ContactUsModal
        visible={contactUsModalVisible}
        onClose={contactUsModalToggle}
      />
      <RateUsModal visible={rateUsModalVisible} onClose={rateUsModalToggle} />
      <Toast />
      <View style={{width: '100%', backgroundColor: 'red'}}>
        <Text></Text>
      </View>
    </>
  );
};

export default React.memo(DrawerMenu);

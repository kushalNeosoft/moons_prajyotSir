import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function LoginStyles() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);

  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const Login = StyleSheet.create({
    scrollContainer: {
      flex: 1,
    },
    container: {
      flexGrow: 1,
      flex: 1,
      height: height,
      backgroundColor: root.color_active,
    },
    block1: {
      flex: 1,
      flexGrow: 1,
      flexDirection: 'column',
      padding: 16,
    },
    block1ButtonContainer: {
      flexDirection: 'row',
      marginTop: 48,
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    buttonContainer: {
      flexDirection: 'row',
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: font.size_16,
      alignSelf: 'center',
    },
    buttonTextone: {
      color: root.color_text,
      fontSize: font.size_16,
      alignSelf: 'center',
      fontFamily: font_Family.medium,
    },
    buttonImage: {
      color: root.color_active,
      width: font.size_16,
      marginLeft: 16,
    },
    buttonImageone: {
      color: root.color_text,
      width: font.size_16,
      marginLeft: 16,
    },
    forgettxt: {
      color: root.color_textual,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    haventtxt: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    registertxt: {
      color: root.color_textual,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    signupContainer: {
      flexDirection: 'row',
      marginTop: 32,
      alignItems: 'center',
      backgroundColor: root.color_black,
      paddingVertical: 16,
      paddingHorizontal: 24,
      borderRadius: 16,
    },
    signupContainerHeading: {
      color: root.color_active,
      fontFamily: font_Family.medium,
      fontSize: font.size_16,
    },
    signupContainerSubHeading: {
      color: root.signup_wrap_subtitle,
      fontSize: font.size_13,
      fontFamily: font_Family.regular,
      marginTop: 8,
    },
    Avaltxt: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    rowtxt: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.medium,
    },
    exchtxt: {
      fontSize: font.size_10,
      color: root.color_textual,
      fontFamily: font_Family.medium,
    },
    block2: {
      padding: 16,
    },
    heading: {
      fontSize: font.size_30,
      color: root.color_text,
      fontFamily: font_Family.medium,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_subtext,
      borderWidth: 0.7,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
      color: root.color_text,
    },
    inputIcon: {
      width: 24,
      color: root.color_subtext,
      margin: 12,
    },
    sectionContainer: {
      marginTop: 32,
      paddingHorizontal: 24,
    },
    sectionTitle: {
      fontSize: 24,
      fontWeight: '600',
    },
    sectionDescription: {
      marginTop: 8,
      fontSize: 18,
      fontWeight: '400',
    },
    highlight: {
      fontWeight: '700',
    },
    footerContainer: {
      marginTop: 8,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    buttonSContainer: {
      flexDirection: 'row',
      backgroundColor: root.color_dark_black,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonSTextone: {
      color: root.color_text,
      fontSize: font.size_16,
      alignSelf: 'center',
      fontFamily: font_Family.medium,
    },
    buttonSImageone: {
      color: root.color_text,
      width: 16,
      marginLeft: 16,
    },
  });
  return {Login};
}

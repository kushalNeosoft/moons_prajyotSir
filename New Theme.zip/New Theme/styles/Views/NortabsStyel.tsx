import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function NortabsStyle() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const nortabstyles = StyleSheet.create({
    headerComponentView: {
      height: Dimensions.get('window').width * 0.117,
      backgroundColor: root.color_active,
      flexDirection: 'row',
      alignContent: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 16,
      alignItems: 'center',
    },
    norflex: {
      flexDirection: 'row',
      flex: 1.4,
    },
    downicon: {
      justifyContent: 'flex-end',
      marginLeft: '5%',
    },
    Nortxt: {
      fontSize: font.size_16,
      color: root.color_text,
      fontFamily: font_Family.medium,
    },
    headerFlexEndView: {
      flex: 1,
      flexDirection: 'row',
      width: 150,
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    lenght: {
      color: root.color_active,
      borderColor: root.color_active,
      borderWidth: 1,
      fontSize: font.size_9,
      fontWeight: 'bold',
      backgroundColor: 'red',
      paddingLeft: '36%',
      //marginLeft:'6%',
      height: 16,
      width: 16,
      borderRadius: 20,
      alignItems: 'center',
      position: 'absolute',
      right: -4,
      justifyContent: 'center',
    },
    addText: {
      paddingHorizontal: 11,
      paddingVertical: 3,
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.medium,
    },
  });
  return {nortabstyles};
}

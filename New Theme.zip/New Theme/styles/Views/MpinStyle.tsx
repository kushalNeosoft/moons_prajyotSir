import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function MpinStyle() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const MpinStyles = StyleSheet.create({
    titleContainer: {
      marginTop: 34,
    },
    title: {
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      color: root.color_text,
      marginBottom: 2,
    },
    pinContainer: {
      flexDirection: 'row',
      marginTop: 16,
    },
    pinInput: {
      color: root.color_text,
      borderColor: root.color_subtext,
      borderWidth: 0.5,
      borderRadius: 4,
      margin: 0,
      paddingVertical: 8,
      paddingHorizontal: 16,
      height: 40,
      width: 40,
      textAlign: 'center',
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: 'yellow',
      margin: 12,
    },
    secondaryContainer: {
      marginTop: 32,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    takeMe: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    watchlist: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
      paddingVertical: 4,
    },
    dropdownIcon: {
      height: 22,
      width: 22,
      color: root.color_text,
    },
    forgotMpin: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
    },
  });

  return {MpinStyles};
}

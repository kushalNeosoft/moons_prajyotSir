import {Dimensions, StyleSheet} from 'react-native';
import {hideMessage} from 'react-native-flash-message';
import {Border} from 'victory-native';
import {colordata} from '../assets/demoData';
import alignment from '../components/utils/alignment';
import {Cfont, Font, TColors, root} from '../styles/colors';
import globalStyleClass, {textAlign} from './globalStyleClass';
import {textAlign as demo} from './globalStyleClass';
import Theme from './Theme';

const height = Dimensions.get('window').height;
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;
const size_family = {...globalStyleClass.font_size_family};
const fontFamily = {...globalStyleClass.fontFamily};
// const size = {...globalStyleClass.font};
const bgColor = {...globalStyleClass.backgroundColor};
const color = {...globalStyleClass.color};
const padding = {...globalStyleClass.padding};
const p = {...globalStyleClass.padding};
const m = {...globalStyleClass.margin};

// Login Screen componets styling
// console.log(height);
// const statusHeight = StatusBar?.currentHeight ? StatusBar?.currentHeight : 0;

export const text = StyleSheet.create({
  text_14: {
    fontSize: 14,
  },
  text_12: {
    fontSize: Font.font_normal_one,
  },
  text_famaly_medium: {
    fontFamily: Cfont.rubik_medium,
  },
  text_famaly_regular: {
    fontFamily: Cfont.rubik_regular,
  },
  text_color: {
    color: root.color_text,
  },
});

export const Login = StyleSheet.create({
  scrollContainer: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    flex: 1,
    height: height,
    backgroundColor: root.color_active,
  },
  block1: {
    flex: 1,
    flexGrow: 1,
    flexDirection: 'column',
    padding: 16,
  },
  block1ButtonContainer: {
    flexDirection: 'row',
    marginTop: 48,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },
  buttonTextone: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
    fontFamily: Cfont.rubik_medium,
  },
  buttonImage: {
    color: root.color_active,
    width: Font.font_normal_three,
    marginLeft: 16,
  },
  buttonImageone: {
    color: root.color_text,
    width: Font.font_normal_three,
    marginLeft: 16,
  },
  forgettxt: {
    color: root.color_textual,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  haventtxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  registertxt: {
    color: root.client_background,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  signupContainer: {
    flexDirection: 'row',
    marginTop: 32,
    alignItems: 'center',
    backgroundColor: 'black',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 16,
  },
  signupContainerHeading: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  signupContainerSubHeading: {
    color: root.signup_wrap_subtitle,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    marginTop: 8,
  },
  Avaltxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  rowtxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  exchtxt: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
  },
  block2: {
    padding: 16,
  },
  heading: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: 'lightgrey',
    borderWidth: 2,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
  inputIcon: {
    width: 24,
    color: 'grey',
    margin: 12,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  footerContainer: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

// SignUP page

export const SignupStyles = StyleSheet.create({
  scrollContainer: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    flex: 1,
    // height: height,
    backgroundColor: root.color_active,
    padding: 16,
  },
  block1ButtonContainer: {
    flexDirection: 'row',
    marginTop: 7,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 9,
    paddingHorizontal: 18,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },
  buttonImage: {
    color: root.color_active,
    width: 24,
    marginLeft: 22,
  },
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 25,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

//Forgot password & MPIN

export const ForgotPasswordStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    padding: 16,
  },
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  Sendotp: {
    marginTop: 16,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  user: {
    fontSize: Font.font_normal_four,
    marginTop: 32,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  userId: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
  email: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  mobile: {
    paddingVertical: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  om: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  moons: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  99: {
    paddingVertical: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  backIcon: {
    width: 32,
    height: 22,

    color: root.color_text,
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 11,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    alignSelf: 'center',
  },
});

//Phone component (SignUP button from Login Screen)
export const PhoneComponentStyles = StyleSheet.create({
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
  },
  buttonText: {
    // color: root.color_active,
    fontSize: Font.font_normal_three,
    // alignSelf: 'center',
  },
  buttonImage: {
    color: 'white',
    width: 24,
    marginLeft: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.8,
    color: root.color_text,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
});
//OTP Component  (Sign UP Button from Login Screen)

export const OtpComponentStyles = StyleSheet.create({
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    flexDirection: 'row',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    // alignSelf: 'center',
  },
  buttonImage: {
    color: 'white',
    width: 40,
    marginLeft: 19,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
});

//Phone Verification

export const PhoneVerificationStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    padding: 16,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
});

//Input MPin Profile Screen

export const MpinStyles = StyleSheet.create({
  titleContainer: {
    marginTop: 34,
  },
  title: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 2,
  },
  pinContainer: {
    flexDirection: 'row',
    marginTop: 16,
  },
  pinInput: {
    color: root.color_text,
    borderColor: root.color_text,
    borderWidth: 0.5,
    borderRadius: 4,
    margin: 0,
    paddingVertical: 8,
    paddingHorizontal: 16,
    height: 40,
    width: 40,
    textAlign: 'center',
  },
  buttonContainer: {
    backgroundColor: 'darkblue',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
    alignSelf: 'center',
  },

  inputContainer: {
    flexDirection: 'row',
    borderColor: 'lightgrey',
    borderWidth: 2,
    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  inputIcon: {
    width: 24,
    color: 'grey',
    margin: 12,
  },
  secondaryContainer: {
    marginTop: 32,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  takeMe: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  watchlist: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    paddingVertical: 4,
  },
  dropdownIcon: {
    height: 22,
    width: 22,
    color: root.client_background,
  },
  forgotMpin: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
});

//Password screen

export const PasswordStyles = StyleSheet.create({
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },

  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,
    borderRadius: 8,
  },
  input: {
    margin: 0,
    color: root.color_text,

    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  inputIcon: {
    width: 24,
    color: root.color_text,

    margin: 12,
  },
  takeme: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  watchList: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    paddingVertical: 4,
  },
  dropdownIcon: {
    height: 22,
    width: 24,
    color: 'black',
  },
  forgotPassword: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
});

//Profile screen with MPIN Screen

export const ProfileStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  headerContainer: {
    backgroundColor: 'white',
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,

    elevation: 8,
  },
  userContainer: {
    flexDirection: 'row',
    padding: 26,
  },
  userProfilePic: {
    width: 64,
    height: 64,
    backgroundColor: 'gray',
    borderRadius: 32,
  },
  userInfoContainer: {
    // flex: 1,
    marginLeft: 16,
  },
  userName: {
    fontSize: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 9,
  },
  userId: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  switchAccountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  switchAccount: {
    fontSize: 14,
    color: 'black',
    fontWeight: 'bold',
  },
  dropDownIcon: {
    height: 24,
    width: 24,
    color: 'black',
  },
  tabContainer: {
    flexDirection: 'row',
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
  },
  itemText: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    //fontWeight: 'bold',
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  itemUnderlineContainer: {
    paddingHorizontal: 16,
    height: 2,
    width: '100%',
  },
  itemUnderline: {
    height: 2,
    flex: 1,
    width: '100%',
  },
  bodyContainer: {
    padding: 16,
    flex: 1,
    backgroundColor: 'white',
  },
});

// Watchlist Screen & Components styles

export const watchlistheader = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: Dimensions.get('window').width * 0.146,
    paddingTop: 8,
    //  justifyContent:'flex-end',
    backgroundColor: 'red',
    // backgroundColor:'yellow'
  },
  image: {
    height: 20,
    width: 20,
  },
  titleconstainer: {flexDirection: 'row', paddingHorizontal: 40},
  titleText: {
    top: -2.5,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    color: root.color_text,

    // paddingHorizontal: 40,
  },
  titleText_12: {
    // top: -2.5,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  changePercentage: {
    // color: colors.bright_green,
    top: -2.5,
    marginRight: 4,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    color: root.color_positive,
    alignSelf: 'center',
    // backgroundColor:root.color_positive_rgb
  },
  changePercentageminus: {
    // color: colors.bright_green,
    top: -2.5,
    marginRight: 4,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    color: root.color_negative,
    alignSelf: 'center',
    // backgroundColor:root.color_negative_rgb
  },
  headerLeft: {
    flex: 0.65,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'red',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerMiddle: {
    flex: 4,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'red',
    alignItems: 'center',
  },
  headerRight: {
    flex: 1,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'red',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  midtxt: {
    alignItems: 'center',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    padding: 0,
    top: -4,
  },
  headercon: {
    alignItems: 'center',
    // borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    height: Dimensions.get('window').width * 0.121,
  },
  rupeicon: {
    height: 16,
    width: 16,
  },
});

export const nortabstyles = StyleSheet.create({
  headerComponentView: {
    height: Dimensions.get('window').width * 0.117,
    backgroundColor: 'white',
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  norflex: {
    flexDirection: 'row',
    flex: 1.4,
  },
  downicon: {
    justifyContent: 'flex-end',
    marginLeft: '5%',
  },
  Nortxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  headerFlexEndView: {
    flex: 1,
    flexDirection: 'row',
    width: 150,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lenght: {
    color: 'white',
    borderColor: root.color_active,
    borderWidth: 1,
    fontSize: Font.font_normal_eight,
    fontWeight: 'bold',
    backgroundColor: 'red',
    paddingLeft: '36%',
    //marginLeft:'6%',
    height: 16,
    width: 16,
    borderRadius: 20,
    alignItems: 'center',
    position: 'absolute',
    right: -4,
    justifyContent: 'center',
  },
  addText: {
    paddingHorizontal: 11,
    paddingVertical: 3,

    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

export const watchlistdata = StyleSheet.create({
  stock: {
    height: 60,
    flex: 1.5,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingTop: 2,
    backgroundColor: 'white',
  },
  stockcomp: {
    flex: 4,
    height: 36,
  },
  Nsetxt: {
    marginLeft: '3%',
    marginTop: '3%',
    height: '50%',
    width: '13%',
    backgroundColor: root.backgroung_exchange_chip_color,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 2,
  },
  index: {
    color: root.color_subtext,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
  Atxt: {
    marginLeft: '2%',
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    // marginTop: 3,
  },
  nertxt: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '55%',
    justifyContent: 'space-between',
  },
  valtxt: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    marginLeft: '4%',
  },
  plustxt: {
    color: root.color_positive,
    fontWeight: '300',
    fontSize: Font.font_normal_six,
  },
  minustxt: {
    color: root.color_negative,
    fontWeight: '300',
    fontSize: Font.font_normal_six,
  },
  volGainerTxt: {
    marginLeft: 3,
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    backgroundColor: root.color_positive_rgb,
  },
  prLoserTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_negative,
    backgroundColor: root.color_negative_rgb,
  },
  defaultTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    fontWeight: 'bold',
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_active,
  },
  stockContainerPositive: {
    alignItems: 'flex-end',
    // justifyContent: 'center',
    // backgroundColor: '#e6ffe6',
  },
  stockContainerNegative: {
    alignItems: 'flex-end',
    // backgroundColor: '#ffe6e6',
  },
  stockPriceText: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  endcom: {
    flex: 0.85,
    alignItems: 'center',
    paddingTop: 5,
    paddingLeft: '1%',
  },
  endT: {
    borderWidth: 1.5,
    height: 26,
    width: 26,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  endTtext: {
    fontWeight: 'bold',
    color: 'black',
  },
  perchantxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  stocktxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  felxrow: {
    flexDirection: 'row',
  },
  flatallign: {
    // height: '85%',
    // height:screenHeight*0.95,
    flex: 0.92,
    backgroundColor: 'white',
  },
  secondinner: {
    height: screenWidth * 0.117,
    flexDirection: 'row',
    alignItems: 'center',
  },
  flexallign: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  fittrtxt: {
    left: 0,
    backgroundColor: 'white',
    height: 20,
    paddingHorizontal: 10,
    ...size_family.rr_14,
  },
});

export const NormodalStyle = StyleSheet.create({
  Normain: {
    // ...alignment.row_alingC_SpaceB,
    flex: 1,
    height: '70%',
    flexDirection: 'row',
    paddingHorizontal: 6,
  },
  Normaininner: {
    flex: 1,
    justifyContent: 'space-between',
    height: Dimensions.get('window').width * 0.292,
    paddingTop: 16,
  },
  watchListText: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  closestyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  NorMaxheight: {
    maxHeight: Dimensions.get('window').width * 0.8,
  },
  NorBanner: {
    height: 48,
    width: '100%',
    paddingRight: 10,
  },
  img: {
    height: 20,
    width: 20,
  },
  norModtxt: {
    color: root.ion_rb_2,
    marginLeft: '10%',
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  norModdis: {
    color: root.ion_rb_2,
    marginLeft: '10%',
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  binheart: {
    width: 55,
    ...alignment.row_SpaceB,
  },
  norbannertwo: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createWatchListText: {
    paddingLeft: 10,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    color: root.client_background,
  },
  footallign: {
    ...alignment.row_alignC,
    paddingVertical: 10,
    padding: 10,
  },
  btn: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  alligntouch: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export const TrendModalStyle = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  modalView: {
    position: 'absolute',
    //top: Dimensions.get('window').width * 0.9,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    // paddingHorizontal: 15,
    paddingVertical: 20,
    paddingBottom: 0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    // borderRadius: 10,
  },
  commonTimingView: {
    height: Dimensions.get('window').width * 0.619,
    width: 120,
    alignItems: 'flex-start',
  },
  notificationView: {
    height: 32,
    width: 32,
    borderRadius: 12.5,
    backgroundColor: 'white',
    alignSelf: 'flex-end',
    marginRight: 20,
    right: 0,
    top: -20,
  },
  itemBox: {
    // height: Dimensions.get('window').width * 0.35,
    // width: Dimensions.get('window').width * 0.33,
    height: Dimensions.get('window').width * 0.272,
    width: Dimensions.get('window').width * 0.272,

    borderRadius: 8,
    justifyContent: 'space-around',
    marginHorizontal: 10,
    paddingHorizontal: 10,
    marginBottom: 40,
    marginTop: 40,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 24,
  },
  tradeText: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 10,
    top: -20,
    left: 3,
  },
  image: {
    height: 15,
    width: 15,
  },
  companyNameText: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    top: -20,
    left: 3,
  },
  gainer: {
    backgroundColor: root.color_positive_rgb,
    height: 14,
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -15,
    left: 3,
  },
  gaTxt: {
    marginLeft: 3,
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    // backgroundColor: root.color_positive_rgb,
  },
  Loser: {
    backgroundColor: root.color_negative_rgb,
    height: 14,
    width: 52,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -15,
    left: 3,
  },
  Lotxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    // fontWeight: '400',
  },
  lenght: {
    color: root.color_active,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    backgroundColor: root.color_negative,
    paddingLeft: '5%',
    paddingTop: '2%',
    marginLeft: '6%',
    height: 16,
    width: 20,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewbox: {
    flexDirection: 'row',
    width: '35%',
    // justifyContent: 'space-between',
    alignItems: 'center',
  },
  Donttxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginRight: 10,
  },
  bannerallign: {
    ...alignment.row_alingC_SpaceB,
    paddingHorizontal: 16,
  },
  valpercentage: {
    flexDirection: 'row',
    top: -20,
    left: 3,
  },
  valtxtstyl: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  percentagestyl: {
    color: root.color_negative,
    fontSize: Font.font_normal_seven,
    marginLeft: '3%',
    fontFamily: Cfont.rubik_regular,
  },
});

//Custombottom  tabstyle

export const custombottomstyle = StyleSheet.create({
  mainContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'absolute',
    backgroundColor: 'rgba(52, 52, 52, 0.01)',
    bottom: 0,
    height: 60,
    width: '100%',
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,
    elevation: 24,
  },
  mainItemContainer: {
    flex: 1,
    height: 60,
    // backgroundColor: 'red',
  },
  customtab: {
    height: Dimensions.get('window').width * 0.147,
    width: Dimensions.get('window').width * 0.147,
    backgroundColor: root.client_background,
    borderRadius: 24,
    top: -25,
    transform: [{rotate: '45deg'}],
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 4,
  },
  tabtxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 5,
  },
  tabtxt2: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    marginTop: 5,
  },
  taballign: {
    height: 60,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
  taballigntwo: {
    height: 60,
    marginRight: 50,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
  taballignthree: {
    height: 60,
    marginLeft: 50,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
  customtabone: {
    alignItems: 'center',
    top: -10,
  },
  searchicon: {
    position: 'absolute',
    height: 0,
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'red',
  },
});
//Caurosal list style
export const Courselstyles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignSelf: 'center',
    height: '100%',
    zIndex: 100,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
  },
  scrillview: {
    paddingLeft: 16,
    paddingRight: 16,
    backgroundColor: root.color_active,
    maxHeight: '80%',
  },
  subContainer: {
    // borderTopLeftRadius: 20,
    // borderTopRightRadius: 20,
    // width: screenWidth - 50,
    //  height: screenHeight / 1.5,
    height: '100%',
    width: '100%',
    bottom: 0,
    // backgroundColor: 'rgba(52, 52, 52, 0.8)',
    alignSelf: 'center',
    position: 'relative',

    // padding: 16,
  },
  subContainertwo: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    // width: screenWidth - 50,
    height: screenHeight / 1.5,
    // height:"100%",
    // width:'100%',
    // top: screenHeight / 4.4,
    bottom: 0,
    // backgroundColor: 'white',
    alignSelf: 'center',
    position: 'absolute',

    // padding: 16,
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    width: '100%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: root.color_active,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
    height: 106,
  },
  companyName_Value_Text: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    padding: 2,
    fontSize: Font.font_normal_five,
  },
  buy_sell_Text: {
    paddingHorizontal: 40,
    fontSize: Font.font_normal_three,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    paddingVertical: 7,
  },
  buttonContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 10,
  },
  ordersView: {
    ...alignment.row_SpaceB,
    marginTop: '4%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  buySellViewContainer: {
    height: 160,
    width: '49%',
  },
  buyText: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  sellText: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  ordersHeaderText: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  progressMain: {
    backgroundColor: root.color_negative_rgb,
    height: 20,
    width: '100%',
    marginTop: '5%',
    alignSelf: 'center',

    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressOuter: {
    width: '50%',
    backgroundColor: root.color_positive_rgb,
    justifyContent: 'center',
    height: 20,
  },
  corhedval: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chaval: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  iconall: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 2,
  },
  bsesty: {
    marginTop: '3%',
    backgroundColor: '#F0F0F0',
    flexDirection: 'row',
    width: '35%',

    justifyContent: 'space-around',
  },
  txtsty: {
    color: root.color_text,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
  buysty: {
    backgroundColor: root.color_positive,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    width: '47%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  sellsty: {
    backgroundColor: root.color_negative,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 6,
    shadowColor: '#000',
    height: 40,
    width: '47%',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  Bidtxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  perplus: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  negtxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  oneflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  twoflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txtallign: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  prtitle: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  prval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  prline: {
    height: '5%',
    backgroundColor: 'yellow',
  },
  over: {
    width: '40%',
    height: 60,
    justifyContent: 'space-between',
  },
  threeflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
  },
  endstyle: {
    margin: '1%',
  },
});

export const DotModalStyle = StyleSheet.create({
  dotmodalallign: {
    flexDirection: 'row',
    height: 48,
    alignItems: 'center',
  },
  commonTimingView: {
    height: 300,
    width: 120,
    alignItems: 'flex-start',
  },
  image: {
    height: 14,
    width: 14,
    marginVertical: 10,
    alignSelf: 'flex-end',
  },
  dotmain: {
    color: root.color_text,
    paddingLeft: 20,
    fontSize: Font.font_normal_three,
    paddingVertical: 10,
    fontFamily: Cfont.rubik_regular,
  },
  imgsize: {
    height: 24,
    width: 24,
  },
});
export const SortModal = StyleSheet.create({
  Maincon: {
    width: Dimensions.get('window').width,
  },
  space: {
    height: 82,
    backgroundColor: 'white',
    marginBottom: 8,
  },
  spacetwo: {
    height: 82,
    backgroundColor: 'white',
    marginBottom: 8,
  },
  spaceinner: {
    backgroundColor: 'white',
    height: 30,
    padding: 16,
    paddingBottom: 0,
  },
  spacetwoinner: {
    backgroundColor: 'white',
    height: 30,
    padding: 16,
    paddingBottom: 0,
  },
  titleText: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: root.client_background,
    height: 40,
    width: 126.86,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F7FA',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtLUnSelected: {
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 10,
    height: 40,
    width: 126.86,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: root.client_background,
    height: 40,
    // width: 81,
    alignItems: 'center',
    paddingHorizontal: 24,
    justifyContent: 'center',
    backgroundColor: '#F5F7FA',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtZUnSelected: {
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 10,
    height: 40,
    // width: 81,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,

    // paddingRight: 24,
    // paddingLeft: 24,
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  text: {
    color: root.color_text,
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
  },
  Sorttitle: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: '5%',
  },
});

export const CloseModal = StyleSheet.create({
  innermain: {
    flex: 1.5,
    height: '100%',
    alignItems: 'center',
  },
  Wavetitle: {
    fontSize: 20,
    color: 'black',
    marginTop: '15%',
    fontWeight: 'bold',
    marginBottom: '20%',
  },
  leftallign: {
    justifyContent: 'flex-end',
    flex: 3,
    height: '100%',
    paddingBottom: '5%',
  },
  centeredView: {
    flex: 1,

    justifyContent: 'center',
    alignItems: 'center',

    backgroundColor: 'rgba(48,48,48,0.8)',
  },
  modalView: {
    flexDirection: 'row',
    margin: 30,
    height: Dimensions.get('window').height * 0.2,
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 5,

    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'left',
    fontSize: 15,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  button: {
    borderRadius: 20,
    height: 30,
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.client_background,
  },
  textStyle: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
  },
  buttontwo: {
    borderRadius: 20,
    height: 30,
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    backgroundColor: 'white',
  },
  textStyletwo: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
  },
});

//Constituents screen and its Components
export const constituentsScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  topBar: {
    marginTop: 10,
    // height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  switchBotton: {
    flexDirection: 'row',
    padding: 3,
    backgroundColor: 'rgba(0,0,0,0.07)',
    width: 90,
    borderRadius: 5,
    marginLeft: 10,
    marginTop: 10,
  },
  searchIcon: {
    marginRight: 20,
  },
  leftSwitchButtonWhite: {
    width: '45%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'white',
  },
  leftSwitchButtonTransparent: {
    width: '45%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'transparent',
  },
  rightSwitchButtonWhite: {
    width: '55%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'white',
  },
  rightSwitchButtonTransparent: {
    width: '55%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'transparent',
  },
  searchFilterContainer: {
    flexDirection: 'row',
    marginRight: 20,
    alignItems: 'center',
    marginTop: 10,
  },
  listViewContainer: {
    marginTop: 15,
    marginBottom: 50,
    width: '100%',
  },
  faltListBottomGap: {
    width: '100%',
    marginTop: 23,
    borderBottomWidth: 1,
    borderBottomColor: '#ededed',
  },
});
export const addToWatchListModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '30%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  select_watchList_Txt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  watchlistNameTxt: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
    paddingHorizontal: 10,
  },
  innerContainer: {
    height: '100%',
    paddingHorizontal: 10,
    paddingVertical: 16,
  },
  titleTxtContainer: {
    marginLeft: 6,
  },
  listViewContainer: {
    marginTop: '12%',
    height: '65%',
  },
  createWatchListContainer: {
    paddingLeft: 5,
    ...alignment.row,
    alignItems: 'center',
  },
  createWatchListTxt: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
    marginLeft: 10,
  },
  itemContainer: {
    ...alignment.row_alignC,
    marginVertical: '1.7%',
  },
});
export const constituentsListComponent = StyleSheet.create({
  container: {
    // borderBottomColor: 'grey',
    paddingHorizontal: 16,
    backgroundColor: 'yellow',

    // paddingVertical: 3,
    ...alignment.row_SpaceB,
  },
  future: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    marginLeft: 2,
  },
  stockName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    top: -2,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
  nseTxt: {
    fontSize: Font.font_normal_eight,
    // marginTop: 3,
    marginLeft: 5,
    //  backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    // borderColor: '#979797',
    // borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  volGainerTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    borderRadius: 10,
    paddingHorizontal: 5,
    top: -3,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    backgroundColor: '#4caf5026',
    fontFamily: Cfont.rubik_medium,
  },
  prLoserTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_negative,
    backgroundColor: '#d32f2f26',
    fontFamily: Cfont.rubik_medium,
  },
  defaultTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    borderRadius: 10,
    paddingHorizontal: 5,
    fontWeight: 'bold',
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_active,
  },
  changes: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  rightValuesView_200_300: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',
    // marginRight: 15,
    backgroundColor: root.color_positive_rgb,
  },
  rightValuesView_300_500: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',

    // width: 120,
    // marginRight: 15,
    backgroundColor: root.color_negative_rgb,
  },
  rightValuesDefault: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',

    // width: 120,
    // marginRight: 15,
    backgroundColor: root.color_active,
  },
  currentPriceTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
  },
});
export const constituentsBoxComponent = StyleSheet.create({
  container: {
    borderRadius: 10,
    shadowOffset: {width: 1, height: 1},
    shadowColor: '#0000001A',
    shadowOpacity: 0.8,
    marginTop: 10,
    elevation: 5,
    width: (Dimensions.get('window').width - 20) / 2 - 10,
    marginLeft: 5,
    marginBottom: 5,
    height: 130,
    borderColor: '#F4F4F4',
    padding: 10,
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  companyName: {
    color: '#ffffff',
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
  },
  price: {
    color: '#ffffff',
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_four,
  },
  changes: {
    color: 'white',
    fontFamily: Cfont.rubik_regular,
    marginTop: 5,
    fontSize: Font.font_normal_two,
  },
  T_container: {
    width: 30,
    height: 30,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: 'white',
    marginTop: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  T_text: {
    color: 'white',
    fontWeight: '500',
    fontSize: 15,
  },
});

//Overview Screen
export const overViewScreen = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#ffffff',
  },
  keyStatsContainer: {
    backgroundColor: 'white',
    height: 166,
    marginTop: 16,
  },
  keyStatsTxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  innerContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  keyStatsLowerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 16,
  },
  headingTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valuesTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 5,
  },
  horizontalLine: {
    borderWidth: 0.2,
    borderColor: 'grey',
    width: '100%',
    alignSelf: 'center',
    marginTop: 19,
    opacity: 0.3,
  },
  lowToHighTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 12,
  },
  dailyPriceTxt: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
  },
  linearGradient: {
    height: 4,
    width: 135,
    borderRadius: 5,
    marginTop: 6,
  },
});

//Future screen and its components
export const futureScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0)',
  },
});
export const listItem = StyleSheet.create({
  conatiner: {
    padding: 12,
  },
  card: {
    marginTop: 17,
    marginHorizontal: 16,
    backgroundColor: '#FFFFFF',
    height: 110,
    borderRadius: 20,
  },
  date: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  price: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  change: {
    fontSize: Font.font_normal_one,
    paddingTop: 4,
    paddingLeft: 3,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  discountTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  discount: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingLeft: 3,
    fontFamily: Cfont.rubik_medium,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
  dayPriceContainer: {
    ...alignment.row_alingC_SpaceB,
  },
  dateYearContainer: {
    ...alignment.row,
  },
  priceChangeContainer: {
    ...alignment.row,
    paddingTop: 10,
  },
  iconsContainer: {
    ...alignment.row,
  },
  plusCircleIcon: {
    marginHorizontal: 5,
  },
  discountConatiner: {
    ...alignment.row,
    paddingTop: 20,
  },
  T_text: {
    fontWeight: 'bold',
    color: 'black',
  },
  yearText: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_light,
    color: root.color_primary,
    marginLeft: 6,
  },
});

//Option chain and its components
export const optionChainScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  callsPutInner: {
    ...alignment.row_SpaceB,
    height: '100%',
  },
  expiryTxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 32,
    paddingLeft: 15,
  },
  dayValueTxtContainer: {
    justifyContent: 'center',
  },
  callsPutTxtContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: 12,
    marginTop: 34,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
  callsPutContainer: {
    height: 150,
  },
  value: {
    fontSize: Font.font_normal_two,
  },
  dayValue: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  dashedLine: {
    width: '100%',
    zIndex: 1,
    position: 'absolute',
    top: 14,
    borderWidth: 0.5,
    borderStyle: 'dashed',
  },
  hexagonContainer: {
    position: 'absolute',
    height: 20,
    zIndex: 1,
    width: '100%',
    left: 110,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
});
export const putModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  dataContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  singleDataContainer: {
    width: '45%',
  },
  topTxtContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  nameValueContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 5,
  },
  horizontalLine: {
    borderWidth: 0.5,
    marginHorizontal: 16,
    borderColor: '#979797',
  },
  callValue: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  callTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  buyBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_positive,
    borderRadius: 10,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
    paddingHorizontal: 16,
  },
});
export const callModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  dataContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  singleDataContainer: {
    width: '45%',
  },
  nameValueContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 5,
  },
  topTxtContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  horizontalLine: {
    borderWidth: 0.5,
    marginHorizontal: 16,
    borderColor: '#979797',
  },
  callValue: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  callTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  buyBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_positive,
    borderRadius: 10,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
    paddingHorizontal: 16,
  },
});
export const callPutList = StyleSheet.create({
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 22,
    height: 22,
    borderRadius: 22 / 2,
    ...alignment.alignC_justifyC,
  },
  leftContainerView: {
    height: '100%',
    width: 115,
    backgroundColor: '#FFFED6',
  },
  rightContainerView: {
    height: '100%',
    width: 115,
    backgroundColor: '#FFFFFF',
  },
  propertyValueContainer: {
    ...alignment.row,
  },
  leftContainerIconFlexDisplay: {
    paddingVertical: 5,
    alignItems: 'flex-end',
  },
  rightContainerIconFlexFlexDisplay: {
    paddingVertical: 5,
    alignItems: 'flex-start',
  },
  ltpTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  iconsContainer: {
    ...alignment.row,
    width: '60%',
    alignSelf: 'center',
    justifyContent: 'space-between',
    marginTop: 34,
  },
});
export const dateComponent = StyleSheet.create({
  dateContainerUnselected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
  },
  monthYearContainer: {
    ...alignment.row,
  },
  container: {
    paddingLeft: 10,
    paddingTop: 16,
  },
  dateContainerSelected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
    backgroundColor: root.client_background,
  },
  dateTxtUnselected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  dateTxtSelected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  monthTxtUnselected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  monthTxtSelected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
  },
  yearTxtUnselected: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  yearTxtSelected: {
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
  },
  expiryTxt: {
    fontSize: Font.font_normal_seven,
    color: 'grey',
    fontFamily: Cfont.rubik_regular,
    paddingTop: 25,
    paddingLeft: 15,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});
export const callPutCommonModal = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
});

//Market Screen and Components styling

export const marketScreen = StyleSheet.create({
  marketContainer: {
    backgroundColor: '#FFFFFF',
    flex: 1,
    // borderBottomColor: root.color_primary,
  },
  marketHeaderView: {
    width: '100%',
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_primary,
    paddingLeft: 17,
    paddingRight: 16,
  },
  marketHeaderIcon: {
    width: 15,
    backgroundColor: '#303030',
    height: 1.8,
    marginVertical: 1.5,
  },
  marketHeaderText: {
    color: root.color_text,
    fontSize: 16,
    marginLeft: 20,
    fontFamily: Cfont.rubik_medium,
  },
  scrollBarBackgroundView: {
    width: '100%',
    paddingHorizontal: 13,
    flexDirection: 'row',
    // alignSelf: 'center',
  },
  scrollBarView: {
    flexDirection: 'row',
    borderRadius: 25,
    // alignItems:"center",
    // justifyContent:"center",
    height: 32,
  },
  scrollView: {
    borderRadius: 25,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.10)',
    marginVertical: 0,
    marginLeft: 0,
    height: 32,
  },
  scrollBarTextBg: {
    paddingHorizontal: 10,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    // backgroundColor: index == 0 ? root.color_textual : 'transparent',
  },
  scrollBarText: {
    fontSize: 11,
    marginHorizontal: 9,
    fontFamily: Cfont.rubik_medium,
  },
  whatsNewHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 14,
  },
  WhatsNewFlatlistFooter: {
    width: 16,
  },
  WhatsNewContentContainer: {
    marginLeft: 16,
  },
  newProductHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newProductFlatList: {
    marginLeft: 16,
  },
  indicesHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  indicesHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 17,
  },
  indicesViewAllBtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
    marginTop: 15,
  },
  indicesFlateList: {
    marginLeft: 16,
  },
  myScreenerHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  myScreenerHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 9,
    marginBottom: 3,
  },
  myScreenerViewAllbtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  myScreenerScrollView: {
    marginLeft: 13,
  },
  newsAndAnnounceHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  newAndAnnounceHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newAndAnnounceSearchBtn: {
    color: root.color_text,
    paddingTop: 16,
  },
  newAndAnnounceFlatListFooter: {
    width: 16,
  },
  newAndAnnounceFlatlist: {
    marginTop: -10,
  },
  newAndAnnounceBottomListView: {
    marginTop: 18,
  },
  viewAllNews: {
    color: root.color_textual,
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 33,
  },
  eventHeadView: {
    ...alignment.row_alingC_SpaceB,
    ...p.r_15,
  },
  eventHeadText: {
    ...color.text,
    ...size_family.rm_16,
    ...p.l_16,
    ...m.t_5,
  },
  eventDateView: {
    backgroundColor: root.calendar_bg,
    height: 60,
    width: '100%',
    ...m.t_5,
    ...alignment.row_alingC_SpaceB,
  },
  eventCurrentDate: {
    ...color.text,
    ...size_family.rm_15,
    ...m.m_l_16,
  },
  eventCalendarIcon: {
    ...m.r_15,
  },
  eventCalendar: {
    width: '100%',
  },
  eventCalendarTheme: {
    calendarBackground: root.color_chipFilter,
    dayTextColor: root.color_text,
    textDayFontWeight: '800',
    textDayFontSize: 17,
    textSectionTitleColor: root.color_text,
    textSectionTitleFontWeight: '800',
    textDayHeaderFontSize: 17,
    textDayHeaderFontWeight: '800',
  },
  eventFlatList: {
    ...m.t_15,
    ...m.b_30,
  },
  noEventView: {
    ...alignment.alignC_justifyC,
  },
  noEventImage: {
    height: 110,
    width: 115,
    ...m.t_10,
  },
  emptyEventText: {
    ...color.subtext,
    ...size_family.rr_14,
    ...m.b_60,
    ...m.t_13,
  },
  ipoHeadText: {
    ...color.text,
    ...size_family.rm_16,
    ...p.l_16,
    ...m.t_10,
  },
  ipoFlatList: {
    ...m.m_l_13,
    ...p.r_10,
  },
  ipoFooter: {
    height: 135,
  },
  ipoHeadView: {
    ...alignment.row_alingC_SpaceB,
    ...p.r_15,
  },
  ipoViewAllbtn: {
    ...color.client_background,
    ...size_family.rm_11,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...p.l_16,
    ...p.t_18,
    ...m.b_12,
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
  },
  filterTagData: {
    ...size_family.rm_9,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
  eventBtnView: {
    ...alignment.row_alignC,
    ...p.t_19,
    ...m.b_7,
  },
  eventSearchBtn: {
    ...color.text,
    fontSize: 24,
  },
  eventFilterBtn: {
    ...color.text,
    fontSize: 24,
    ...m.m_l_10,
  },
});

export const whatsNewComp = StyleSheet.create({
  whatsNewContainer: {
    // marginLeft: 16,
    height: 127,
    width: Dimensions.get('window').width / 1.25,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    flexDirection: 'row',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    overflow: 'hidden',
  },
  whatsNewTitle: {
    color: '#303030',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 15,
    marginTop: 13,
  },
  whatsNewSubTitle: {
    color: '#303030',
    fontSize: 12,
    marginLeft: 15,
    marginTop: 8,
    fontFamily: Cfont.rubik_regular,
  },
  whatsNewButton: {
    backgroundColor: '#25325C',
    width: 100,
    height: 35,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 15,
    marginTop: 11,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  whatsNewButtonText: {
    color: 'white',
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  whatsNewImage: {
    height: 85,
    width: 90,
    marginTop: 11,
    marginRight: 15,
    backgroundColor: 'white',
  },
});

export const newProductComp = StyleSheet.create({
  container: {
    backgroundColor: '#B6D0E2',
    height: 131,
    width: 171,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
    borderStartColor: '#EFF3FF',
  },
  container2: {
    backgroundColor: '#B6D0E2',
    height: 131,
    width: 171,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
    borderStartColor: '#B4EBCC',
  },
  image: {
    height: 83,
    width: 95,
    marginTop: 15,
    backgroundColor: 'white',
  },
  imageView: {
    height: 83,
    width: 95,
    marginTop: 15,
    backgroundColor: 'white',
  },
});

export const indicesComp = StyleSheet.create({
  container: {
    backgroundColor: root.indices_red,
    height: 133,
    width: 145,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    marginTop: 10,
    paddingBottom: 25,
    fontSize: 13,
  },
  price: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    paddingBottom: 2,
    fontSize: 17,
  },
  changes: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    fontSize: 11,
  },
  date: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_light,
    marginLeft: 12,
    marginTop: 14,
    fontSize: 9,
  },
});

export const myScreenerComp = StyleSheet.create({
  container: {
    backgroundColor: root.color_active,
    height: 115,
    width: 112,
    marginVertical: 10,
    marginBottom: 18,
    marginRight: 13,
    marginLeft: 3,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    paddingTop: 20,
    paddingRight: 18,
    paddingBottom: 18,
    fontSize: 13,
  },
});

export const newsComp = StyleSheet.create({
  container: {
    backgroundColor: root.color_text,
    height: 175,
    width: 150,
    marginVertical: 15,
    borderRadius: 8,
    marginLeft: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    marginLeft: 12,
    marginRight: 15,
    marginBottom: 8,
    marginTop: -7,
  },
  subTitle: {
    color: root.color_active,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    marginRight: 17,
  },
  icon: {
    textAlign: 'right',
    padding: 3,
  },
});

export const newsListComp = StyleSheet.create({
  container: {
    // backgroundColor: '#fff',
    height: 90,
    width: '90%',
    marginTop: 5,
    alignSelf: 'center',
    flexDirection: 'row',
    marginLeft: 16,
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    marginRight: 5,
    paddingBottom: 8,
  },
  time: {
    color: '#303030',
    fontSize: 9,
    paddingTop: 6,
    fontFamily: Cfont.rubik_regular,
  },
  nse: {
    color: root.color_text,
    fontSize: 9,
    fontFamily: Cfont.rubik_medium,
    paddingBottom: 8,
  },
  stockName: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    paddingBottom: 2,
  },
  price: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: 13,
    paddingBottom: 2,
  },
  changes: {
    color: root.indices_red,
    fontFamily: Cfont.rubik_regular,
    fontSize: 11,
  },
  line: {
    height: 57,
    width: 0.5,
    backgroundColor: 'grey',
    marginTop: 10,
    alignSelf: 'center',
    marginRight: 10,
    opacity: 0.2,
    marginLeft: 8,
  },
  newsLeftView: {
    width: '60%',
  },
});

//Calendar Date event component style

export const dateEventComp = StyleSheet.create({
  container: {
    ...m.v_20,
    ...alignment.row_alingC_SpaceB,
  },
  companyName: {
    ...size_family.rm_13,
    ...color.text,
    ...m.m_l_15,
  },
  event: {
    backgroundColor: '#9AB3FF33',
    ...p.p_3,
    ...p.h_6,
    borderRadius: 8,
    ...m.m_l_15,
    ...m.t_6,
    alignSelf: 'flex-start',
  },
  eventText: {
    color: root.color_textual,
    ...size_family.rm_8,
  },
  icon: {
    fontSize: 24,
    ...color.text,
    ...p.r_15,
  },
});

export const ipoComp = StyleSheet.create({
  container: {
    ...bgColor.color_active,
    height: 238,
    width: 195,
    borderRadius: 8,
    ...m.t_20,
    ...m.v_10,
    ...m.r_13,
    ...m.m_l_3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  innerView: {
    ...m.m_l_13,
  },
  imageView: {
    backgroundColor: '#FF6700',
    height: 39,
    width: 39,
    borderRadius: 25,
    ...m.t_10,
    opacity: 0.7,
    justifyContent: 'center',
  },
  title: {
    ...color.text,
    ...size_family.rm_11,
    width: '60%',
    ...m.t_10,
    ...m.m_l_6,
  },
  subTitle: {
    ...color.active,
    ...size_family.rm_9,
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: 'center',
    borderRadius: 25,
    ...m.t_12,
    alignSelf: 'flex-start',
  },
  pricerRange: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_36,
  },
  issueDate: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  date: {
    ...color.text,
    ...size_family.rr_11,
  },
  minQty: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  qty: {
    ...color.text,
    ...size_family.rr_11,
  },
  minAmount: {
    ...color.text,
    ...m.t_12,
    ...size_family.rm_11,
  },
  amount: {
    ...color.text,
    ...size_family.rr_11,
  },
  titleAndImgView: {
    ...alignment.row,
  },
  minQtyAndAmmountView: {
    ...alignment.row_SpaceB,
    ...m.r_25,
  },
});

// Porfolio Screen styling

export const portFolioScreen = StyleSheet.create({
  portFolioContainer: {
    flex: 1,
  },
  tabBarContainer: {
    ...alignment.row,
    ...p.h_16,
    height: 40,
    ...bgColor.color_active,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: root.color_textual,
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  selectedBtnText: {
    textAlign: 'center',
    ...color.client_background,
    ...size_family.rm_12,
  },
  tabBtnsText: {
    textAlign: 'center',
    ...color.subtext,
    ...size_family.rm_12,
  },

  // Nifty and Sensex Header styling

  currentAndInvestedView: {
    ...m.t_8,
    ...alignment.row_SpaceB,
  },
  currentValue: {
    ...size_family.rm_9,
    ...color.text,
    ...m.m_l_16,
  },
  currentValueNumber: {
    ...size_family.rr_17,
    ...color.text,
    ...m.m_l_16,
  },
  overAllPl: {
    ...color.text,
    ...size_family.rm_9,
    ...m.m_l_16,
    ...m.t_3,
  },
  overAllPlNumber: {
    ...color.positive,
    ...size_family.rr_11,
    ...m.m_l_16,
  },
  investedValue: {
    ...color.text,
    ...size_family.rm_9,
  },
  investedValueNumber: {
    ...color.text,
    ...size_family.rr_11,
  },
  todaysPl: {
    ...color.text,
    ...size_family.rm_9,
    flex: 1,
    ...p.t_10,
  },
  todaysNumber: {
    color: root.color_negative,
    ...size_family.rr_11,
  },
});

// Holding Screen Styling

export const holdingScreen = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  header: {
    ...alignment.row_alingC_SpaceB,
    height: 45,
    ...m.v_1,
  },
  headerScripsText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rl_12,
  },
  headerIconsView: {
    ...alignment.row_alignC,
  },
  headerInfoIcon: {
    ...m.r_15,
  },
  headerSearchIcon: {
    ...m.r_15,
  },
  headerFilterIcon: {
    ...m.r_20,
  },
  holdingFlatlistFooter: {
    width: '100%',
    height: Dimensions.get('window').height / 2.5,
    ...m.b_50,
  },
  toolkitText: {
    ...color.active,
    ...size_family.rr_9,
  },
  toolkitView: {
    height: 38,
    width: 200,
    backgroundColor: root.color_text,
    borderRadius: 7,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...m.m_l_16,
    flexWrap: 'wrap',
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_5,
  },
  ammountTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_8,
  },
  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
    ...m.t_10,
  },
  filterTagData: {
    ...size_family.rm_10,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
});

// holdingListComponent code
export const holdingListComp = StyleSheet.create({
  container: {
    ...p.p_3,
    ...p.l_10,
    // ...alignment.row_SpaceB,
    height: 75,
    borderRadius: 7,
    width: '94%',
    alignSelf: 'center',
    ...bgColor.color_active,
    ...m.t_6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    // overflow: 'hidden',
  },
  listTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...p.t_2,
  },
  listSubTitle: {
    ...size_family.rr_11,
    ...color.text,
    ...p.t_7,
  },
  listPlLtpView: {
    alignItems: 'flex-end',
    ...m.r_5,
  },
  listPlText: {
    ...size_family.rr_11,
    ...color.text,
    ...m.t_10,
  },
  listLtpText: {
    ...size_family.rr_11,
    ...color.text,
    ...p.t_2,
  },
  listPlValue: {
    ...size_family.rr_11,
    ...p.t_10,
  },
  listLtpValue: {
    ...size_family.rr_11,
    ...m.t_2,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  rowSpaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  rowSpaceBetweenCenter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

//Footer
export const FooterStyles = StyleSheet.create({
  footerContainer: {
    padding: 16,

    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'white',
  },
  itemContainer: {
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  text: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
  },
  cliper: {
    borderRadius: 16,
  },
});

//Holding Search Modal

export const HoldingSearchModal = StyleSheet.create({
  modal: {
    width: Dimensions.get('window').width,
    height: '100%',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: 'center',
    ...m.t_100,
  },
});

//position Search modal

export const positionSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: '100%',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: 'center',
    ...m.t_100,
  },
});

// holding Screen bottom Modal
export const holdingBottomModal = StyleSheet.create({
  modalView: {
    width: '100%',
    ...p.h_7,
  },
  stockName: {
    ...color.text,
    ...m.t_10,
    ...size_family.rm_14,
  },
  stockTitle: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_6,
  },
  stockDetailsView: {
    ...alignment.row_SpaceB,
    ...m.b_10,
    ...m.t_12,
  },
  stockDetailsText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_6,
  },
  stockDetailsValue: {
    ...size_family.rr_11,
    ...m.v_6,
  },
  additionalDetailsText: {
    ...color.text,
    ...size_family.rm_11,
  },
  additionalDetailsTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_8,
  },
  additionalDetailsValues: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_8,
  },
  additionalTextIconView: {
    ...alignment.row_alignC,
    ...m.t_17,
  },
  upDownIcon: {
    ...m.m_l_9,
  },
  row: {
    ...alignment.row,
  },
  additionDetailView: {
    ...alignment.row_SpaceB,
    ...m.b_28,
    ...m.t_22,
  },
  rowSpaceBtween: {
    ...alignment.row_SpaceB,
  },
});

// BuySellButton Style
export const BuySellBtn = StyleSheet.create({
  conatiner: {
    borderRadius: 7,
    height: 40,
    ...alignment.alignC_justifyC,
    ...m.b_16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },
  btnText: {
    ...color.active,
    ...size_family.rr_14,
  },
});

// position screen Bottom Modal

export const positionBottomModal = StyleSheet.create({
  positionmodalView: {
    // height: 254,
    width: '100%',
    ...p.h_7,
  },
  positionlistTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...m.t_4,
  },
  positiontitleChip: {
    ...m.m_l_5,
    backgroundColor: 'rgba(151,151,151,0.1)',
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...m.t_4,
  },
  positiontitleChipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  positionbuyText: {
    color: root.color_positive,
    ...size_family.rm_11,
    ...m.t_7,
  },
  positionlistSubTitle: {
    ...color.text,
    ...size_family.rl_10,
    ...m.t_7,
  },
  positionbottomChip: {
    backgroundColor: '#EFF3FF',
    borderRadius: 10,
    ...m.t_10,
    ...alignment.row,
    ...alignment.alignC_justifyC,
    ...p.p_2,
    ...p.h_4,
  },
  positionbottomChipText: {
    ...size_family.rm_10,
    color: root.color_textual,
  },
  positionlistPlLtpView: {
    alignItems: 'flex-end',
    ...m.r_5,
  },
  positionlistPlText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_10,
  },
  positionlistPlValue: {
    color: root.color_negative,
    ...size_family.rr_11,
    ...m.b_10,
  },
  positionlistLtpText: {
    ...color.text,
    ...size_family.rm_11,
    // marginTop: 3,
  },
  positionlistLtpValue: {
    ...color.text,
    ...size_family.rr_11,
    // marginTop: 3,
  },

  positionadditionalDetailsText: {
    ...color.text,
    ...size_family.rm_11,
  },
  positionadditionalDetailsTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_18,
  },
  positionadditionalDetailsHTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_6,
    ...m.t_12,
  },
  positionadditionalDetailsValues: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_18,
  },
  positionaddtionaldetailsView: {
    ...alignment.row_SpaceB,
    ...m.b_10,
  },
  closeIcon: {
    ...alignment.row,
    justifyContent: 'flex-end',
    ...m.t_4,
  },
  additionalTextIconView: {
    ...alignment.row_alignC,
    ...m.t_17,
  },
  upDownIcon: {
    ...m.m_l_8,
  },
  row: {
    ...alignment.row,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  rowSpacebetween: {
    ...alignment.row_SpaceB,
  },
  subView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
});

//position Bottom modal button

export const positionModalButton = StyleSheet.create({
  conatiner: {
    // flex: 1,
    ...bgColor.color_active,
    borderWidth: 1,
    borderBottomColor: root.color_textual,
    borderRadius: 7,
    height: 40,
    // width: 100,
    ...alignment.alignC_justifyC,
    ...m.b_23,
    ...m.t_5,
  },
  btnText: {
    ...size_family.rm_14,
    color: root.color_textual,
  },
});

//Holding Screen filter style

export const holdingFilter = StyleSheet.create({
  Maincon: {
    width: Dimensions.get('window').width,
  },
  contentView: {
    ...m.b_100,
    ...m.t_20,
  },
  space: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spacetwo: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spaceinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  spacetwoinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  titleText: {
    ...color.text,
    ...size_family.rm_12,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 126,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },

  commonAtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 81,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_5,
    ...m.t_15,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
  applyBtn: {
    width: '100%',
    ...bgColor.client_background,
    height: 50,
    ...alignment.alignC_justifyC,
    position: 'absolute',
    bottom: 0,
  },
  applyBottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});
export const minMaxcomp = StyleSheet.create({
  commonMinMaxSelected: {
    borderWidth: 1,
    borderRadius: 10,
    height: 40,
    width: 180,
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    ...alignment.row_alignC,
  },
  minMaxTextInput: {
    borderBottomColor: root.color_subtext,
    height: 20,
    padding: 0,
    margin: 0,
    width: 130,
    flex: 1,
    ...m.r_5,
    textAlign: 'right',
    color: root.client_background,
  },
  minMaxText: {
    ...color.text,
    ...size_family.rr_14,
    ...m.m_l_17,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
});

//position Screen styles
export const positionScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  switchButtonView: {
    width: '100%',
    height: 30,
    alignSelf: 'center',
    borderRadius: 25,
    ...m.t_10,
    ...alignment.row,
    ...p.h_13,
  },
  todaysView: {
    height: 30,
    ...alignment.alignC_justifyC,
    width: '50%',
    flex: 1,
    borderTopLeftRadius: 25,
    borderBottomLeftRadius: 25,
  },
  todayText: {
    ...size_family.rm_12,
  },
  overallView: {
    height: 30,
    ...alignment.alignC_justifyC,
    width: '50%',
    flex: 1,
    borderTopEndRadius: 25,
    borderBottomEndRadius: 25,
  },
  overallText: {
    ...size_family.rm_12,
  },
  header: {
    color: root.color_active,
    ...alignment.row_alingC_SpaceB,
    height: 45,
    ...m.t_5,
  },
  todayPlTextValueView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
  todaysPlText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rm_10,
  },
  todaysPlValue: {
    color: root.color_negative,
    ...size_family.rm_10,
  },
  actualPlTextValueView: {
    ...alignment.row_alignC,
    ...m.t_2,
  },
  actualPlText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rm_10,
  },
  actualPlValue: {
    ...color.text,
    ...size_family.rm_10,
  },
  headerIconsView: {
    ...alignment.row_alignC,
  },
  headerSearchIcon: {
    ...m.r_15,
  },
  headerFilterIcon: {
    ...m.r_20,
  },
  squareOffView: {
    backgroundColor: root.color_textual,
    borderRadius: 25,
    width: 85,
    ...alignment.alignC_justifyC,
    ...m.r_20,
    height: 24,
  },
  squareOffViewText: {
    ...color.active,
    ...size_family.rr_12,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...p.l_16,
    flexWrap: 'wrap',
    ...m.t_3,
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_5,
  },
  ammountTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_8,
  },

  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
    ...m.t_10,
  },
  filterTagData: {
    ...size_family.rm_10,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
});

//position Filter style
export const positionFilter = StyleSheet.create({
  Maincon: {
    width: Dimensions.get('window').width,
  },
  contentView: {
    ...m.b_100,
    ...m.t_20,
  },
  space: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spacetwo: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spaceinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  spacetwoinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  titleText: {
    ...color.text,
    ...size_family.rm_12,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 117,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },

  commonAtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 81,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
  applyBtn: {
    width: '100%',
    ...bgColor.client_background,
    height: 50,
    ...alignment.alignC_justifyC,
    position: 'absolute',
    bottom: 0,
  },
  applyBottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});
//ToadysList Component

export const todaysList = StyleSheet.create({
  container: {
    ...p.p_3,
    ...p.l_10,
    ...alignment.row_SpaceB,
    height: 85,
    borderRadius: 7,
    width: '94%',
    alignSelf: 'center',
    ...bgColor.color_active,
    ...m.t_8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },
  listTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...m.t_4,
  },
  titleChip: {
    ...m.m_l_5,
    backgroundColor: 'rgba(151,151,151,0.1)',
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...m.t_4,
  },
  titleChipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  buyText: {
    color: root.color_positive,
    ...size_family.rm_11,
    ...m.t_7,
  },
  listSubTitle: {
    ...size_family.rl_10,
    ...color.text,
    ...m.t_7,
  },
  bottomChip: {
    backgroundColor: '#EFF3FF',
    borderRadius: 10,
    ...m.t_10,
    ...alignment.alignC_justifyC,
    ...alignment.row,
    ...p.p_2,
    ...p.h_4,
  },
  bottomChipText: {
    ...size_family.rm_10,
    ...color.client_background,
  },
  listPlLtpView: {
    alignItems: 'flex-end',
    ...m.r_5,
  },
  listPlText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_10,
  },
  listPlValue: {
    ...size_family.rr_11,
    ...m.b_10,
  },
  listLtpText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.t_4,
  },
  listLtpValue: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_4,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  subView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
  row: {
    ...alignment.row,
  },
});

// Square Off screen style

export const squareOff = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    width: '100%',
  },
  subContainer: {
    // paddingHorizontal: 18,
    flex: 1,
    width: '100%',
  },
  squareHeaderView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    paddingHorizontal: 16,
  },
  backIcon: {
    color: root.color_text,
    fontSize: 23,
  },
  squareOffText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    marginLeft: 15,
  },
  orderHeadView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  orderText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  selectAllTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectAllText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_five,
  },
  selectAllIcon: {
    color: root.color_text,
    fontSize: 24,
    marginLeft: 10,
  },
  headerBorder: {
    color: root.color_subtext,
    borderWidth: 0.2,
    opacity: 0.1,
    marginTop: 15,
    marginHorizontal: 16,
  },
  bottomView: {
    backgroundColor: root.color_textual,
    height: 71,
    width: '100%',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  bottominnerView: {
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomSquareOffText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: '#FFFFFF',
  },
  bottomSelectedText: {
    color: '#FFFFFF',
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    marginTop: 3,
  },
  bottomDoneBtn: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    height: 43,
    width: 81,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomDoneText: (length: number) => ({
    fontSize: Font.font_normal_two,
    color: length > 0 ? root.color_textual : root.color_subtext,
    fontFamily: Cfont.rubik_medium,
  }),
  bottomCountView: {
    backgroundColor: root.color_negative,
    height: 16,
    width: 20,
    borderRadius: 25,
    marginLeft: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 3,
  },
  bottomCountText: {
    color: '#FFFFFF',
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
});

//square Off list styles
export const squareOffList = (props = {}) =>
  StyleSheet.create({
    container: {
      padding: 3,
      flexDirection: 'row',
      justifyContent: 'space-between',
      height: 120,
      width: '100%',
      alignSelf: 'center',
      backgroundColor:
        props.clicked === true ? 'rgba(211, 47, 47, 0.15)' : '#FFFFFF',
      paddingTop: 15,
      paddingHorizontal: 16,
    },
    listTitle: {
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_fifteen,
      marginTop: 4,
    },
    titleChip: {
      marginLeft: 5,
      backgroundColor: 'rgba(151,151,151,0.1)',
      borderRadius: 2,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 4,
      // padding: 1,
    },
    titleChipText: {
      fontSize: Font.font_normal_eight,
      fontFamily: Cfont.rubik_medium,
      color: '#979797',
    },
    buyText: {
      color: root.color_positive,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_medium,
      marginTop: 12,
    },
    listSubTitle: {
      fontSize: Font.font_normal_six,
      color: root.color_text,
      fontFamily: Cfont.rubik_light,
      marginTop: 12,
    },
    bottomChip: {
      backgroundColor: '#25335C33',
      borderRadius: 10,
      marginTop: 13,
      // justifyContent: 'center',
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      padding: 2,
      paddingHorizontal: 4,
    },
    bottomChipText: {
      fontSize: Font.font_normal_six,
      fontFamily: Cfont.rubik_medium,
      color: root.color_textual,
    },
    listPlLtpView: {
      alignItems: 'flex-end',
    },
    listPlText: {
      fontSize: Font.font_normal_six,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      // marginBottom: 5,
      marginTop: 4,
    },
    listPlValue: {
      fontSize: Font.font_normal_six,
      color: root.color_negative,
      fontFamily: Cfont.rubik_regular,
      // marginBottom: 10,
      marginTop: 4,
    },
    listLtpText: {
      fontSize: Font.font_normal_seven,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      marginTop: 4,
    },
    listLtpValue: {
      fontSize: Font.font_normal_seven,
      color: root.color_text,
      fontFamily: Cfont.rubik_regular,
      marginTop: 4,
    },
    selectAllIcon: {
      color: root.color_text,
      fontSize: 24,
    },
  });

// Choose Indiecs screen style

export const chooseIndices = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    paddingHorizontal: 16,
  },
  crossicon: {
    fontSize: Font.font_normal_twenty_six,
    color: root.color_text,
    marginTop: 16,
  },
  title: {
    fontSize: Font.font_sub_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 16,
  },
});

//ChooseIndices Card styles

export const chooseIndicesCard = (props = {}) =>
  StyleSheet.create({
    mainView: {
      backgroundColor: root.choose_indices_background,
      height: 157,
      width: '100%',
      marginTop: 44,
      borderRadius: 8,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 3,
    },
    innerView: {
      paddingTop: 18,
      paddingHorizontal: 18,
      paddingBottom: 10,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    stockName: {
      color: root.color_active,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_medium,
      paddingBottom: 26,
    },
    leftStockprice: {
      color:
        props.leftPrice > 15000
          ? root.color_positive
          : props.leftPrice === 0
          ? root.color_active_text
          : root.color_negative,
      fontSize: Font.font_normal_twenty_two,
      fontFamily: Cfont.rubik_regular,
    },
    rightStockprice: {
      color:
        props.rightPrice > 15000
          ? root.color_positive
          : props.rightPrice === 0
          ? root.color_active_text
          : root.color_negative,
      fontSize: Font.font_normal_twenty_two,
      fontFamily: Cfont.rubik_regular,
    },
    leftStockchanges: {
      color:
        props.leftPrice > 15000
          ? root.color_positive
          : props.leftPrice === 0
          ? root.color_active_text
          : root.color_negative,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_regular,
    },
    rightStockchanges: {
      color:
        props.rightPrice > 15000
          ? root.color_positive
          : props.rightPrice === 0
          ? root.color_active_text
          : root.color_negative,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_regular,
    },
    changeBotton: {
      backgroundColor: root.color_active,
      height: 23,
      width: 69,
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 25,
      marginTop: 10,
    },
    changeBottonText: {
      fontSize: Font.font_normal_seven,
      color: root.color_textual,
      fontFamily: Cfont.rubik_medium,
    },
    centerLine: {
      height: '99%',
      width: 0.8,
      backgroundColor: root.color_active,
      opacity: 0.4,
    },
  });

// Choose Indices  Modal

export const chooseIndicesModal = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
    //   backgroundColor : "#00BCD4",
    //   height: 300 ,
    //   width: '80%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: root.color_active,
    width: '100%',
    height: 58,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  headerTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_ten,
    marginLeft: 19,
  },
  crossIcon: {
    paddingLeft: 16,
    fontSize: Font.font_normal_twenty_six,
    color: root.color_text,
  },
  searchIcon: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_twenty_six,
    marginRight: 22,
  },
  listView: dropDown => ({
    flex: 1,
    paddingHorizontal: 16,
    zIndex: dropDown ? -1 : 0,
  }),
  dropDown: {
    height: 16,
    // width: 70,
    backgroundColor: root.dropdown_background,
    alignItems: 'center',
    marginLeft: 2,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  dropDownText: {
    fontSize: Font.font_normal_six,
    color: root.color_subtext,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 2,
  },
  dropDownListView: {
    height: 128,
    width: 80,
    backgroundColor: root.color_active,
    zIndex: 10,
    position: 'absolute',
    top: 16,
    elevation: 2,
    borderRadius: 6,
    marginLeft: 2,
  },
  dropDownItems: {
    fontSize: Font.font_normal_five,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 10,
    marginBottom: 15,
    marginLeft: 7,
  },
  arrowIcon: {
    color: root.color_subtext,
    fontSize: Font.font_normal_fifteen,
    paddingRight: 2,
    paddingLeft: 8,
  },
  headerInsideView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
});

//Choose Indices Serach Modal styles
export const chooseIndicesSearch = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    marginHorizontal: 13,
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  micIcon: {
    marginHorizontal: 13,
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  textInput: {
    flex: 1,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

// IndicesList style

export const indicesList = StyleSheet.create({
  mainView: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 27,
  },
  circleIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_one,
  },
  title: {
    fontSize: Font.font_normal_five,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 25,
  },
});

//Indices View All styling

export const indicesViewAll = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    paddingHorizontal: 18,
    height: 53,
    alignItems: 'center',
  },
  headerShadowHideView: {
    width: '100%',
    height: 8,
    backgroundColor: root.color_active,
    // zIndex: 10,
  },
  headerTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_ten,
    marginLeft: 34,
  },
  backIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_two,
  },
  filterIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_two,
  },

  // cutom Tab Bar style

  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 46,
    backgroundColor: root.color_active,
    // shadowColor: '#000',
    // shadowOffset: {
    //   width: 20,
    //   height: 20,
    // },
    // shadowOpacity: 0.25,
    // shadowRadius: 3.84,
    elevation: 8,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: root.color_textual,
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  selectedBtnText: {
    textAlign: 'center',
    color: root.color_textual,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
  },
  tabBtnsText: {
    textAlign: 'center',
    color: root.color_subtext,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
  },

  // tab bar style not cutom
  tabBarLabelStyle: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    textTransform: 'none',
    marginBottom: 20,
  },
  tabBarStyle: {
    height: 40,
  },
  tabBarIndicatorStyle: {
    backgroundColor: root.color_textual,
    width: 120,
    marginLeft: 14,
    paddingRight: 17,
    height: 1.8,
  },
});

//Box component Indices View All

export const boxComponentIndices = (props = {}) =>
  StyleSheet.create({
    container: {
      backgroundColor:
        props.price > 13000
          ? root.color_positive
          : props.price == 0
          ? '#B1B1B1'
          : root.indices_red,
      height: 132,
      // flex: 0.5,
      width: '48%',
      marginBottom: 14,
      borderRadius: 8,
      marginRight: 11,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,

      elevation: 3,
      overflow: 'hidden',
    },
    title: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_medium,
      marginLeft: 12,
      marginTop: 11,
      paddingBottom: 25,
      fontSize: 12,
    },
    price: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 12,
      paddingBottom: 2,
      fontSize: 16,
    },
    changes: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 12,
      fontSize: Font.font_normal_seven,
    },
    date: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_light,
      marginLeft: 12,
      marginTop: 12,
      fontSize: Font.font_normal_six,
    },
    heartIcon: {
      fontSize: Font.font_normal_twenty_one,
      color: root.color_active,
      marginRight: 15,
      marginTop: 11,
    },
    titleHeartView: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
  });

//indexFilter style

export const indexFilter = (props = {}) =>
  StyleSheet.create({
    Maincon: {
      width: Dimensions.get('window').width,
    },
    space: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spacetwo: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spaceinner: {
      backgroundColor: 'white',
      height: 33,
      padding: 16,
      paddingBottom: 0,
    },
    spacetwoinner: {
      backgroundColor: 'white',
      height: 33,
      padding: 16,
      paddingBottom: 0,
    },
    titleText: {
      color: root.color_text,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
    },
    commonPriceSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true && props?.type == 'Price'
          ? root.client_background
          : root.color_border,
      height: 40,
      width: 126,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:
        props?.selected == true && props?.type == 'Price' ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 10,
      marginTop: 15,
      // marginHorizontal:20
    },
    commonPercentageSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true && props?.type == 'Percentage'
          ? root.client_background
          : root.color_border,
      height: 40,
      width: 126,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:
        props?.selected == true && props?.type == 'Percentage'
          ? '#F5F7FA'
          : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 10,
      marginTop: 15,
      // marginHorizontal:20
    },

    commonAlphaSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 5,
      marginTop: 15,
      // marginHorizontal:20
    },
    text: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
    },
    applyBtn: {
      width: '100%',
      backgroundColor: root.color_textual,
      height: 50,
      justifyContent: 'center',
      alignItems: 'center',
      position: 'absolute',
      bottom: 0,
    },
    applyBottonText: {
      fontSize: 14,
      color:
        props?.FilterData != '' || props?.new != ''
          ? root.color_active
          : root.color_primary,
      fontFamily: Cfont.rubik_medium,
    },
    contentView: {
      height: Dimensions.get('window').height - 68,
      marginLeft: 7,
    },
  });

//MyFavourites screen style

export const myFavouritesScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    paddingHorizontal: 12,
  },
  filterView: {
    marginTop: 20,
  },
});

// Local screen style
export const localScreen = (props = {}) =>
  StyleSheet.create({
    mainView: {
      flex: 1,
      paddingHorizontal: 12,
    },
    dropDown: {
      height: 16,
      // width: 70,
      backgroundColor: root.dropdown_background,
      alignItems: 'center',
      // paddingLeft: 2,
      marginLeft: 4,
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 18,
      borderWidth: 0.4,
      borderColor: root.dropdown_background,
    },
    dropDownText: {
      fontSize: Font.font_normal_six,
      color: root.color_subtext,
      fontFamily: Cfont.rubik_medium,
      paddingLeft: 3,
    },
    dropDownListView: {
      height: 123,
      width: 80,
      backgroundColor: root.color_active,
      zIndex: 10,
      position: 'absolute',
      top: 35,
      elevation: 2,
      borderRadius: 6,
      marginLeft: 4,
    },
    dropDownItems: {
      fontSize: Font.font_normal_five,
      color: root.color_text,
      fontFamily:
        props.dropDownChip == props.Item
          ? Cfont.rubik_medium
          : Cfont.rubik_regular,
      marginTop: 10,
      marginBottom: 15,
      marginLeft: 7,
    },
    arrowIcon: {
      color: root.color_subtext,
      fontSize: Font.font_normal_fifteen,
      paddingRight: 2,
      paddingLeft: 8,
    },
    filterView: {
      marginTop: 18,
      marginLeft: 8,
      flexDirection: 'row',
    },
  });

//global screen style
export const globalScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    paddingHorizontal: 12,
  },
  countryText: {
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 17,
  },
  innerFlatlist: {
    marginBottom: 15,
  },
  outerFlatlist: {
    marginTop: 29,
    paddingBottom: 30,
  },
  filterView: {
    marginTop: 18,
  },
});

export const screenFilter = StyleSheet.create({
  mainView: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 1,
  },
  filterTitle: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  filterText: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  filterDataView: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.backgroung_exchange_chip_color,
    paddingHorizontal: 3,
    borderRadius: 5,
    marginLeft: 12,
  },

  filterDataViewtwo: {
    flexDirection: 'row',
    alignItems: 'center',
    height: screenWidth * 0.068,
    backgroundColor: root.backgroung_exchange_chip_color,
    paddingHorizontal: 3,
    borderRadius: 5,
    marginLeft: 12,
  },
  filterTag: {
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    color: root.color_subtext,
    paddingLeft: 5,
  },
  filterTagData: {
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingLeft: 2,
  },
  closeIcon: {
    color: root.color_text,
    fontSize: 20,
    paddingLeft: 5,
  },
});

// Messages Screen Style
export const sideDrawerMessages = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    height: 56,
    ...p.h_18,
  },
  backIconHeaderView: {
    ...alignment.row_alignC,
  },
  headerText: {
    ...size_family.rm_17,
    ...color.text,
    ...p.l_20,
  },
  headerBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  headerSearchIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  dropDownIcon: {
    fontSize: Font.font_normal_three,
    ...p.r_11,
  },
  scrollBarView: {
    ...alignment.row,
    borderRadius: 25,
    height: 32,
    ...p.h_18,
  },
  brokerTopBarTextBg: {
    ...m.r_10,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    borderColor: root.color_text,
    width: 78,
  },
  brokerTopBarText: {
    ...size_family.rm_11,
    ...p.h_9,
  },
  ordersTopBarTextBg: {
    ...m.r_5,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    width: 78,
  },
  ordersTopBarText: {
    ...size_family.rm_11,
    ...p.h_9,
  },
  nseTopBarTextBg: {
    ...m.r_5,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
  },
  nseTopBarText: {
    ...size_family.rm_11,
    ...p.l_20,
    ...p.r_6,
  },
  topBarBackgroundView: {
    width: '100%',
    ...alignment.row,
    ...p.t_7,
  },
  activityIndicatore: {
    ...m.t_15,
    ...m.b_5,
    fontSize: 25,
  },
  noDataText: {
    ...m.t_40,
    ...size_family.rr_14,
    ...color.subtext,
    alignSelf: 'center',
  },
  row: {
    ...alignment.row_alignC,
  },
  flatelist: {
    ...m.t_15,
    ...m.b_5,
  },
});

//side Drawer Message Modal

export const messagesModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: '100%',
    height: 51,
    ...bgColor.color_active,
    ...alignment.row_alingC_SpaceB,
  },
  modalItemTitle: {
    color: root.ion_rb_2,
    ...size_family.rm_13,
  },
  radioBtn: {
    color: root.ion_rb_2,
    fontSize: Font.font_normal_twenty_six,
  },
  modalDataFlatelist: {
    ...m.t_8,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
});

export const messageOrder = StyleSheet.create({
  mainView: {
    width: '100%',
    backgroundColor: root.color_chipFilter,
    ...alignment.row,
    ...m.b_5,
  },
  messageOrderImg: {
    borderRadius: 25,
    height: 35,
    width: 35,
    ...bgColor.color_active,
    ...m.t_10,
    ...m.m_l_17,
  },
  messageOrderText: {
    ...size_family.rr_11,
    ...p.t_9,
    ...p.l_25,
    ...p.r_30,
    ...color.text,
    ...m.r_30,
  },
  messageOrderDate: {
    ...size_family.rl_9,
    ...p.l_25,
    ...color.text,
    ...p.t_3,
    ...p.b_10,
  },
});

// Messages Search Modal

export const messageSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: '100%',
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
    // textTransform:'uppercase'
  },

  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: 'center',
    ...m.t_100,
  },
});

// user Profile screen styling

export const userProfile = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  userProfileHeaderView: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 42,
    paddingHorizontal: 16,
  },
  userProfileHeaderText: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingLeft: 20,
  },
  userProfileHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  imageProfileView: {
    paddingTop: 22,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 25,
  },
  userProfileImage: {
    height: 51,
    width: 51,
    borderRadius: 25,
    backgroundColor: 'black',
  },
  userProfileEditIconView: {
    borderRadius: 25,
    // height: 18,
    // width: 18,
    backgroundColor: root.color_textual,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'flex-end',
    marginLeft: -17,
  },
  userProfileEditIcon: {
    color: root.color_active,
    size: 45,
    padding: 3,
  },
  userName: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: 30,
  },
  userIdTextNameView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 30,
    paddingTop: 2,
  },
  userIdText: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  userId: {
    fontSize: 12,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  line: {
    width: '100%',
    borderColor: root.color_subtext,
    borderWidth: 0.2,
    opacity: 0.3,
  },
  userInfoView: {
    paddingHorizontal: 16,
  },
  userInformationText: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 28,
  },
  userDetailsView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 30,
  },
  userDetailText: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  userDetailData: {
    fontSize: 13,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  segmetsAllowedView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 33,
  },
  segmentAllowedMap: {
    flexWrap: 'wrap',
    // height: '100%',
    width: '50%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  segmentBgColor: {
    backgroundColor: root.backgroung_exchange_chip_color,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    margin: '1%',
  },
  segmentText: {
    fontSize: 8,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  bankAcText: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 42,
    paddingBottom: 3,
  },
  closeAccountView: {
    borderColor: root.color_text,
    borderRadius: 25,
    marginTop: 33,
    borderWidth: 0.8,
    width: 110,
    justifyContent: 'center',
    alignItems: 'center',
  },
  closeAccountText: {
    fontSize: 11,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    padding: 4,
  },
});

//profile Edit modal

export const profileEditModal = StyleSheet.create({
  modalMainView: {
    flex: 1,
    paddingLeft: 6,
    paddingBottom: 6,
  },
  header: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 4,
  },
  EditOption: {
    marginTop: 34,
  },
  EditOptionText: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

// setting Screen style
export const settings = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  settingHeaderView: {
    ...alignment.row_alignC,
    // height: size.size_50,
    height: 50,
    ...p.h_14,
  },
  settingHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  settingHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    ...color.text,
  },
  scrollView: {
    ...p.h_18,
  },
  themeView: {
    ...p.t_40,
  },
  title: {
    ...size_family.rm_16,
    ...color.text,
  },
  subTitle: {
    ...size_family.rr_13,
    ...color.text,
  },
  lightDarkTheme: {
    ...size_family.rr_14,
    ...color.text,
  },
  radioButtonView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_26,
  },
  orderPreferenceView: {
    ...p.t_35,
  },
  rowDirectionView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_18,
  },
  arrowIcon: {
    ...color.text,
    fontSize: 22,
  },
  chartPreferenceView: {
    ...p.t_36,
  },
  appNotificationView: {
    ...p.t_35,
  },
  securityView: {
    ...p.t_35,
  },
  takeMeToView: {
    ...p.t_35,
  },
});

// Push notification styles
export const pushNotification = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    ...p.h_16,
  },
  notificationHeaderView: {
    ...alignment.row_alignC,
    height: 45,
  },
  notificationHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  notificationHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  subTitle: {
    ...size_family.rl_13,
    ...color.text,
    ...m.t_58,
  },
  notificationText: {
    ...size_family.rm_17,
    ...color.text,
    ...m.t_30,
    ...p.b_17,
  },
  listItemView: {
    ...alignment.row_alingC_SpaceB,
    ...p.b_30,
  },
  toggleTitle: {
    ...size_family.rr_13,
    ...color.text,
  },
});

// Take me To default style

export const takeMeTo = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...p.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: '100%',
    height: 51,
    ...bgColor.color_active,
    ...alignment.row_alignC,
  },
  modalItemTitle: {
    ...color.text,
    ...size_family.rm_13,
  },
  modalDataFlatelist: {
    height: 200,
    ...m.t_8,
    ...m.b_8,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
});

//Finger Print Face Id style

export const fingerFaceId = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 22,
    ...p.t_20,
  },
  headerView: {
    ...m.t_48,
    ...m.b_12,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_27,
  },
  detailView: {
    width: '100%',
    borderRadius: 7,
    borderColor: '#979797',
    borderWidth: 0.8,
    ...m.t_16,
  },
  detailText: {
    ...color.text,
    ...size_family.rr_13,
    ...p.p_11,
  },
  upperView: {
    flex: 1,
  },
  botton: {
    width: '100%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});

//ChangeMpin Style setting
export const changeMpin = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_42,
    ...m.b_30,
  },
  enterPinText: {
    ...color.text,
    ...size_family.rm_13,
  },
  botton: {
    width: '100%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  inputStyle: {
    width: '60%',
    height: 70,
    ...m.b_5,
  },
  codeInputFieldStyle: {
    width: 40,
    height: 42,
    borderWidth: 1,
    borderRadius: 7,
    ...color.text,
    borderColor: root.color_subtext,
  },
  codeInputHighlightStyle: {
    borderColor: '#000',
  },
});

//Change password styles

export const changePassword = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_40,
  },
  subHeader: {
    ...color.text,
    ...size_family.rl_11,
    ...m.t_14,
    ...m.b_32,
  },
  botton: {
    width: '100%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },

  inputContainer: {
    width: '100%',
    borderWidth: 1,
    borderColor: root.color_subtext,
    ...alignment.row_alingC_SpaceB,
    alignSelf: 'center',
    borderRadius: 7,
    ...m.b_15,
  },
  input: {
    flex: 1,
    ...p.p_6,
    ...color.text,
  },
  iconContainer: {
    ...p.p_6,
  },
  rowView: {
    ...alignment.row_alignC,
  },
  passwordStrenthText: {
    ...color.text,
    ...size_family.rr_13,
    ...m.t_26,
  },
  passwordStrenth: {
    ...color.positive,
    ...size_family.rr_13,
    ...m.t_26,
  },
  conditionText: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_17,
    ...m.m_l_10,
  },
  checkIcon: {
    fontSize: 14,
    color: root.color_subtext,
    ...m.t_17,
  },
});

// Order Preferences screen style
export const orderPreferences = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    ...p.h_16,
  },
  orderHeaderView: {
    ...alignment.row_alignC,
    height: 45,
  },
  orderHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  orderHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  subTitle: {
    ...size_family.rr_11,
    ...color.text,
    ...m.t_50,
  },
  exchangeText: {
    ...size_family.rr_13,
    ...color.text,
    ...m.t_31,
    ...p.b_17,
  },
  botton: {
    width: '100%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  arrowIcon: {
    ...color.text,
    fontSize: 22,
  },
  plusMinusIcon: {
    ...color.text,
    fontSize: 13,
  },
  productTypeView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_20,
  },
  enterProtectionView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_17,
  },
  productTypeText: {
    ...size_family.rr_13,
    ...color.text,
  },
  rowView: {
    ...alignment.row_alignC,
  },

  // modal
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...m.t_12,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: '100%',
    ...m.t_10,
    ...bgColor.color_active,
    ...alignment.row_alingC_SpaceB,
  },
  modalItemTitle: {
    ...color.text,
    ...size_family.rr_13,
  },
  modalDataFlatelist: {
    ...m.t_25,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
  input: {
    ...p.p_6,
    ...color.text,
    ...m.h_35,
  },
  listView: {
    borderColor: root.color_subtext,
    borderWidth: 0.8,
    borderRadius: 10,
    ...alignment.row,
    height: 33,
    // padding: 3,
  },
  listItemView: {
    ...alignment.justify_container_center,
    borderColor: root.color_subtext,
  },
  listItemText: {
    ...size_family.rr_11,
    ...p.h_10,
  },
});

//Enable TOTP style

export const enableTOTP = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_10,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_34,
  },
  subText: {
    ...color.text,
    ...m.t_10,
    ...size_family.rl_13,
    ...p.r_15,
  },
  subTextBold: {
    ...color.text,
    ...m.t_10,
    ...size_family.rm_13,
  },
  inputContainer: {
    width: '90%',
    borderWidth: 1,
    ...alignment.row_alingC_SpaceB,
    borderRadius: 7,
    ...m.t_31,
  },
  input: {
    flex: 1,
    ...p.p_6,
    ...color.text,
    ...m.m_l_10,
  },
  botton: {
    width: '36%',
    ...alignment.row_alingC_SpaceB,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.v_8,
    ...p.h_10,
    ...m.t_45,
    elevation: 5,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  bottonIcon: {
    ...color.active,
    fontSize: 23,
  },
  timerText: {
    ...color.text,
    ...m.t_10,
    ...size_family.rl_13,
  },
});

// Market Status styles
export const marketStatus = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_18,
  },
  headerView: {
    paddingBottom: 10,
    // shadowColor: '#000',
    // shadowOffset: {width: 1, height: 1},
    // shadowOpacity: 0.4,
    // shadowRadius: 3,
    // elevation: 5,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  searchIcon: {
    ...color.text,
    fontSize: 20,
    ...p.t_18,
  },
  headerTextView: {
    ...alignment.row_alingC_SpaceB,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_23,
  },
  exchangeStatusText: {
    ...color.text,
    ...size_family.rm_13,
    ...m.t_28,
  },
  lineView: {
    width: '100%',
    backgroundColor: root.color_subtext,
    height: 0.8,
    ...m.t_10,
    opacity: 0.3,
    ...m.b_6,
  },
  boxView: {
    ...alignment.row_alingC_SpaceB,
    ...m.b_9,
  },
  boxText: {
    ...color.text,
    ...size_family.rm_13,
  },
  chipView: {
    ...bgColor.backgroung_exchange_chip_color,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    ...p.p_7,
  },
  chipText: {
    ...size_family.rm_11,
  },
});

// Market Status Search Modal

export const marketStatusSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
    ...color.text,
    fontSize: 21,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
});

export const eventSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
    fontSize: 21,
    ...color.text,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
  upcomingEventText: {
    ...size_family.rm_14,
    ...color.text,
    ...m.m_l_10,
  },
  upcomingEventIcon: {
    ...color.text,
    fontSize: 22,
  },
  row: {
    ...alignment.row_alignC,
    ...m.t_16,
    ...m.m_l_15,
  },
  eventsView: {
    flexWrap: 'wrap',
    width: '100%',
    ...alignment.row,
    justifyContent: 'flex-start',
    ...p.h_15,
    ...m.t_14,
  },
  eventBgColor: {
    ...color.active,
    borderRadius: 5,
    ...alignment.alignC_justifyC,
    ...p.p_6,
    ...p.h_10,
    borderColor: root.color_border_bg,
    borderWidth: 1,
    ...m.r_10,
  },
  eventText: {
    ...size_family.rm_10,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rm_13,
    alignSelf: 'center',
    ...m.t_50,
  },
});

// Event Filter Modal

export const eventFilterModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...p.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  eventText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.t_25,
  },
  eventsView: {
    flexWrap: 'wrap',
    width: '100%',
    ...alignment.row,
    justifyContent: 'flex-start',
    ...m.t_11,
  },
  eventBgColor: {
    borderRadius: 7,
    ...alignment.alignC_justifyC,
    ...p.p_5,
    ...p.h_20,
    ...p.v_10,
    borderColor: root.color_border_bg,
    borderWidth: 1,
    ...m.r_10,
    ...m.b_12,
  },
  eventChipText: {
    ...size_family.rr_12,
    ...color.text,
  },
  botton: {
    width: '100%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    borderRadius: 7,
    ...p.p_10,
    ...m.t_14,
    ...m.b_7,
  },
  bottonText: {
    ...size_family.rm_14,
  },
});

// Event details Modal
export const eventDetailModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...m.t_13,
  },
  companyName: {
    ...size_family.rm_12,
    ...color.text,
  },
  chip: {
    backgroundColor: 'rgba(151,151,151,0.1)',
    borderColor: 'rgba(151,151,151,0.1)',
    borderWidth: 0.5,
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...p.p_3,
    alignSelf: 'flex-start',
  },
  chipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  price: {
    ...size_family.rr_13,
    ...color.text,
    ...m.m_l_4,
  },
  changes: {
    ...size_family.rr_10,
    ...m.m_l_6,
  },
  eventText: {
    ...size_family.rm_16,
    ...color.text,
    ...m.t_22,
  },
  eventDate: {
    ...size_family.rm_16,
    ...color.text,
    ...m.t_21,
  },
  memo: {
    ...size_family.rr_11,
    ...color.text,
  },
  memoScrollView: {
    ...m.t_23,
    ...m.b_35,
  },
  plusBottonView: {
    borderColor: root.color_text,
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    ...alignment.alignC_justifyC,
  },
  tBottonView: {
    borderColor: root.color_text,
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    ...alignment.alignC_justifyC,
    ...m.r_25,
  },
  topView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_17,
  },
  chipPriceView: {
    ...alignment.row_alignC,
    ...m.t_10,
  },
  rowView: {
    ...alignment.row,
  },
  tText: {
    fontFamily: Cfont.rubik_medium,
    ...color.text,
  },
  plusText: {
    ...color.text,
    fontSize: 21,
  },
});

// IPO Modal

export const ipoModal = StyleSheet.create({
  modal: {
    width: Dimensions.get('window').width,
    height: Dimensions.get('window').height,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  mainView: {
    ...p.h_15,
    flex: 1,
  },
  closeIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    marginTop: 21,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_23,
  },
  imgAndTitleView: {
    ...alignment.row_alignC,
  },
  imageView: {
    backgroundColor: '#FF6700',
    height: 49,
    width: 49,
    borderRadius: 50,
    opacity: 0.7,
    justifyContent: 'center',
  },
  title: {
    ...color.text,
    ...size_family.rm_14,
    ...m.m_l_13,
    width: '52%',
  },
  status: {
    ...color.active,
    ...size_family.rm_9,
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: 'center',
    borderRadius: 25,
    ...m.t_20,
    alignSelf: 'flex-start',
  },
  pricerRange: {
    ...color.text,
    ...size_family.rr_14,
  },
  detailsView: {
    ...m.t_25,
    ...alignment.row_alignC,
  },
  row: {
    ...alignment.row_alignC,
    ...m.t_20,
  },
  detailsText: {
    ...size_family.rm_11,
    ...color.text,
  },
  detailsTextData: {
    ...size_family.rm_13,
    ...color.text,
    ...m.t_2,
  },
  mLeft: {
    ...m.m_l_70,
  },
  mTop: {
    ...m.t_15,
  },
  botton: {
    width: '92%',
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    borderRadius: 7,
    ...p.p_10,
    ...m.t_14,
    ...m.b_14,
    alignSelf: 'center',
  },
  bottonText: {
    ...size_family.rm_14,
    ...color.active,
  },
});

// IPO View All screen

export const ipoViewAll = StyleSheet.create({
  mainView: {
    flex: 1,
    // paddingHorizontal: 15,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    height: 56,
    width: '100%',
    ...bgColor.color_active,
    elevation: 5,
    ...p.h_15,
  },
  backIconHeaderView: {
    ...alignment.row_alignC,
  },
  headerText: {
    ...size_family.rm_17,
    ...color.text,
    ...p.l_20,
  },
  headerBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  headerSearchIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  longHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
    ...m.t_15,
  },
  longHeaderView: {
    width: '100%',
    ...bgColor.color_active,
    elevation: 5,
    ...p.h_15,
  },
  longHeaderText: {
    ...size_family.rm_27,
    ...color.text,
  },
  longHeaderTextView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_35,
    ...m.b_23,
  },
  sectionText: {
    ...size_family.rm_17,
    ...color.client_background,
    ...m.t_12,
    ...m.b_20,
  },
  viewMoreView: {
    ...alignment.row_alignC,
    ...m.b_18,
    ...m.t_15,
    alignSelf: 'flex-start',
  },
  viewMoreText: {
    ...size_family.rm_11,
    color: root.color_textual,
  },
  viewMoreIcon: {
    fontSize: 11,
    color: root.color_textual,
    ...m.m_l_5,
  },
});

// Ipo card

export const ipoCard = StyleSheet.create({
  mainView: {
    ...bgColor.color_active,
    width: '100%',
    height: 142,
    borderRadius: 10,
    ...m.t_10,
    ...p.h_12,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_10,
  },
  imgAndTitleView: {
    ...alignment.row_alignC,
  },
  imageView: {
    backgroundColor: '#EC6F32',
    height: 35,
    width: 35,
    borderRadius: 50,
    opacity: 0.7,
    justifyContent: 'center',
  },
  title: {
    ...color.text,
    ...size_family.rm_12,
    ...m.m_l_15,
    ...m.r_30,
  },
  priceRange: {
    ...color.text,
    ...size_family.rr_12,
  },
  rowCenter: {
    ...alignment.row_alignC,
  },
  dateStatusView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_35,
  },
  minQtyAndAmmountView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_12,
  },
  detailsText: {
    ...size_family.rm_11,
    ...color.text,
  },
  detailsTextData: {
    ...size_family.rr_11,
    ...color.text,
  },
  status: {
    ...color.active,
    ...size_family.rm_10,
    backgroundColor: '#4CAF50',
    ...p.t_1,
    ...p.h_5,
    ...p.b_2,
    textAlign: 'center',
    borderRadius: 25,
  },
});

// Ipo search Modal

export const ipoSearchModal = StyleSheet.create({
  modal: {
    width: Dimensions.get('window').width,
    backgroundColor: '#f6f6f6',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
    fontSize: 21,
    ...color.text,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: 'center',
    ...m.t_100,
  },
});

//Add to watchList Screen
export const addToWatchList = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innerContainer: {
    padding: 16,
  },
  topContainerView: {
    ...alignment.row_SpaceB,
  },
  backIcon: {
    height: 24,
    width: 24,
    color: root.color_text,
  },
  skipContainer: {
    width: 55,
    height: 24,
    borderRadius: 18,
    backgroundColor: root.client_background,
    ...alignment.alignC_justifyC,
  },
  skipTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active_text,
  },
  titleTxt: {
    fontSize: 30,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingBottom: 10,
  },
  titleTxtContainer: {
    height: 82,
    width: '80%',
    marginTop: 32,
  },
  subTitleTxt: {
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 20,
    color: root.color_text,
  },
  textIp: {
    height: 38,
    borderWidth: 1,
    paddingLeft: 16,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
    flexGrow: 1,
  },
  textIpContainer: {
    ...alignment.row,
    paddingTop: 20,
  },
  createBtnContainer: {
    width: 90,
    backgroundColor: root.client_background,
    height: 38,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createTxt: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: '#ffffff4d',
  },
  createTxttwo: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: '#ffffff',
  },
  oddtxt: {
    ...size_family.rm_16,
    ...color.text,
    marginVertical: 32,
    ...p.h_16,
  },
  starcontainer: {
    height: screenWidth * 0.117,
    ...alignment.row_alignC,
    ...p.h_16,
  },
  toppicktxt: {
    ...size_family.rr_16,
    ...color.text,
    ...m.m_l_15,
  },
  item: {
    borderRadius: 6,
    borderTopWidth: 1 / 2,
    borderBottomWidth: 1 / 2,
    borderColor: root.color_border,
    backgroundColor: root.color_active,
    width: 125,
    height: 175,
    padding: 12,
    // marginVertical: 8,
    marginHorizontal: 11,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 14,
  },
  toptxt: {
    ...size_family.rr_10,
    ...color.text,
    ...m.t_12,
  },
  titletxtx: {
    ...size_family.rm_14,
    ...color.text,
    height: screenWidth * 0.117,
  },
  newbottom: {
    ...alignment.row_alignC,
  },
  subtx: {
    ...size_family.rr_10,
    ...color.text,
    ...m.m_l_5,
  },
});
//SideDrawer style

export const SideDrawerstyling = StyleSheet.create({
  Maincon: {
    flex: 1,
  },
  slideimgcon: {
    height: '50%',
    width: '75%',
    borderRadius: 20,
    backgroundColor: 'red',
  },
  slideimgcontwo: {
    height: '100%',
    width: '100%',
    borderRadius: 20,
    backgroundColor: 'red',
  },
  imgconstyl: {
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  Innerconstart: {
    height: 200,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 1,
    padding: 10,
  },
  Innercon: {
    height: 70,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    padding: 15,
    borderBottomColor: '#E0E0E0',
  },
  Imgcon: {
    borderRadius:
      Math.round(
        Dimensions.get('window').width + Dimensions.get('window').height,
      ) / 2,
    width: Dimensions.get('window').width * 0.12,
    height: Dimensions.get('window').width * 0.12,
    backgroundColor: 'red',
  },
  imagemain: {
    borderRadius:
      Math.round(
        Dimensions.get('window').width + Dimensions.get('window').height,
      ) / 2,
    width: Dimensions.get('window').width * 0.12,
    height: Dimensions.get('window').width * 0.12,
  },
  texticon: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  Innerconone: {
    height: 90,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderBottomColor: '#E0E0E0',
    borderTopColor: '#E0E0E0',
    padding: 15,
  },
  stylingtxt: {
    right: '140%',
  },
  protextalign: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  protextaligntwo: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    paddingLeft: 16,
  },
  Innercotwo: {
    height: 110,
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  Innertwoone: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  Innercothree: {
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  newcontact: {
    borderBottomColor: '#E0E0E0',
    height: 80,
    borderBottomWidth: 1,
  },
  usagecon: {
    height: 50,
    width: '90%',
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#000080',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  styleb: {
    color: root.client_background,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  radio: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  Lighttxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
    marginRight: 50,
  },
  Darktxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  Buttomtxtcon: {
    width: '100%',
  },
  Innercokyc: {
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  buttontxt: {
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 15,
    color: 'black',
    fontWeight: '500',
    marginBottom: 30,
  },
  versiontxt: {
    color: 'black',
    fontSize: 15,
  },
});

// Script View design and Style.

export const Scriptviewstyle = StyleSheet.create({
  maincontainer: {
    flex: 1,
    // paddingHorizontal: 16,
    backgroundColor: root.color_active,
  },
  header: {
    width: '100%',
    height: screenWidth * 0.136,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  detailblock: {
    width: '100%',
    height: screenWidth * 0.163,
    flexDirection: 'row',
    paddingHorizontal: 16,
  },
  detailone: {
    flex: 1.11,
    height: '100%',
  },
  detailtwo: {
    flex: 1,
    height: '100%',
  },
  aligntxt: {
    flexDirection: 'row',
    // marginTop:-2,
  },
  companyname: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: -2,
    marginRight: 5,
  },
  Astyle: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  futuretxt: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  filtler: {
    height: 16,
    width: screenWidth * 0.141,
    backgroundColor: 'rgba(151, 151, 151, 0.1)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    alignItems: 'center',
    borderRadius: 2,
    paddingHorizontal: 4,
    borderWidth: 1,
    borderColor: root.color_border,
    marginRight: 5,
  },
  Bsetxtstyle: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_subtext,
    marginRight: 8,
  },
  valtxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
    textAlign: 'right',
    top: -2,
  },
  chgvaltxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    textAlign: 'right',
    marginLeft: 5,
  },
  iconcontainer: {
    height: 32,
    width: screenWidth * 0.346,
    flexDirection: 'row',
    paddingTop: 5,
    justifyContent: 'flex-end',
    alignSelf: 'flex-end',
  },
  byselconatiner: {
    height: screenWidth * 0.136,
    width: '100%',
    paddingTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  buycontainer: {
    height: 40,
    width: screenWidth * 0.397,
    backgroundColor: root.color_positive,

    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
  },
  sellconstainer: {
    height: 40,
    width: screenWidth * 0.397,
    backgroundColor: root.color_negative,

    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
  },
  buyselltxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active,
  },
  circle: {
    borderWidth: 1.5,
    borderRadius: 50,
    height: 24,
    width: 24,
    marginHorizontal: 15,
  },
  headertwo: {
    width: '100%',
    height: screenWidth * 0.141,
    backgroundColor: root.color_active,
    padding: 10,
    // paddingRight: 0,
  },
  innerheadconatiner: {
    flexDirection: 'row',
    width: '100%',
    height: '100%',
  },
  innerflexone: {
    flex: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  innerflextwo: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  bseflexallign: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  buysmallbtn: {
    width: 42.59,
    height: 24,
    backgroundColor: root.color_positive,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sellsmallbtn: {
    width: 42.59,
    height: 24,
    backgroundColor: root.color_negative,

    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 5,
  },
  buysellsmalltxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_active,
  },
  dropbox: {
    borderTopWidth: 0,
    height: screenWidth * 0.097,
    width: screenWidth * 0.146,
    // bottom: 0,
    // top: 95,
    // left: 10,
    // padding: 12,
    // paddingBottom:0,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    backgroundColor: root.color_active,
  },
  dropboxtwo: {
    borderTopWidth: 0,
    height: screenWidth * 0.097,
    width: screenWidth * 0.146,
    // bottom: 0,
    // top: 50,
    // left: '7%',
    padding: 12,
    borderRadius: 8,
    backgroundColor: root.color_active,
  },
  modalcon: {
    flex: 1,
    backgroundColor: root.color_active,
    width: screenWidth * 0.146,
    height: screenWidth * 0.097,
  },
  menucon: {
    width: screenWidth * 0.314,
    height: screenWidth * 0.099,
    // alignItems: 'flex-start',
    justifyContent: 'center',
    paddingLeft: 10,

    backgroundColor: root.color_active,
  },
  whitetwo: {
    width: screenWidth * 0.152,
    bottom: 0,
    // top: 109,
    left: '4%',
    borderColor: 'rgba(0,0,0,0.13)',
    borderRadius: 8,
    backgroundColor: root.color_active,
    borderWidth: 1 / 2,
    justifyContent: 'center',
  },
  whitethree: {
    width: screenWidth * 0.152,
    bottom: 0,
    top: 50,
    left: '8%',
    backgroundColor: root.color_active,
    justifyContent: 'center',
    borderWidth: 1 / 2,
    borderRadius: 8,
    borderColor: 'rgba(0,0,0,0.13)',
  },
  white: {
    position: 'absolute',
    right: 15,
    top: 47,
    width: screenWidth * 0.314,
    backgroundColor: root.color_active,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 1,
  },

  option: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

export const Overviewstylecom = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innerconatiner: {
    flex: 1,
    marginTop: 16,
    backgroundColor: root.color_active,
    paddingTop: 16,
    paddingHorizontal: 16,
  },
  marketxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  bidcontainer: {
    marginTop: 16,
    paddingBottom: 16,
    height: 171,
    width: '100%',
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
  },
  buySellViewContainer: {
    height: 171,
    width: '49.9%',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
  },
  buyText: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
  },
  buyTextorder: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
    textAlign: 'center',
  },
  sellText: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
  },
  sellTextorder: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    textAlign: 'center',
    width: 46,
  },
  sellTextqty: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    textAlign: 'right',
    width: 46,
  },
  ordersHeaderText: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 10,
  },
  totalbidareacontainer: {
    flexDirection: 'row',
    height: 36,
    paddingTop: 16,
    justifyContent: 'space-between',
  },
  totaltxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  progressMain: {
    backgroundColor: root.color_active,
    height: screenWidth * 0.102,
    paddingVertical: 12,
    width: '100%',
    alignSelf: 'center',
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressOuter: {
    width: '50%',
    backgroundColor: root.color_positive_rgb,
    justifyContent: 'center',
    height: 16,
  },
  progressnetive: {
    width: '50%',
    backgroundColor: root.color_negative_rgb,
    justifyContent: 'center',
    height: 16,
  },
  perplus: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  negtxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    textAlign: 'right',
  },
  keytxtx: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
  },
  oneflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
    flex: 1,
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  twoflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txtallign: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  prtitle: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  prval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  prline: {
    height: '5%',
    backgroundColor: 'yellow',
  },
  over: {
    width: '40%',
    height: 60,
    justifyContent: 'space-between',
  },
  threeflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
    flex: 1,
  },
  endstyle: {
    flex: 1,
  },
  endingcom: {
    height: 36,
    width: '100%',
    paddingTop: 16,
    marginBottom: 16,
  },
  Markettxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  endnodata: {
    height: 58,
    width: '100%',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    alignContent: 'center',
  },
  txtnostyle: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  allflex: {
    flex: 1,
    alignSelf: 'flex-start',
  },

  Tradeview: {
    height: screenWidth * 0.438,
    backgroundColor: root.color_active,
    paddingTop: 12,
    marginBottom: 5,
    //  paddingVertical: 12,
  },
  Tradlistconatiner: {
    height: screenWidth * 0.311,
    width: screenWidth * 0.311,
    backgroundColor: root.color_active,
    marginHorizontal: 9,
    //  paddingVertical: 12,
    justifyContent: 'center',
    paddingHorizontal: 8,
    borderRadius: 8,
    borderTopWidth: 1,
    borderTopColor: root.color_border,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 5,
  },
  tradetxt: {
    fontSize: Font.font_normal_four,
    color: root.color_positive,
    fontFamily: Cfont.rubik_medium,
  },

  datetxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  cetxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  changetxtx: {
    fontSize: Font.font_normal_six,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingLeft: 5,
  },
  changetxtxnegtive: {
    fontSize: Font.font_normal_six,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingLeft: 5,
  },
  valtxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  allignvc: {
    flexDirection: 'row',
  },
  R1brokecontainer: {
    height: screenWidth * 0.066,
    width: '100%',
    paddingTop: 10,
  },
  Broketxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
    backgroundColor: root.color_positive_rgb,
    height: 14,
    width: 63.88,
    borderRadius: 20,
    textAlign: 'center',
  },
});

export const Eventstylecom = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innerconatiner: {
    height: 52,
    width: '100%',
    paddingHorizontal: 16,
    marginTop: 16,
  },
  innertwo: {
    height: 52,
    width: '100%',
    justifyContent: 'center',
  },
  cortxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  menuitem: {
    backgroundColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    borderWidth: 1,
    borderColor: root.client_background,
    justifyContent: 'center',
    marginBottom: 16,
  },
  menuitemtwo: {
    backgroundColor: root.color_active,
    borderWidth: 1,
    borderColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    justifyContent: 'center',
    marginBottom: 16,
  },
  titletxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
  },
  titletxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },
  calendercontainer: {
    height: 155,
    backgroundColor: 'yellow',
    flexDirection: 'row',
  },
  dateconatiner: {
    marginVertical: 12,
    marginRight: 18,
    height: 128,
    width: 128,
    backgroundColor: root.color_active,
    paddingHorizontal: 8,
    paddingVertical: 12,
    borderRadius: 8,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderLeftColor: root.color_border,
    borderTopColor: root.color_border,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 5,
  },
  oneflex: {
    // justifyContent: 'space-between',

    flex: 1,
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  allflextwo: {
    flex: 1,
    alignSelf: 'flex-start',
    height: 150,
    width: 150,
  },
  txtdate: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txtdatetwo: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    paddingLeft: 5,
  },
  gmstyle: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  dateconatinerinner: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  iconallign: {
    alignItems: 'flex-end',
  },
  emptyview: {
    height: 300,
    width: '100%',
  },
  Newcontainer: {
    height: screenWidth * 0.36,
    width: screenWidth * 0.51,
    backgroundColor: root.color_active,
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 16,
    marginRight: 16,
    borderRadius: 8,
    // borderWidth:1,
    borderColor: root.color_border,
    // position:'absolute',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderBottomWidth: 1,
    //     borderLeftColor: root.color_border,
    //     borderTopColor: root.color_border,
    //     borderBottomColor:root.color_border,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 4,
  },
  shadow: {
    // backgroundColor:'#0000',
    // shadowColor: '#000',
    // shadowOffset: {
    //   width: 0,
    //   height: 12,
    // },
    // shadowOpacity: 0.58,
    // shadowRadius: 16.0,
    // elevation: 24,
  },
  headlinetxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  bottomLine: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    marginTop: 16,
  },
  newdate: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    marginRight: 5,
  },
});
//Scriptview_EventModalStyle:
export const Eventmodaistyle = StyleSheet.create({
  Maincon: {
    width: '100%',
    height: screenWidth * 0.059,
    paddingHorizontal: 6,
  },
  header: {
    height: screenWidth * 0.059,
    width: '100%',
    alignItems: 'flex-end',
    // paddingTop: 5,
  },
  innercon: {
    marginTop: 16,
    paddingTop: 15,
    paddingHorizontal: 6,
    height: 36,
    width: '100%',
  },
  innercontwo: {
    marginVertical: 16,
    paddingHorizontal: 6,
    paddingTop: 15,
    height: 36,
    width: '100%',
    flexDirection: 'row',
  },
  txtTitle: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  yeartxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    marginLeft: 3,
  },
  scrView: {
    maxHeight: screenWidth * 0.428,
    width: '100%',
    paddingHorizontal: 6,
  },
  scrViewtwo: {
    maxHeight: screenWidth * 0.828,
    width: '100%',
    paddingHorizontal: 6,
    paddingTop: 16,
  },
  txtpara: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  durationtxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  Closurecon: {
    width: '100%',
    paddingHorizontal: 6,
  },
  innerclousercon: {
    justifyContent: 'space-between',
    height: 40,
  },
  innerclousercontwo: {
    justifyContent: 'space-between',
    height: 40,
    marginTop: 16,
  },
  Closurebottom: {
    marginTop: 16,
    width: '100%',
    paddingTop: 16,
  },
  allign: {
    marginBottom: 10,
  },
  bottomtxtclosure: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  AgmStyle: {
    paddingHorizontal: 6,
  },
  Gmcontainer: {
    justifyContent: 'space-between',
    height: 41,
    marginBottom: 16,
    width: '100%',
  },
  gmtxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  Dividendcontainer: {
    width: '100%',
    marginTop: 32,
    paddingHorizontal: 6,
  },
  innerdiv: {
    marginBottom: 16,
  },
  headerbackicon: {
    top: -215,
    position: 'absolute',
    paddingHorizontal: 10,
  },
  newsheader: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  datetxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  scrollcontainer: {
    width: '100%',
  },
});

export const Recommendationsstyle = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innercon: {
    marginTop: 32,
    height: screenWidth * 0.18,
    width: '100%',
    paddingHorizontal: 16,
    // padding: 16,
  },
  srytxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_regular,
    color: root.color_subtext,
    textAlign: 'center',
  },
  emptyview: {
    height: 800,
    width: '100%',
  },
});

export const CompanyStyle = StyleSheet.create({
  maincon: {
    flex: 1,
    backgroundColor: root.color_active,
    paddingHorizontal: 16,
  },
  innerView: {},
  listone: {
    height: screenWidth * 0.063,
    paddingVertical: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  listmanage: {
    height: 58,
    paddingVertical: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  innermanage: {
    height: 41,
    padding: 5,
    justifyContent: 'space-between',
  },
  txtstylemange: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txtstylemagetwo: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  listonetwo: {
    // height: screenWidth * 0.063,
    paddingVertical: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  txtstyle: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  txtstyleindes: {
    color: root.color_text,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
  },
  partconatiner: {
    backgroundColor: 'rgba(151,151,151,0.1)',
    paddingHorizontal: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: root.color_border,
    marginTop: 12,
    marginRight: 12,
  },
  securitycon: {
    height: screenWidth * 0.127,
    width: '100%',
    justifyContent: 'center',
    ...padding.h_6,
  },
  companyinfo: {
    width: '100%',
    paddingVertical: 16,
    marginTop: 16,
  },
  sectxtstyle: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  redtxt: {
    ...size_family.rm_12,
    ...color.client_background,
  },
  allred: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },

  menuitem: {
    backgroundColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    borderWidth: 1,
    borderColor: root.client_background,
    justifyContent: 'center',
    marginBottom: 32,
  },
  menuitemtwo: {
    backgroundColor: root.color_active,
    borderWidth: 1,
    borderColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    justifyContent: 'center',
    marginBottom: 32,
  },
  titletxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
  },
  titletxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },
  allignlast: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    alignItems: 'center',
    flex: 1,
    width: '100%',
  },
  detaistxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    textAlign: 'right',
    // backgroundColor:root.color_active,
    width: screenWidth * 0.53,
  },
  detaistxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    width: screenWidth * 0.38,
  },
  newallign: {
    // width: 379,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 32,
  },
});
export const Companymodalstyle = StyleSheet.create({
  maincon: {
    height: screenWidth * 0.147,
    width: '100%',
    alignItems: 'center',
    paddingTop: 16,
    marginBottom: 16,
  },
  titletxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  desctxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txtstyleindes: {
    color: root.color_text,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
  },
  partconatiner: {
    backgroundColor: 'rgba(151,151,151,0.1)',
    paddingHorizontal: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: root.color_border,
  },
  listoneone: {
    // height: screenWidth * 0.063,
    height: 26,
    paddingVertical: 5,
    paddingHorizontal: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  txtstyle: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  txtstyletwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

export const Analysisstyle = (props: any) =>
  StyleSheet.create({
    maincon: {
      flex: 1,
      backgroundColor: root.color_active,
      paddingHorizontal: 16,
    },
    innercon: {
      width: '100%',
      height: 700,
    },
    switchButtonView: {
      width: '100%',
      height: 30,
      alignSelf: 'center',
      borderRadius: 25,
      marginTop: 10,
      flexDirection: 'row',
      paddingHorizontal: 13,
    },
    todaysView: {
      backgroundColor:
        props?.selectedIndex == 0 ? root.client_background : root.color_active,
      height: 30,
      justifyContent: 'center',
      alignItems: 'center',
      width: '50%',
      flex: 1,
      borderTopLeftRadius: 25,
      borderBottomLeftRadius: 25,
      borderWidth: props?.selectedIndex == 0 ? 0 : 0.3,
      borderColor: 'grey',
    },
    todayText: {
      color:
        props?.selectedIndex == 0 ? root.color_active : root.client_background,
      fontFamily: Cfont.rubik_medium,
      fontSize: 12,
    },
    overallView: {
      backgroundColor:
        props?.selectedIndex == 1 ? root.client_background : root.color_active,
      height: 30,
      justifyContent: 'center',
      alignItems: 'center',
      width: '50%',
      flex: 1,
      borderTopEndRadius: 25,
      borderBottomEndRadius: 25,
      borderWidth: props?.selectedIndex == 1 ? 0 : 0.3,
      borderColor: 'grey',
    },
    overallText: {
      color: props?.selectedIndex == 1 ? 'white' : '#25335C',
      fontFamily: Cfont.rubik_medium,
      fontSize: 12,
    },
    containerone: {
      height: screenWidth * 0.175,
      width: '100%',
      paddingHorizontal: 6,
      paddingTop: 16,
    },
    containertwo: {
      height: 56,
      width: '100%',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    txtstyle: {
      fontSize: Font.font_normal_four,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },
    scoreconatoner: {
      flex: 1,
      marginTop: 16,
      ...alignment.row,
      borderRadius: 20,
      height: 20,
      backgroundColor: 'red',
    },
    showindicator: {
      ...size_family.rm_18,
      color: 'gold',
      alignSelf: 'center',
      marginTop: 16,
    },
    indicon: {
      marginBottom: 16,
      flex: 1,
      flexDirection: 'row',
      justifyContent: 'space-between',
      ...padding.h_3,
    },
    indicatortxt: {
      ...size_family.rm_10,
      ...color.text,
    },

    iconcon: {
      height: 24,
      width: 24,
      borderRadius: 20,
      backgroundColor: root.client_background,
      alignItems: 'center',
      justifyContent: 'center',
    },
    supportcon: {
      height: 52,
      width: '100%',
      marginTop: 16,
      justifyContent: 'center',
      paddingHorizontal: 6,
    },
    menuitem: {
      backgroundColor: root.client_background,
      height: screenWidth * 0.074,
      width: 76,
      borderRadius: 25,
      alignItems: 'center',
      //  paddingHorizontal: 12,
      marginTop: 5,
      marginRight: 5,
      borderWidth: 1,
      borderColor: root.client_background,
      justifyContent: 'center',
      marginBottom: 32,
    },
    menuitemtwo: {
      backgroundColor: root.color_active,
      borderWidth: 1,
      borderColor: root.client_background,
      height: screenWidth * 0.074,
      width: 76,
      borderRadius: 25,
      alignItems: 'center',
      // paddingHorizontal: 12,
      marginTop: 5,
      marginRight: 5,
      justifyContent: 'center',
      marginBottom: 32,
    },
    titletxt: {
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
      color: root.color_active,
    },
    titletxttwo: {
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
      color: root.client_background,
    },
    menuitemthree: {
      backgroundColor: root.client_background,
      height: screenWidth * 0.074,
      // width: 76,
      borderRadius: 25,
      alignItems: 'center',
      paddingHorizontal: 15,
      marginTop: 5,
      marginRight: 5,
      borderWidth: 1,
      borderColor: root.client_background,
      justifyContent: 'center',
      marginBottom: 32,
    },
    menuitemfour: {
      backgroundColor: root.color_active,
      borderWidth: 1,
      borderColor: root.client_background,
      height: screenWidth * 0.074,
      // width: 76,
      borderRadius: 25,
      alignItems: 'center',
      paddingHorizontal: 15,
      marginTop: 5,
      marginRight: 5,
      justifyContent: 'center',
      marginBottom: 32,
    },
    listone: {
      height: 36,
      paddingVertical: 5,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    suprestxt: {
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      fontSize: Font.font_normal_one,
    },
    pvoitxt: {
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      fontSize: Font.font_normal_two,
    },
    suprestxts1: {
      fontFamily: Cfont.rubik_medium,
      color: root.color_positive,
      fontSize: Font.font_normal_one,
    },
    suprestxts2: {
      fontFamily: Cfont.rubik_medium,
      color: root.color_negative,
      fontSize: Font.font_normal_one,
    },
    suppcontainer: {flexDirection: 'row', flex: 1, height: 30, width: '100%'},
    suppallign: {flex: 1, justifyContent: 'center', alignItems: 'center'},
    suppresdata: {flexDirection: 'row', flex: 1},
    suprescondata: {flex: 1, paddingHorizontal: 6},
    pivoitcon: {
      flex: 0.75,
      justifyContent: 'center',
      alignItems: 'center',
      borderRightColor: root.color_border,
      borderLeftColor: root.color_border,
      borderRightWidth: 1,
      borderLeftWidth: 1,
    },
    putcontainer: {
      flexDirection: 'row',
      flex: 1,
      justifyContent: 'flex-start',
      marginTop: -36,
    },
    puttransform: {
      transform: [{rotate: '-90deg'}],
      alignSelf: 'center',

      width: 37,
      height: 12,
    },
    striktxt: {
      fontSize: 10,
      fontFamily: Cfont.rubik_regular,
      alignSelf: 'center',
      color: root.color_text,
    },
    titleput: {fontSize: 10, fontFamily: Cfont.rubik_regular},
    indicatorcontainer: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    colorindicator: {
      height: 10,
      width: 10,
      borderRadius: 20,
      marginRight: 8,
    },
    colortxtx: {
      fontSize: 12,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },
    collorallign: {
      marginHorizontal: 15,
      flexDirection: 'row',
      marginTop: 20,
    },
    Deliveryconatiner: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    Movecontainer: {
      flex: 1,
      flexDirection: 'row',
      height: 37,
      paddingHorizontal: 6,
      borderBottomColor: root.color_border,
      borderBottomWidth: 1,
    },
    Movecontainerone: {
      flex: 2,

      justifyContent: 'center',
    },
    Movecontainertwo: {
      flex: 1,

      justifyContent: 'center',
    },
    Movecontainerthree: {
      flex: 1,
      alignItems: 'flex-end',
      justifyContent: 'center',
    },
    moviingcon: {
      flex: 1,
      flexDirection: 'row',
      height: 26,
      justifyContent: 'center',
      paddingHorizontal: 6,
      marginTop: 5,
    },
    moviingconone: {
      flex: 2,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
      color: root.color_text,
    },
    moviingcontwo: {
      flex: 1,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
      color: root.color_text,
    },
    moviingconthree: {
      flex: 1,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
      color: root.color_text,
      textAlign: 'right',
    },
    OUcontainer: {
      flex: 1,
      flexDirection: 'row',
      height: 33,
      paddingHorizontal: 6,
      borderBottomWidth: 1,
      borderBottomColor: root.color_border,
    },
    Ouheader: {
      flex: 2,
      fontSize: 12,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },
    showcom: {
      width: 83.25,
      height: 22,
      borderWidth: 1,
      borderRadius: 20,
      borderColor: root.client_background,
      ...alignment.alignC_justifyC,
      alignSelf: 'flex-end',
      marginTop: 10,
    },
    showcomtwo: {
      width: 83.25,
      height: 22,
      borderWidth: 1,
      borderRadius: 20,
      borderColor: root.client_background,
      ...alignment.alignC_justifyC,
      alignSelf: 'flex-end',
      marginTop: 10,
      marginBottom: 16,
    },
    showtxt: {
      ...size_family.rm_12,
      ...color.text,
    },
    Outitle: {
      flex: 1,
      flexDirection: 'row',
      paddingHorizontal: 6,
      height: 26,
      justifyContent: 'center',
      marginTop: 5,
    },
    outitleone: {
      flex: 2,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },
    outitlstand: {
      flex: 2,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
      color: root.color_text,
    },
    outitlethree: {
      flex: 1,
      textAlign: 'right',
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
      color: root.color_text,
    },
    healthconatiner: {
      height: 80,
      alignItems: 'center',
      justifyContent: 'center',
    },
    listmanage: {
      height: 58,
      paddingVertical: 5,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    innermanage: {
      height: 41,
      padding: 5,
      justifyContent: 'space-between',
      flexDirection: 'row',
      flex: 1,
    },
    txtstylemange: {
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      flex: 2,
    },
    txtstylemagetwo: {
      fontSize: Font.font_normal_six,
      fontFamily: Cfont.rubik_light,
      color: root.color_text,
    },
    txtstylemagegreen: {
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_medium,
      color: root.color_positive,
    },
    allignprice: {alignItems: 'flex-end', flex: 1, justifyContent: 'center'},
    sharehold: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      alignItems: 'center',
    },
    colorepieone: {
      marginHorizontal: 15,
      flexDirection: 'row',
      marginTop: 13,
    },
    colorpietwo: {
      height: 10,
      width: 10,
      borderRadius: 20,
      marginRight: 8,
    },
    colorpieThree: {
      fontSize: 12,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },

    colorpiefour: {
      marginHorizontal: 15,
      flexDirection: 'row',
      marginTop: 20,
    },
    colourpieFive: {
      height: 10,
      width: 10,
      borderRadius: 20,
      marginRight: 8,
    },
    colourpiesix: {
      fontSize: 12,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
    },

    colorpie: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    annnualmodal: {
      fontSize: 30,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
    },
    annualmodalone: {flexDirection: 'row', height: 48},
    annualmodaltwo: {
      fontSize: 16,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      marginLeft: 10,
    },
  });

// Orders screen and its components
export const equitySipCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    height: 81,
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    // elevation:1
  },
  companyNameContainer: {
    padding: 8,
    height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: 'green',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  eqSIP: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  activeTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

export const goodTillDateCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completed: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingRight: 5,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    paddingHorizontal: 8,
    paddingBottom: 10,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  frequenctTxt: {
    fontSize: 9,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const multiLeg = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completed: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingRight: 5,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    // ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  date: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

export const singleScriptCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completedTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingRight: 5,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    // ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const spreadOrders = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  sellTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  completedTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingRight: 5,
  },
});

export const equitySipSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  modifyBtn: {
    width: 171,
    backgroundColor: root.client_background,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelBtn: {
    width: 153,
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modifyOrderTxt: {
    color: 'white',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  cancelOrderTxt: {
    color: '#25335c',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
    color: root.color_text,
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installments: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  eqSIP: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const goodTillDateSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 16,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  qty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
});

export const multiLegSheet = StyleSheet.create({
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 32,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  leg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'center',
  },
  multileg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'flex-start',
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  name: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  date: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  sellTxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  quantity: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 24,
  },
  orderName: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    top: '70%',
    backgroundColor: 'white',
    paddingHorizontal: 16,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    paddingVertical: 16,
  },
  modalSelectLeg: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  legName: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export const netPositionSheet = StyleSheet.create({
  container: {
    // overflow: 'hidden',
    height: Dimensions.get('screen').height,
    overflow: 'hidden',
  },
  netPositionTxt: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 10,
  },
  pL: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  plContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 16,
  },
  plView: {
    ...alignment.row,
  },
  overAllCard: {
    backgroundColor: root.color_active,
    marginVertical: 10,
    // elevation: 3,
    shadowOpacity: 0.5,
    paddingHorizontal: 10,
  },
  overAllCardInnerContainer: {
    padding: 8,
  },
  companyDetailView: {
    ...alignment.row_SpaceB,
  },
  companyNameView: {
    ...alignment.row,
    alignItems: 'center',
  },
  topView: {
    ...alignment.row_SpaceB,
  },
  qtyPlContainer: {
    ...alignment.row_SpaceB,
  },
  buyQty: {
    ...alignment.row,
  },
  deliveryTxt: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  companyNameTxt: {
    ...size_family.rm_16,
    ...color.text,
  },
  ltp: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  plTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  topPl: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  squareOffTxt: {
    backgroundColor: root.client_background,
    color: root.color_active,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  eqCombined: {
    ...size_family.rm_9,
    color: '#979797',
  },
  expiryTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 13,
    color: root.color_text,
    paddingTop: 5,
  },
  marketLotNetPrice: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 12,
  },
  actualPl: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
    color: root.color_text,
  },
  netPrice: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
  },
  actualPrice: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
    color: root.color_text,
  },
  todaysPl: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
  sellTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
});

export const singleSheetScript = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  noTrades: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
    color: root.color_text,
    paddingTop: 16,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 50,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const spreadOrdersSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 42,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  timePeriodTxt: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  executedTxt: {
    paddingTop: 10,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  sellTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  buyQty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_positive,
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
});

export const headerComp = StyleSheet.create({
  headerView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    backgroundColor: 'white',
    paddingHorizontal: '4%',
    paddingVertical: '2%',
  },
  headerLeftContainer: {
    ...alignment.row_alingC_SpaceB,
    alignItems: 'center',
  },
  chooseOrderContainer: {
    paddingLeft: '3%',
    ...alignment.row,
    alignItems: 'center',
  },
  orderTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  chosenOrderTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

export const ordersNavigation = StyleSheet.create({
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  clearTxt: {
    ...size_family.rm_16,
    ...color.text,
  },
  searchModalTxtip: {
    fontFamily: Cfont.rubik_light,
    marginLeft: 16,
    flexGrow: 0.85,
  },
  searchModal: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#f6f6f6',
  },
  searchModalHeader: {
    ...alignment.row_SpaceB,
    height: 56,
    alignItems: 'center',
    ...p.h_10,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  searchModalTxt: {
    ...alignment.row,
    alignItems: 'center',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  netPositionValueContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: '4%',
    alignItems: 'center',
    backgroundColor: '#F0F2F5',
    height: 56,
    paddingVertical: 4,
  },
  netPositionTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
  },
  pLvalueTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  modalFullView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '67%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  modalCompanyTitleView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 10,
  },
  modalCompanyName: {
    ...alignment.row,
    alignItems: 'center',
  },
  additionalDetailsTxt: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: 20,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
  },
  btns: {
    height: 38,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    borderRadius: 10,
    marginTop: 20,
  },
  squareOffBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 38,
    borderWidth: 1,
    marginTop: 32,
    borderColor: root.client_background,
    borderRadius: 10,
  },
  name: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  eqCombined: {
    fontSize: 9,
    fontFamily: Cfont.rubik_medium,
    color: '#979797',
    backgroundColor: '#9797971A',
    paddingHorizontal: 5,
  },
  todaysPlTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  todaysPlValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  additionalDetailsText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  btnTxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },

  container: {backgroundColor: '#fff', paddingTop: 16},
  head: {paddingLeft: '10%'},
  wrapper: {flexDirection: 'row'},
  row: {height: 48},
  headText: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  dataText: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    alignSelf: 'center',
  },
});

export const ordersModal = StyleSheet.create({
  container: {
    position: 'absolute',
    height: '47%',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  innerContainer: {
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  orderTxt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  scriptsTxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
  },
  renderItemView: {
    ...alignment.row,
    alignItems: 'center',
    height: 48,
    paddingTop: 16,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export const shiftButton = StyleSheet.create({
  tabBarContainer: {
    ...alignment.row,
    ...p.h_16,
    height: '5%',
    ...bgColor.color_active,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: root.client_background,
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  tabBtnsText: {
    textAlign: 'center',
    ...color.subtext,
    ...fontFamily.rubic_medium,
  },
  selectedBtnText: {
    textAlign: 'center',
    ...color.client_background,
    ...fontFamily.rubic_medium,
  },
});

//OrderEntry Page (BuySale)

export const OrderEntry = StyleSheet.create({
  Top: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    backgroundColor: 'white',
    elevation: 8,
  },

  closeIcon: {width: 24, height: 24, color: root.color_text},

  stockName: {
    fontWeight: 'bold',
    fontSize: 16,
    color: root.color_text,
  },

  nseView: {
    marginLeft: 8,
    alignSelf: 'center',
    flexDirection: 'row',
  },
  Nse: {
    color: 'grey',
    fontSize: 8,
    backgroundColor: '#EFF2F2',
    borderRadius: 2,
    paddingVertical: 1,
    paddingHorizontal: 4,
    alignSelf: 'center',
    fontFamily: Cfont.rubik_medium,
  },
  A: {
    color: root.color_text,
    fontSize: 10,
    // backgroundColor: '#EEE7E7',
    //  borderRadius: 2,
    // paddingVertical: 1,
    paddingHorizontal: 4,
    fontFamily: Cfont.rubik_regular,
  },

  Asub: {
    fontSize: 12,
    alignSelf: 'center',
    marginLeft: 8,
  },
  price: {
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  Changes: {
    fontSize: 10,

    fontFamily: Cfont.rubik_medium,
    paddingLeft: 20,
  },

  Buy: {
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
    paddingVertical: 6,
    paddingHorizontal: 12,

    borderRadius: 16,
  },

  BseView: {
    marginHorizontal: 18,
    paddingVertical: 2,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderRadius: 3,
    borderColor: root.client_background,
    alignSelf: 'flex-start',
    position: 'relative',
  },
  BsePrice: {textAlign: 'right', fontSize: 12},

  qty: {textAlign: 'right', fontSize: 12},

  Bse: {
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: root.client_background,
    color: 'white',
    paddingHorizontal: 1,
    paddingVertical: 1,
    fontSize: 8,
  },

  Bsebox: {
    marginHorizontal: 2,
    paddingVertical: 2,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderRadius: 3,
    borderColor: 'grey',
    alignSelf: 'flex-start',
    position: 'relative',
  },
  BseBoxPrice: {textAlign: 'right', fontSize: 12},

  NSE: {
    position: 'absolute',
    top: 0,
    left: 0,
    backgroundColor: '#EEE7E7',
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 1,
    paddingVertical: 1,
    fontSize: 8,
  },
});

export const addFunds = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    paddingVertical: '4%',
  },
  name: {
    ...alignment.row,
    alignItems: 'center',
    paddingLeft: 15,
  },
  caretDown: {
    paddingLeft: 10,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  amountContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'flex-end',
    paddingTop: '7%',
  },
  addFundsTxtContainer: {
    width: '40%',
    alignItems: 'flex-start',
  },
  enterAmountContainer: {
    width: '50%',
  },
  addFundsTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  txtIpContainer: {
    borderBottomWidth: 1,
    ...alignment.row,
    alignItems: 'center',
  },
  txtIp: {
    flexGrow: 1,
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
  },
  addMoneyContainer: {
    width: '50%',
    alignSelf: 'flex-end',
    ...alignment.row_SpaceB,
  },
  constMoneyTxt: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    borderWidth: 0.3,
    alignSelf: 'flex-start',
    borderRadius: 20,
    paddingHorizontal: 5,
    paddingVertical: 1,
  },
  linkedAccountContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '7%',
  },
  linkedAccounts: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_six,
    paddingLeft: '6%',
  },
  linkedAccountsTxt: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_six,
    color: root.color_text,
  },
  paymentGatewayContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '9%',
  },
  addFundsBtn: {
    height: 40,
    backgroundColor: root.client_background,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addFundsBtnTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  addFundsBtnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  paymentCardUnselected: {
    height: 112,
    width: 112,
    marginRight: 18,
    padding: 12,
    backgroundColor: root.color_active,
    borderRadius: 10,
    elevation: 1,
  },
  paymentCardSelected: {
    height: 112,
    width: 112,
    marginRight: 18,
    padding: 12,
    backgroundColor: root.client_background,
    borderRadius: 10,
    elevation: 1,
  },
  paymentTypeTxtUnselected: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    height: '100%',
    paddingTop: 3,
  },
  paymentTypeTxtSelected: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
    fontSize: Font.font_normal_four,
    height: '100%',
    paddingTop: 3,
  },
  unSelectedRadioDark: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerUnSelectedRadioDark: {
    height: 11,
    width: 11,
    borderRadius: 5.5,
    borderColor: root.color_text,
    backgroundColor: root.color_text,
  },
  selectedRadioLight: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerSelectedRadioLight: {
    height: 11,
    width: 11,
    borderRadius: 5.5,
    borderColor: root.color_text,
    backgroundColor: root.color_text,
  },
  paymentContainer: {
    paddingTop: '9%',
  },
  changeBank: {
    ...alignment.row,
    alignItems: 'center',
  },
});
export const chooseBankModal = StyleSheet.create({
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: '25%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  headerView: {
    ...alignment.row_SpaceB,
  },
  accountList: {
    marginTop: 24,
  },

  accountsTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  accountsContainer: {
    ...alignment.row_SpaceB,
    height: 48,
    alignItems: 'center',
  },
  selectAccount: {
    ...alignment.row,
    alignItems: 'center',
  },
  name: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_text,
  },
});
export const upiModal = StyleSheet.create({
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: '25%',
    justifyContent: 'space-between',
    width: '100%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  headerView: {
    ...alignment.row_SpaceB,
  },
  accountsTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  proceedBtn: {
    height: 40,
    backgroundColor: root.client_background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  proceedTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  proceedTxtEnabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  txtIp: {
    borderWidth: 0.5,
    borderRadius: 10,
    // marginTop: '6%',
  },
});

// Available Funds and its components
export const availableFunds = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    paddingVertical: 16,
  },
  header: {
    ...alignment.row_SpaceB,
  },
  availableFundsTxt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 16,
  },
  periodictyView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 16,
  },
  periodicityValue: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
  valueContainer: {
    ...alignment.row,
    height: 49,
    marginTop: 28,
  },
  utilisedContainer: {
    width: '50%',
    backgroundColor: root.color_positive_step_50,
  },
  availableContainer: {
    width: '50%',
    backgroundColor: root.color_positive_step_100,
  },
  utlised_available_Txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_active,
    fontSize: Font.font_normal_six,
  },
  utilised_available_Value: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_two,
    color: root.color_active,
    paddingTop: 3,
  },
  utilised_available_Container: {
    paddingVertical: 8,
    paddingLeft: 16,
  },
  cardActive: {
    height: 140,
    width: 140,
    marginRight: 16,
    borderRadius: 10,
    backgroundColor: root.client_background,
  },
  cardInactive: {
    height: 140,
    width: 140,
    marginRight: 16,
    borderRadius: 10,
    backgroundColor: root.color_active,
  },
  cardContainer: {
    padding: 12,
    justifyContent: 'space-between',
    height: '100%',
  },
  headingActive: {
    fontSize: Font.font_normal_two,
    color: root.color_active,
    fontFamily: Cfont.rubik_regular,
  },
  headingInactive: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  add_withDraw_Funds: {
    ...alignment.row,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  add_withdraw_ActiveTxt: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_six,
    paddingRight: 5,
  },
  add_withdraw_InactiveTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_six,
    paddingRight: 5,
  },
  perodiCtyContainer: {
    height: 34,
    width: '46%',
    ...alignment.row_SpaceB,
    alignItems: 'center',
    marginHorizontal: 8,
  },
  innerPeriodicity: {
    ...alignment.row,
  },
  indicatorTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  valueTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    alignment: 'flex-end',
  },
  cardView: {
    paddingTop: 20,
  },
  periodicityContainer: {
    paddingTop: 24,
  },
  menuNav: {
    width: 156,
    backgroundColor: root.color_active,
    position: 'absolute',
    right: 25,
    top: 40,
    zIndex: 1,
  },
  menuItem: {
    height: 40,
    justifyContent: 'center',
    paddingLeft: 12,
  },
  menuTxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  value: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: '40%',
  },
});
export const periodicityModal = StyleSheet.create({
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '20%',
    backgroundColor: 'white',
    padding: 16,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  header: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
  },
  titleTxt: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  item: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '10%',
  },
  itemTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});
export const fundDetails = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    flex: 1,
    backgroundColor: 'white',
  },
  titleContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
  },
  titleTxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  titleValueContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  titleValue: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    paddingRight: 10,
  },
  header: {
    ...alignment.row,
    height: 44,
    alignItems: 'center',
  },
  backIcon: {
    paddingRight: 25,
  },
  headerTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});
export const fundList = StyleSheet.create({
  detailsContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 10,
    alignItems: 'center',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valueTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  singleIndicatorTxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    width: '50%',
  },
  singleIndicatorValue: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    paddingRight: 27,
  },
});
export const recentTransactions = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    ...alignment.row_SpaceB,
    height: 45,
    alignItems: 'center',
  },
  titleContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    paddingLeft: 20,
  },
  transactionCard: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
  },
  cardTitleContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  cardTitleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_text,
  },
  accountTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_three,
    color: root.color_text,
  },
  dateTime: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  bankTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  amount: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  status: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_two,
  },
});
export const filterModal = StyleSheet.create({
  modalContainerHalf: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    height: '60%',
    backgroundColor: root.color_active,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  applyTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  applyButton: {
    height: 40,
    backgroundColor: root.client_background,
    marginTop: '20%',
    marginHorizontal: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  applyConstBtn: {
    height: 40,
    backgroundColor: root.client_background,
    marginHorizontal: 10,
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalContainerFull: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    height: '100%',
    backgroundColor: root.color_active,
    flex: 1,
  },
  header: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    height: 58,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  titleContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
    paddingLeft: 24,
  },
  clearTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    color: root.color_text,
  },
  particularTitle: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingHorizontal: 16,
    paddingTop: 24,
  },
  cardUnselcted: {
    borderWidth: 0.3,
    borderColor: 'grey',
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_active,
    paddingHorizontal: 24,
    marginTop: 12,
    marginLeft: 12,
  },
  cardSelected: {
    borderWidth: 0.3,
    borderColor: 'violet',
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_chipFilter,
    paddingHorizontal: 24,
    marginLeft: 12,
    marginTop: 12,
  },
  itemTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  inputView: {
    ...alignment.row,
    alignItems: 'center',
    width: '100%',
    flex: 1,
  },
  inputContainer: {
    borderWidth: 0.3,
    ...alignment.row,
    alignItems: 'center',
    paddingVertical: 10,
    paddingLeft: 16,
    paddingRight: 8,
    borderRadius: 10,
  },
  input: {
    width: 106,
    height: 40,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  txtInputStyleFocused: {
    ...alignment.row,
    borderBottomWidth: 1,
    alignItems: 'center',
    height: 20,
  },
  txtInputStyleUnFocused: {
    alignItems: 'center',
    height: 20,
    ...alignment.row,
  },
  top: {
    ...alignment.row_SpaceB,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  filter: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});
export const withDrawFunds = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    paddingVertical: '4%',
  },
  name: {
    ...alignment.row,
    alignItems: 'center',
    paddingLeft: 15,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  caretDown: {
    paddingLeft: 10,
  },
  amountContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'flex-end',
    paddingTop: '7%',
  },
  addFundsTxtContainer: {
    width: '47%',
    alignItems: 'flex-start',
  },
  addFundsTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  enterAmountContainer: {
    width: '50%',
  },
  txtIpContainer: {
    borderBottomWidth: 1,
    ...alignment.row,
    alignItems: 'center',
  },
  txtIp: {
    flexGrow: 1,
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
  },
  addFundsBtn: {
    height: 40,
    backgroundColor: root.client_background,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addFundsBtnTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  addFundsBtnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  availableFund: {
    fontSize: Font.font_normal_six,
    color: root.color_textual,
    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 8,
    backgroundColor: root.chip_primary,
    alignSelf: 'flex-end',
    borderRadius: 10,
    marginTop: 8,
  },
});

export const needHelpStyle = StyleSheet.create({
  header: {
    ...alignment.row,
    alignItems: 'center',
    height: 56,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    paddingLeft: 32,
  },
  typeTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: 'black',
    paddingTop: 16,
  },
  detailsTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    paddingTop: 16,
  },
});

export const rateUsModal = StyleSheet.create({
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  infoText: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    alignSelf: 'center',
  },
  ratingView: {
    alignItems: 'center',
    paddingTop: 16,
  },
  storeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_six,
  },
  feedbackTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
    fontSize: Font.font_normal_three,
  },
  buttonContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 24,
  },
  buttonView: {
    width: '45%',
    height: 38,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    borderColor: root.client_background,
  },
  closeButton: {
    alignItems: 'flex-end',
  },
  infoView: {
    paddingTop: 28,
  },
  redirectionTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_six,
    color: root.color_text,
    textAlign: 'center',
    paddingTop: 5,
  },
});

export const contactUsModal = StyleSheet.create({
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  typeTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_three,
    paddingLeft: 16,
  },
  typeContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: 24,
  },
  closeButton: {
    alignItems: 'flex-end',
  },
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '36%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    paddingVertical: 20,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  list: {
    paddingVertical: 16,
  },
});

//Link, Report , BackOffice , Calculator page

export const linkOne = StyleSheet.create({
  main: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: root.color_active,
  },
  backicon: {
    width: 24,
    height: 24,
    color: root.color_text,
  },

  header: {
    fontSize: 18,
    marginLeft: 35,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  cardtext: {
    fontSize: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  cardsub: {
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 6,
  },

  BackiconSide: {
    width: 28,
    height: 28,
    color: root.color_text,
  },
  card: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginVertical: 10,
    borderRadius: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    cardText: {
      fontSize: 14,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  image: {
    height: '100%',
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'flex-end',
    width: '15%',
  },

  shadowone: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 0,
    backgroundColor: root.color_active,
  },
  shadowtwo: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  shadowthree: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

//Span Margin Page

export const Span = StyleSheet.create({
  main: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: root.color_active,
  },
  bar: {padding: 4, width: 32, height: 32},

  closeIcon: {width: 24, height: 24, color: root.color_text},

  span: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,

    marginTop: 26,
  },

  calculator: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  blank: {
    textAlign: 'right',
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 1,
  },

  txt: {fontFamily: Cfont.rubik_medium, color: root.color_text},

  txt1: {
    marginTop: 8,
    borderRadius: 8,
    borderWidth: 0.4,
    borderColor: root.color_text,

    flexDirection: 'row',
    alignItems: 'center',
  },

  textInput: {
    flex: 1,
    paddingVertical: 6,
    paddingHorizontal: 16,
    fontSize: 14,
  },

  AddIcon: {
    width: 24,
    height: 24,
    color: root.color_text,
    marginRight: 12,
  },
});

//Calculator

export const calculator = StyleSheet.create({
  main: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    flexDirection: 'row',
    paddingHorizontal: 12,
    paddingVertical: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 0,
    backgroundColor: root.color_active,
  },
  backIcon: {width: 24, height: 24, color: root.color_text},
  headerText: {
    fontSize: 18,
    marginLeft: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  scrollMain: {flex: 1, marginTop: 2},

  cardMain: {
    backgroundColor: root.color_active,
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 8,
    paddingVertical: 18,
    paddingHorizontal: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // alignItems: 'center',
  },
  cardText: {
    fontSize: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 1,
  },
  cardSubText: {
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 1,
  },
  image: {
    height: '100%',
    paddingHorizontal: 10,
    alignItems: 'flex-end',
    width: '15%',
  },
});

//Future Fair

export const future = StyleSheet.create({
  main: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: root.color_active,
    padding: 16,
  },

  main1: {padding: 2, width: 32, height: 32},

  closeIcon: {width: 24, height: 24, color: root.color_text},

  Future: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 38,
    //fontWeight: 'bold',
  },

  value: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,

    // fontWeight: 'bold',
  },
  top: {flexDirection: 'row', justifyContent: 'flex-end'},
  clearView: {paddingVertical: 4, paddingHorizontal: 8},
  clear: {
    //textAlign: 'right',
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  sub: {flexDirection: 'row', marginTop: 28},
  sub1: {flex: 1, marginRight: 8},
  sub2: {flex: 1, marginLeft: 8},
  sub3: {flexDirection: 'row', marginTop: 28},

  txt: {fontFamily: Cfont.rubik_medium, color: root.color_text},

  textInput: {
    marginTop: 8,
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: root.color_text,
    paddingVertical: 6,
    paddingHorizontal: 16,
    fontSize: 16,
  },

  inputView: {
    marginTop: 8,
    borderRadius: 8,
    borderWidth: 0.5,
    borderColor: root.color_text,
    flexDirection: 'row',
    alignItems: 'center',
  },

  Expiry: {
    flex: 1,
    paddingVertical: 6,
    paddingHorizontal: 16,
    fontSize: 16,
  },

  Minus: {
    width: 20,
    height: 20,
    color: root.color_text,
    marginRight: 12,
  },
  MinusMain: {flex: 1, flexDirection: 'row'},

  Days: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginRight: 12,
  },
  AddIcon: {
    width: 20,
    height: 20,
    color: root.color_text,
    marginRight: 12,
  },

  MinusOne: {
    width: 18,
    height: 18,
    color: root.color_text,
  },
  textZero: {
    flex: 1,
    paddingVertical: 6,
    paddingHorizontal: 16,
    fontSize: 16,
    textAlign: 'center',
  },
  AddOne: {
    width: 18,
    height: 18,
    color: root.color_text,
  },
  Div: {flex: 1, marginLeft: 8},
  popMain: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  pop: {
    width: 300,
    padding: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },

  Info: {width: 16, height: 16, color: root.color_text},

  range: {marginLeft: 8, fontSize: 12},

  99: {
    marginLeft: 8,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  btnMain: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: root.client_background,
    marginTop: 50,
    borderRadius: 8,
    alignItems: 'center',
    width: '40%',
  },

  btnTxt: {color: root.color_active, fontSize: 18, marginRight: 22},

  Arrow: {width: 24, height: 24, color: root.color_active},
});

//Options Value

export const options = StyleSheet.create({
  main: {
    flexDirection: 'column',
    flex: 1,
    backgroundColor: root.color_active,
  },
});

export const recommendationsAlerts = StyleSheet.create({
  container: {
    flex: 1,
  },
  settingsView: {
    position: 'absolute',
    ...bgColor.color_active,
    height: 35,
    width: 100,
    top: 40,
    right: 25,
    ...alignment.alignC_justifyC,
    elevation: 5,
    borderRadius: 5,
    shadowOpacity: 0.5,
    shadowOffset: {width: 0, height: 5},
  },
  settingsTxt: {
    ...color.text,
    ...size_family.rr_14,
  },
  searchModal: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    ...bgColor.color_active,
  },
  modalHeader: {
    ...alignment.row_alingC_SpaceB,
    height: 40,
  },
  title: {
    ...size_family.rm_18,
    ...color.text,
    ...padding.l_25,
  },
  header: {
    ...alignment.row_alingC_SpaceB,
    height: 56,
    ...bgColor.color_active,
    ...padding.h_16,
  },
  rightHeaderView: {
    ...alignment.row_alignC,
  },
  txtIp: {
    ...fontFamily.rubic_light,
    width: '80%',
  },
});

export const recommendations = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  alertsTxt: {
    ...color.client_background,
    ...size_family.rm_12,
  },
  horzontalLine: {
    height: 1,
    borderColor: 'grey',
    backgroundColor: 'grey',
    ...m.t_30,
    opacity: 0.2,
  },
  innerProgress: {
    height: 5,
    borderRadius: 10,
    ...bgColor.color_positive,
  },
  outerProgress: {
    height: '100%',
    ...bgColor.color_negative,
    width: '50%',
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
  },
  header: {
    height: 50,
    ...alignment.row_alingC_SpaceB,
    ...padding.h_16,
    ...m.t_10,
  },
  card: {
    ...bgColor.color_active,
    ...m.h_16,
    ...m.t_16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 1,
    backgroundColor: '#F5F7FA',
    marginBottom: 30,
  },
  buyTxt: {
    ...size_family.rm_12,
    ...color.active,
    ...bgColor.color_positive,
    height: 24,
    width: 55,
    ...textAlign.center,
    borderRadius: 15,
  },
  stockName: {
    ...size_family.rm_16,
    ...color.text,
  },
  nseText: {
    ...size_family.rm_10,
    color: root.color_subtext,
    ...bgColor.backgroung_exchange_chip_color,
    ...textAlign.center,
    ...p.h_3,
    ...m.m_l_5,
  },
  volGainer: {
    ...size_family.rm_10,
    ...bgColor.chip_background_positive_cotrast,
    ...color.positive,
    ...p.h_8,
    borderRadius: 15,
    ...p.v_2,
  },
  eQ: {
    ...size_family.rr_10,
    ...color.text,
    ...p.l_5,
  },
  buyTarget: {
    ...size_family.rr_12,
    ...color.text,
  },
  detailTxt: {
    ...size_family.rl_12,
    ...color.text,
    ...p.t_3,
  },
  followUp: {
    ...size_family.rr_12,
    ...color.text,
    ...p.l_10,
  },
  noOfFollupRecommendation: {
    ...size_family.rm_10,
    ...bgColor.color_negative,
    ...color.active,
    ...p.h_7,
    borderRadius: 20,
    ...p.v_2,
  },
  noOfRecommendations: {
    ...size_family.rl_14,
    ...color.text,
  },
  followUpSection: {
    ...alignment.row_alignC,
    ...p.v_10,
    backgroundColor: '#F5F7FA',
  },
  filterSearchContainer: {
    ...alignment.row_alignC,
  },
  recommendationValidity: {
    ...alignment.row_SpaceB,
  },
  nameContainer: {
    ...alignment.row_alignC,
  },
  gainerContainer: {
    ...alignment.row,
    ...p.t_12,
  },
  topView: {
    ...alignment.row_alingC_SpaceB,
  },
});

export const ordersFilter = StyleSheet.create({
  Maincon: {
    width: Dimensions.get('window').width,
  },
  titleTxt: {
    ...size_family.rm_12,
    ...color.text,
    ...p.l_12,
    ...m.v_16,
  },
  typeTxt: {
    ...size_family.rr_14,
    ...color.text,
  },
  blockUnSelected: {
    ...p.h_24,
    borderWidth: 1,
    borderColor: root.color_border,
    ...p.v_12,
    ...bgColor.color_active,
    ...m.m_l_15,
    borderRadius: 10,
  },
  blockSelected: {
    ...p.h_24,
    borderWidth: 1,
    borderColor: root.client_background,
    ...p.v_12,
    backgroundColor: '#F5F7FA',
    ...m.m_l_15,
    borderRadius: 10,
  },
  applyBtn: {
    width: '100%',
    backgroundColor: root.color_textual,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
  },
  applyBottonText: {
    ...color.active,
    ...size_family.rm_16,
  },
  contentView: {
    height: Dimensions.get('window').height - 98,
  },
  item: {
    ...size_family.rl_14,
    ...color.text,
  },
});

export const followUpModal = StyleSheet.create({
  titleTxt: {
    ...size_family.rr_16,
    ...color.text,
  },
  indicator: {
    position: 'absolute',
    top: 0,
    left: -5,
    height: 10,
    width: 10,
    borderRadius: 10,
    backgroundColor: 'black',
  },
  volGainer: {
    ...size_family.rm_10,
    ...bgColor.chip_background_positive_cotrast,
    ...color.positive,
    ...p.h_8,
    borderRadius: 15,
    ...p.v_2,
  },
  typeTxt: {
    ...size_family.rr_12,
    ...color.text,
  },
  transaction: {
    ...size_family.rm_12,
    ...color.active,
    ...bgColor.color_positive,
    height: 24,
    width: 55,
    textAlignVertical: 'center',
    textAlign: 'center',
    borderRadius: 15,
  },
  date: {
    ...size_family.rl_10,
    ...color.text,
  },
  detailsContainer: {
    height: 68,
    borderLeftWidth: 0.5,
    borderStyle: 'dotted',
    marginTop: 16,
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  gainerContainer: {
    ...alignment.row,
    paddingTop: 5,
  },
});

export const Setalertstyle = StyleSheet.create({
  maincon: {
    paddingHorizontal: 16,
  },

  Title: {
    ...size_family.rm_30,
    ...color.text,
    marginBottom: 16,
  },
  piceconatiner: {
    height: 88,
    ...alignment.row_alingC_SpaceB,
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderTopColor: root.color_border,
    borderBottomColor: root.color_border,
  },
  txtstyle: {
    ...size_family.rm_16,
    ...color.text,
  },
  txtdesc: {
    ...size_family.rr_12,
    ...color.text,
    marginTop: 8,
  },
  innertitleconatiner: {
    ...alignment.row,
  },
  companytxt: {
    ...size_family.rm_16,
    ...color.text,
    marginRight: 5,
  },
  nsetxt: {
    ...size_family.rm_9,
    ...color.text,
    backgroundColor: 'rgba(151,151,151,0.1)',
    height: 12,
    width: 23,
    ...padding.h_3,
    marginTop: 3,
  },
  futtxt: {
    ...size_family.rr_13,
    ...color.text,
    marginRight: 5,
  },
  valuetxtx: {
    ...size_family.rm_14,
    ...color.text,
    marginTop: 8,
  },
  mainnew: {
    marginBottom: 32,
    ...padding.h_6,
  },
  modaltitle: {
    ...size_family.rm_30,
    ...color.text,
    ...padding.h_6,
    marginBottom: 16,
  },
  conatinertwo: {
    height: screenWidth * 0.345,
    marginBottom: 16,
    paddingVertical: 16,
    ...padding.h_6,
    justifyContent: 'space-between',
  },
  pricealerttxt: {
    ...size_family.rm_14,
    ...color.text,
  },
  setprice: {
    ...size_family.rl_13,
    ...color.text,
    ...padding.h_6,
  },
  bottomsetalert: {
    marginTop: 32,
    ...padding.h_6,
  },
  textinput: {
    height: 41,
    width: 142.91,
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
    ...size_family.rm_20,
    ...padding.h_6,
    marginBottom: 16,
  },
  conatiner: {
    height: 40,
    width: '100%',

    backgroundColor: root.client_background,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
  },
  settxt: {
    ...size_family.rm_16,
    ...color.active,
  },
});

export const Toastmsgstyle = StyleSheet.create({
  maincon: {
    height: 48,
    width: '97%',
    backgroundColor: 'black',
    borderRadius: 5,
    ...padding.h_16,
    ...alignment.justify_container_center,
  },
  txt: {
    ...size_family.rr_14,
    ...color.active,
  },
});

export const Addscripstyle = StyleSheet.create({
  Maincontainer: {
    backgroundColor: root.color_active,
    flex: 1,
  },
  flexallign: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
  },
  textinput: {
    top: 0,
    height: 56,
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
    paddingVertical: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 1 / 2,
  },

  innerconatiner: {
    ...padding.h_16,
    paddingTop: 16,
  },
  recomtxt: {
    ...size_family.rm_16,
    ...color.text,
  },
  recomdata: {
    ...alignment.justify_container_center,
    height: 28,
    marginTop: 12,
    marginRight: 12,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: root.color_border,
    paddingHorizontal: 12,
  },
  rcomtxt: {
    ...size_family.rm_11,
    ...color.text,
  },
  bottomconatiner: {
    height: screenWidth * 0.194,
    backgroundColor: root.client_background,
    borderTopRightRadius: 6,
    borderTopLeftRadius: 6,
    width: '100%',
    bottom: 0,
    position: 'absolute',
    ...padding.h_16,
    ...alignment.row_alingC_SpaceB,
  },
  addtxt: {
    ...size_family.rr_12,
    ...color.active,
  },
  watchlisttitle: {
    ...size_family.rm_14,
    ...color.active,
  },
  doneconatiner: {
    height: screenWidth * 0.097,
    width: screenWidth * 0.204,
    backgroundColor: root.color_active,
    borderRadius: 8,
    ...alignment.alignC_justifyC,
  },
  donetxt: {
    ...size_family.rm_16,
    color: root.client_background,
  },
  numtxt: {
    backgroundColor: root.color_negative,
    ...color.active,
    ...size_family.rm_10,
    textAlign: 'center',
    paddingTop: 2,
    borderRadius: 8,
    marginLeft: 5,
    marginTop: 1,
    height: 16,
    width: 20,
  },
  rowconatiner: {
    ...alignment.row,
    justifyContent: 'center',
  },
});

export const Removescripstyle = StyleSheet.create({
  Maincontainer: {
    // flex: 1,
    height: '100%',
    backgroundColor: root.color_active,
  },
  innoecontainer: {
    ...padding.h_16,
  },
  donecontainer: {
    height: 24,
    width: 60.66,
    borderRadius: 20,
    backgroundColor: root.client_background,
    ...alignment.alignC_justifyC,
  },
  donetxt: {
    ...size_family.rr_12,
    ...color.active,
  },
  RemoveTitle: {
    ...size_family.rm_30,
    ...color.text,
    marginVertical: 16,
  },
  containerinner: {
    ...alignment.row_SpaceB,
    height: 33,
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
  },
  removetxt: {
    ...size_family.rm_16,
    ...color.text,
  },
  removetxttwo: {
    ...size_family.rr_16,
    ...color.text,
  },
  removeconatiner: {
    height: screenWidth * 0.127,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
    width: '100%',
    ...p.h_16,
    flex: 1,
    ...alignment.row_alingC_SpaceB,
  },
  shadowconationer: {
    backgroundColor: root.color_active,
    height: screenWidth * 0.127,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.1)',
    width: '100%',
    paddingHorizontal: 30,
    flex: 1,
    ...alignment.row_alingC_SpaceB,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.37,
    shadowRadius: 7.49,

    elevation: 12,
  },
  rowItem: {
    height: 100,
    width: 100,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innercontainer: {
    ...alignment.row,
  },
  tittxtstyle: {
    ...size_family.rm_16,
    ...color.text,
  },
  nsetxt: {
    ...size_family.rm_9,
    ...color.text,
    backgroundColor: root.color_border,
    ...m.m_l_5,
    marginTop: 2,
    height: 11,
    width: 18,
  },
  eqtxt: {
    ...size_family.rr_10,
    ...color.text,
    ...m.m_l_5,
    marginTop: 1,
  },
  removemodal: {
    width: screenWidth * 0.681,
    height: screenWidth * 0.352,
  },
  innercontainerone: {
    width: screenWidth * 0.681,
    height: 56.59,
    paddingHorizontal: 24,
    ...alignment.justify_container_center,
  },
  innercontainertwo: {
    width: screenWidth * 0.681,
    height: 52,
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  innercontainerthree: {
    width: screenWidth * 0.681,
    height: 36,
    ...alignment.row,
    justifyContent: 'flex-end',
    paddingHorizontal: 12,
    paddingBottom: 12,
  },
  modeltitle: {
    ...size_family.rm_18,
    ...color.text,
  },
  desptxt: {
    ...size_family.rm_14,
    ...color.text,
  },
  yescontainer: {
    height: 24,
    width: 52,
    ...alignment.alignC_justifyC,
    marginRight: 5,
    borderRadius: 20,
    backgroundColor: root.client_background,
  },
  yescontainertwo: {
    height: 24,
    // width: 52,
    ...alignment.alignC_justifyC,
    ...p.h_14,
    marginRight: 5,
    borderRadius: 20,
    backgroundColor: root.client_background,
  },
  nocontainer: {
    height: 24,
    width: 52,
    ...alignment.alignC_justifyC,
    borderWidth: 1,
    marginRight: 5,
    borderRadius: 20,
  },
  nocontainertwo: {
    height: 24,

    ...alignment.alignC_justifyC,
    ...p.h_14,
    borderWidth: 1,
    marginRight: 5,
    borderRadius: 20,
  },
  yestxt: {
    ...size_family.rm_12,
    ...color.active,
  },
  notxt: {
    ...size_family.rm_12,
    ...color.client_background,
  },
});

export const Renamestyle = StyleSheet.create({
  backcon: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
    paddingLeft: 10,
    paddingTop: 10,
  },
  modalView: {
    position: 'absolute',
    backgroundColor: 'white',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    ...p.t_10,
    ...p.h_16,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    // borderRadius: 10,
  },
  modalViewtwo: {
    position: 'absolute',
    backgroundColor: 'white',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    ...p.t_10,
    ...p.h_16,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    // borderRadius: 10,
  },
  header: {
    height: screenWidth * 0.059,
    width: '100%',
    alignItems: 'flex-end',
  },
  Normaininner: {
    width: 135,
    justifyContent: 'space-between',
    paddingBottom: 16,
  },
  watchListText: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textinpstyle: {
    paddingLeft: 15,
    width: '100%',
    height: 40,
    borderWidth: 1,
    borderRadius: 10,
    borderColor: root.color_border,
    marginBottom: 32,
  },
  bottom: {
    backgroundColor: root.client_background,
    height: 40,
    width: '106%',
    bottom: 0,
    position: 'absolute',
    ...alignment.alignC_justifyC,
  },
  txtstyle: {
    ...size_family.rm_16,
    ...color.active,
  },
  customtxt: {
    ...size_family.rr_14,
    ...color.active,
  },
  customcontaioner: {
    height: 68,
    borderRadius: 6,
    width: '100%',
    position: 'absolute',
    bottom: 10,
    padding: 16,
    alignSelf: 'center',
    backgroundColor: root.color_text,
  },
});

export const Donestyle = StyleSheet.create({
  maincon: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    width: '100%',
    height: '100%',
  },
  donetxt: {
    ...size_family.rm_18,
    ...color.text,
  },
});

// My Favourite Page

//MyFav.flatListMain

export const MyFav = StyleSheet.create({
  header: {
    fontSize: 28,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    padding: 16,
    marginTop: 18,
  },

  total: {
    fontSize: 16,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    paddingHorizontal: 16,
  },

  flatListMain: {marginHorizontal: 12, marginTop: 16, height: 43},

  group: {
    backgroundColor: 'white',
    padding: 14,
    marginTop: 18,
    marginHorizontal: 16,
    marginVertical: 6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 8,
  },

  groupText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
  },

  description: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    marginTop: 4,
  },

  imageMain: {position: 'absolute', bottom: 0, right: 0},
  Image: {width: 32, height: 32},
  mainView: {
    borderRadius: 16,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderWidth: 0.5,
    marginLeft: 4,
    borderColor: root.color_text,
  },
});

//Favourite Page

export const FavOne = StyleSheet.create({
  MainGroup: {
    backgroundColor: 'white',
  },

  itemMain: {flexDirection: 'row', padding: 16},

  itemSub: {
    flexDirection: 'row',
    // justifyContent: 'center',
    // alignItems: 'center',
    flex: 1,
  },

  itemSymbol: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginRight: 4,
    fontSize: 16,
  },

  itemClose: {
    textAlign: 'right',
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  CardView: {
    borderWidth: 1,
    borderColor: root.color_text,
    height: 24,
    width: 24,
    borderRadius: 12,
    marginLeft: 8,
    marginTop: 8,
  },

  T: {
    textAlign: 'center',
    fontWeight: 'bold',
    fontFamily: Cfont.rubik_medium,

    color: root.color_text,
    fontSize: 16,
  },

  AddMain: {
    borderWidth: 1.7,
    borderColor: root.color_text,
    height: 24,
    width: 24,
    borderRadius: 20,
    marginLeft: 10,
    marginTop: 8,
  },
  AddIcon: {
    height: 22,
    width: 22,
    color: root.color_text,

    fontFamily: Cfont.rubik_medium,
  },
  Border: {height: 1, backgroundColor: 'lightgrey'},

  GroupMain: {
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
    backgroundColor: 'white',
    zIndex: 10,
  },

  GroupView: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginVertical: 8,
    alignItems: 'center',
  },
  BackIcon: {width: 24, height: 24, color: root.color_text},

  GroupTxt: {
    flex: 1,
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    marginHorizontal: 12,
    color: root.color_text,
  },

  HeartFilled: {width: 24, height: 24, color: root.color_text, fill: 'red'},

  HeartIcon: {width: 24, height: 24, color: root.color_text},

  FilterIcon: {width: 24, height: 24, color: root.color_text},

  Header1: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },

  Filter: {color: root.color_text, fontFamily: Cfont.rubik_regular},

  Dropdown1: {
    marginLeft: 16,
    backgroundColor: '#EFEFEF',
    flexDirection: 'row',
    paddingHorizontal: 6,
    borderRadius: 4,
    alignItems: 'center',
  },

  Equity: {paddingVertical: 4, fontFamily: Cfont.rubik_medium, fontSize: 12},

  ExpandIcon: {height: 16, width: 16, color: root.color_text},

  Flex: {
    flexDirection: 'row',
  },
  Flex1: {flex: 1},

  Scnnar1: {
    textAlign: 'center',
    fontSize: 12,
    paddingVertical: 12,
    fontFamily: Cfont.rubik_medium,
  },

  Scnnar2: {
    textAlign: 'center',
    fontSize: 12,
    paddingVertical: 12,
    fontFamily: Cfont.rubik_medium,
  },
});

//Dialog Box

//ExDialog.choose
export const ExDialog = StyleSheet.create({
  main: {
    position: 'absolute',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingVertical: 24,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  view: {width: '100%', height: '100%'},

  header: {
    paddingHorizontal: 20,
    position: 'relative',
  },

  choose: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },

  exc: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },
  closeMain: {position: 'absolute', right: 16},

  closeIcon: {height: 24, width: 24, color: root.color_text},

  mainTxt: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
  },
  mainTxt2: {
    width: 20,
    height: 20,
    borderWidth: 1.8,
    borderColor: root.color_text,
    borderRadius: 12,
    padding: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },

  border: {
    height: 10,
    width: 10,
    backgroundColor: root.color_text,
    borderRadius: 8,
  },

  txt: {marginLeft: 16, color: root.color_text, fontFamily: Cfont.rubik_medium},
});

//Filter Dialog BULK BLOCL

export const filterbulk = StyleSheet.create({
  touchable: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  main: {
    position: 'absolute',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingVertical: 22,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  view: {width: '100%', height: '100%'},

  header: {
    paddingHorizontal: 12,
    paddingVertical: 12,
    position: 'relative',
  },

  choose: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },

  exc: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },
  closeMain: {position: 'absolute', right: 16},

  closeIcon: {height: 24, width: 24, color: root.color_text},

  mainTxt: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
  },
  mainTxt2: {
    width: 20,
    height: 20,
    borderWidth: 1.8,
    borderColor: root.color_text,
    borderRadius: 12,
    padding: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },

  border: {
    height: 10,
    width: 10,
    backgroundColor: root.color_text,
    borderRadius: 8,
  },

  txt: {marginLeft: 16, color: root.color_text, fontFamily: Cfont.rubik_medium},

  main2: {paddingHorizontal: 16, marginTop: 16},

  textDate: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  Date2: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 18,
    marginTop: 8,
    width: '80%',
  },
  main3: {
    paddingHorizontal: 18,
    paddingVertical: 14,
    borderRadius: 8,
    borderWidth: 1,
  },
  Date3: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  textIndices: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 16,
  },
  mainIndices: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  mainIndex: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 6,
    borderWidth: 1,
  },
  index: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },

  ApplyBtn: {
    marginTop: 18,
    marginHorizontal: 16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: root.client_background,
    paddingVertical: 12,
    borderRadius: 8,
  },
  textApply: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
});

//SegmentDialog

export const SegDialog = StyleSheet.create({
  close: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  main: {
    position: 'absolute',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingVertical: 24,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  main1: {width: '100%', height: '100%'},

  textView: {
    paddingHorizontal: 20,
    position: 'relative',
  },

  choose: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },

  seg: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    width: '75%',
  },
  closeView: {position: 'absolute', right: 16},

  closeIcon: {height: 24, width: 24, color: root.color_text},
});

//Sector Dialog

export const sectorDialog = StyleSheet.create({
  searchMain: {
    marginTop: 16,
    marginHorizontal: 16,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: root.color_text,
    paddingVertical: 4,
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchIcon: {width: 16, height: 16, fill: root.color_text},
  textInput: {
    marginLeft: 8,
    flex: 1,
    paddingVertical: 0,
    fontSize: 14,
    color: root.color_text,
  },
});

//Bulk Block Page

export const Bulkblock = StyleSheet.create({
  BackIcon: {width: 24, height: 24, color: root.color_text},

  mainView: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    position: 'relative',
    backgroundColor: 'white',
  },
  textScrip: {
    fontSize: 14,
    marginTop: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    textTransform: 'uppercase',
  },

  textB: {marginTop: 4, fontSize: 12, fontFamily: Cfont.rubik_regular},

  textAvg: {color: root.color_text, marginTop: 6},

  transacted: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },

  textClint: {
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },

  textDate: {
    position: 'absolute',
    top: 18,
    right: 16,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },

  AnimatedMain: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    width: '100%',
    overflow: 'hidden',
    zIndex: 10,
    // STYLE
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },

  viewTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },

  Bulk: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    // width: '90%',
  },
  textFilter: {
    color: root.color_text,
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
  },
  dateMain: {
    borderWidth: 1,
    borderColor: '#9797971A',
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#9797971A',
  },

  textDate1: {
    fontSize: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
    color: '#979797',
    fontFamily: Cfont.rubik_medium,
  },

  close: {height: 12, width: 12, color: root.color_text},

  indicesMain: {
    borderWidth: 1,
    borderColor: '#9797971A',

    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#9797971A',
  },
  textindices: {
    fontSize: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
    color: '#979797',
    fontFamily: Cfont.rubik_medium,
  },

  tab1: {
    textAlign: 'center',
    fontSize: 12,
    paddingVertical: 12,
    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 32,
  },

  olderMain: {
    marginTop: 16,
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'lightgrey',
  },

  textOlder: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
  },

  textRecord: {
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    fontSize: 14,
  },
});

export const maregr = StyleSheet.create({
  flex: {flex: 1},
  background: {backgroundColor: 'white'},
  group: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontSize: 30,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    width: '90%',
  },
  date: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  transaction: {
    color: root.color_text,
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
  },

  dateMain: {
    borderWidth: 1,
    borderColor: '#9797971A',

    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#9797971A',
  },
  textDate1: {
    fontSize: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
    color: '#979797',
    fontFamily: Cfont.rubik_medium,
  },
  close: {height: 12, width: 12, color: root.color_text},

  flatMain: {
    backgroundColor: 'white',
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginTop: 12,
    marginHorizontal: 10,
    borderRadius: 8,
  },
  flag: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    textTransform: 'uppercase',
  },
  viewCompany: {flexDirection: 'row', marginTop: 8},
  textCompany: {
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  textCompanyName: {
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  margerMain: {
    flex: 1,
    alignItems: 'center',
    alignContent: 'center',
    flexDirection: 'column-reverse',
  },
  textMargerRatio: {
    marginBottom: 12,
    alignSelf: 'center',
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,

    fontSize: 16,
  },
  textMargedCompany: {
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

//MF Activity Page

export const mfActivity = StyleSheet.create({
  group: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontSize: 30,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    width: '50%',
  },
  textFii: {
    textAlign: 'center',
    fontSize: 12,
    paddingVertical: 12,

    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 32,
  },
  flatMain: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: 'lightgray',
  },
  textFiiDate: {
    marginTop: 36,
    flex: 3,
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  textEquity: {
    marginTop: 36,
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textDept: {
    marginTop: 36,
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  main2: {
    marginTop: 4,
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textGross: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textGrossP: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  textDebtGross: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  main3: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginTop: 2,
  },

  textGrossSale: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textEGross: {
    marginTop: 2,
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  textDGross: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  main4: {
    marginTop: 2,
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textNet: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textNetEquity: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  textDNet: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  main5: {
    marginTop: 2,
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textCommu: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textECommu: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  textDCumu: {
    paddingHorizontal: 16,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },

  main6: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: 'lightgrey',
  },
  textTdate: {
    marginTop: 36,
    flex: 3,
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textEquity2: {
    marginTop: 36,
    paddingHorizontal: 58,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  main7: {
    marginTop: 4,
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textBuy2: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textItemBuy: {
    paddingHorizontal: 58,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  main8: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginTop: 2,
  },
  textSell: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textItemSell: {
    marginTop: 2,
    paddingHorizontal: 58,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  main9: {
    marginTop: 2,
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  textNet2: {
    flex: 3,
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  textItemNet2: {
    paddingHorizontal: 58,
    flex: 1,
    textAlign: 'right',
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  style3: {
    marginTop: 10,
    borderBottomWidth: 1,
    borderColor: 'lightgrey',
  },
});

//FilterDialog Page

export const filterDialog = StyleSheet.create({
  main: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },

  main2: {
    position: 'absolute',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingVertical: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },

  dialogMain: {width: '100%', height: '100%'},

  dialogMain2: {paddingHorizontal: 16, position: 'relative'},

  headerText: {
    // fontSize: Font.font_title,
    // fontFamily: Cfont.rubik_medium,
    // color: root.color_text,
    ...size_family.rm_30,
    ...color.text,
  },

  closeView: {position: 'absolute', right: 16},

  closeIcon: {height: 24, width: 24, color: 'black'},

  Containt: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
  },

  Containt2: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  Text: {
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    flex: 1,
  },

  DropdownText: {flexDirection: 'row', alignItems: 'center'},

  ExpandIcon: {height: 24, width: 24, color: root.color_text},

  ButtonMain: {
    backgroundColor: root.client_background,
    marginTop: 32,
    marginHorizontal: 16,
    borderRadius: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },

  ButtonText: {
    fontSize: 16,
    color: 'white',
    textAlign: 'center',
    fontFamily: Cfont.rubik_semibold,
    opacity: 1,
  },
});

//Hot PurSuit Dialog

export const HotpurDialog = StyleSheet.create({
  main: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },

  Close: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },

  MainDialog: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    // maxHeight: '74%',
    height: '74%',
    backgroundColor: 'white',
    // paddingHorizontal: 18,
    // paddingVertical: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },

  TimeView: {width: '100%', height: '100%'},

  Time: {
    padding: 20,
    marginTop: 19,
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },

  HeadingView: {paddingHorizontal: 16, paddingVertical: 2},

  Heading: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  Submain: {paddingHorizontal: 16},

  SubHeading: {
    marginTop: 8,
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },

  BackgroundView: {
    marginTop: 16,
    paddingHorizontal: 16,
    paddingVertical: 8,
    backgroundColor: '#F5F7FA',
  },

  View1: {flexDirection: 'row'},

  Dont: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,

    color: root.client_background,
    marginRight: 8,
  },

  round: {
    backgroundColor: '#EC6F32',
    paddingHorizontal: 8,
    borderRadius: 16,
  },

  roundtxt: {fontSize: 14, color: 'white'},

  Stockmain: {flexDirection: 'row', marginTop: 8},

  StockView: {marginRight: 16},

  Exc: {
    marginTop: 8,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 10,
  },
  stock: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
  },
  price: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
  },
  percent: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
  },
  ShowmoreMain: {
    marginTop: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  Show: {
    color: root.client_background,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
  },
  Expand: {
    width: 28,
    height: 16,
    color: root.client_background,
  },
  OtherNews: {
    marginTop: 28,
    paddingHorizontal: 16,
    // paddingVertical: 16,
    fontSize: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  FlatMain: {
    marginHorizontal: 12,
    marginVertical: 16,
    borderRadius: 8,
    backgroundColor: 'white',
    paddingVertical: 8,
    paddingHorizontal: 12,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    width: 250,
    height: 150,
  },

  FlatHeader: {
    fontSize: 14,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginVertical: 16,
    flex: 1,
  },
  FlatDes: {
    fontSize: 12,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  FlatTime: {
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginBottom: 16,
  },
});

//Announcement Component

export const Announce = StyleSheet.create({
  CardBack: {
    position: 'relative',
    paddingHorizontal: 28,
    paddingVertical: 12,
    backgroundColor: 'white',
    marginVertical: 6,
    borderRadius: 8,
  },
  Cap: {color: root.color_text, fontFamily: Cfont.rubik_medium, fontSize: 14},
  Memo: {
    marginTop: 8,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 12,
  },
  date: {
    marginTop: 18,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 10,
  },
  DropDown: {height: 24, width: 24, color: 'black'},
  SectorMain: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'center',
  },
  Exc: {color: root.color_text, fontFamily: Cfont.rubik_regular},

  DropDown1: {position: 'relative', marginLeft: 12},

  ExcSec: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    backgroundColor: '#E6E2E2',
    flexDirection: 'row',
    borderRadius: 4,
    //width: 70,
    marginLeft: 12,
    alignItems: 'center',
    //justifyContent: 'flex-end',
  },
  ExcSelect: {color: root.color_text},
  ExcExpand: {height: 16, width: 14, color: root.color_text, marginLeft: 8},

  ShowMain: {
    position: 'absolute',
    top: 32,
    zIndex: 999,
    backgroundColor: 'white',
    shadowColor: '#000',
    height: 110,
    width: 80,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 4,
  },
  ShowMain1: {paddingHorizontal: 8, paddingVertical: 4},
  ShowExc: {
    marginTop: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },

  SearchMain: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  back: {width: 24, height: 24, color: root.color_text},
});

//News Component Page

export const NewsComp = StyleSheet.create({
  flex: {flex: 1},

  SectorMain: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: 'center',
  },
  Sector: {color: root.color_text, fontFamily: Cfont.rubik_regular},

  SelectMain: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    // marginVertical: 2,
    backgroundColor: '#E6E2E2',
    flexDirection: 'row',
    borderRadius: 4,
    marginLeft: 12,
    alignItems: 'center',
  },

  Select: {color: root.color_text, fontFamily: Cfont.rubik_regular},

  Expand: {height: 16, width: 16, color: root.color_text, marginLeft: 8},

  flatMain: {marginHorizontal: 18, marginVertical: 14},

  FlatHeadingMain: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: 'white',
    marginVertical: 6,
    borderRadius: 8,
  },

  FlatHeading: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 14,
  },

  FlatTime: {
    marginTop: 18,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 10,
  },
});

//News Dialog Page

export const NewsDialog1 = StyleSheet.create({
  Main: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },

  close: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },

  MainView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '26%',
    backgroundColor: 'white',
    // paddingHorizontal: 18,
    // paddingVertical: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  Main1: {width: '100%', height: '100%'},
  main2: {paddingHorizontal: 16, paddingVertical: 16},
  Time: {
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  HaedingView: {paddingHorizontal: 16},
  Heading: {
    fontSize: 18,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  Html: {fontSize: 14, marginTop: 16},
});

//Select Sector

export const SelectSector = StyleSheet.create({
  main: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  close: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  MainView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '59%',
    backgroundColor: 'white',
    // paddingHorizontal: 18,
    // paddingVertical: 16,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  modal: {width: '100%', height: '100%'},

  Choose: {
    padding: 16,
    fontSize: 28,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 18,
  },
});

//Search Market News

export const SearchScreen = StyleSheet.create({
  main: {
    flexDirection: 'row',
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
  },
  padding: {padding: 16},

  close: {height: 24, width: 24, color: 'black'},

  flex: {flex: 1},
});

//View All Page

export const ViewAll1 = StyleSheet.create({
  flex: {flex: 1},

  back: {
    width: 24,
    height: 24,
    color: root.color_text,
    marginLeft: 16,
  },

  FlatMain: {marginHorizontal: 12, marginTop: 18, height: 43},
  main1: {
    borderRadius: 16,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderWidth: 0.5,
    marginLeft: 4,
    borderColor: root.color_text,
  },
});

export const optionChainSkeleton = StyleSheet.create({
  linearGradient: {
    height: 20,
    width: 120,
  },
  topView: {
    alignItems: 'flex-end',
    width: '33%',
  },
  overAllCard: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_10,
  },
  style: {
    backgroundColor: '#ededed',
    ...m.t_10,
  },
  middleView: {
    ...alignment.alignC_justifyC,
    width: '33%',
  },
});

export const squareOffOrders = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
    overflow: 'hidden',
    ...p.h_16,
    ...p.v_10,
  },
  header: {
    ...alignment.row_alingC_SpaceB,
  },
  priceAndPercent: {
    ...alignment.row_alignC,
  },
  titleTxt: {
    ...size_family.rm_15,
    color: root.color_text,
  },
  price: {
    ...size_family.rm_13,
    color: root.color_text,
  },
  change: {
    ...size_family.rr_10,
    color: root.color_text,
    ...p.l_8,
  },
  card: {
    backgroundColor: root.color_active,
    ...m.v_6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 8,
    ...p.h_16,
    ...p.v_10,
    ...m.t_10,
    ...p.b_30,
  },
  symbol: {
    ...alignment.row_alignC,
  },
  qtyContainer: {
    ...alignment.row_alignC,
    ...p.t_5,
  },
  sellTxt: {
    ...size_family.rm_12,
    color: root.color_negative,
  },
  qtyTxt: {
    ...size_family.rl_12,
    color: root.color_text,
  },
  typeTxt: {
    ...size_family.rm_10,
    color: '#25335C',
    backgroundColor: '#9AB3FF33',
    ...p.h_6,
    borderRadius: 30,
    ...p.v_2,
    ...m.m_l_6,
  },
  validityTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  validityValue: {
    ...size_family.rr_14,
    color: root.color_text,
  },
  nseTxt: {
    ...size_family.rm_8,
    ...m.m_l_5,
    backgroundColor: root.backgroung_exchange_chip_color,
    ...p.h_3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
  },
  sellBtn: {
    ...size_family.rm_12,
    color: root.color_active,
    backgroundColor: root.color_negative,
    height: 24,
    width: 40,
    ...textAlign.center,
    borderRadius: 15,
    alignSelf: 'flex-end',
  },
  typeTitle: {
    ...size_family.rm_12,
    ...p.v_7,
    ...p.h_10,
  },
  squareOffBtn: {
    position: 'absolute',
    bottom: 30,
    left: 16,
    right: 16,
    ...alignment.alignC_justifyC,
    backgroundColor: root.client_background,
    height: 40,
    borderRadius: 10,
  },
  squareOffTxt: {
    ...size_family.rm_16,
    color: root.color_active,
  },
  topView: {
    ...alignment.row_SpaceB,
  },
  breakDownView: {
    ...alignment.row,
  },
  detailsContainer: {
    ...p.l_10,
  },
  navigationContainer: {
    ...alignment.row_SpaceB,
    borderWidth: 1,
    borderRadius: 4,
    borderColor: root.client_background,
    ...m.t_16,
  },
});

export const limit = StyleSheet.create({
  txtIp: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 24,
    color: root.color_text,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
    width: 120,
  },
  tickTxt: {
    textAlignVertical: 'center',
    ...p.l_16,
    ...size_family.rm_12,
    color: root.color_text,
  },
  rangeTxt: {
    ...size_family.rl_11,
    color: root.color_text,
    ...p.l_5,
  },
  rangeValue: {
    ...size_family.rm_11,
    color: root.color_text,
  },
  qtyTxt: {
    ...p.t_18,
    ...size_family.rr_14,
    color: root.color_text,
  },
  validityTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  validityValue: {
    ...size_family.rr_14,
    color: root.color_text,
  },
  btnContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_32,
  },
  btnTxtModify: {
    ...size_family.rm_16,
    color: root.color_active,
    backgroundColor: root.client_background,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
  },
  btnTxtCancel: {
    ...size_family.rm_16,
    color: root.client_background,
    backgroundColor: root.color_active,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  tooltip: {
    color: root.color_active,
    ...size_family.rr_9,
  },
  toolkitView: {
    height: 38,
    width: 200,
    backgroundColor: root.color_text,
    borderRadius: 7,
  },
  toolTipContainer: {
    ...alignment.row_alignC,
    ...p.t_5,
  },
  txtIpMainContainer: {
    ...alignment.row_alingC_SpaceB,
  },
  validityContainer: {
    ...alignment.row_alignC,
  },
});

export const marginPrice = StyleSheet.create({
  qtyTxt: {
    ...p.t_16,
    ...size_family.rr_14,
    color: root.color_text,
  },
  txtIp: {
    ...size_family.rr_24,
    color: root.color_text,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
  },
  validityTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  validityValue: {
    ...size_family.rr_14,
    color: root.color_text,
  },
  btnContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_32,
  },
  btnTxtModify: {
    ...size_family.rm_16,
    color: root.color_active,
    backgroundColor: root.client_background,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
  },
  btnTxtCancel: {
    ...size_family.rm_16,
    color: root.client_background,
    backgroundColor: root.color_active,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  priceTypeTxt: {
    ...size_family.rm_16,
    color: root.color_text,
  },
  priceTxt: {
    ...m.t_12,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  txtIpMainContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_5,
  },
  validityContainer: {
    ...alignment.row_alignC,
  },
});

export const slLimit = StyleSheet.create({
  txtIp: {
    ...size_family.rr_24,
    color: root.color_text,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
    width: 140,
  },
  tickTxt: {
    textAlignVertical: 'center',
    ...p.l_16,
    ...size_family.rm_12,
    color: root.color_text,
  },
  rangeTxt: {
    ...size_family.rl_11,
    color: root.color_text,
    ...p.t_3,
  },
  rangeValue: {
    ...size_family.rm_11,
    color: root.color_text,
  },
  qtyTxt: {
    ...p.t_16,
    ...size_family.rr_14,
    color: root.color_text,
  },
  validityTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  validityValue: {
    ...size_family.rr_14,
    color: root.color_text,
  },
  btnContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_32,
  },
  btnTxtModify: {
    ...size_family.rm_16,
    color: root.color_active,
    backgroundColor: root.client_background,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
  },
  btnTxtCancel: {
    ...size_family.rm_16,
    color: root.client_background,
    backgroundColor: root.color_active,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  triggerTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  tickValue: {
    ...size_family.rm_12,
    color: root.color_text,
  },
  sell: {
    ...size_family.rl_12,
    color: root.color_text,
  },
  triggerLimitContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_5,
  },
  validityContainer: {
    ...alignment.row_alignC,
  },
});

export const slMarket = StyleSheet.create({
  txtIp: {
    ...size_family.rr_24,
    color: root.color_text,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
    width: 140,
  },
  tickTxt: {
    textAlignVertical: 'center',
    ...p.l_16,
    ...size_family.rm_12,
    color: root.color_text,
  },
  rangeTxt: {
    ...size_family.rl_11,
    color: root.color_text,
    ...p.t_3,
  },
  rangeValue: {
    ...size_family.rm_11,
    color: root.color_text,
  },
  qtyTxt: {
    ...p.t_16,
    ...size_family.rr_14,
    color: root.color_text,
  },
  validityTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  validityValue: {
    ...size_family.rr_14,
    color: root.color_text,
  },
  btnContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_32,
  },
  btnTxtModify: {
    ...size_family.rm_16,
    color: root.color_active,
    backgroundColor: root.client_background,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
  },
  btnTxtCancel: {
    ...size_family.rm_16,
    color: root.client_background,
    backgroundColor: root.color_active,
    ...p.h_42,
    ...p.v_11,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  triggerTxt: {
    ...size_family.rm_14,
    color: root.color_text,
  },
  tickValue: {
    ...size_family.rm_12,
    color: root.color_text,
  },
  sell: {
    ...size_family.rl_12,
    color: root.color_text,
  },
  triggerContainer: {
    ...alignment.row,
  },
  txtIpMainContainer: {
    ...alignment.row_alingC_SpaceB,
    ...p.t_5,
  },
  validityContainer: {
    ...alignment.row_alignC,
  },
});

export const NoMatch = StyleSheet.create({
  Main: {backgroundColor: 'white', flex: 1},
  Main1: {alignItems: 'center', justifyContent: 'center', flex: 1},
  Image: {height: 90, width: 90},
  textNo: {fontSize: 16, fontFamily: Cfont.rubik_regular, marginTop: 26},
  textTry: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 70,
    textAlign: 'center',
    marginTop: 6,
  },
  Main2: {backgroundColor: 'lightgrey', flex: 1},
});

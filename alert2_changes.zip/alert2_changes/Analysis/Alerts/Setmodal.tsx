import React, { useState } from 'react';
import {ScrollView, TouchableNativeFeedback} from 'react-native';
import { TextInput } from 'react-native';
import {Touchable} from 'react-native';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import {companymodaldata} from '../../../../assets/demoData';
import CommonModal from '../../../../components/CommonModal/CommonModal';

import {Cfont, root} from '../../../../styles/colors';
import {
  Companymodalstyle,
  Eventmodaistyle,
  Eventstylecom,
  Setalertstyle,
} from '../../../../theme/light';
import BuySellButton from '../../../Portfolio/Holding/component/BuySellButton';

export const Setmodal = (props: any) => {
  const [operation, setOperation] = useState<string>('BUY');
  const [selectedTab, setSelectedTab] = useState<string>('MARGIN');


  // console.log(props?.data,"New data importedmow====>");

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>
      <Text style={Setalertstyle.modaltitle}>Set Price Alert</Text>
      <View style={Setalertstyle.mainnew}>
        <View style={Setalertstyle.innertitleconatiner}>
          <Text style={Setalertstyle.companytxt}>
            {props?.data?.companyName}
          </Text>
          <Text style={Setalertstyle.nsetxt}>NSE</Text>
        </View>
        <View style={Setalertstyle.innertitleconatiner}>
          <Text style={Setalertstyle.futtxt}>{props?.data?.date?.day}</Text>
          <Text style={Setalertstyle.futtxt}>{props?.data?.date?.value}</Text>
        </View>
        <Text style={Setalertstyle.valuetxtx}>{props?.data?.value}</Text>
      </View>
      <View style={Setalertstyle.conatinertwo}>
        <Text style={Setalertstyle.pricealerttxt}>
          Alert me when the price goes
        </Text>

        <View>
              <View
                style={{
                  flexDirection: 'row',
                  borderWidth: 1,
                  width:92,
                  borderColor: 'lightgrey',
                  borderRadius: 16,
                  opacity: selectedTab == 'SIP_ORDER' ? 0.5 : 1,
                }}>
                <View style={{borderRadius: 15, overflow: 'hidden'}}>
                  <TouchableNativeFeedback
                    disabled={selectedTab == 'SIP_ORDER'}
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      // navigation.goBack();
                      setOperation('BUY');
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 12,
                          backgroundColor:
                            operation == 'BUY'
                              ? root.color_positive
                              : 'transparent',
                          borderRadius: 16,
                          color: operation == 'BUY' ? 'white' : root.color_text,
                        }}>
                        BUY
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>

                <View
                  style={{
                    borderRadius: 15,
                    overflow: 'hidden',
                  }}>
                  <TouchableNativeFeedback
                    disabled={selectedTab == 'SIP_ORDER'}
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setOperation('SELL');
                      // navigation.goBack();
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 8,
                          borderRadius: 16,
                          backgroundColor:
                            operation == 'SELL'
                              ? root.color_negative
                              : 'transparent',
                          color:
                            operation == 'SELL' ? 'white' : root.color_text,
                        }}>
                        SELL
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>
              </View>
            </View>
        
            
        
        <Text style={Setalertstyle.pricealerttxt}>Set Price</Text>
      </View>
      <Text style={Setalertstyle.setprice}>Enter Price</Text>
      <TextInput style={Setalertstyle.textinput} placeholder="0"/>
      <View style={Setalertstyle.bottomsetalert}>
        <TouchableOpacity style={Setalertstyle.conatiner} >
            <Text style={Setalertstyle.settxt}>Set Alert</Text>
        </TouchableOpacity>


      </View>
    </CommonModal>
  );
};

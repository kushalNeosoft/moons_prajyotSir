import React, {useState} from 'react';
import {ScrollView, Text, TouchableOpacity, View} from 'react-native';
import {Analysisstyle} from '../../../theme/light';
import Technicals from './Charts/Technicals';
import Fundamentals from './Charts/Fundamentals';

const Analysis: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [selectedIndex, setSelectedIndex] = useState(0);

  return (
    <ScrollView
      style={Analysisstyle({selectedIndex}).maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Analysisstyle({selectedIndex}).switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).todaysView}>
          <Text style={Analysisstyle({selectedIndex}).todayText}>
            Technicals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).overallView}>
          <Text style={Analysisstyle({selectedIndex}).overallText}>
            Fundamentals
          </Text>
        </TouchableOpacity>
      </View>
      {selectedIndex === 0 ? (
        <>
          <Technicals />
        </>
      ) : selectedIndex === 1 ? (
        <>
          <Fundamentals />
        </>
      ) : null}
    </ScrollView>
  );
};

export default Analysis;

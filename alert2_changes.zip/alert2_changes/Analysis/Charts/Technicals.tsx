import { useNavigation } from '@react-navigation/native';
import React, {useState} from 'react';
import {
  Dimensions,
  FlatList,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import {
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryTheme,
} from 'victory-native';
import { colordata, colordatatwo, MovingAveragesdata, OIdata, Puttdata, s1datar1 } from '../../../../assets/demoData';
import { root } from '../../../../styles/colors';
import { Analysisstyle, CompanyStyle } from '../../../../theme/light';

const Technicals=()=>{
  const navigation =useNavigation()
    // const setScrollValue = route.params.setScrollValue;
    const [selectedIndex, setSelectedIndex] = useState(0);
    const [selectedItem, setSelectedItem] = useState(0);
  
    const [selectedItemoi, setSelectedItemoi] = useState(0);
  
    const [selectedname, setSelectedName] = useState('Price');
    const [showFullTextnew, setShowFullTextnew] = useState(false);

    const toggleTextDisplaynew = () => {
      setShowFullTextnew(!showFullTextnew);
    };

    const data = [
        {year: '30 Day Avg', earnings: 19000, expenditure: 12000},
        {year: '5 Day Avg', earnings: 14250, expenditure: 8000},
        {year: 'Yesterday', earnings: 17506, expenditure: 10000},
        {year: 'Today', earnings: 5000, expenditure: 13000},
      ];

      const renderItem = ({item, index}: any) => (
        <TouchableOpacity
          onPress={() => {
            setSelectedItem(index);
            setSelectedName(item?.title);
          }}>
          {selectedItem === index ? (
            <>
              <View style={Analysisstyle({selectedIndex}).menuitem}>
                <Text style={Analysisstyle({selectedIndex}).titletxt}>
                  {item.title}
                </Text>
              </View>
            </>
          ) : (
            <>
              <View style={Analysisstyle({selectedIndex}).menuitemtwo}>
                <Text style={Analysisstyle({selectedIndex}).titletxttwo}>
                  {item.title}
                </Text>
              </View>
            </>
          )}
        </TouchableOpacity>
      );

      const renderItemOI = ({item, index}: any) => (
        <TouchableOpacity
          onPress={() => {
            setSelectedItemoi(index);
           
          }}>
          {selectedItemoi === index ? (
            <>
              <View style={Analysisstyle({selectedIndex}).menuitemthree}>
                <Text style={Analysisstyle({selectedIndex}).titletxt}>
                  {item.title}
                </Text>
              </View>
            </>
          ) : (
            <>
              <View style={Analysisstyle({selectedIndex}).menuitemfour}>
                <Text style={Analysisstyle({selectedIndex}).titletxttwo}>
                  {item.title}
                </Text>
              </View>
            </>
          )}
        </TouchableOpacity>
      );



    return(
        <>
        
        <View style={[Analysisstyle({selectedIndex}).containerone]}>
          <View style={Analysisstyle({selectedIndex}).containertwo}>
            <Text style={Analysisstyle({selectedIndex}).txtstyle}>
              Charts
            </Text>
            <TouchableOpacity style={Analysisstyle({selectedIndex}).iconcon} onPress={() => navigation.navigate('Webchart')}>
              <SimpleLineIcons
                name="frame"
                size={15}
                color={root.color_active}
              />
            </TouchableOpacity>
          </View>
        </View>
        <View>
          <VictoryChart theme={VictoryTheme.material} width={380}>
            <VictoryAxis />
            <VictoryAxis dependentAxis orientation="right" />
            <VictoryLine
              animate={{
                onLoad: {duration: 1000},
                duration: 1000,
                easing: 'circle',
              }}
              interpolation="natural"
              style={{
                data: {stroke: '#c43a31'},
                parent: {border: '1px solid #ccc'},
              }}
              data={[
                {x: 1, y: 2},
                {x: 2, y: 3},
                {x: 3, y: 5},
                {x: 4, y: 4},
                {x: 5, y: 7},
              ]}
            />
          </VictoryChart>
        </View>
        <View style={Analysisstyle({selectedIndex}).supportcon}>
          <Text style={Analysisstyle({selectedIndex}).txtstyle}>
            Support & Resistance
          </Text>
        </View>
        <View style={Analysisstyle({selectedIndex}).suppcontainer}>
          <View style={Analysisstyle({selectedIndex}).suppallign}>
            <Text style={Analysisstyle({}).suprestxt}>Support</Text>
          </View>
          <View style={Analysisstyle({selectedIndex}).suppallign}>
            <Text style={Analysisstyle({}).suprestxt}>Resistance</Text>
          </View>
        </View>
        <View style={Analysisstyle({selectedIndex}).suppresdata}>
          <View style={Analysisstyle({}).suprescondata}>
            {s1datar1.map(item => {
              return (
                <View style={Analysisstyle({}).listone}>
                  <Text style={Analysisstyle({}).suprestxt}>{item.s}</Text>
                  <Text style={Analysisstyle({}).suprestxts1}>
                    {item.values1}
                  </Text>
                </View>
              );
            })}
          </View>
          <View style={Analysisstyle({}).pivoitcon}>
            <Text style={Analysisstyle({}).pvoitxt}>Pivot</Text>
            <Text style={Analysisstyle({}).pvoitxt}>0.0000</Text>
          </View>
          <View style={Analysisstyle({}).suprescondata}>
            {s1datar1.map(item => {
              return (
                <View style={Analysisstyle({}).listone}>
                  <Text style={Analysisstyle({}).suprestxt}>{item.r}</Text>
                  <Text style={Analysisstyle({}).suprestxts2}>
                    {item.valuer1}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
        {/* Moving Averages */}
        <View style={Analysisstyle({selectedIndex}).supportcon}>
          <Text style={Analysisstyle({selectedIndex}).txtstyle}>
            Moving Averages
          </Text>
        </View>

        <View style={Analysisstyle({}).Movecontainer}>
          <View style={Analysisstyle({}).Movecontainerone}>
            <Text style={Analysisstyle({}).suprestxt}>Averages</Text>
          </View>
          <View style={Analysisstyle({}).Movecontainertwo}>
            <Text style={Analysisstyle({}).suprestxt}>NSE</Text>
          </View>
          <View style={Analysisstyle({}).Movecontainerthree}>
            <Text style={Analysisstyle({}).suprestxt}>BSE</Text>
          </View>
        </View>

        {MovingAveragesdata.map(item => {
          return (
            <View style={Analysisstyle({}).moviingcon}>
              <Text style={Analysisstyle({}).moviingconone}>{item.days}</Text>
              <Text style={Analysisstyle({}).moviingcontwo}>
                {item.valueone}
              </Text>
              <Text style={Analysisstyle({}).moviingconthree}>
                {item.valuetwo}
              </Text>
            </View>
          );
        })}

        {/* Putt call ratio */}
        <View style={Analysisstyle({selectedIndex}).supportcon}>
          <Text style={Analysisstyle({selectedIndex}).txtstyle}>
            Put Call Ratio
          </Text>
        </View>

        <ScrollView
          horizontal
          key={2}
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}>
          <FlatList
            data={Puttdata}
            renderItem={renderItem}
            keyExtractor={(item, index) => index.toString()}
            horizontal
            nestedScrollEnabled
            showsHorizontalScrollIndicator={false}
          />
        </ScrollView>
        {Puttdata.map((events, i) => {
          if (selectedItem == i) {
            return (
              <>
                <View style={Analysisstyle({}).putcontainer}>
                  <View style={Analysisstyle({}).puttransform}>
                    <Text style={Analysisstyle({}).titleput}>
                      {selectedname}
                    </Text>
                  </View>
                  <View style={{marginLeft: -12}}>
                    <VictoryChart
                      width={Dimensions.get('window').width * 0.92}
                      height={230}
                      domainPadding={{x: 10, y: 10}}>
                      <VictoryAxis
                        tickLabelComponent={
                          <VictoryLabel
                            angle={-50}
                            textAnchor="end"
                            style={{fontSize: 10}}
                          />
                        }
                        style={{axis: {strokeWidth: 0}}}
                      />
                      <VictoryAxis
                        dependentAxis
                        standalone={false}
                        style={{axis: {strokeWidth: 0}}}
                        tickLabelComponent={
                          <VictoryLabel
                            textAnchor="end"
                            verticalAnchor="middle"
                            style={{fontSize: 10}}
                          />
                        }
                      />

                      <VictoryGroup
                        offset={15}
                        colorScale={['#464983', '#6FA9E2']}>
                        <VictoryBar
                          alignment="start"
                          barWidth={10}
                          data={events.data}
                          x="x"
                          y="earnings"
                          animate={{
                            onLoad: {duration: 1000},
                            duration: 1000,
                          }}
                        />
                        <VictoryBar
                          data={events.data}
                          barWidth={10}
                          x="x"
                          y="expenditure"
                          animate={{
                            onLoad: {duration: 1000},
                            duration: 1000,
                          }}
                        />
                      </VictoryGroup>
                    </VictoryChart>
                  </View>
                </View>
                <Text style={Analysisstyle({}).striktxt}>Strike Price</Text>
                <View style={Analysisstyle({}).indicatorcontainer}>
                  {colordata.map(item => {
                    return (
                      <View style={Analysisstyle({}).collorallign}>
                        <View
                          style={[
                            Analysisstyle({}).colorindicator,
                            {backgroundColor: item.color},
                          ]}
                        />
                        <Text style={Analysisstyle({}).colortxtx}>
                          {item.title}
                        </Text>
                      </View>
                    );
                  })}
                </View>
              </>
            );
          }
        })}
        {/* OI Bulldup */}
        <View style={Analysisstyle({selectedIndex}).supportcon}>
          <Text style={Analysisstyle({selectedIndex}).txtstyle}>
            OI Bulldup
          </Text>
        </View>

        <ScrollView
          horizontal
          key={2}
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}>
          <FlatList
            data={OIdata}
            renderItem={renderItemOI}
            keyExtractor={(item, index) => index.toString()}
            horizontal
            nestedScrollEnabled
            showsHorizontalScrollIndicator={false}
          />
        </ScrollView>

        <View
          style={Analysisstyle({}).OUcontainer}>
          <Text
            style={Analysisstyle({}).Ouheader}>
            Time
          </Text>
          <Text
            style={[Analysisstyle({}).Ouheader,{textAlign:'right',flex:1}]}>
            29 JUN '23
          </Text>
          <Text
             style={[Analysisstyle({}).Ouheader,{textAlign:'right',flex:1}]}>
            27 JUN '23
          </Text>
          <Text
             style={[Analysisstyle({}).Ouheader,{textAlign:'right',flex:1}]}>
            31 AUG '23
          </Text>
        </View>
        <ScrollView style={{maxHeight:showFullTextnew?null:100}} scrollEnabled={false}>

        {OIdata.map((events, i) => {
          if (selectedItemoi == i) {
            return (
              <>
                {events.data.map(item => {
                  return (
                    <View
                      style={Analysisstyle({}).Outitle}>
                      <Text
                        style={Analysisstyle({}).outitleone}>
                        {item.time}
                      </Text>
                      <Text
                        style={Analysisstyle({}).outitlethree}>
                        {item.t1}
                      </Text>
                      <Text
                       style={Analysisstyle({}).outitlethree}>
                        {item.t2}
                      </Text>
                      <Text
                        style={Analysisstyle({}).outitlethree}>
                        {item.t3}
                      </Text>
                    </View>
                  );
                })}
              </>
            );
          }
        })}
        </ScrollView>

        <TouchableOpacity
            onPress={toggleTextDisplaynew}
            style={Analysisstyle({}).showcom}>
            <Text style={Analysisstyle({}).showtxt}>
              {showFullTextnew ?  'Show More':'Show Less' }
            </Text>
           
          </TouchableOpacity>

        {/* Delivery quantity build up */}
        <View style={Analysisstyle({selectedIndex}).supportcon}>
          <Text style={Analysisstyle({selectedIndex}).txtstyle}>
            Dellvery Quantity Buildup
          </Text>
        </View>
        <View style={{marginLeft: 10}}>
          <VictoryChart
            width={330}
            height={150}
            horizontal
            padding={{left: 60, right: 0, top: 0, bottom: 0}}>
            <VictoryAxis
              tickFormat={tick => tick}
              style={{axis: {strokeWidth: 0}}}
              tickLabelComponent={
                <VictoryLabel
                  textAnchor="end"
                  verticalAnchor="middle"
                  style={{fontSize: 10}}
                />
              }
            />
            <VictoryGroup offset={12} colorScale={['#464983', '#6FA9E2']}>
              <VictoryBar
                data={data}
                barWidth={10}
                x="year"
                y="earnings"
                labels={({datum}) => `${datum.earnings} Lac`}
              />
              <VictoryBar
                data={data}
                barWidth={10}
                x="year"
                y="expenditure"
                labels={({datum}) => `${datum.expenditure} Lac`}
              />
            </VictoryGroup>
          </VictoryChart>
        </View>
        <View style={Analysisstyle({selectedIndex}).Deliveryconatiner}>
          {colordatatwo.map(item => {
            return (
              <View style={Analysisstyle({}).collorallign}>
                <View
                  style={[
                    Analysisstyle({}).colorindicator,
                    {backgroundColor: item.color},
                  ]}
                />
                <Text style={Analysisstyle({}).colortxtx}>{item.title}</Text>
              </View>
            );
          })}
        </View>
        <View style={{height: 20, width: '100%'}} />
        </>
       
      
        

    )
}

export default Technicals;
import { StyleSheet } from 'react-native';
import {Cfont, root, Font} from '../styles/colors';

 const font = {
  size_9: {
    fontSize: 9,
  },
  size_10: {
    fontSize: 10,
  },
  size_11: {
    fontSize: 11,
  },
  size_12: {
    fontSize: 12,
  },
  size_13: {
    fontSize: 13,
  },
  size_14: {
    fontSize: 14,
  },
  size_15: {
    fontSize: 15,
  },
  size_16: {
    fontSize: 16,
  },
  size_17: {
    fontSize: 17,
  },
  size_18: {
    fontSize: 18,
  },
  size_19: {
    fontSize: 19,
  },
  size_20: {
    fontSize: 20,
  },
  size_21: {
    fontSize: 21,
  },
  size_22: {
    fontSize: 22,
  },
  size_23: {
    fontSize: 23,
  },
  size_24: {
    fontSize: 24,
  },
  size_25: {
    fontSize: 25,
  },
  size_26: {
    fontSize: 26,
  },
  size_27: {
    fontSize: 27,
  },
  size_28: {
    fontSize: 28,
  },
  size_29: {
    fontSize: 29,
  },
  size_30: {
    fontSize: 30,
  },
};

  const fontFamily = {
  rubic_medium: {
    fontFamily: Cfont.rubik_medium,
  },
  rubic_regular: {
    fontFamily: Cfont.rubik_regular,
  },
  rubic_light: {
    fontFamily: Cfont.rubik_light,
  },
  rubic_bold: {
    fontFamily: Cfont.rubik_bold,
  },
  rubic_black: {
    fontFamily: Cfont.rubik_black,
  },
  rubic_extrabold: {
    fontFamily: Cfont.rubik_extrabold,
  },
  rubic_semibold: {
    fontFamily: Cfont.rubik_semibold,
  },
};

 const color = {
  text: {
    color: root.color_text,
  },
  subtext: {
    color: root.color_subtext,
  },
  positive: {
    color: root.color_positive,
  },
  active: {
    color: root.color_active,
  },
  client_background:{
    color:root.client_background
  }
};

 const padding = {
  l_25: {
    paddingLeft: 25,
  },
  h_3: {
    paddingHorizontal: 3,
  },
  l_5: {
    paddingLeft: 5,
  },
  h_6: {
    paddingHorizontal: 6,
  },
  h_8: {
    paddingHorizontal: 8,
  },
  v_2: {
    paddingVertical: 2,
  },
  t_3: {
    paddingTop: 3,
  },
  t_8: {
    paddingTop: 8,
  },
  h_7: {
    paddingHorizontal: 7,
  },
  h_16:{
    paddingHorizontal:16
  },
  t_20:{
    paddingTop: 20,
  }
};

 const backgroundColor = {
  backgroung_exchange_chip_color: {
    backgroundColor: root.backgroung_exchange_chip_color,
  },
  chip_background_positive_cotrast: {
    backgroundColor: root.chip_background_positive_cotrast,
  },
  color_negative: {
    backgroundColor: root.color_negative,
  },
  color_active:{
    backgroundColor:root.color_active
  },
  client_background:{
    backgroundColor:root.client_background
  },
  color_positive:{
    backgroundColor:root.color_positive
  }
};

 export const textAlign = StyleSheet.create({
  center: {
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});

 const margin = {
  m_l_5: {
    marginLeft: 5,
  },
};

 const borderRadius = {
  5: {
    borderRadius: 5,
  },
  10: {
    borderRadius: 10,
  },
  15: {
    borderRadius: 15,
  },
  20: {
    borderRadius: 20,
  },
};

 const font_size_family = {
  rm_9: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 9,
  },
  rm_10: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 10,
  },
  rm_11: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 11,
  },
  rm_12: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  rm_14: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
  },
  rm_16: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
  },
  rm_18: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
  },
  rm_20: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 20,
  },
  rm_30: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 30,
  },
  rr_9: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 9,
  },
  rr_10: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 10,
  },
  rr_11: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 11,
  },
  rr_12: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
  },
  rr_13: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 13,
  },
  rr_14: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 14,
  },
  rr_16: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 16,
  },
  rr_18: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
  },
  rr_20: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 20,
  },
  rr_30: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 30,
  },
  rl_9: {
    fontFamily: Cfont.rubik_light,
    fontSize: 9,
  },
  rl_10: {
    fontFamily: Cfont.rubik_light,
    fontSize: 10,
  },
  rl_11: {
    fontFamily: Cfont.rubik_light,
    fontSize: 11,
  },
  rl_12: {
    fontFamily: Cfont.rubik_light,
    fontSize: 12,
  },
  rl_13: {
    fontFamily: Cfont.rubik_light,
    fontSize: 13,
  },
  rl_14: {
    fontFamily: Cfont.rubik_light,
    fontSize: 14,
  },
  rl_16: {
    fontFamily: Cfont.rubik_light,
    fontSize: 16,
  },
  rl_18: {
    fontFamily: Cfont.rubik_light,
    fontSize: 18,
  },
  rl_20: {
    fontFamily: Cfont.rubik_light,
    fontSize: 20,
  },
  rl_30: {
    fontFamily: Cfont.rubik_light,
    fontSize: 30,
  },
};


export default {font,fontFamily,color,backgroundColor,font_size_family,padding}

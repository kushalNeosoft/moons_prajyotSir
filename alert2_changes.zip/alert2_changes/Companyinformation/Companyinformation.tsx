import React, {useState} from 'react';
import {FlatList, ScrollView, Text, TouchableOpacity, View} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {useDispatch} from 'react-redux';
import ReadMore from 'react-native-read-more-text';
import {
  Bookclosure,
  CompanyData,
  Contactdata,
  Listingdata,
  Management,
  PartofIndices,
  SecurityDetail,
} from '../../../assets/demoData';
import {root} from '../../../styles/colors';
import {CompanyStyle} from '../../../theme/light';
import {Companymodal} from './CompanyinformationModal/Companymodal';
import {GestureResponderEvent} from 'react-native';
import Showmoretext from '../../../components/Showmoretext/Showmoretext';

const Companyinformation: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);
  const [managemodalvisible, setManagemodalvisible] = useState(false);
  const [comapanydata, setCompanydata] = useState([]);

  const [showFullText, setShowFullText] = useState(false);
  const [showFullTextnew, setShowFullTextnew] = useState(false);

  const text =
    'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.';

  const toggleTextDisplay = () => {
    setShowFullText(!showFullText);
  };

  const toggleTextDisplaynew = () => {
    setShowFullTextnew(!showFullTextnew);
  };

  const _renderTruncatedFooter = (
    handlePress: ((event: GestureResponderEvent) => void) | undefined,
  ) => {
    return (
      <TouchableOpacity onPress={handlePress}>
        <Text style={{color: 'red', marginTop: 5, fontSize: 15}}>
          Read more
        </Text>
      </TouchableOpacity>
    );
  };

  const _renderRevealedFooter = (
    handlePress: ((event: GestureResponderEvent) => void) | undefined,
  ) => {
    return (
      <Text
        style={{color: 'black', marginTop: 5, fontSize: 15}}
        onPress={handlePress}>
        Show less
      </Text>
    );
  };

  const _handleTextReady = () => {};

  const onNewsModalClose = () => {
    setManagemodalvisible(prevState => !prevState);
  };

  const renderItem = ({item, index}: any) => (
    <TouchableOpacity onPress={() => setSelectedItem(index)}>
      {selectedItem === index ? (
        <>
          <View style={CompanyStyle.menuitem}>
            <Text style={CompanyStyle.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={CompanyStyle.menuitemtwo}>
            <Text style={CompanyStyle.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  return (
    <ScrollView
      style={CompanyStyle.maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={CompanyStyle.Startcon}>
        {CompanyData.map(item => {
          return (
            <View style={CompanyStyle.listone}>
              <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
              <Text style={CompanyStyle.txtstyle}>{item.Value}</Text>
            </View>
          );
        })}
      </View>
      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Security Details</Text>
      </View>
      {SecurityDetail.map(item => {
        return (
          <View style={CompanyStyle.listone}>
            <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
            <Text style={CompanyStyle.txtstyle}>{item.Value}</Text>
          </View>
        );
      })}

      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Book Closure/Record Data</Text>
      </View>
      {Bookclosure.map(item => {
        return (
          <View style={CompanyStyle.listone}>
            <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
            <Text style={CompanyStyle.txtstyle}>{item.Value}</Text>
          </View>
        );
      })}
      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Company Info</Text>
      </View>
      
      <View style={{flexWrap: 'wrap', flexDirection: 'row'}}>
        <Text
          style={{textAlign: 'justify'}}
          numberOfLines={showFullText ? undefined : 4}
          ellipsizeMode="tail">
          {text}
        </Text>
        {text.length > 3 && (
          <TouchableOpacity
            onPress={toggleTextDisplay}
            style={CompanyStyle.allred}>
            <Text style={CompanyStyle.redtxt}>
              {showFullText ? 'Read Less' : 'Read More'}{' '}
            </Text>
            <Entypo
              name="chevron-small-right"
              size={20}
              color={root.client_background}
            />
          </TouchableOpacity>
        )}
      </View>


      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Management</Text>
      </View>

      {Management.map(item => {
        return (
          <TouchableOpacity
            onPress={() => {
              setManagemodalvisible(true);
              setCompanydata(item);
            }}>
            <View style={CompanyStyle.listmanage}>
              <View style={CompanyStyle.innermanage}>
                <Text style={CompanyStyle.txtstylemange}>{item.title}</Text>
                <Text style={CompanyStyle.txtstylemagetwo}>{item.value}</Text>
              </View>
              <Entypo
                name="chevron-small-right"
                size={20}
                color={root.client_background}
              />
            </View>
          </TouchableOpacity>
        );
      })}

      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Listing</Text>
      </View>
      {Listingdata.map(item => {
        return (
          <View style={CompanyStyle.listone}>
            <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
            <Text style={CompanyStyle.txtstyle}>{item.value}</Text>
          </View>
        );
      })}
      <Text style={CompanyStyle.txtstyle}>Part of Indices</Text>
      <View style={{flexDirection: 'row', flexWrap: 'wrap'}}>
        {PartofIndices.map(item => {
          return (
            <View style={CompanyStyle.partconatiner}>
              <Text style={CompanyStyle.txtstyleindes}>{item.title}</Text>
            </View>
          );
        })}
      </View>

      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Contact Information</Text>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Contactdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>
      <View style={{flex: 1}}>
        {Contactdata.map((events, i) => {
          if (selectedItem == i) {
            return (
              <FlatList
                scrollEnabled={false}
                showsHorizontalScrollIndicator={false}
                data={events.data}
                horizontal
                nestedScrollEnabled
                renderItem={({item}) => {
                  return (
                    <>
                      <View>
                        {item.RegName == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Register Name
                            </Text>
                            {item.RegName == '' ? (
                              <Text style={CompanyStyle.detaistxt}>-</Text>
                            ) : (
                              <Text style={CompanyStyle.detaistxt}>
                                {item.RegName}
                              </Text>
                            )}
                          </View>
                        )}
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Address</Text>
                          {item.addvalue == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.addvalue}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>
                            Telephone
                          </Text>
                          {item.telephone == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.telephone}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Fax</Text>
                          {item.fax == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.fax}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Email</Text>
                          {item.email == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.email}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Website</Text>
                          {item.website == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.website}
                            </Text>
                          )}
                        </View>
                        {item.author == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Author
                            </Text>
                            {item.author == '' ? (
                              <Text style={CompanyStyle.detaistxt}>-</Text>
                            ) : (
                              <Text style={CompanyStyle.detaistxt}>
                                {item.author}
                              </Text>
                            )}
                          </View>
                        )}
                      </View>
                    </>
                  );
                }}
              />
            );
          }
        })}
      </View>

      <Companymodal
        visible={managemodalvisible}
        onClose={onNewsModalClose}
        companydata={comapanydata}
      />
    </ScrollView>
  );
};

export default Companyinformation;

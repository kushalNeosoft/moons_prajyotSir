import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Modal,
  Dimensions,
  TouchableOpacity,
  Animated,
  Easing,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Scriptviewstyle } from '../../theme/light';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { root } from '../../styles/colors';
import Scriptviewtab from '../../navigators/ScriptviewtabNavigation';
import { styles } from '../../navigators/Curverbottom';
import NorModal from './WatchListComponent/WatchlistDrawer/WatchlistDrawer';

const Scriptviewdetail = () => {
  const route = useRoute();
  const detail = route.params?.detail;
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  const [visible, setVisible] = useState(false);
  const [value, setValue] = useState('BSE');
  const [show, setShow] = useState(false);
  const [pickoption, setPickoption] = useState('');
  const [norModalVisible, setNorModalVisible] = useState(false);
  const [isvisible, setIsvisible] = useState(false);

  const onNorClose = () => {
    setNorModalVisible(prevState => !prevState);
    // setIsvisible(prevState => !prevState)
  };

  const option = ['NSE', 'BSE'];
  const menu = ['View Chart', 'Add to Watchlist', 'Alert'];

  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      setShow(false);
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [180, 58],
    extrapolate: 'clamp',
  });
  const navigation = useNavigation();

  const navtoScreen = (item: any) => {
    if (item == 'View Chart') {
      navigation.navigate('Screen3');
    } else if (item == 'Alert') {
      navigation.navigate('Screen3');
      console.log('Iam alert');
    } else {
      console.log('open Modal');
      setNorModalVisible(true);
      setIsvisible(false);
    }
    setShow(!show);
  };

  return (
    <View style={Scriptviewstyle.maincontainer}>
      <Animated.View
        style={{
          height: height,
          backgroundColor: 'white',
        }}>
        {scrollValue == 1 ? (
          <View style={Scriptviewstyle.headertwo}>
            <View style={Scriptviewstyle.innerheadconatiner}>
              <View style={Scriptviewstyle.innerflexone}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Entypo name="cross" size={24} color={'black'} />
                </TouchableOpacity>
                <View>
                  <View style={Scriptviewstyle.aligntxt}>
                    <Text style={Scriptviewstyle.companyname}>
                      {detail?.item?.companyName}
                    </Text>
                    <Text style={Scriptviewstyle.Astyle}>A</Text>
                  </View>

                  <View
                    style={{ flexDirection: 'row', justifyContent: 'center' }}>


                    <TouchableOpacity onPress={() => setVisible(true)}>
                      <View style={Scriptviewstyle.filtler}>
                        <Text style={Scriptviewstyle.Bsetxtstyle}>{value}</Text>

                        <Entypo
                          name="chevron-small-down"
                          size={16}
                          color={root.color_subtext}
                        />
                      </View>

                    </TouchableOpacity>



                    <View style={Scriptviewstyle.bseflexallign}>
                      <Text style={Scriptviewstyle.valtxt}>
                        {detail?.item?.value}
                      </Text>
                      <Text style={Scriptviewstyle.chgvaltxt}>
                        {detail?.item?.changes}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={Scriptviewstyle.innerflextwo}>
                <View style={Scriptviewstyle.buysmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Buy</Text>
                </View>
                <View style={Scriptviewstyle.sellsmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Sell</Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                    setShow(true);
                  }}>
                  <Entypo
                    name="dots-three-vertical"
                    color={'black'}
                    size={20}
                  />
                </TouchableOpacity>
                {/* <Modal
                  transparent={true}
                  visible={visible}
                  onRequestClose={() => setVisible(!visible)}>
                  <View
                    style={
                      scrollValue == 1
                        ? Scriptviewstyle.whitethree
                        : Scriptviewstyle.whitetwo
                    }>
                    {option.map((item, index) => {
                      return (
                        <TouchableOpacity
                          onPress={() => {
                            setVisible(!visible);
                            setValue(item);
                          }}
                          activeOpacity={1}>
                          <View style={Scriptviewstyle.dropbox}>
                            <Text style={Scriptviewstyle.option}>{item}</Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </Modal> */}
              </View>
            </View>
          </View>
        ) : (
          <>
            <View style={Scriptviewstyle.header}>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Entypo name="cross" size={24} color={'black'} />
              </TouchableOpacity>
            </View>
            <View style={Scriptviewstyle.detailblock}>
              <View style={Scriptviewstyle.detailone}>
                <View style={Scriptviewstyle.aligntxt}>
                  <Text style={Scriptviewstyle.companyname}>
                    {detail?.item?.companyName}
                  </Text>
                  <Text style={Scriptviewstyle.Astyle}>A</Text>
                </View>
                {detail?.item?.future == true ? (
                  <>
                    <View>
                      {detail?.item.date.value == '' ? (
                        <>
                          <Text style={Scriptviewstyle.futuretxt}>
                            {detail?.item?.date.day}{' '}
                            {detail?.item?.date?.strickprice}{' '}
                            {detail?.item?.date?.optiontype}
                          </Text>
                        </>
                      ) : (
                        <>
                          <Text>
                            {detail?.item?.date.day} {detail?.item?.date?.value}{' '}
                          </Text>
                        </>
                      )}
                    </View>
                  </>
                ) : null}

                <TouchableOpacity onPress={() => setVisible(true)}>
                  <View style={Scriptviewstyle.filtler}>
                    <Text style={Scriptviewstyle.Bsetxtstyle}>{value}</Text>
                    <Entypo
                      name="chevron-small-down"
                      size={16}
                      color={root.color_subtext}
                    />
                  </View>
                </TouchableOpacity>
                {/* <Modal
                  transparent={true}
                  visible={visible}
                  onRequestClose={() => setVisible(!visible)}>
                  <View
                    style={
                      scrollValue == 1
                        ? Scriptviewstyle.whitethree
                        : Scriptviewstyle.whitetwo
                    }>
                    {option.map((item, index) => {
                      return (
                        <TouchableOpacity
                          onPress={() => {
                            setVisible(!visible);
                            setValue(item);
                          }}
                          activeOpacity={1}>
                          <View style={Scriptviewstyle.dropbox}>
                            <Text style={Scriptviewstyle.option}>{item}</Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </Modal> */}
              </View>

              <View style={Scriptviewstyle.detailtwo}>
                <Text style={Scriptviewstyle.valtxt}>
                  {detail?.item?.value}
                </Text>
                <Text style={Scriptviewstyle.chgvaltxt}>
                  {detail?.item?.changes}
                </Text>
                <View style={Scriptviewstyle.iconcontainer}>
                  <TouchableOpacity
                    onPress={() => navigation.navigate('Screen3')}>
                    <MaterialCommunityIcons
                      name="bell-outline"
                      color={'black'}
                      size={23}
                    />
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={Scriptviewstyle.circle}
                    onPress={() => navigation.navigate('Screen3')}>
                    <Feather name="bar-chart-2" size={20} color="black" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => setNorModalVisible(true)}>
                    <AntDesign
                      name="pluscircleo"
                      size={24}
                      color={root.color_text}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View style={Scriptviewstyle.byselconatiner}>
              <TouchableOpacity style={Scriptviewstyle.buycontainer}>
                <Text style={Scriptviewstyle.buyselltxt}>Buy</Text>
              </TouchableOpacity>
              <TouchableOpacity style={Scriptviewstyle.sellconstainer}>
                <Text style={Scriptviewstyle.buyselltxt}>Sell</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
           <Modal
                  transparent={true}
                  visible={visible}
                  onRequestClose={() => setVisible(!visible)}>
                  <View
                    style={
                      scrollValue == 1
                        ? Scriptviewstyle.whitethree
                        : [Scriptviewstyle.whitetwo,{top:detail?.item?.future == true?109:95}]
                    }>
                    {option.map((item, index) => {
                      return (
                        <TouchableOpacity
                          onPress={() => {
                            setVisible(!visible);
                            setValue(item);
                          }}
                          activeOpacity={1}>
                          <View style={Scriptviewstyle.dropbox}>
                            <Text style={Scriptviewstyle.option}>{item}</Text>
                          </View>
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                </Modal>
      </Animated.View>



      <NorModal
        visible={norModalVisible}
        onClose={onNorClose}
        isvisible={isvisible}
      />
      <Scriptviewtab data={detail} setScrollValue={setScrollValue} />

      {show ? (
        <>
          <View style={Scriptviewstyle.white}>
            {menu.map((item, index) => {
              return (
                <TouchableOpacity
                  onPress={() => {
                    // setShow(!show);
                    // setPickoption(item);
                    navtoScreen(item);
                  }}
                  activeOpacity={1}>
                  <View style={Scriptviewstyle.menucon}>
                    <Text style={Scriptviewstyle.option}>{item}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        </>
      ) : null}
    </View>
  );
};

export default Scriptviewdetail;

import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import {useNavigation} from '@react-navigation/native';

const list = ['Equity', 'Derivative', 'Commodity', 'Currency','Derivative'];
const SecrorDialog = (props: any) => {
  const {item, visible, onClose} = props;

  const [selected, setSelected] = useState('Equity');
  const navigation = useNavigation();

  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => navigation.goBack()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          paddingVertical: 24,
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View
            style={{
              paddingHorizontal: 20,
              position: 'relative',
            }}>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                width: '75%',
              }}>
              Choose Indices /
            </Text>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                width: '75%',
              }}>
            Sectors
            </Text>
            <TouchableNativeFeedback
              onPress={() => {
                props.onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={{position: 'absolute', right: 16}}>
                <CloseIcon style={{height: 24, width: 24, color: root.color_text}} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <View
              style={{
                marginTop: 16,
                marginHorizontal: 16,
                borderWidth: 1,
                borderRadius: 8,
                borderColor:  root.color_text,
                paddingVertical: 4,
                paddingHorizontal: 8,
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <SearchIcon style={{width: 16, height: 16, fill: root.color_text}} />
              <TextInput
                style={{
                  marginLeft: 8,
                  flex: 1,
                  paddingVertical: 0,
                  fontSize: 14,
                  color: root.color_text 
                }}
                keyboardType="default"
                placeholder="Search"
              />
            </View>

           
          <FlatList
            style={{marginTop: 12}}
            data={list}
            showsHorizontalScrollIndicator={false}
            renderItem={(i: any) => {
              return (
               
                <TouchableNativeFeedback
                  key={i.item}
                  // disabled={!filled}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setSelected(i.item);
                    // setConfirmOrderVisible(true);
                  }}>
                
                <View
                    style={{
                      paddingVertical: 14,
                      paddingHorizontal: 20,
                      flexDirection: 'row',
                      
                    }}>
                    <View
                      style={{
                        width: 20,
                        height: 20,
                        borderWidth: 1.8,
                        borderColor:  root.color_text,
                        borderRadius: 12,
                        padding: 2,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      {selected === i.item && (
                        <View
                          style={{
                            height: 10,
                            width: 10,
                            backgroundColor:  root.color_text,
                            borderRadius: 8,
                          }}
                        />
                      )}
                    </View>
                    <Text style={{marginLeft: 16,color: root.color_text ,fontFamily: Cfont.rubik_medium}}>{i.item}</Text>
                    </View>
                </TouchableNativeFeedback>
                
              
              );
            }}
          />
          
        </View>
       
      </View>
   
    </Modal>
  );
};
export default SecrorDialog;

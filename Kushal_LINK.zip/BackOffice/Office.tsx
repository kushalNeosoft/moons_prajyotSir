import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { linkOne } from '../../theme/light';

const Office = () => {
  const navigation = useNavigation();
  
  return (
    <View
      style={linkOne.main}>
      <View
        style={linkOne.shadowone}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={linkOne.backicon} />
        </TouchableOpacity>

        <Text style={linkOne.header}>
          BackOffice
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          
              <View
                
                style={linkOne.shadowthree}>
                  <View>
                <Text
                  style={linkOne.cardtext}>
                 Profit Loss Summry
                </Text>
                <Text
                  style={linkOne.cardsub}>
                 View your profit loss report
                </Text>
                </View>
                <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
              </View>

              <View
                
                style={linkOne.shadowthree}>
                  <View>
                <Text
                  style={linkOne.cardtext}>
                 Ledger Report
                </Text>
                <Text
                  style={linkOne.cardsub}>
                Your ledge report is available here
                </Text>
                </View>
                <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
              </View>
              <View
                
                style={linkOne.shadowthree}>
                  <View>
                <Text
                  style={linkOne.cardtext}>
                 F&O Outstanding Report
                </Text>
                <Text
                  style={linkOne.cardsub}>
                View your F&O outstanding report
                </Text>
                </View>
                <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
              </View>
              <View
                
                style={linkOne.shadowthree}>
                  <View>
                <Text
                  style={linkOne.cardtext}>
                 Holdings View
                </Text>
                <Text
                  style={linkOne.cardsub}>
                 Click here to see your holdings
                </Text>
                </View>
                <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
              </View>
              <View
                
                style={linkOne.shadowthree}>
                  <View>
                <Text
                  style={linkOne.cardtext}>
                My Profile
                </Text>
                <Text
                  style={linkOne.cardsub}>
                 Profile information
                </Text>
                </View>
                <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
              </View>
           
        </ScrollView>
      </View>
    </View>
  );
};
export default Office;

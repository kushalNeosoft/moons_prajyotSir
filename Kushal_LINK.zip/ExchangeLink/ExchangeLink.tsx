import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  Linking,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {  linkOne } from '../../theme/light';

const ExchangeLink = () => {
  const [links, setLinks] = useState([]);
  const navigation = useNavigation();

  const loadData = async () => {
    fetch(
      'https://pre-prod1.odinwave.com/nontransactional/1404/v1/getExchangeLinks',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        setLinks(data.result);
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View
      style={linkOne.main}>
      <View
        style={linkOne.shadowone}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={linkOne.backicon} />
        </TouchableOpacity>


        <Text
          style={linkOne.header}>
          Links
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {links.map((link: any, index: any) => {
            return (
              <TouchableNativeFeedback
                key={index}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  Linking.openURL(link.sLinkAddress);
                }}>
                <View
                  key={index}
                  style={linkOne.card}>
                  <Text
                    style={linkOne.cardtext}>
                    {link.sLinkTitle}
                  </Text>
                  <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
                </View>
              </TouchableNativeFeedback>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
};
export default ExchangeLink;

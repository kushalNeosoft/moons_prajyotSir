import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Logo from '../../assets/Logo';
import AddIcon from '../../assets/AddIcon';
import AddFunds from '../Funds/AddFunds/AddFunds';
import { calculator } from '../../theme/light';

const Calculator = () => {
  // const image = require('../../assets/');
  const navigation = useNavigation();
  return (
    <View
      style={calculator.main}>
      <View
        style={calculator.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={calculator.backIcon} />
        </TouchableOpacity>

        <Text
          style={calculator.headerText}>
          Calculators
        </Text>
      </View>
      <View style={calculator.scrollMain}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              navigation.navigate('FutureFairValueCalculator');
            }}>
            <View
              style={calculator.cardMain}>
              <View>
                <Text
                  style={calculator.cardText}>
                  Future Fair Value
                </Text>
                <Text
                  style={calculator.cardSubText}>
                  Calculaton of future fair value
                </Text>
              </View>
              <Image
                source={require('../../assets/Broker.png')}
                style={calculator.image}
              />
            </View>
          </TouchableNativeFeedback>

          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              navigation.navigate('OptionValueCalculator');
            }}>
            <View
              style={calculator.cardMain}>
              <View>
                <Text
                  style={calculator.cardText}>
                  Option Value
                </Text>
                <Text
                  style={calculator.cardSubText}>
                  Calculation of Option Value and Greeks
                </Text>
              </View>
              <Image
                source={require('../../assets/Broker.png')}
                style={calculator.image}
              />
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              navigation.navigate('SpanMargin');
            }}>
            <View
              style={calculator.cardMain}>
              <View>
                <Text
                  style={calculator.cardText}>
                  Span Margin
                </Text>
                <Text
                  style={calculator.cardSubText}>
                  Calculation of SPAN margin
                </Text>
              </View>
              <Image
                source={require('../../assets/Broker.png')}
                style={calculator.image}
              />
            </View>
          </TouchableNativeFeedback>
        </ScrollView>
      </View>
    </View>
  );
};
export default Calculator;

import React from 'react';
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import CommonModaltwo from '../../../../components/CommonModal/CommonModaltwo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../../../styles/colors';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import alignment from '../../../../components/utils/alignment';
import { contactUsModal } from '../../../../theme/light';

const ContactUsModal = (props: any) => {
  const data = [
    {
      name: 'phone',
      type: 'Customer Support',
      number: '9167396666',
    },
    {
      name: 'phone',
      type: 'Tech Support',
      number: '9167396666',
    },
    {
      name: 'email',
      type: 'Email your Query',
      number: 'presalesteam@63moons.com',
    },
  ];
  return (
    <Modal
    visible={props.visible}
    transparent={true}
    onRequestClose={()=>props.onClose()}
    >
            <TouchableOpacity style={contactUsModal.centeredView} onPress={() => props.onClose()} activeOpacity={1}>
        
        </TouchableOpacity>
      <View style={contactUsModal.container}>
      <View style={{...alignment.row_SpaceB}}>
      <Text style={contactUsModal.titleTxt}>Contact Us</Text>
      <TouchableOpacity style={contactUsModal.closeButton} onPress={()=>props.onClose()}>
        <AntDesign name="close" size={24} color={root.color_text} />
        </TouchableOpacity>
        </View>
        <FlatList
        style={contactUsModal.list}
          data={data}
          renderItem={({item}) => (
            <View style={contactUsModal.typeContainer}>
              <MaterialCommunityIcons
                name={item.name}
                size={24}
                color={'black'}
              />
              <Text style={contactUsModal.typeTxt}>{item.type}</Text>
              <Text style={contactUsModal.typeTxt}>{item.number}</Text>
            </View>
          )}
        />
        </View>
    </Modal>
  );
};

export default ContactUsModal;

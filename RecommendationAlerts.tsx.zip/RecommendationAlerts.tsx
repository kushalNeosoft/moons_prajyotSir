import React, {useRef, useState} from 'react';
import {View, Text, TouchableHighlight, TouchableOpacity} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {recommendationsAlerts, shiftButton} from '../../theme/light';
import Recommendations from './Recommendations/Recommendations';
import Alerts from './Alerts/Alerts';
import SortFilterBottomSheet from '../../components/BottomSheet/SortFilterBottomSheet';
import Filter from './components/Filter/Filter';
import BottomSheet from '@gorhom/bottom-sheet';
import SearchRecommendations from './components/SearchModal/SearchModal';
import {useNavigation} from '@react-navigation/native';
import AlertFilter from './Alerts/components/AlertFilter';

function RecommendationsAlerts() {
  const [categoryFilters, setCategoryFilters] = useState('');
  const [alertFilters, setAlertFilters] = useState('');
  const [selectedBtn, setSelectedBtn] = useState<any>(0);
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [settingsView, setSettingsView] = useState(false);
  const buttons = ['Recommendations', 'Alerts'];
  const [order, setOrder] = useState('');
  const [brokerTags, setBrokerTags] = useState('');
  const bottomSheetRef = useRef<BottomSheet>(null);

  const navigation = useNavigation();

  const setOrderFilter = (value: string) => {
    setOrder(value);
  };

  const setBrokerTagFilter = (value: string) => {
    setBrokerTags(value);
  };

  const setCategoryFilter = (value: string) => {
    setCategoryFilters(value);
  };

  const setAlertFilter = (value: string) => {
    setAlertFilters(value);
  };

  const clearCategoryFilter=()=>{
    setCategoryFilters('')
  }

  const clearAlertFilter=()=>{
    setAlertFilters('')
  }

  const clearOrderFilter = () => {
    setOrder('');
  };

  const clearTagFilter = () => {
    setBrokerTags('');
  };

  const renderButtons = () => {
    return (
      <View style={shiftButton.tabBarContainer}>
        {buttons &&
          buttons.map((btn: any, key: any) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? shiftButton.selectedTabBtns
                    : shiftButton.unSelectedTabBtns
                }
                onPress={() => setSelectedBtn(key)}>
                <Text
                  style={
                    selectedBtn === key
                      ? shiftButton.selectedBtnText
                      : shiftButton.tabBtnsText
                  }>
                  {btn}
                </Text>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };

  const searchModalToggle = () => {
    setSearchModalVisible(prevState => !prevState);
  };

  const openSortFilterSheet = () => {
    bottomSheetRef.current?.snapToIndex(0);
  };

  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return (
          <Recommendations
            openSortFilterSheet={openSortFilterSheet}
            searchModalToggle={searchModalToggle}
            data={data}
            filterOrder={order}
            brokerTags={brokerTags}
            clearOrderFilter={clearOrderFilter}
            clearTagFilter={clearTagFilter}
          />
        );
      case buttons[1]:
        return (
          <Alerts
            openAlertFilterSheet={openSortFilterSheet}
            categoryFilters={categoryFilters}
            alertFilters={alertFilters}
            clearCategoryFilter={clearCategoryFilter}
            clearAlertFilter={clearAlertFilter}
          />
        );
    }
  };

  const data = [
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Buy',
      buyType: 'Buy @ 560.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 1,
      gainer: 'Vol Gainer',
      order: '1',
      tags: 'All1',
    },
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Sell',
      buyType: 'Buy @ 561.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 2,
      gainer: 'Raco',
      order: '1',
      tags: 'Bracket',
    },
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Sell',
      buyType: 'Buy @ 562.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 2,
      gainer: 'Raco',
      order: '2',
      tags: 'All1',
    },
  ];

  return (
    <View style={recommendationsAlerts.container}>
      <View style={recommendationsAlerts.header}>
        <View style={recommendationsAlerts.rightHeaderView}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <AntDesign name="arrowleft" size={24} color={'black'} />
          </TouchableOpacity>
          <Text style={[recommendationsAlerts.title]}>
            Recommendations & Alerts
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => setSettingsView(prevState => !prevState)}>
          <Entypo name="dots-three-vertical" size={20} color={'black'} />
        </TouchableOpacity>
      </View>
      {renderButtons()}
      {renderView(buttons[selectedBtn])}
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        closesheet={closeSheet}
        index={-1}>
        {selectedBtn === 0 ? (
          <Filter
            setOrderFilter={setOrderFilter}
            setBrokerTagFilter={setBrokerTagFilter}
            order={order}
            brokerTags={brokerTags}
            closeSheet={closeSheet}
          />
        ) : (
          <AlertFilter
            closeSheet={closeSheet}
            setCategoryFilter={setCategoryFilter}
            setAlertFilter={setAlertFilter}
            categoryFilters={categoryFilters}
            alertFilters={alertFilters}
          />
        )}
      </SortFilterBottomSheet>
      <SearchRecommendations
        visible={searchModalVisible}
        onClose={searchModalToggle}
        data={data}
      />
      {settingsView ? (
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('Settings');
            setSettingsView(prevState => !prevState);
          }}
          style={recommendationsAlerts.settingsView}>
          <Text style={recommendationsAlerts.settingsTxt}>Settings</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export default RecommendationsAlerts;

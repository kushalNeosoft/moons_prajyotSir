export const demoData = [
  {
    price: 827.67,
    changes: '+3.65(+0.44%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 5000,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'WIPRO',
    price: 977.7,
    changes: '+2.65(+0.54%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'HDFCBANK',
    price: 767.7,
    changes: '+5.67(+0.50%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'TCS',
    price: 890.5,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 1200,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'SBIN',
    price: 890.89,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 1800,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'BSE',
    price: 890.79,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 300,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'SBIN',
    price: 1098.59,
    changes: '+4.69(+0.75%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 400,
    plus: '',
    minus: '[-12.90%]',
  },
  {
    stockName: 'NTPC',
    price: 655.52,
    changes: '+1.69(+0.35%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'INFY',
    price: 789.5,
    changes: '+1.69(+0.35%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'RELIANCE',
    price: 890.5,
    changes: '+5.69(+0.45%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'BAJAJ',
    price: 870.5,
    changes: '+4.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 500,
    plus: '',
    minus: '[-10.90%]',
  },
  {
    stockName: 'TATA',
    price: 560.5,
    changes: '+7.69(+0.90%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 800,
    plus: '',
    minus: '[-14.70%]',
  },

  {
    stockName: 'INDUSLAND',
    price: 878.5,
    changes: '+1.69(+0.20%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'ICICIBANK',
    price: 678.5,
    changes: '+4.69(+0.50%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'SBI',
    price: 678.5,
    changes: '+4.89(+0.5%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'AXIS',
    price: 767.5,
    changes: '+2.60(+0.30%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'TCS',
    stockfrom: 'NSE',
    date: '25 MAY',
    tag: 'FUT',
    price: '3229.35',
    changes: '0.00(0.00)',
  },
  {
    stockName: 'TCS',
    stockfrom: 'NSE',
    date: '25 MAY',
    future: '3200.00CE',
    tag: 'FUT',
    price: '61.70',
    changes: '0.00(0.00)',
  },
];

export const courselDemodata = [
  {
    title: 'Open',
    value: '1213.45',
  },
  {
    title: 'Close',
    value: '1207.35',
  },
  {
    title: 'Daily Price Range',
    value: '1101.60-',
    valuetwo: '1346.40',
  },
];

export const progressData = [
  {
    title: 'Today (Low-High)',
    price: '1383.30',
    pricetwo: '1411.05',
  },
  {
    title: '52 Week (Low-High)',
    price: '1185.30',
    pricetwo: '1672.60',
  },
];

export const endDemodata = [
  {
    title: 'Avg Trading Price',
    value: '1394.82',
  },
  {
    title: 'Value',
    value: '120797392.35',
  },
  {
    title: 'Volume',
    value: '9844356',
  },
  {
    title: 'Last Traded Time',
    value: '15:29:59',
  },
  {
    title: 'Last Updated Time',
    value: '15:11:17',
  },
];

export const newDemodata = [
  {
    title: 'Avg Trading Price',
    value: '1394.82',
  },
  {
    title: 'Value',
    value: '120797392.35',
  },
  {
    title: 'Volume',
    value: '9844356',
  },
];

export const newsecondDemodata = [
  {
    title: 'Last Traded Qty',
    value: '23',
  },
  {
    title: 'Last Traded Time',
    value: '15:29:59',
  },
  {
    title: 'Last Updated Time',
    value: '15:11:17',
  },
];

export const marketdata = [
  {
    title: 'Market Cap',
    value: '30',
  },
];

export const eventdata = [
  {
    title: 'Board Meeting',
    data:{
      date:[
        {
          day:"09 Nov",
          year:"'21"
        },
        {
          day:"10 Nov",
          year:"'21"
        },
        {
          day:"11 Nov",
          year:"'21"
        },
        {
          day:"12 Nov",
          year:"'21"
        },
        {
          day:"13 Nov",
          year:"'21"
        },
      ]
      

    }
  },
  {
    title: 'Book Closure',
    data:{
      date:[
        {
          day:"09 Nov",
          year:"'21"
        },
        {
          day:"09 Nov",
          year:"'21"
        },
      ]
    }
  },
  {
    title: 'AGM',
    data:{
      date:[
        {
          day:"09 Nov",
          year:"'21"
        },
      ]
    }
  },
  {
    title: 'EGM',
    data:{
      date:[
        {
          day:"09 Nov",
          year:"'21"
        },
        {
          day:"18 Nov",
          year:"'21"
        },
        {
          day:"12 Nov",
          year:"'21"
        },
      ]
    }
  },
  {
    title: 'Split',
    data:{
      date:[
        {
          day:"09 Nov",
          year:"'21"
        },
      ]
    }
  },
  {
    title: 'Dividend',
    data:{
      date:[
        {
          day:"18 Nov",
          year:"'21"
        },
        {
          day:"13 Nov",
          year:"'21"
        },
      ]
    }
  },
  {
    title: 'Buy Back',
    data:{
      date:[
        {
        day:"19 Nov",
        year:"'21"
      },]
    }
  },
  {
    title: 'Rights',
    data:{
      date:[
        {
          day:"20 Nov",
          year:"'21"
        },
      ]
    }
  },
];

export interface Itemtrade {
  
  title: string;
  date: string;
  value: string;
  change: string;
  cevalue: string;
  Broken: string;
  ptive:string;
  id:string;
}
export const tradeData: Itemtrade[] = [
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id:'1',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id:'2',

  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '23.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id:'3',

  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '27.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id:'4',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '9.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id:'5',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id:'6',
  },
];

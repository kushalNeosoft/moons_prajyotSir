import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import alignment from '../utils/alignment';
import {Cfont, Font, root} from '../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { useSelector } from 'react-redux';

function Header(props: any) {
  const getScriptName=useSelector(state=>state.Reducer.scriptName);
  console.log('ScriptName in header Component bottomsheet',getScriptName)

  return (
    <View
      style={{
        ...alignment.row,
        backgroundColor: 'white',
        // alignItems: 'center',
      }}>
      <TouchableOpacity onPress={() => props.closeSheet()}>
        <Ionicons name="arrow-back" size={20} color={'black'} />
      </TouchableOpacity>
      <Text style={styles.companyNameTop}>{props.name}</Text>
      <View
        style={{
          right: 0,
          position: 'absolute',
        }}>
        {props.scriptName === 'Equity SIP' ? (
          <View style={{ ...alignment.row}}>
            <Text style={styles.activeTxt}>Active</Text>
            <Ionicons name="md-at-circle-outline" size={15} />
          </View>
        ) : (
          <View style={{ ...alignment.row}}>
          <Text style={styles.activeTxt}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
        </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  companyNameTop: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 10,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
});

export default Header;

import React, {useCallback, useMemo, useState} from 'react';
import BottomSheet, {
  BottomSheetBackdrop,
  BottomSheetScrollView,
} from '@gorhom/bottom-sheet';
import {StyleSheet, Dimensions, TouchableOpacity, Text} from 'react-native';
import Header from './Header';
import {Cfont, Font, root} from '../../styles/colors';

const screenheight = Dimensions.get('window').height;

const Bottomsheet = React.forwardRef((props: any, ref) => {
  const snapPoints = useMemo(() => ['67%', '100%'], []);
  const [reachedTop, setReachedTop] = useState(false);

  const handleSheetChanges = useCallback((index: number) => {
    switch (index) {
      case 1:
        setReachedTop(true);
        props && props.getHeightValue && props.getHeightValue(true);
        break;
      default:
        setReachedTop(false);
        props && props.getHeightValue && props.getHeightValue(false);
    }
  }, []);

  const renderBackdrop = useCallback(
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
      />
    ),
    [],
  );

  const closeSheet = () => {
    props.closeSheet();
  };

  return (
    <BottomSheet
      {...props}
      backgroundComponent={null}
      handleIndicatorStyle={{display: reachedTop ? 'none' : 'flex'}}
      style={styles(reachedTop).container}
      snapPoints={props.snapPoints ? props.snapPoints : snapPoints}
      onChange={handleSheetChanges}
      backdropComponent={renderBackdrop}
      // enableHandlePanningGesture={reachedTop ? false : true}
      // enableContentPanningGesture={reachedTop ? false : true}
      ref={ref}
      index={props.index}>
      <BottomSheetScrollView
        contentContainerStyle={{paddingHorizontal: 10}}
        // stickyHeaderIndices={[0]}
        stickyHeaderHiddenOnScroll={false}>
        {reachedTop ? (
          <Header
            closeSheet={closeSheet}
            name={props?.allData?.name}
            scriptName={props?.scriptName}
          />
        ) : null}
        {props.children}
      </BottomSheetScrollView>
      <TouchableOpacity>
        <Text style={{
          color: root.color_active,
          fontSize: Font.font_normal_three,
          fontFamily: Cfont.rubik_medium,
        }}>Apply</Text>
      </TouchableOpacity>
    </BottomSheet>
  );
});

const styles = (reachedTop?: boolean) =>
  StyleSheet.create({
    container: {
      backgroundColor: 'white',
      borderTopRightRadius: reachedTop ? 0 : 20,
      borderTopLeftRadius: reachedTop ? 0 : 20,
      zIndex: 1,
    },
    
  });

export default Bottomsheet;

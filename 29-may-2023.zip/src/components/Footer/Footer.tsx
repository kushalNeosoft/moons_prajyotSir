import {
  TouchableNativeFeedback,
  View,
  Text,
  Dimensions,
  ScrollView,
} from 'react-native';
import useStyles from '../../styles/useStyles';
import {useTranslation} from 'react-i18next';
// import {createFooterStyles} from './footer.styles';
import React, {useRef, useState} from 'react';
import AboutUsDialog from '../../screens/Login/components/AboutUsDialog';
import MembershipDialog from '../../screens/Login/components/MembershipDialog';
import ExchangeDialog from '../../screens/Login/components/ExchangeDialog';
import { FooterStyles } from '../../theme/light';

const Footer = () => {
  // const {colors, styles} = useStyles(createFooterStyles);
  const {t} = useTranslation();
  const height = Dimensions.get('window').height;
  const [selectedDailog, setSelectedDialog] = useState('ABOUT_US');
  const [exhModalVisible, setExModalVisible] = useState(false);
  const [aboutModalVisible, setaboutModalVisible] = useState(false);
  const [memModalVisible, setmemModalVisible] = useState(false);

  const onNorClose = () => {
    setExModalVisible(prevState => !prevState);
    
  };
  const onNor1Close = () => {
    
    setaboutModalVisible(prevState => !prevState);
   
  };
  const onNor2Close = () => {
   
    setmemModalVisible(prevState => !prevState);
    
  };
  return (
    <>
      <View style={FooterStyles.footerContainer}>
        <View style={FooterStyles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            // onPress={() => {
            //   setSelectedDialog('EXCHANGE');
            //   bottomSheetRef.current?.open();
            // }}
            onPress={() => setExModalVisible(true)}
            >
            <View style={FooterStyles.itemContainer}>
              <Text style={FooterStyles.text}> {t('login.exchange_timings')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
        <View style={FooterStyles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            // onPress={() => {
            //   setSelectedDialog('ABOUT_US');
            //   bottomSheetRef.current?.open();
            // }}
            onPress={() => setaboutModalVisible(true)}
            
            >
            <View style={FooterStyles.itemContainer}>
              <Text style={FooterStyles.text}>{t('login.about_us')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
        <View style={FooterStyles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            // onPress={() => {
            //   setSelectedDialog('MEMBERSHIP');
            //   bottomSheetRef.current?.open();
            // }}
            onPress={() => setmemModalVisible(true)}
            
            >
            <View style={FooterStyles.itemContainer}>
              <Text style={FooterStyles.text}>{t('login.membership_details')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <AboutUsDialog 
          visible={aboutModalVisible}
        onClose={onNor1Close}
        />
         <ExchangeDialog 
          visible={exhModalVisible}
        onClose={onNorClose}
        />
         <MembershipDialog 
          visible={memModalVisible}
        onClose={onNor2Close}
        />
      {/* <BottomSheet
        ref={bottomSheetRef}
        height={(height * 3) / 4}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 16,
          },
        }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {selectedDailog === 'ABOUT_US' && <AboutUsDialog />}
          {selectedDailog === 'MEMBERSHIP' && <MembershipDialog />}
          {selectedDailog === 'EXCHANGE' && <ExchangeDialog />}
        </ScrollView>
      </BottomSheet> */}
    </>
  );
};
export default Footer;

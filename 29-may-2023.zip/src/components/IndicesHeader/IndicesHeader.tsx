import React, {useState, useEffect} from 'react';
import {View, Text, FlatList, TouchableOpacity, Alert} from 'react-native';
// import {assets} from '../../assets';
import FlashMessage, {showMessage} from 'react-native-flash-message';
// import IndexModal from '../Modal';

import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {MenuIcon, RupeeIcon} from '../Svg/Svg';
// import {texts} from '../../../constants/text';
import { texts } from '../../screens/WatchList/WatchListComponent/CommonText/text';
import { watchlistheader } from '../../theme/light';


function Header(props: any) {
  const [modalVisible, setModalVisible] = useState(false);
  const [niftyValue, setNiftyValue] = useState(true);
  const [sensexValue, setSenSexValue] = useState(true);
  const [otherValue, setOtherValue] = useState(false);

  const navigation = useNavigation<any>();

  useEffect(() => {
    if (niftyValue && sensexValue && otherValue) {
      showMessage({
        message: 'Information',
        description: 'Please select any two indices',
        type: 'danger',
      });
    }
  }, [niftyValue, sensexValue, otherValue]);

  const data = [
    {
      name: texts.NIFTY_50,
      value: '17755.00',
      change: '160.65',
      minu: true,
      percentage: '+0.91%',
    },
    {
      name: texts.SENSEX,
      value: '60397.62',
      change: '--588.65',
      minu: false,
      percentage: '0.98%',
    },
  ];

  const onClose = () => {
    setModalVisible(prev => !prev);
  };
  // const pressalert = () => {
  //   Alert.alert('Work in Progress');
  // };

  // () => navigation.navigate('Constituents')}

  const changeIndex = (text: any) => {
    switch (text) {
      case 'Nifty':
        setNiftyValue((prevState: any) => !prevState);
        break;
      case 'SenSex':
        setSenSexValue((prevState: any) => !prevState);
        break;
      case 'Other':
        setOtherValue((prevState: any) => !prevState);
        break;

      default:
        null;
    }
  };

  const renderIndexView = ({item}: any) => {
    return (
      <TouchableOpacity
        style={watchlistheader.headercon}
        onPress={() => navigation.navigate('Constituents')}>
        <Text style={watchlistheader.titleText}>{item.name}</Text>
        <Text style={watchlistheader.titleText}>{item.value}</Text>
        <Text
          style={
            item.minu == true
              ? watchlistheader.changePercentage
              : watchlistheader.changePercentageminus
          }>{`${item.change}(${item.percentage})`}</Text>
      </TouchableOpacity>
    );
  };
  return (
    <>
      {/* <IndexModal
        visible={modalVisible}
        onClose={onClose}
        changeIndex={changeIndex}
        niftyValue={niftyValue}
        sensexValue={sensexValue}
        otherValue={otherValue}
      /> */}
      <View style={watchlistheader.container}>
        <View style={watchlistheader.headerLeft}>
          <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
            <MenuIcon />
          </TouchableOpacity>
        </View>
        <View style={watchlistheader.headerMiddle}>
          <FlatList
            horizontal={true}
            data={data}
            renderItem={renderIndexView}
            showsHorizontalScrollIndicator={false}
            scrollEnabled={false}
          />
        </View>
        <View style={watchlistheader.headerRight}>
          <TouchableOpacity>
            <RupeeIcon style={watchlistheader.rupeicon} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setModalVisible(prev => !prev)}>
            <Ionicons name="md-settings-sharp" size={20} color={'black'} />
          </TouchableOpacity>
        </View>
      </View>
      <FlashMessage
        position={'top'}
        animated={true}
        animationDuration={1000}
        floating={true}
      />
    </>
  );
}

export default Header;

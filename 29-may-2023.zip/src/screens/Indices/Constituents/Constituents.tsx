import React, {useState, useEffect} from 'react';
import {View, TouchableOpacity, FlatList} from 'react-native';
// import ConstituentsList from './components/ConstituentsList/ConstituentsList';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
import ConstituentsBoxList from './components/ConstituentsBox/ConstituentsBox';
import {constituentsScreen} from '../../../theme/light';
import AddToWatchListModal from './components/AddToWatclistModal';
import StockListView from '../../../components/StockListView/StockListView';

function Constituents() {
  const [selectedFilter, setSelectedFilter] = useState(1);
  const [stockData, setStockData] = useState<any>();
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    pushStockData();
  }, []);

  const hideModal = () => {
    setShowModal(prevState => !prevState);
  };

  var randomStock = [
    'BRITANIA',
    'AXISBANK',
    'TCS',
    'ULTRACEMCO',
    'BPCL',
    'DIVISLAB',
    'MARUTI',
    'LT',
  ];
  var randomPrice = ['295.03', '443.05', '220.54', '577.94'];
  var gainerLoser = ['Vol.Gainer', 'Pr.Loser', ''];
  var showIcon = [true, false];
  var iconName = ['crown-circle', 'pie-chart-2'];
  var colors = ['#FF0000', '#D60707', '#4CAF50', '#B70404'];

  const addToScripts = (index: any, stockName: any, value: any) => {
    console.log(index, stockName);
    console.log(value);
    setShowModal(value);
  };

  const pushStockData = () => {
    let StockArraydata = [];
    for (let i = 0; i < 15; i++) {
      StockArraydata.push({
        companyName:randomStock[Math.floor(Math.random() * randomStock.length)],
        title: gainerLoser[Math.floor(Math.random() * gainerLoser.length)],
        index: 'NSE',
        value: randomPrice[Math.floor(Math.random() * randomPrice.length)],
        changes: '+3.65(+0.44%)',
        showIcon: showIcon[Math.floor(Math.random() * showIcon.length)],
        iconName: iconName[Math.floor(Math.random() * iconName.length)],
        colors: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    setStockData(StockArraydata);
  };

  const renderItembox = ({item,index}: any) => {
    console.log('item', item);
    return (
      <ConstituentsBoxList
        companyName={item.companyName}
        price={item.value}
        changes={item.changes}
        colors={item.colors}
        addToScripts={addToScripts}
        index={index}
      />
    );
  };

  const renderItem = ({item, index}: any) => {
    return (
   
        <StockListView
          stockName={item.companyName}
          stockTtile={item.title}
          price={item.value}
          changes={item.changes}
          index={index}
          title={item.title}
          showIcon={item.showIcon}
          iconName={item.iconName}
          addToScripts={addToScripts}
        />
        
      
    );
  };

  return (
    <View style={constituentsScreen.container}>
      <View style={constituentsScreen.topBar}>
        <View style={constituentsScreen.switchBotton}>
          <TouchableOpacity
            style={
              selectedFilter == 1
                ? constituentsScreen.leftSwitchButtonWhite
                : constituentsScreen.leftSwitchButtonTransparent
            }
            onPress={() => {
              setSelectedFilter(1);
            }}>
            <AntDesign
              name="bars"
              size={18}
              color={selectedFilter == 1 ? 'black' : 'gray'}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={
              selectedFilter == 2
                ? constituentsScreen.rightSwitchButtonWhite
                : constituentsScreen.rightSwitchButtonTransparent
            }
            onPress={() => {
              setSelectedFilter(2);
            }}>
            <AntDesign
              name="appstore1"
              size={18}
              color={selectedFilter == 2 ? 'black' : 'gray'}
            />
          </TouchableOpacity>
        </View>
        <View style={constituentsScreen.searchFilterContainer}>
          <TouchableOpacity>
            <Ionicons
              name="search-sharp"
              size={20}
              color="black"
              style={constituentsScreen.searchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="list-sharp" size={22} color="black" />
          </TouchableOpacity>
        </View>
      </View>
      <View style={constituentsScreen.listViewContainer}>
        <FlatList
          key={selectedFilter}
          numColumns={selectedFilter}
          data={stockData}
          renderItem={selectedFilter == 1 ? renderItem : renderItembox}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <AddToWatchListModal visible={showModal} onClose={hideModal} />
    </View>
  );
}

export default Constituents;

import {useEffect, useState} from 'react';
import {
  Image,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Popable} from 'react-native-popable';
import CloseIcon from '../../../assets/CloseIcon';
import AddIcon from '../../../assets/AddIcon';
import MinusIcon from '../../../assets/MinusIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import ChooseFrequencyDialog from './ChooseFrequencyDialog';
import ValidityDialog from './ValidityDialog';
import DropDownIcon from '../../../assets/DropDownIcon';
import Look5Icon from '../../../assets/Look5Icon';
import MarketDepthDialog from './MarketDepthDialog';
import React from 'react';
import { Cfont, root } from '../../../styles/colors';
import CheckBox from '@react-native-community/checkbox';
const MarginPrice = ({
  item,
  setFilled,
  transactionType,
  setTransactionTypeVisible,
}: any) => {
  const [marketOrder, setMarketOrder] = useState(false);
  const [lot, setLot] = useState(0);
  const [slLimit, setSlLimit] = useState(0);
  const [validityDailogVisible, setValidityDialogVisible] = useState(false);
  const [marketDepthDailogVisible, setMarketDepthDialogVisible] =
    useState(false);
  const [validity, setValidity] = useState('EOSESS');

  useEffect(() => {
    setFilled(lot > 0);
  }, [lot, setFilled]);
  return (
    <View>
      <View style={{flexDirection: 'row',marginTop: 10}}>
        <View style={{flex: 1}}>
        <View style={{flexDirection: 'row'}}>
        <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              setTransactionTypeVisible(true);
            }}>
            <View style={{flexDirection: 'row'}}>
              <Text style={{color: 'black', fontWeight: 'bold', fontSize: 14}}>
                {transactionType}
              </Text>
              <ExpandIcon style={{width: 18, height: 22, color:root.color_text}} />
            </View>
          </TouchableNativeFeedback>
          </View>
          
        
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                if (lot > 0) setLot(prev => prev - 1);
              }}>
              <View style={{padding: 4}}>
                <MinusIcon style={{width: 16, height: 16, color:  root.color_text,}} />
              </View>
            </TouchableNativeFeedback>
            <TextInput
              style={{
                flex: 1,
                marginHorizontal: 8,
                borderBottomWidth: 2,
                borderColor: 'lightgrey',
                paddingVertical: 0,
                paddingHorizontal: 8,
                textAlign: 'center',
                fontSize: 18,
              }}
              keyboardType="number-pad"
              defaultValue={lot.toString()}
            />
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                setLot(prev => prev + 1);
              }}>
              <View style={{padding: 4}}>
                <AddIcon style={{width: 16, height: 16, color:  root.color_text}} />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <View style={{width: 16}} />
        <View style={{flex: 1}}>
          <Text style={{color:  root.color_text,  fontFamily: Cfont.rubik_medium, fontSize: 14}}>
            Market
          </Text>
          <Text style={{marginTop: 12, fontFamily: Cfont.rubik_light,color:  root.color_text}}>
            Price:{' '}
            <Text style={{ fontFamily: Cfont.rubik_medium, color:  root.color_text,fontSize: 16}}>
              {item.price}
            </Text>
          </Text>
          
        </View>
        <View style={{width: 16}} />
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            setMarketDepthDialogVisible(true);
          }}>
          <View style={{width: 24, height: 24}}>
            <Look5Icon style={{width: 24, height: 24, color:  root.color_text}} />
          </View>
        </TouchableNativeFeedback>
      </View>
      <View style={{marginTop: 26 }}>
      <Text
              style={{
                fontSize: 12,
                color:  root.color_text,
                fontFamily: Cfont.rubik_regular
              }}>
                Click here to update Approx. Margin</Text>

        <Text style={{
                marginTop: 8, 
                fontSize: 12,
                color:  root.color_text,
                fontFamily: Cfont.rubik_regular}}>
                  Approx. Margin: <Text style={{fontFamily: Cfont.rubik_medium}}> ₹ 0</Text></Text>
        
        <Text style={{
                marginTop: 4, 
                fontSize: 12,
                color:  root.color_text,
                fontFamily: Cfont.rubik_regular}}>
                  Available Margin:<Text style={{fontFamily: Cfont.rubik_medium}}> ₹ 0</Text></Text>
        <View
          style={{marginTop: 16, flexDirection: 'row', alignItems: 'center'}}>
          <View
            style={{
              flex: 1,
            }}>
            <Text
              style={{
                fontSize: 14,
                color:  root.color_text,
                fontFamily: Cfont.rubik_bold,
                //fontWeight: 'bold',
              }}>
             "{'>'}Limit your loss or set target for profit
            </Text>
            <Text
              style={{
                fontSize: 12,
                color: root.color_text,
                flex: 1,
                fontFamily: Cfont.rubik_medium,
                marginLeft: 12
              }}>
              Cover order, Bracket Order
            </Text>
            <AddIcon
            style={{width: 24, height: 24, marginLeft: 2, color: 'black'}}
          />
            
          </View>
          <CloseIcon style={{width: 28, height: 28, marginLeft: 8}} />
        </View>
        <View
          style={{
            marginTop: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flex: 1,
          }}>
          <Text style={{fontSize: 14, color: root.color_text, fontFamily: Cfont.rubik_medium}}>
            Disclosed Qty
          </Text>
          <AddIcon
            style={{width: 28, height: 28, marginLeft: 8, color: root.color_text}}
          />
        </View>
        <View style={{flexDirection: 'row'}}>
          <View
            style={{
              marginTop: 16,
              flexDirection: 'row',
              alignItems: 'center',
              flex: 1,
            }}>
            <Text style={{fontSize: 14, color: root.color_text,fontFamily: Cfont.rubik_medium}}>
              Validity
            </Text>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  setValidityDialogVisible(true);
                  // navigation.navigate('SignupScreen');
                }}>
                <View
                  style={{
                    paddingHorizontal: 10,
                    paddingVertical: 2,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <Text style={{fontFamily: Cfont.rubik_regular, color: root.color_text}}>{validity}</Text>
                  <ExpandIcon
              style={{
                width: 16,
                height: 16,
                color: 'black',
                alignSelf: 'center',
                marginLeft: 4,
              }}
            />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          <View
            style={{
              marginTop: 16,
              flexDirection: 'row',
              alignItems: 'center',
              flex: 1,
              
            }}>
            <CheckBox
              value={marketOrder}
              onValueChange={setMarketOrder}
              style={{}}
            />
            <Text style={{fontSize: 14, color: root.color_text,fontFamily: Cfont.rubik_medium, marginLeft: 8}}>
              After Market Order
            </Text>
          </View>
        </View>
      </View>
      <ValidityDialog
        visible={validityDailogVisible}
        onClose={() => {
          setValidityDialogVisible(false);
        }}
        onChange={(v: any) => {
          setValidity(v.id);
          setValidityDialogVisible(false);
        }}
      />
      <MarketDepthDialog
        visible={marketDepthDailogVisible}
        onClose={() => {
          setMarketDepthDialogVisible(false);
        }}
      />
    </View>
  );
};
export default MarginPrice;

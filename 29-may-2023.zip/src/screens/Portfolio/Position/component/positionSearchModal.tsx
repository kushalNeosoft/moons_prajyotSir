import React, {useState} from 'react';
import {TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {positionSearchModal} from '../../../../theme/light';
const PositionSearchModal = ({modalVisible, setModalVisible}) => {
  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={positionSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View>
        <View style={positionSearchModal.headerView}>
          <TouchableOpacity
            style={positionSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={positionSearchModal.textInput}
            placeholder="Search your holdings eg: Axis, Reliance"
            placeholderTextColor={'grey'}
          />
          <TouchableOpacity onPress={() => {}}>
            <Text style={positionSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default PositionSearchModal;

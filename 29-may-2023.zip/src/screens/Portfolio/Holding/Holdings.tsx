import React, {useState, useEffect, useRef, useMemo, useCallback} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import HoldingList from './component/HoldingList';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SearchModal from './component/SearchModal';
import Tooltip from 'react-native-walkthrough-tooltip';
import {holdingScreen} from '../../../theme/light';
import TopHeader from './component/TopHeader';
import {useDispatch} from 'react-redux';
import {bottomTabshowhide, showAnimatedOverlay} from '../../../redux/Action';
import {useNavigation} from '@react-navigation/native';
import HoldingFilterComp from '../Component/HoldingFilterComp';
import Bottomsheet from '../../../components/BottomSheet/BottomSheet';

const Holdings = ({bottomSheetRef, setTabFilter}: any) => {
  const [stockData, setStockData] = useState([]);
  const [handleRefresh, setHandleRefresh] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [toolTipVisible, setToolTipVisible] = useState(false);
  // const bottomSheetRef = useRef<BottomSheet>(null);
  const dispatch = useDispatch();
  useEffect(() => {
    pushStockData();
  }, []);
  const pushStockData = () => {
    setHandleRefresh(true);
    let StockArraydata = [];
    for (let i = 0; i < 6; i++) {
      StockArraydata.push({
        companyName: 'ABB',
        title: `1000 @ Avg. ${1300.0 + 70 * i}`,
        PL: '19,30,250.00(148.48%)',
        LTP: '3,230.25(+0.83%)',
        index: 'NSE',
        value: 1035.78 + Math.floor(Math.random() * 999),
        changes: '+3.65(+0.44%)',
        invested: 3315000.56 + 47 * i,
        cmv: 3315000.42 + 92 * i,
      });
    }
    setStockData(StockArraydata);
    setHandleRefresh(false);
  };
  const renderItem = ({item}) => {
    return (
      <HoldingList
        stockName={item.companyName}
        stockTtile={item.title}
        PL={item.PL}
        LTP={item.LTP}
        invested={item.invested}
        cmv={item.cmv}
      />
    );
  };

  return (
    <View style={holdingScreen.container}>
      <TopHeader
        leftTopText={'Current value'}
        leftBottomText={'Overall P/L'}
        rightTopText={'Invested value'}
        rightBottomText={'Todays P/L'}
        currentVal={'18,73,38,879.00'}
        investedVal={'18,73,38,879.00'}
        overallPL={'83,73,60.00(98.36%)'}
        todaysPL={'83,73,60.00(98.36%)'}
      />
      <View style={holdingScreen.header}>
        <Text style={holdingScreen.headerScripsText}>
          {stockData.length} Scrips
        </Text>
        <View style={holdingScreen.headerIconsView}>
          <Tooltip
            isVisible={toolTipVisible}
            content={
              <Text style={holdingScreen.toolkitText}>
                PNC Infra gets provionsnal completion certificate
              </Text>
            }
            placement="bottom"
            childContentSpacing={1}
            contentStyle={holdingScreen.toolkitView}
            onClose={() => setToolTipVisible(false)}>
            <TouchableOpacity
              onPress={() => {
                setToolTipVisible(true);
              }}>
              <Ionicons
                name="information-circle-outline"
                size={18}
                color="black"
                style={holdingScreen.headerInfoIcon}
              />
            </TouchableOpacity>
          </Tooltip>
          <TouchableOpacity
            onPress={() => {
              // open Search modal here
              setModalVisible(true);
            }}>
            <Ionicons
              name="search-sharp"
              size={22}
              color="#303030"
              style={holdingScreen.headerSearchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              // dispatch(showAnimatedOverlay(true));
              setTabFilter('Holding');
              bottomSheetRef?.current?.snapToIndex?.(0);
            }}>
            <Ionicons
              name="options-outline"
              size={22}
              color="#303030"
              style={holdingScreen.headerFilterIcon}
            />
          </TouchableOpacity>
        </View>
      </View>
      <SearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
      <FlatList
        data={stockData}
        renderItem={renderItem}
        contentContainerStyle={{paddingBottom: 10}}
        keyExtractor={(_, index) => `item-${index}`}
        refreshing={handleRefresh}
        onRefresh={() => {
          pushStockData();
        }}
      />
      {/* <Bottomsheet ref={bottomSheetRef} index={-1}>
        <HoldingFilterComp />
      </Bottomsheet> */}
    </View>
  );
};
export default Holdings;

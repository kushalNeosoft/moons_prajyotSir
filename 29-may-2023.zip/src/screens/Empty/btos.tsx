import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Filtercom from '../WatchList/WatchListComponent/filtercom/Filtercom';
// import {styles} from '../../components/Component/BottomSheet/BottomSheetStyle';
// import CustomHeader from '../../components/Component/Header/CustomHeader';
// import Filtercom from '../../components/filtercom/Filtercom';
import {Cfont, Font, root} from '../../styles/colors';
import CustomHeader from '../../components/IndicesHeader/CustomHeader';
import { styles } from '../WatchList/StockDetailsStyle';

const Btos = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [percentageValue, setPercentageValue] = useState('');
  const [typeValue, setTypeValue] = useState('');
  const [priceValue, setPriceValue] = useState('');
  //   const dispatch = useDispatch();
  //   const navigation=useNavigation();
  const navigation = useNavigation();
  const navtoback = () => {
    navigation.goBack();
  };

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['High to Low', 'Low to High'];
  const type = ['A-Z', 'Z-A'];
  const percentage = ['High to Low', 'Low to High'];
  return (
    <View style={{height: '100%', backgroundColor: root.color_active}}>
      <CustomHeader
        title="Sort & Filter"
        leftComponent={
          <TouchableOpacity onPress={navtoback}>
            <Ionicons name="arrow-back" size={25} color={'black'} />
          </TouchableOpacity>
        }
        rightComponent={
          <TouchableOpacity onPress={navtoback}>
            <Text
              style={{
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                fontSize: Font.font_normal_two,
                alignSelf: 'center',
              }}>
              Clear
            </Text>
          </TouchableOpacity>
        }
      />
      <Filtercom/>
      <TouchableOpacity >
        <Text style={{color: root.color_active,fontSize:Font.font_normal_three,fontFamily:Cfont.rubik_medium}}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};
export default Btos;

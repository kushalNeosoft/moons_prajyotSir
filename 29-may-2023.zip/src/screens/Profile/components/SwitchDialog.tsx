import { useNavigation } from '@react-navigation/native';
import React from 'react';
import {Text, TouchableNativeFeedback, TouchableOpacity, View} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
// import AccountIcon from '../../../assets/AccountIcon';
// import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import CommonModal from '../../../components/CommonModal/CommonModal';
import { Cfont, Font, root } from '../../../styles/colors';

const SwitchDialog = (props:any) => {
  const navigation=useNavigation();
  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
    <View
      style={{width: '100%'}}
      onLayout={event => {
        var {x, y, width, height} = event.nativeEvent.layout;
        console.log(height);
      }}>
      <View style={{flexDirection:'row',justifyContent:'space-between', padding: 16}}>
      <Text style={{fontSize: Font.font_title, color: root.color_text, fontFamily:Cfont.rubik_medium}}>
        Switch Account
      </Text>
      <TouchableOpacity onPress={props.onClose} >
          <Entypo name='cross' size={29} color={'black'}/>
        </TouchableOpacity>
      </View>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {}}>
        <View style={{flexDirection: 'row', marginTop: 16, padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            <View
              style={{
                height: 12,
                width: 12,
                borderRadius: 6,
                backgroundColor: '#000',
              }}
            />
          </View>
          <Text style={{fontSize: Font.font_normal_one, fontWeight: 'bold', marginLeft: 16,color:root.client_background}}>
            OM
          </Text>
        </View>
      </TouchableNativeFeedback>
      <View style={{height: 2, backgroundColor: 'lightgray'}} />
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          navigation.navigate("LoginScreen");
        }}>
        <View style={{flexDirection: 'row', padding: 16, alignItems: 'center'}}>
          {/* <AccountIcon
            style={{
              height: 28,
              width: 28,
              color: 'black',
            }}
          /> */}
          <Text style={{fontSize: Font.font_normal_one, fontWeight: 'bold', marginLeft: 16,color:root.client_background}}>
            Use Another Account
          </Text>
        </View>
      </TouchableNativeFeedback>
    </View>
    </CommonModal>
  );
};

export default SwitchDialog;

import React, {useState} from 'react';
import {
  FlatList,
  Modal,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import alignment from '../../../components/utils/alignment';
import Feather from 'react-native-vector-icons/Feather';
import {Cfont, Font, root} from '../../../styles/colors';
import {RadioButton} from 'react-native-paper';
import { useDispatch } from 'react-redux';
import { changeScriptName } from '../../../redux/Action';

function OrdersModal(props: any) {
  const [order, setOrder] = useState(props.scriptName);
  const dispatch=useDispatch();

  const changeOrderName = (item: string) => {
    props.changeScriptName(item);
    dispatch(changeScriptName(item))
    setOrder(item);
    props.onClose();
  };
  
  const data = [
    'Single Script Orders',
    'Spread Orders',
    'Multileg Orders',
    'Good Till Date',
    'Equity SIP',
  ];

  const renderItem = ({item}: any) => {
    return (
      <TouchableOpacity
      activeOpacity={1}
        style={ordersModal.renderItemView}
        onPress={() => changeOrderName(item)}>
        <RadioButton
          color={root.color_text}
          value={item}
          onPress={() => {
            changeOrderName(item);
          }}
          status={order === item ? 'checked' : 'unchecked'}
        />
        <Text style={ordersModal.scriptsTxt}>{item}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
              <TouchableOpacity style={ordersModal.centeredView} onPress={() => props.onClose()} activeOpacity={1}></TouchableOpacity>
      <View style={ordersModal.container}>
        <View style={ordersModal.innerContainer}>
          <View style={{...alignment.row_SpaceB}}>
            <Text style={ordersModal.orderTxt}>Orders</Text>
            <TouchableOpacity onPress={() => props.onClose()}>
              <Feather name="x" size={25} color={'black'} />
            </TouchableOpacity>
          </View>
          <FlatList data={data} renderItem={renderItem} 
          style={{marginTop:16}}
          />
        </View>
      </View>
    </Modal>
  );
}

const ordersModal = StyleSheet.create({
  container: {
    position: 'absolute',
    height:'47%',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  innerContainer: {
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  orderTxt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  scriptsTxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
  },
  renderItemView: {
    ...alignment.row,
    alignItems: 'center',
    height: 48,
    paddingTop: 16,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position:'relative'
  },
});

export default OrdersModal;

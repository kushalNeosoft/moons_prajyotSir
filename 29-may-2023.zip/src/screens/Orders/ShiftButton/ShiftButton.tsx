import {memo} from 'react';
import React from 'react';
import {Text, TouchableHighlight, View, StyleSheet} from 'react-native';

const RenderButtons=(props:any)=>{
  return(
    <View style={shiftButton.tabBarContainer}>
    {props.buttons &&
      props.buttons.map((btn:any, key:any) => {
        return (
          <TouchableHighlight
            underlayColor={'#F0F2F5'}
            key={key}
            style={
              props.selectedBtn === key
                ? shiftButton.selectedTabBtns
                : shiftButton.unSelectedTabBtns
            }
            onPress={() => props.setButton(key)}>
            <Text
              style={
                props.selectedBtn === key
                  ? shiftButton.selectedBtnText
                  : shiftButton.tabBtnsText
              }>
              {btn}
            </Text>
          </TouchableHighlight>
        );
      })}
  </View>
  )
}

const shiftButton = StyleSheet.create({
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
});

export default memo(RenderButtons);

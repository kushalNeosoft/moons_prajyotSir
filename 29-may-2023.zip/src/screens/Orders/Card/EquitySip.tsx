import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';

const EquityCard = (props: any) => {
  return (
    <View style={equitySipCard.container}>
      <View style={equitySipCard.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={equitySipCard.companyNameTxt}>{props.name}</Text>
            <Text style={equitySipCard.nseTxt}>NSE</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center'}}>
            <Text style={equitySipCard.buyTxt}>Buy : </Text>
            <Text style={equitySipCard.buyQty}>{props.buy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center'}}>
            <Text style={equitySipCard.frequenctTxt}>{props.frequency}</Text>
            <Text style={equitySipCard.eqSIP}>EQ SIP</Text>
          </View>
        </View>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row,alignItems:"center"}}>
          <Text>Active</Text>
          <Ionicons name="md-at-circle-outline" size={15} style={{paddingLeft:10}}/>
          </View>
          <Text style={equitySipCard.installMent}>{props.installments}</Text>
          <Text style={equitySipCard.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};

const equitySipCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    height: 81,
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: 'green',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  eqSIP: {
    fontSize:Font.font_normal_six,
    color:'#25335C',
    fontFamily:Cfont.rubik_medium,
    backgroundColor:'#9AB3FF33',
    paddingHorizontal:6,
    borderRadius:30,paddingVertical:1,
    marginLeft:7
  },
});

export default EquityCard;

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { Cfont,Font,root } from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign'

const SpreadOrdersCard = (props: any) => {
  return (
    <View
      style={spreadOrders.container}>
      <View style={spreadOrders.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={spreadOrders.companyNameTxt}>{props.name}</Text>
            <Text style={spreadOrders.nseTxt}>NSE</Text>
          </View>
          <Text style={{color:'black'}}>{props.timePeriod}</Text>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={spreadOrders.sellTxt}>Sell - </Text>
            <Text style={spreadOrders.buyTxt}>Buy : </Text>
            <Text style={spreadOrders.buyQty}>{props.sellBuy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={spreadOrders.frequenctTxt}>{props.time}</Text>
            <Text style={spreadOrders.delivery}>Carryforward</Text>
          </View>
        </View>
        <View style={{justifyContent:'flex-end'}}>
          <View style={{...alignment.row,alignItems:'center',paddingBottom:15}}>
          <Text style={spreadOrders.completedTxt}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
          <Text style={spreadOrders.installMent}>{props.quantity}</Text>
          <Text style={spreadOrders.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};

const spreadOrders = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop:10
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop:10
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery:{
    fontSize:Font.font_normal_six,
    color:'#25335C',
    fontFamily:Cfont.rubik_medium,
    backgroundColor:'#9AB3FF33',
    paddingHorizontal:6,
    borderRadius:30,paddingVertical:1,
    marginLeft:7
  },
  sellTxt:{
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  completedTxt:{
    fontSize:Font.font_normal_one,
    fontFamily:Cfont.rubik_medium,
    color:root.color_text
  }
});

export default SpreadOrdersCard;

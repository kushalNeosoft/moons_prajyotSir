import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { Cfont,Font,root } from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign'

const GoodTillDateCard = (props: any) => {
  return (
    <View
      style={goodTillDateCard.container}>
      <View style={goodTillDateCard.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={goodTillDateCard.companyNameTxt}>{props.name}</Text>
            <Text style={goodTillDateCard.nseTxt}>NSE</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={goodTillDateCard.buyTxt}>Buy : </Text>
            <Text style={goodTillDateCard.buyQty}>{props.buy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={goodTillDateCard.frequenctTxt}>{`Valid till ${props.validity}`}</Text>
            <Text style={goodTillDateCard.delivery}>GTD</Text>
            <Text style={goodTillDateCard.delivery}>DELIVERY</Text>
          </View>
        </View>
        <View>
          <View style={{...alignment.row,alignItems:'center',paddingTop:10}}>
          <Text >Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
          <Text style={goodTillDateCard.installMent}>{props.quantity}</Text>
          <Text style={goodTillDateCard.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};

const goodTillDateCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop:10
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop:10
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery:{
    fontSize:Font.font_normal_six,
    color:'#25335C',
    fontFamily:Cfont.rubik_medium,
    backgroundColor:'#9AB3FF33',
    paddingHorizontal:6,
    borderRadius:30,paddingVertical:1,
    marginLeft:7
  }
});

export default GoodTillDateCard;

import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { useSelector } from 'react-redux';

const SingleScriptComp = React.forwardRef((props: any) => {
  const singleScriptData = useSelector(state => state.Reducer.bottomSheetData);
  console.log('Data in sheet in Sheet Component',singleScriptData)
  const orderdetails = [
    {
      title: 'Product Type',
      value: props.allData.productType,
    },
    {
      title: 'Quantity',
      value: props.allData.quantity,
    },
    {
      title: 'Price',
      value: props.allData.price,
    },
    {
      title: 'Validity',
      value: props.allData.validity,
    },
    {
      title: 'Stop Loss',
      value: props.allData.stopLoss,
    },
  ];

  const additionalDetails = [
    {
      title: 'Date & Time',
      value: props.allData.dateAndTime,
    },
    {
      title: 'Exchange date & Time',
      value: props.allData.exgDateAndTime,
    },
    {
      title: 'Exchange Order No.',
      value: props.allData.exgOrderNo,
    },
    {
      title: 'Initiated From',
      value: props.allData.initiatedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={singleSheetScript.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={singleSheetScript.companyName}>{props.allData.name}</Text>
          )}
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={singleSheetScript.buyTxt}>Buy : </Text>
            <Text style={singleSheetScript.marketRate}>{props.allData.buy}</Text>
          </View>
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={singleSheetScript.dayTxt}>{props.allData.dateAndTime} </Text>
            <Text style={singleSheetScript.delivery}>DELIVERY</Text>
          </View>
          <Text
            style={
              singleSheetScript.nxtDate
            }>{`Avg Price : ${props.allData.avgprice}`}</Text>
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 27, ...alignment.row}}>
              <Text style={singleSheetScript.activeTxt}>Completed</Text>
              <AntDesign name="checkcircle" size={15} color={'#4caf50'} />
            </View>
          )}
          <Text>{props.allData.quantity}</Text>
          <Text style={singleSheetScript.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
        </View>
      </View>
      {/*  */}
      <TouchableOpacity style={singleSheetScript.reOrderBtn}>
        <Text style={singleSheetScript.reOrderTxt}>Re-Order</Text>
      </TouchableOpacity>
      {/*  */}
            <Text>Trades Here</Text>
      {/*  */}
      <Text style={singleSheetScript.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={singleSheetScript.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={singleSheetScript.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={singleSheetScript.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={singleSheetScript.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={singleSheetScript.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
    </>
  );
});

const singleSheetScript = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 16,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export default SingleScriptComp;

import React, {useState} from 'react';
import {FlatList, TouchableHighlight, TouchableOpacity} from 'react-native';
import {View, Text, StyleSheet} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';

const NetPosition = (props: any) => {
  const buttons = ['Todays', 'Overall'];
  const [selectedBtn, setSelectedBtn] = useState<number>(0);

  const data = [
    {
      name: 'BAJAJ-AUTO',
      ltp: 4612.45,
      buy: '10 Qty@ ₹4623.00',
      todaysPL: '-105.50(-0.23%)',
      buyQty: 10,
      buyAvgPrice: 4632.0,
      buyTotalValue: '46,230.00',
      sellQty: 0,
      sellAvgPrice: 0.0,
      sellTotalValue: 0.0,
      netQty: 10,
      netAvgPrice: 4623.0,
      netTotalValue: '46,230.00',
    },
  ];

  const todays = () => {
    return <Text>Todays</Text>;
  };

  const renderOverallView = ({item}: any) => {
    return (
      <TouchableOpacity
        style={netPositionSheet.overAllCard}
        onPress={() => props.openModal()}>
        <View style={netPositionSheet.overAllCardInnerContainer}>
          <View style={netPositionSheet.companyDetailView}>
            <View style={netPositionSheet.companyNameView}>
              <Text style={netPositionSheet.companyNameTxt}>{item.name}</Text>
              <Text style={netPositionSheet.eqCombined}>EQ Combined</Text>
            </View>
            <View style={netPositionSheet.topView}>
              <Text style={netPositionSheet.ltp}>LTP : </Text>
              <Text style={netPositionSheet.ltp}>{item.ltp}</Text>
            </View>
          </View>
          <View style={netPositionSheet.qtyPlContainer}>
            <View style={netPositionSheet.buyQty}>
              <Text style={netPositionSheet.buyTxt}>Buy : </Text>
              <Text style={netPositionSheet.buyValue}>10 Qty@ ₹4623.00</Text>
            </View>
            <View style={{alignItems: 'flex-end'}}>
              <Text style={netPositionSheet.pL}>Today's P/L</Text>
              <Text style={netPositionSheet.plValue}>{item.todaysPL}</Text>
            </View>
          </View>
          <Text style={netPositionSheet.deliveryTxt}>Delivery</Text>
        </View>
      </TouchableOpacity>
    );
  };

  const overall = () => {
    return (
      <View style={{flex: 1}}>
        <View style={netPositionSheet.plContainer}>
          <View>
            <View style={netPositionSheet.plView}>
              <Text style={netPositionSheet.topPl}>Today's P/L : </Text>
              <Text style={netPositionSheet.plValue}>₹-160.00</Text>
            </View>
            <Text style={netPositionSheet.topPl}>{`Actual P/L : ₹${0.0}`}</Text>
          </View>
          <TouchableOpacity>
            <Text style={netPositionSheet.squareOffTxt}>Square-Off</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          style={{paddingTop: 16}}
          data={data}
          renderItem={renderOverallView}
        />
      </View>
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return todays();
      case buttons[1]:
        return overall();
    }
  };

  const renderBtn = () => {
    return (
      <View style={netPositionSheet.tabBarContainer}>
        {buttons &&
          buttons.map((btn, key) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? netPositionSheet.selectedTabBtns
                    : netPositionSheet.unSelectedTabBtns
                }
                onPress={() => setSelectedBtn(key)}>
                <View style={{...alignment.row, justifyContent: 'center'}}>
                  <Text
                    style={
                      selectedBtn === key
                        ? netPositionSheet.selectedBtnText
                        : netPositionSheet.tabBtnsText
                    }>
                    {btn}
                  </Text>
                  {/* <Text>0</Text> */}
                </View>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };

  return (
    <View style={netPositionSheet.container}>
      <Text style={netPositionSheet.netPositionTxt}>Net Position</Text>
      <Text style={netPositionSheet.pL}>{`P/L : ₹ 0`}</Text>
      {renderBtn()}
      {renderView(buttons[selectedBtn])}
    </View>
  );
};

const netPositionSheet = StyleSheet.create({
  container: {
    // backgroundColor: 'yellow',
  },
  netPositionTxt: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop:10
  },
  pL: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
    elevation:3,
    marginTop:12
  },
  plContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 16,
  },
  plView: {
    ...alignment.row,
  },
  overAllCard: {
    backgroundColor: root.color_active,
    marginVertical: 10,
    elevation: 3,
    shadowOpacity: 0.5,
  },
  overAllCardInnerContainer: {
    padding: 8,
  },
  companyDetailView: {
    ...alignment.row_SpaceB,
  },
  companyNameView: {
    ...alignment.row,
    alignItems: 'center',
  },
  topView: {
    ...alignment.row,
  },
  qtyPlContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 5,
  },
  buyQty: {
    ...alignment.row,
  },
  deliveryTxt: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  companyNameTxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ltp: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  plTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  topPl: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  squareOffTxt: {
    backgroundColor: root.client_background,
    color: root.color_active,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  eqCombined: {
    fontFamily: Cfont.rubik_medium,
    color: '#979797',
    fontSize: 9,
  },
});

export default NetPosition;

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { useSelector } from 'react-redux';

const SpreadOrdersComp = (props: any) => {
  const [showAdditionalDetails, setShowAdditionalDetails] = useState(false);
  const spreadOrdersData = useSelector(state => state.Reducer.bottomSheetData);
  console.log('Data in sheet in Sheet Component',spreadOrdersData)
  const orderdetails = [
    {
      title: 'Sell',
      value: props.allData.orderDetailsSell,
    },
    {
      title: 'Buy',
      value: props.allData.orderDetailsBuy,
    },
    {
      title: 'Quatity',
      value: props.allData.orderDetailsQty,
    },
    {
      title: 'Price',
      value: props.allData.orderDetailsPrice,
    },
    {
      title: 'Validity',
      value: props.allData.orderDetailsValidity,
    },
  ];

  const additionalDetails = [
    {
      title: 'Exchange Order No.',
      value: props.allData.additionalDetailsExgOrderNo,
    },
    {
      title: 'Order Type',
      value: props.allData.additionalDetailsOrderType,
    },
    {
      title: 'Client Order No.',
      value: props.allData.additionalDetailsClientOrderNo,
    },
    {
      title: 'Initiated From',
      value: props.allData.additionalDetailsInitiatedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.additionalDetailsModifiedFrom,
    },
    {
      title: 'Pre-Order',
      value: props.allData.additionalDetailsPreOrder,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={spreadOrdersSheet.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={spreadOrdersSheet.companyName}>{props.allData.name}</Text>
          )}
          <Text style={spreadOrdersSheet.timePeriodTxt}>{props.allData.timePeriod}</Text>
          <Text style={spreadOrdersSheet.executedTxt}>EXECUTED</Text>
        </View>
      </View>
      <View style={{...alignment.row_SpaceB, paddingTop: 8}}>
        <View style={{...alignment.row, alignItems: 'center'}}>
          <Text style={spreadOrdersSheet.sellTxt}>Sell - </Text>
          <Text style={spreadOrdersSheet.buyTxt}>Buy : </Text>
          <Text style={spreadOrdersSheet.buyQty}>{props.allData.sellBuy}</Text>
        </View>
        <Text style={spreadOrdersSheet.buyQty}>{props.allData.qty}</Text>
      </View>

      <View style={{...alignment.row_SpaceB, paddingTop: 8}}>
        <View style={{...alignment.row, alignItems: 'center'}}>
          <Text style={spreadOrdersSheet.sellTxt}>Sell : </Text>
          <Text style={spreadOrdersSheet.buyQty}>{props.allData.sell}</Text>
        </View>
        <View style={{...alignment.row, alignItems: 'center'}}>
          <Text style={spreadOrdersSheet.buyTxt}>Buy : </Text>
          <Text style={spreadOrdersSheet.buyQty}>{props.allData.buy}</Text>
        </View>
      </View>

      <View
        style={{...alignment.row_SpaceB, paddingTop: 8, alignItems: 'center'}}>
        <View style={{...alignment.row, alignItems: 'center'}}>
          <Text style={spreadOrdersSheet.buyQty}>{props.allData.timeAndDate}</Text>
          <Text>CarryForward</Text>
        </View>
        <Text style={spreadOrdersSheet.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
      </View>

      <View style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
        <Text style={spreadOrdersSheet.plTxt}>P/L : </Text>
        <Text style={spreadOrdersSheet.plValue}>{props.allData.pL}</Text>
      </View>
      {/*  */}
      <TouchableOpacity style={spreadOrdersSheet.reOrderBtn}>
        <Text style={spreadOrdersSheet.reOrderTxt}>Re-Order</Text>
      </TouchableOpacity>
      {/*  */}
      <Text style={spreadOrdersSheet.tradesTxt}>Trades</Text>
      {/* Add table here padding vertical 15px  */}
      {/*  */}
      <Text style={spreadOrdersSheet.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={spreadOrdersSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={spreadOrdersSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      {!showAdditionalDetails && (
        <TouchableOpacity
          style={{
            ...alignment.row,
            alignItems: 'center',
            height: 48,
          }}
          onPress={()=>setShowAdditionalDetails(true)}
          >
          <Text
            style={{
              fontSize: Font.font_normal_one,
              fontFamily: Cfont.rubik_medium,
              color: root.client_background,
            }}>
            Additional Details
          </Text>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
      )}
      {props.reachedTop && showAdditionalDetails && (
        <>
          <Text style={spreadOrdersSheet.orderDetailsTxt}>Additional Details</Text>
          <View style={{paddingVertical: 20, marginBottom: 50}}>
            <FlatList
              data={additionalDetails}
              renderItem={({item}) => (
                <View style={{...alignment.row, paddingTop: 10}}>
                  <View style={{width: '40%'}}>
                    <Text style={spreadOrdersSheet.detailedTitleTxt}>{item.title}</Text>
                  </View>
                  <View style={{width: '60%'}}>
                    <Text style={spreadOrdersSheet.detailedValueTxt}>{item.value}</Text>
                  </View>
                </View>
              )}
            />
          </View>
        </>
      )}
    </>
  );
};

const spreadOrdersSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 42,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  timePeriodTxt: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  executedTxt: {
    paddingTop: 10,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  sellTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  buyQty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_positive,
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
});

export default SpreadOrdersComp;

import React, {useRef} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import LinearGradient from 'react-native-linear-gradient';
import BottomSheet from '@gorhom/bottom-sheet';
import { useSelector } from 'react-redux';

const Component = (props: any) => {
  const bottomSheetRef = useRef<BottomSheet>(null);
  const storeEquityData = useSelector(state => state.Reducer.bottomSheetData);
  console.log('Data in sheet in Sheet Component',storeEquityData)
  const orderdetails = [
    {
      title: 'Product Type',
      value: props.allData.productType,
    },
    {
      title: 'Quantity',
      value: props.allData.quantity,
    },
    {
      title: 'Price',
      value: props.allData.price,
    },
    {
      title: 'Cap Price',
      value: props.allData.capPrice,
    },
    {
      title: 'No. of Installments',
      value: props.allData.noOfInstallments,
    },
    {
      title: 'Frequency',
      value: props.allData.frequency,
    },
    {
      title: 'Start Date',
      value: props.allData.startDate,
    },
    {
      title: 'Invested',
      value: props.allData.invested,
    },
    {
      title: 'CMV',
      value: props.allData.CMV,
    },
  ];

  const additionalDetails = [
    {
      title: 'SIP ID',
      value: props.allData.sipId,
    },
    {
      title: 'Transaction Type',
      value: props.allData.transactionType,
    },
    {
      title: 'Order Entry Date',
      value: props.allData.orderEntryDate,
    },
    {
      title: 'Pending Installments',
      value: props.allData.pendingInstallments,
    },
    {
      title: 'Installments Completed',
      value: props.allData.installmentsCompleted,
    },
    {
      title: 'Failed Installments',
      value: props.allData.failedInstallments,
    },
    {
      title: 'Rejection Reason',
      value: props.allData.rejectionReason,
    },
    {
      title: 'Initiated From',
      value: props.allData.initiatedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={styles.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={styles.companyName}>{props.allData.name}</Text>
          )}
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={styles.buyTxt}>Buy : </Text>
            <Text style={styles.marketRate}>{props.allData.buy}</Text>
          </View>
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={styles.dayTxt}>{props.allData.day} </Text>
            <Text style={styles.eqSIP}>EQ SIP</Text>
          </View>
          <Text
            style={
              styles.nxtDate
            }>{`Next date : ${props.allData.nextDate}`}</Text>
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 27, ...alignment.row}}>
              <Text style={styles.activeTxt}>Active</Text>
              <Ionicons name="md-at-circle-outline" size={15} />
            </View>
          )}
          <Text style={styles.installments}>{props.allData.installments}</Text>
          <Text style={styles.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
        </View>
      </View>
      {/*  */}
      <View style={{height: 40, ...alignment.row_SpaceB, marginTop: 32}}>
        <TouchableOpacity style={styles.modifyBtn}>
          <Text style={styles.modifyOrderTxt}>Modify Order</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.cancelBtn}>
          <Text style={styles.cancelOrderTxt}>Cancel Order</Text>
        </TouchableOpacity>
      </View>
      {/*  */}
      <Text style={styles.orderHistoryTxt}>Order History</Text>
      <Text style={styles.noOrdersTxt}>
        No order so far : Next Order due on 7 May'23{' '}
      </Text>
      {/*  */}
      <Text style={styles.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={styles.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={styles.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={styles.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={styles.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={styles.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  modifyBtn: {
    width: 171,
    backgroundColor: root.client_background,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelBtn: {
    width: 153,
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modifyOrderTxt: {
    color: 'white',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  cancelOrderTxt: {
    color: '#25335c',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installments: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  eqSIP: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export default Component;

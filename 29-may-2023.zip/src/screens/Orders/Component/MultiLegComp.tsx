import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Modal,
} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {RadioButton} from 'react-native-paper';
import { useSelector } from 'react-redux';

const MultiLegComp = (props: any) => {
  const [modalVisible, setModalVisible] = useState(false);
  const multiLegData = useSelector(state => state.Reducer.bottomSheetData);
  console.log('Data in sheet in Sheet Component',multiLegData)
  const orderdetails = [
    {
      title: 'Product Type',
      value: 'Multileg',
    },
    {
      title: 'Quantity',
      value: 500,
    },
    {
      title: 'Price',
      value: 1422.2,
    },
    {
      title: 'Validity',
      value: '10C',
    },
    {
      title: 'Exchange Order No.',
      value: 133050,
    },
  ];

  const additionalDetails = [
    {
      title: 'Date & Time',
      value: "11:58:07 AM, 25 May '23",
    },
    {
      title: 'Initiated From',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Pre-Order',
      value: '-',
    },
  ];

  const legData = [
    {
      name: 'BAJAJFINSV',
      date: "25 MAY'23 FUT",
      ltp: 1422.35,
      qty: '500/500 Qty',
      buyOrSell: 'Buy',
      buy: '500 Qty @ 1422.00',
    },
    {
      name: 'BAJAJFINSV',
      date: "25 MAY'23 FUT",
      ltp: 1413.35,
      qty: '500/500 Qty',
      buyOrSell: 'Sell',
      buy: '500 Qty @ 1413.40',
    },
  ];

  const closeModal = () => {
    setModalVisible(prevState => !prevState);
  };

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={multiLegSheet.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={multiLegSheet.companyName}>{props.allData.name}</Text>
          )}
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 20, ...alignment.row}}>
              <Text style={multiLegSheet.activeTxt}>Completed</Text>
              <AntDesign name="checkcircle" size={15} color={'#4caf50'} />
            </View>
          )}
        </View>
      </View>
      {/*  */}
      <View
        style={{...alignment.row_SpaceB, alignItems: 'center', paddingTop: 5}}>
        <View>
          <View style={{...alignment.row}}>
            <Text>{`${props.allData.time} 25 May'23`}</Text>
            <Text style={multiLegSheet.leg}>2 leg</Text>
          </View>
          <Text style={multiLegSheet.multileg}>Multileg</Text>
        </View>
        <View style={{...alignment.row, alignItems: 'center'}}>
          <Text style={multiLegSheet.plTxt}>P/L</Text>
          <Text style={multiLegSheet.plValue}>-100(0.01%)</Text>
        </View>
      </View>
      <Text style={multiLegSheet.active}>EXECUTED</Text>
      {/*  */}

      <View>
        {legData.map(item => (
          <View
            style={{
              ...alignment.row_SpaceB,
              alignItems: 'center',
              paddingTop: 16,
            }}>
            <View>
              <Text style={multiLegSheet.name}>{item.name}</Text>
              <Text style={multiLegSheet.date}>{item.date}</Text>
              <View style={{...alignment.row, paddingTop: 5}}>
                <Text
                  style={
                    item.buyOrSell === 'Buy' ? multiLegSheet.buyTxt : multiLegSheet.sellTxt
                  }>{`${item.buyOrSell} : `}</Text>
                <Text style={multiLegSheet.buyValue}>{item.buy}</Text>
              </View>
            </View>
            <View>
              <View style={{...alignment.row}}>
                <Text style={multiLegSheet.ltpTxt}>LTP : </Text>
                <Text style={multiLegSheet.ltpValue}>{item.ltp}</Text>
              </View>
              <Text style={multiLegSheet.quantity}>{item.qty}</Text>
            </View>
          </View>
        ))}
      </View>

      {/*  */}
      <TouchableOpacity style={multiLegSheet.reOrderBtn}>
        <Text style={multiLegSheet.reOrderTxt}>Re-Order</Text>
      </TouchableOpacity>
      {/*  */}
      <Text style={multiLegSheet.tradesTxt}>Trades</Text>
      {/*  */}
      <Text style={multiLegSheet.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <TouchableOpacity
        style={{...alignment.row, paddingTop: 32, alignItems: 'center'}}
        onPress={() => setModalVisible(prevState => !prevState)}>
        <Text style={multiLegSheet.orderName}>BAJAJFINSV 25 May'23 FUT</Text>
        <AntDesign
          name="caretdown"
          size={10}
          color={'black'}
          style={{paddingLeft: '4%'}}
        />
      </TouchableOpacity>
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '55%'}}>
                <Text style={multiLegSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '45%'}}>
                <Text style={multiLegSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={multiLegSheet.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={multiLegSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={multiLegSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      <Modal
        visible={modalVisible}
        onRequestClose={closeModal}
        transparent={true}>
        <TouchableOpacity
          style={multiLegSheet.centeredView}
          onPress={closeModal}
          activeOpacity={1}></TouchableOpacity>
        <View style={multiLegSheet.modalContainer}>
          <View style={{...alignment.row_SpaceB}}>
            <Text style={multiLegSheet.modalSelectLeg}>Select Leg</Text>
            <TouchableOpacity onPress={closeModal}>
              <AntDesign name="close" size={24} color={'black'} />
            </TouchableOpacity>
          </View>
          <View
            style={{...alignment.row, paddingTop: 32, alignItems: 'center'}}>
            <RadioButton
              color={root.color_text}
              value={'abc'}
              // onPress={() => {
              //   changeOrderName(item);
              // }}
              status={'checked'}
            />
            <Text style={multiLegSheet.legName}>BAJAJFINSV 25 MAY'23 FUT</Text>
          </View>
        </View>
      </Modal>
    </>
  );
};

const multiLegSheet = StyleSheet.create({
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 32,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  leg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'center',
  },
  multileg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'flex-start',
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  name: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  date: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  sellTxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  quantity: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 24,
  },
  orderName: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    top: '70%',
    backgroundColor: 'white',
    paddingHorizontal: 16,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    paddingVertical: 16,
  },
  modalSelectLeg: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  legName: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export default MultiLegComp;

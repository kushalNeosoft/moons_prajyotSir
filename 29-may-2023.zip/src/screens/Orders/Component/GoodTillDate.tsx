import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { useSelector } from 'react-redux';

const GoodTillDateComp =(props: any) => {
  const storeGoodTillDateData = useSelector(state => state.Reducer.bottomSheetData);
  console.log('Data in sheet in Sheet Component',storeGoodTillDateData)
  const orderdetails = [
    {
      title: 'Product Type',
      value: props.allData.productType,
    },
    {
      title: 'Order Type',
      value: props.allData.quantity,
    },
    {
      title: 'Ordered Qty',
      value: props.allData.price,
    },
    {
      title: 'Traded Qty',
      value: props.allData.validity,
    },
    {
      title: 'Open Qty',
      value: props.allData.stopLoss,
    },
    {
      title: 'Quantity',
      value: props.allData.stopLoss,
    },
    {
      title: 'Price',
      value: 300,
    },
    {
      title: 'Validity',
      value: "29 May'23",
    },
    {
      title: 'Stop Loss',
      value: '0.00',
    },
  ];

  const additionalDetails = [
    {
      title: 'Date & Time',
      value: props.allData.dateAndTime,
    },
    {
      title: 'Exchange date & Time',
      value: props.allData.exgDateAndTime,
    },
    {
      title: 'Exchange Order No.',
      value: props.allData.exgOrderNo,
    },
    {
      title: 'GTD Order ID',
      value: props.allData.initiatedFrom,
    },
    {
      title: 'GTD Order Status',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Order Entry Date',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Initiated From',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={goodTillDateSheet.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={goodTillDateSheet.companyName}>{props.allData.name}</Text>
          )}
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={goodTillDateSheet.buyTxt}>Buy : </Text>
            <Text style={goodTillDateSheet.marketRate}>{props.allData.buy}</Text>
          </View>
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={goodTillDateSheet.dayTxt}>
              {`Valid till ${props.allData.validity}`}{' '}
            </Text>
            <Text style={goodTillDateSheet.delivery}>GTD</Text>
            <Text style={goodTillDateSheet.delivery}>DELIVERY</Text>
          </View>
          <Text style={goodTillDateSheet.active}>COMPLETED</Text>
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 20, ...alignment.row}}>
              <Text style={goodTillDateSheet.activeTxt}>Completed</Text>
              <AntDesign name="checkcircle" size={15} color={'#4caf50'} />
            </View>
          )}
          <Text style={goodTillDateSheet.qty}>{props.allData.qty}</Text>
          <Text style={goodTillDateSheet.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
        </View>
      </View>
      {/*  */}
      <TouchableOpacity style={goodTillDateSheet.reOrderBtn}>
        <Text style={goodTillDateSheet.reOrderTxt}>Re-Order</Text>
      </TouchableOpacity>
      {/*  */}
      <Text style={goodTillDateSheet.orderHistoryTxt}>Order History</Text>
      <Text style={goodTillDateSheet.noOrdersTxt}>No order so far</Text>
      {/*  */}
      <Text style={goodTillDateSheet.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={goodTillDateSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={goodTillDateSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={goodTillDateSheet.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={goodTillDateSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={goodTillDateSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
    </>
  );
};

const goodTillDateSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 16,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  qty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
});

export default GoodTillDateComp;

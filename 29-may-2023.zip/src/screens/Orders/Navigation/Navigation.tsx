import React, {memo, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Modal,
} from 'react-native';
import Bottomsheet from '../../../components/BottomSheet/BottomSheet';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../../styles/colors';
import Component from '../Component/Component';
import {Table, Row, Rows,Col,TableWrapper} from 'react-native-table-component';
import {
  selectOpenOrders,
  selectCompletedOrders,
  selectAllOrders,
} from '../helpers/SelectOrder';
import SingleScriptComp from '../Component/SingleScript';
import NetPosition from '../Component/NetPosition';
import SpreadOrdersComp from '../Component/SpreadOrders';
import GoodTillDateComp from '../Component/GoodTillDate';
import MultiLegComp from '../Component/MultiLegComp';
import RenderButtons from '../ShiftButton/ShiftButton';
import RenderCardView from '../helpers/RenderCardView';
import HeaderComp from '../HeaderComp/HeaderComp';
import { useDispatch } from 'react-redux';
import { showInBottomSheetData } from '../../../redux/Action';

const Navigation = React.forwardRef((props: any, ref) => {
  const buttons = ['Open', 'Completed', 'All Orders'];
  const [reachedTop, setReachedTop] = useState(false);
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [allData, setAllData] = useState({});
  const [openNetPosition, setOpenNetPosition] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalData, setModalData] = useState<object>({});
  const [additionalDetailsVisible, setAdditionalDetailsVisible] =
    useState(false);

  const tableHead = ['', 'Qty', 'Avg Price', 'Total Value'];
  const tableData = [
    ['1', '7.05', '7.05'],
    ['0', '0.00', '0.00'],
    ['1', '7.05', '-7.05'],
  ];
  const tableTitle=['Buy','Sell','Net'];
  const dispatch=useDispatch();

  const open = () => {
    return (
      <FlatList
        style={{flex: 1}}
        data={selectOpenOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const completed = () => {
    return (
      <FlatList
        data={selectCompletedOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const allOrders = () => {
    return (
      <FlatList
        data={selectAllOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return open();
      case buttons[1]:
        return completed();
      case buttons[2]:
        return allOrders();
    }
  };

  const renderComponent = () => {
    if (openNetPosition) {
      return <NetPosition openModal={openModal} />;
    } else {
      switch (props.scriptName) {
        case 'Single Script Orders':
          return <SingleScriptComp allData={allData} reachedTop={reachedTop} />;
        case 'Equity SIP':
          return <Component allData={allData} reachedTop={reachedTop} />;
        case 'Spread Orders':
          return <SpreadOrdersComp allData={allData} reachedTop={reachedTop} />;
        case 'Good Till Date':
          return <GoodTillDateComp allData={allData} reachedTop={reachedTop} />;
        case 'Multileg Orders':
          return <MultiLegComp allData={allData} reachedTop={reachedTop} />;
      }
    }
  };

  const getHeightValue = (value: boolean) => {
    setReachedTop(value);
  };

  const openSheet = async (item?: object) => {
    setOpenNetPosition(false);
    setAllData(item);
    dispatch(showInBottomSheetData(item));
    await props.onPress();
  };

  const netPositionSheetView = async () => {
    setOpenNetPosition(true);
    // setAllData({name:'himanshu',age:24}) pas value like this for the header
    await props.onPress();
  };

  const closeModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const openModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const setSelectedButton = (value: any) => {
    setSelectedBtn(value);
  };

  const addtionalDetailsComp = () => {
    return (
      <View style={styles.container}>
        <Table >
          <Row data={tableHead}  style={styles.head} textStyle={styles.headText}/>
          <TableWrapper style={styles.wrapper}>
            <Col data={tableTitle} heightArr={[48,48]} textStyle={styles.headText}/>
            <Rows data={tableData} flexArr={[1, 1,1]} style={styles.row} textStyle={styles.dataText}/>
          </TableWrapper>
        </Table>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <HeaderComp
        orderModalToggle={props.orderModalToggle}
        scriptName={props.scriptName}
      />
      <View style={styles.netPositionValueContainer}>
        <TouchableOpacity
          style={{...alignment.row, alignItems: 'center'}}
          onPress={netPositionSheetView}>
          <Text style={styles.netPositionTxt}>Net Position</Text>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
        <Text style={styles.pLvalueTxt}>Today's P/L: 0</Text>
      </View>
      <RenderButtons
        buttons={buttons}
        selectedBtn={selectedBtn}
        setButton={setSelectedButton}
      />
      {renderView(buttons[selectedBtn])}
      <Bottomsheet
        ref={ref}
        index={props.index}
        getHeightValue={getHeightValue}
        closeSheet={() => props.closeSheet()}
        scriptName={props.scriptName}
        allData={allData}>
        {renderComponent()}
      </Bottomsheet>
      <Modal visible={modalVisible} transparent={true}>
        <View
          style={styles.centeredView}
        />
        <View style={additionalDetailsVisible?styles.modalFullView: styles.modalView}>
          <AntDesign
            name="close"
            size={24}
            color={'black'}
            style={{alignSelf: 'flex-end'}}
          />
          <View style={styles.modalCompanyTitleView}>
            <View style={styles.modalCompanyName}>
              <Text style={styles.name}>IDEA</Text>
              <Text style={styles.eqCombined}>EQ Combined</Text>
            </View>
            <View style={styles.modalCompanyName}>
              <Text style={styles.todaysPlTxt}>Today's P/L : </Text>
              <Text style={styles.todaysPlValue}>0.05(0.71%)</Text>
            </View>
          </View>
          <View style={styles.modalCompanyTitleView}>
            <View style={styles.modalCompanyName}>
              <Text style={styles.buyTxt}>Buy</Text>
              <Text style={styles.buyValue}>1 Qty @ ₹7.05</Text>
            </View>
            <View style={styles.modalCompanyName}>
              <Text style={styles.ltpTxt}>LTP : </Text>
              <Text style={styles.ltpValue}>7.05(0.71%)</Text>
            </View>
          </View>
          <Text style={styles.delivery}>Delivery</Text>
          <TouchableOpacity
            style={styles.additionalDetailsTxt}
            onPress={() =>
              setAdditionalDetailsVisible(prevState => !prevState)
            }>
            <Text style={styles.additionalDetailsText}>Additional Details</Text>
            {!additionalDetailsVisible ? (
              <AntDesign
                name="caretdown"
                size={10}
                color={'black'}
                style={{paddingLeft: '4%'}}
              />
            ) : (
              <AntDesign
                name="caretup"
                size={10}
                color={'black'}
                style={{paddingLeft: '4%'}}
              />
            )}
          </TouchableOpacity>
          {additionalDetailsVisible ? <>{addtionalDetailsComp()}</> : null}
          <View style={styles.btnContainer}>
            <View style={styles.btns}>
              <Text style={styles.btnTxt}>Convert Position</Text>
            </View>
            <View style={styles.btns}>
              <Text style={styles.btnTxt}>Add More</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.squareOffBtn}>
            <Text style={styles.btnTxt}>Square Off</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
});

const styles = StyleSheet.create({
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  netPositionValueContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: '4%',
    alignItems: 'center',
    backgroundColor: '#F0F2F5',
    height: 56,
    paddingVertical: 4,
  },
  netPositionTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
  },
  pLvalueTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '45%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    paddingVertical: 30,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  modalFullView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '65%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    paddingVertical: 30,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  modalCompanyTitleView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 10,
  },
  modalCompanyName: {
    ...alignment.row,
    alignItems: 'center',
  },
  additionalDetailsTxt: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: 16,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
  },
  btns: {
    height: 38,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    borderRadius: 10,
    marginTop: 32,
  },
  squareOffBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 38,
    borderWidth: 1,
    marginTop: 32,
    borderColor: root.client_background,
    borderRadius: 10,
  },
  name: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  eqCombined: {
    fontSize:9,
    fontFamily:Cfont.rubik_medium,
    color:'#979797',
    backgroundColor:'#9797971A',
    paddingHorizontal:5,
  },
  todaysPlTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  todaysPlValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  additionalDetailsText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  btnTxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },

  container: { backgroundColor: '#fff' ,paddingTop:10},
  head: {paddingLeft:'10%'},
  wrapper: { flexDirection: 'row' },
  row: {  height: 48 },
  headText: {
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
  },
  dataText:{
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
    alignSelf:'center'
  }
});

export default memo(Navigation);

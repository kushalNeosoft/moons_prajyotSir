import React from "react";
import { Text, View } from "react-native";

const Analysis: React.FC =()=>{
    return(
        <View>
            <Text>
                Analysis
            </Text>
        </View>
    )
}

export default Analysis;
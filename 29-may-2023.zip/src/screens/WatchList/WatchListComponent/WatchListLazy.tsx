import React, {
  useEffect,
  useState,
  useCallback,
  useRef,
  useContext,
  useMemo,
} from 'react';
import {
  Alert,
  BackHandler,
  Image,
  LogBox,
  PixelRatio,
  Pressable,
  StyleSheet,
} from 'react-native';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Dimensions,
  Modal,
} from 'react-native';

// import Dotmoda from '../../../Component/DotModal/DotModal';
import DotModal from './ThreeDotDrawer/ThreeDotDrawer';
// import Header from '../../../Component/Header/Header';
import Header from '../../../components/IndicesHeader/IndicesHeader';
// import NorModal from '../../../Component/NorModal/NorModal';
import NorModal from './WatchlistDrawer/WatchlistDrawer';
// import TrendModal from '../../../Component/TrendModal/TrendModal';
import TrendModal from './TrendDrawer/TrendDrawer';
//  import {texts} from '../../../constants/text';

import {GestureHandlerRootView} from 'react-native-gesture-handler';
// import {assets} from '../../../assets';
// import alignment from '../../../utils/alignment';

// import DeleteModal from '../../../Component/DeleteModal/DeleteModal';
import DeleteModal from '../../../components/DeleteModal/DeleteModal';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import Fontisto from 'react-native-vector-icons/Fontisto';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {demoData} from '../../../components/replacement-svg/demoData';
import BottomSheet,{BottomSheetBackdrop} from '@gorhom/bottom-sheet';
import {
  CommonActions,
  useFocusEffect,
  useNavigation,
} from '@react-navigation/native';
import CarouselList from './CarouselList/CarouselList';
import { ListItemProps } from './CarouselList/type';
import RNExitApp from 'react-native-exit-app';
import {texts} from './CommonText/text'
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useDispatch} from 'react-redux';
import {bottomTabshowhide} from '../../../redux/Action';
import CustomHeader from '../../../components/IndicesHeader/CustomHeader';
import Filtercom from './filtercom/Filtercom';
import { CloseModal, constituentsScreen, nortabstyles, SortModal, watchlistdata } from '../../../theme/light';
import StockListView from '../../../components/StockListView/StockListView';

const screenHeight = Dimensions.get('window').height;
interface StockListProps {
  navigation: any;
}

const StockLazy = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState<ListItemProps[]>([]);
  const [norModalVisible, setNorModalVisible] = useState(false);
  const [trendModalVisible, setTrendModalVisible] = useState(false);
  const [dotModalVisible, setDotModalVisible] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const [colorChange, setColorChange] = useState(false);
  const [carouselView, setCarouselView] = useState(false);
  const [visibleBottom, setvisibleBottom] = useState(false);
  const [visiblno, setvisibleno] = useState<number>(-1);
  const navigation = useNavigation();
  const listRef = useRef(0);
  const dispatch = useDispatch();
  const toggleRef = useRef(true);
  const bottomSheetRef = useRef<BottomSheet>(null);

  const pressalert = () => {
    Alert.alert('Work in Progress');
  };
useEffect(()=>{
  pushStockData()
},[])

  var randomStock = [
    'BRITANIA',
    'AXISBANK',
    'TCS',
    'ULTRACEMCO',
    'BPCL',
    'DIVISLAB',
    'MARUTI',
    'LT',
  ];
  var randomPrice = ['295.03', '443.05', '220.54', '577.94'];
  var gainerLoser = ['Vol.Gainer', 'Pr.Loser', ''];
  var showIcon = [true, false];
  var iconName = ['crown-circle', 'pie-chart-2'];
  var colors = ['#FF0000', '#D60707', '#4CAF50', '#B70404'];

  const pushStockData = () => {
    let StockArraydata = [];
    for (let i = 0; i < 15; i++) {
      StockArraydata.push({
        companyName:randomStock[Math.floor(Math.random() * randomStock.length)],
        title: gainerLoser[Math.floor(Math.random() * gainerLoser.length)],
        index: 'NSE',
        value: randomPrice[Math.floor(Math.random() * randomPrice.length)],
        changes: '+3.65(+0.44%)',
        showIcon: showIcon[Math.floor(Math.random() * showIcon.length)],
        iconName: iconName[Math.floor(Math.random() * iconName.length)],
        colors: colors[Math.floor(Math.random() * colors.length)],
      });
    }
    setStockData(StockArraydata);
  };

  useFocusEffect(
    React.useCallback(() => {
      BackHandler.addEventListener('hardwareBackPress', handleBackButton);

      return () => {
        BackHandler.removeEventListener('hardwareBackPress', handleBackButton);
      };
    }, []),
  );

  const cinfirmCLode = () => {
    RNExitApp.exitApp();
    setModalVisible(!modalVisible);
  };

  const handleBackButton = () => {
    setModalVisible(true);
    return true; // Returning true prevents the app from closing
  };

  const onPress = () => {
    // if(bottomSheetRef){
    bottomSheetRef.current?.snapToIndex(0);
    //  }

    
    dispatch(bottomTabshowhide(false))
    //  ref?.current?.scrollTo(-500);
  };

  const componentHeaderBlock = () => {
    return (
      <View style={nortabstyles.headerComponentView}>
        <TouchableOpacity
          onPress={() => setNorModalVisible(true)}
          style={nortabstyles.norflex}>
          <Text style={nortabstyles.Nortxt}>{texts.NOR}</Text>
          <View style={nortabstyles.downicon}>
            <Ionicons name="ios-caret-down-sharp" size={15} color={root.color_text} />
          </View>
        </TouchableOpacity>
        <View style={nortabstyles.headerFlexEndView}>
          <TouchableOpacity onPress={() => setTrendModalVisible(true)}>
            <MaterialIcons name="offline-bolt" color={'orange'} size={25} />
            <Text style={nortabstyles.lenght}>6</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{borderWidth: 1, borderRadius: 20}}
            onPress={pressalert}>
            <Text style={nortabstyles.addText}>{texts.ADD}</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={onPress}>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setDotModalVisible(true)}>
            <Entypo name="dots-three-vertical" color={'black'} size={20} />
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  const onPressItem = (index: any) => {
    listRef.current = index;
    dispatch(bottomTabshowhide(false));
    setCarouselView(true);
  };

  const renderListView=({item,index}:any)=>{
    return(
      <TouchableOpacity  onPress={() => onPressItem(index)}>
        <StockListView
          stockName={item.companyName}
          stockTtile={item.title}
          price={item.value}
          changes={item.changes}
          index={index}
          title={item.title}
          showIcon={item.showIcon}
          iconName={item.iconName}
          screenName="WatchList"
          
        />
        </TouchableOpacity>
       
    )
  }

  // const renderListView = ({item, index}: any) => {
    
  //   return (
  //     <TouchableOpacity style={watchlistdata.stock} onPress={() => onPressItem(index)}>
  //       <View style={watchlistdata.stockcomp}>
  //         <View style={watchlistdata.felxrow}>
  //           <Text style={watchlistdata.stocktxt}>{item.stockName}</Text>
  //           <View style={watchlistdata.Nsetxt}>
  //             <Text style={watchlistdata.index}>{item.stockfrom}</Text>
  //           </View>
  //           <Text
  //             style={watchlistdata.Atxt}>
  //             A
  //           </Text>
  //         </View>
  //         <View>
  //           {item.portfolio == true ? (
  //             <>
  //               <View
  //                 style={watchlistdata.nertxt}>
  //                 <Fontisto name="pie-chart-2" size={12} color={'black'} />
  //                 <Text style={watchlistdata.valtxt}>{item.value}</Text>
  //                 {item.plus != '' ? (
  //                   <>
  //                     <Text style={watchlistdata.plustxt}>{item.plus}</Text>
  //                   </>
  //                 ) : item.minus != '' ? (
  //                   <>
  //                     <Text style={watchlistdata.minustxt}>{item.minus}</Text>
  //                   </>
  //                 ) : null}
  //               </View>
  //             </>
  //           ) : (
  //             <>
  //               <View style={{...alignment.row}}>
  //                 {item.tag?
  //                 null
  //                 :
  //                 <>
  //                   <MaterialCommunityIcons
  //                   name="crown-circle"
  //                   size={16}
  //                   color="#ffd700"
  //                 />
  //                 </>
  //                 }
  //                 {item.tag?
  //                 <>
  //                 <View style={watchlistdata.felxrow}>
  //                   <Text style={watchlistdata.valtxt}>{item.date}</Text>
  //                   {item.future?
  //                   <>
  //                   <Text style={[watchlistdata.valtxt]}>{item.future}</Text>
  //                   </>
  //                   :
  //                   <>
  //                   <Text style={[watchlistdata.valtxt]}>{item.tag}</Text>
  //                   </>
  //                   }
                    
  //                 </View>

  //                 </>
  //                 :
  //                 <>
                  // <Text
                  //   style={
                  //     item.title === 'Vol.Gainer'
                  //       ? watchlistdata.volGainerTxt
                  //       : item.title === 'Pr.Loser'
                  //       ? watchlistdata.prLoserTxt
                  //       : watchlistdata.defaultTxt
                  //   }>
                  //   {item.title}
                  // </Text>

  //                 </>

  //                 }
                  
  //               </View>
  //             </>
  //           )}
  //         </View>
  //       </View>
  //       <View style={{flex: 2.9}}>
  //         <View
  //           style={
  //             colorChange
  //               ? watchlistdata.stockContainerPositive
  //               : watchlistdata.stockContainerNegative
  //           }>
  //           <Text style={watchlistdata.stockPriceText}>{item.price}</Text>
  //           <Text
  //             style={[
  //               watchlistdata.perchantxt,
  //               {
  //                 color:
  //                   item.portfolio == true
  //                     ? root.color_positive
  //                     : 
  //                     item.changes=='0.00(0.00)'?
  //                     root.color_text:
  //                     root.color_negative
  //               },
  //             ]}>
  //             {item.changes}
  //           </Text>
  //         </View>
  //       </View>
  //       <View
  //         style={watchlistdata.endcom}>
  //         <TouchableOpacity style={watchlistdata.endT}>
  //           <Text style={watchlistdata.endTtext}>T</Text>
  //         </TouchableOpacity>
  //       </View>
  //     </TouchableOpacity>
  //   );
   
  // };

  // const pushStockData = () => {
  //   let StockArraydata = [];
  //   for (let i = 0; i < 20; i++) {
  //     StockArraydata.push({
  //       companyName: Math.floor(Math.random() * 99),
  //       index: 'NSE',
  //       value: Math.floor(Math.random() * 999),
  //       dayValue: '35.15',
  //       percentage: '1.65',
  //       id: i,
  //     });
  //   }
  //   setStockData(StockArraydata);
  // };

  const onNorClose = () => {
    setNorModalVisible(prevState => !prevState);
  };

  const onTrendClose = () => {
    setTrendModalVisible(prevState => !prevState);
  };

  const onDotModalClose = () => {
    setDotModalVisible(prevState => !prevState);
  };

  const onDeleteClose = () => {
    setDeleteModal(prevState => !prevState);
  };

  const showDeleteModal = () => {
    setDeleteModal(prevState => !prevState);
  };

  const onCloseCarousel = () => {
    setCarouselView(false);
    dispatch(bottomTabshowhide(true));
  };
  console.log(carouselView, 'Stock---->');
  const snapPoints = useMemo(() => ['50%', '100%',], []);

  const handleSheetChanges = useCallback((index: number) => {
    console.log('handleSheetChanges', typeof(index));
    if (index === 1) {
        navigation.navigate('Btos')
        setTimeout(()=>{
          bottomSheetRef.current?.close()
        },2000) 
    }else if(index === -1){
      dispatch(bottomTabshowhide(true))
    }
  },[] );

  
  

  const renderBackdrop = useCallback(
    
    (props: any) => (
      <BottomSheetBackdrop
        {...props}
        disappearsOnIndex={-1}
        appearsOnIndex={0}
      />
      
    ),
    [],
  );

  return (
    <GestureHandlerRootView style={watchlistdata.flexallign}>
      <Header />
      {componentHeaderBlock()}
      <View style={watchlistdata.flatallign}>
        <FlatList data={stockData} renderItem={renderListView} />
      </View>
      {carouselView ? (
        <CarouselList
          listData={stockData}
          index={listRef.current}
          onCloseCarousel={onCloseCarousel}
          carouselView={carouselView}
        />
      ) : null}
      <NorModal
        visible={norModalVisible}
        onClose={onNorClose}
        showDeleteModal={showDeleteModal}
      />
      <TrendModal visible={trendModalVisible} onClose={onTrendClose} />
      <DotModal
        visible={dotModalVisible}
        onClose={onDotModalClose}
        stockDataList={stockData}
      />

      {/* <BottomSheet ref={ref} /> */}
      <BottomSheet
        ref={bottomSheetRef}
        index={visiblno}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}
        backdropComponent={renderBackdrop}>
        <Text style={SortModal.Sorttitle}>Sort & Filter</Text>
        <Filtercom/>
      </BottomSheet>

      <DeleteModal visible={deleteModal} onClose={onDeleteClose} />
      <Modal
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
        transparent={true}>
        <TouchableOpacity
          style={CloseModal.centeredView}
          onPress={() => setModalVisible(false)}
          activeOpacity={1}>
          <View style={CloseModal.modalView}>
            <View style={CloseModal.innermain}>
              <Text
                style={CloseModal.Wavetitle}>
                Wave 2
              </Text>
              <AntDesign name="exclamationcircle" size={40} color="grey" />
            </View>
            <View
              style={CloseModal.leftallign}>
              <Text style={CloseModal.modalText}>Do you want to exit the app?</Text>

              <View
                style={{flexDirection: 'row', justifyContent: 'space-around'}}>
                <Pressable
                  style={[CloseModal.button]}
                  onPress={cinfirmCLode}>
                  <Text style={CloseModal.textStyle}>Confirm</Text>
                </Pressable>
                <Pressable
                  style={[CloseModal.buttontwo]}
                  onPress={() => setModalVisible(!modalVisible)}>
                  <Text style={CloseModal.textStyletwo}>Cancle</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
    </GestureHandlerRootView>
  );
};




export default React.memo(StockLazy);
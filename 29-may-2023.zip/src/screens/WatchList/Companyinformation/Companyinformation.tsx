import React from "react";
import { Text, View } from "react-native";

const Companyinformation: React.FC =()=>{
    return(
        <View>
            <Text>
            Companyinformation
            </Text>
        </View>
    )
}

export default Companyinformation;
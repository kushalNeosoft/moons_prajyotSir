import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {styles} from '../../navigators/Curverbottom';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import SquareOffList from './Component/SquareOffList';

const SquareOff = () => {
  const overallData = [
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
  ];
  const navigation = useNavigation();
  const renderItem = ({item}) => {
    return (
      <SquareOffList
        stockName={item.companyName}
        buy={item.buy}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };
  return (
    <View style={squareOff.container}>
      <View style={squareOff.subContainer}>
        <View style={squareOff.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="arrowleft" style={squareOff.backIcon} />
          </TouchableOpacity>
          <Text style={squareOff.squareOffText}>Square Off</Text>
        </View>
        <View style={squareOff.orderHeadView}>
          <Text style={squareOff.orderText}>Orders(8)</Text>
          <TouchableOpacity style={squareOff.selectAllTextIconView}>
            <Text style={squareOff.selectAllText}>Select All</Text>
            <MaterialIcons
              name="check-box-outline-blank"
              style={squareOff.selectAllIcon}
            />
          </TouchableOpacity>
        </View>
        <View style={squareOff.headerBorder}></View>
        {/* FlateList code */}
        <FlatList
          data={overallData}
          renderItem={renderItem}
          contentContainerStyle={{marginTop: 20, paddingBottom: 70}}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View style={squareOff.bottomView}>
        <View style={squareOff.bottominnerView}>
          <View>
            <Text style={squareOff.bottomSquareOffText}>square-off</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                // justifyContent: 'center',
              }}>
              <Text style={squareOff.bottomSelectedText}>Selected Orders</Text>
              <View style={squareOff.bottomCountView}>
                <Text style={squareOff.bottomCountText}>1</Text>
              </View>
            </View>
          </View>
          <TouchableOpacity style={squareOff.bottomDoneBtn}>
            <Text style={squareOff.bottomDoneText}>Done</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default SquareOff;

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {squareOffList} from '../../../theme/light';

const SquareOffList = props => {
  const [clicked, setClicked] = useState(false);
  return (
    // <View style={{}}>
    <>
      <TouchableOpacity
        style={squareOffList({clicked: clicked}).container}
        onPress={() => {
          setClicked(!clicked);
        }}>
        <View style={{alignItems: 'flex-start'}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Text style={squareOffList(clicked).listTitle}>
              {props.stockName}
            </Text>
            <View style={squareOffList(clicked).titleChip}>
              <Text style={squareOffList(clicked).titleChipText}>
                {props.titleChip}
              </Text>
            </View>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Text style={squareOffList(clicked).buyText}>{props.status} </Text>
            <Text style={squareOffList(clicked).listSubTitle}>{props.buy}</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <Text style={squareOffList(clicked).listPlText}>P/L : </Text>
            <Text style={squareOffList(clicked).listPlValue}>
              {props.todaysPL}
            </Text>
          </View>
          <View style={squareOffList(clicked).bottomChip}>
            <Text style={squareOffList(clicked).bottomChipText}>
              {props.bottomChip}
            </Text>
          </View>
        </View>
        <View style={squareOffList(clicked).listPlLtpView}>
          <MaterialIcons
            name="check-box-outline-blank"
            style={squareOffList(clicked).selectAllIcon}
          />
        </View>
      </TouchableOpacity>
    </>
    // </View>
  );
};
export default SquareOffList;

import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  Linking,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import { link } from '../../theme/light';

const ExchangeLink = () => {
  const [links, setLinks] = useState([]);
  const navigation = useNavigation();

  const loadData = async () => {
    fetch(
      'https://pre-prod1.odinwave.com/nontransactional/1404/v1/getExchangeLinks',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        setLinks(data.result);
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View
      style={link.main}>
      <View
        style={link.shadowone}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={link.backicon} />
        </TouchableOpacity>


        <Text
          style={link.header}>
          Links
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {links.map((link: any, index: any) => {
            return (
              <TouchableNativeFeedback
                key={index}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  Linking.openURL(link.sLinkAddress);
                }}>
                <View
                  key={index}
                  style={{
                    backgroundColor: 'white',
                    marginHorizontal: 16,
                    marginVertical: 8,
                    borderRadius: 8,
                    paddingVertical: 12,
                    paddingHorizontal: 16,
                    shadowColor: '#000',
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.23,
                    shadowRadius: 2.62,
                    elevation: 4,
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontSize: 16,
                      color: root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    {link.sLinkTitle}
                  </Text>
                  <BackIcon
                    style={{width: 28, height: 28, color: root.color_text}}
                  />
                </View>
              </TouchableNativeFeedback>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
};
export default ExchangeLink;

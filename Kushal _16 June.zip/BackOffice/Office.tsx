import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { link } from '../../theme/light';

const Office = () => {
  const navigation = useNavigation();
  
  return (
    <View
      style={link.main}>
      <View
        style={link.shadowone}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={link.backicon} />
        </TouchableOpacity>

        <Text style={link.header}>
          BackOffice
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          
              <View
                
                style={link.shadowtwo}>
                  <View>
                <Text
                  style={link.cardtext}>
                 Profit Loss Summry
                </Text>
                <Text
                  style={link.cardsub}>
                 View your profit loss report
                </Text>
                </View>
                <BackIcon style={link.BackiconSide} />
              </View>

              <View
                
                style={link.shadowtwo}>
                  <View>
                <Text
                  style={link.cardtext}>
                 Ledger Report
                </Text>
                <Text
                  style={link.cardsub}>
                Your ledge report is available here
                </Text>
                </View>
                <BackIcon style={link.BackiconSide} />
              </View>
              <View
                
                style={link.shadowtwo}>
                  <View>
                <Text
                  style={link.cardtext}>
                 F&O Outstanding Report
                </Text>
                <Text
                  style={link.cardsub}>
                View your F&O outstanding report
                </Text>
                </View>
                <BackIcon style={link.BackiconSide} />
              </View>
              <View
                
                style={link.shadowtwo}>
                  <View>
                <Text
                  style={link.cardtext}>
                 Holdings View
                </Text>
                <Text
                  style={link.cardsub}>
                 Click here to see your holdings
                </Text>
                </View>
                <BackIcon style={link.BackiconSide} />
              </View>
              <View
                
                style={link.shadowtwo}>
                  <View>
                <Text
                  style={link.cardtext}>
                My Profile
                </Text>
                <Text
                  style={link.cardsub}>
                 Profile information
                </Text>
                </View>
                <BackIcon style={link.BackiconSide} />
              </View>
           
        </ScrollView>
      </View>
    </View>
  );
};
export default Office;

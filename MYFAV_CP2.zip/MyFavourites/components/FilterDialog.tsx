import React, { useState } from 'react';
//import {View, Text} from 'react-native';
import { Cfont, Font, root } from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import SegmentDialog from './SegmentDialog';
import SectorDialog from './SectorDialog';
import ExchangeDialog from './ExchangeDialog';
import { filterDialog } from '../../../theme/light';


const FilterDialog = (props: any) => {
  const { item, visible, onClose } = props;
  const [exchangeDialogVisibility, setExchageDialogVisibility] =
    useState(false);

  const [SegmentDialogVisibility, setSegmentDialogVisibility] =
    useState(false);
  const [SectorDialogVisibility, setSectorDialogVisibility] =
    useState(false);


  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={filterDialog.main}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={filterDialog.main2}>

        <View style={filterDialog.dialogMain}>
          <View style={filterDialog.dialogMain2}>
            <Text
              style={filterDialog.headerText}>
              Sort & Filter
            </Text>
            <TouchableNativeFeedback
              onPress={() => {
                props.onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={filterDialog.closeView}>
                <CloseIcon style={filterDialog.closeIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <TouchableOpacity
            onPress={() => {
              setSegmentDialogVisibility(true);
            }}>
            <View
              style={filterDialog.Containt}>
              <Text
                style={filterDialog.Text}>
                Segment
              </Text>
              <View style={filterDialog.DropdownText}>
                <Text>Equity</Text>
                <ExpandIcon
                  style={filterDialog.ExpandIcon}
                />
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setExchageDialogVisibility(true);
            }}>
            <View
              style={filterDialog.Containt2}>
              <Text
                style={filterDialog.Text}>
                Exchange
              </Text>
              <View style={filterDialog.DropdownText}>
                <Text>NSE Index</Text>
                <ExpandIcon
                  style={filterDialog.ExpandIcon}
                />
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setSectorDialogVisibility(true);
            }}>

            <View
              style={filterDialog.Containt}>
              <View style={{ flex: 1 }}>
                <Text
                  style={filterDialog.Text}>
                  Index
                </Text>
                <Text style={{ fontSize: 10 }}>Optional*</Text>
              </View>

              <View style={filterDialog.DropdownText}>
                <Text>NIFTY 200</Text>
                <ExpandIcon
                  style={filterDialog.ExpandIcon}
                />
              </View>
            </View>
          </TouchableOpacity>
          <TouchableNativeFeedback
            // disabled={!filled}
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              // setConfirmOrderVisible(true);
            }}>
            <View
              style={filterDialog.ButtonMain}>
              <Text
                style={filterDialog.ButtonText}>
                Apply
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <ExchangeDialog
        visible={exchangeDialogVisibility}
        onClose={() => {
          setExchageDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setExchageDialogVisibility(false);
        }}
      />
      <SegmentDialog
        visible={SegmentDialogVisibility}
        onClose={() => {
          setSegmentDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSegmentDialogVisibility(false);
        }}
      />
      <SectorDialog
        visible={SectorDialogVisibility}
        onClose={() => {
          setSectorDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSectorDialogVisibility(false);
        }}
      />
    </Modal>
  );
};
export default FilterDialog;

import React, {useState} from 'react';
import {
  View,
  Modal,
  Text,
  TouchableOpacity,
  TextInput,
  StyleSheet,
} from 'react-native';
import {netPositionSheet, ordersNavigation} from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import {
  Table,
  Row,
  Rows,
  Col,
  TableWrapper,
} from 'react-native-table-component';
import moment from 'moment';
import {Cfont, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import {RadioButton} from 'react-native-paper';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import SuccessModal from '../SquareOff/components/SuccessModal/SuccessModal';

const DetailsModal = (props: any) => {
  const [modalData, setModalData] = useState(props?.data);
  const [additionalDetailsVisible, setAdditionalDetailsVisible] =
    useState(false);
  const [selectedProductType, setSelectedProductType] = useState('');
  const [productTypeModal, setProductTypeModal] = useState(false);
  const tableHead = ['', 'Qty', 'Avg Price', 'Total Value'];
  const tableData = [
    [props.data?.buy_quantity, props.data?.avg_buy_price, props.data?.buy_value],
    [props.data?.market_lot, '0.00', props.data?.cf_sell_value],
    [props.data?.net_quantity, props.data?.net_price, props.data?.net_value],
  ];
  console.log(modalData?.buy_quantity,'buy qty')
  console.log(props.data)
  const [successModal, setSuccessModal] = useState(false);
  const [conversionView, setConversionView] = useState(false);
  const navigation = useNavigation<any>();
  const tableTitle = ['Buy', 'Sell', 'Net'];
  const productType = ['Intraday', 'MTF', 'BTST'];

  const toggleChooseProductTypeModal = () => {
    setProductTypeModal(prev => !prev);
  };

  const toggleSuccessModal = () => {
    setSuccessModal(prev => !prev);
  };

  const navigateToSquareOff = (data:any) => {
    props.onClose();
    props.closeSheet();
    navigation.navigate('SquareOffOrders',{data:data});
  };

  const goToMain = () => {
    toggleSuccessModal();
    toggleChooseProductTypeModal();
    props.onClose();
    props.closeSheet();
  };

  const addtionalDetailsComp = () => {
    return (
      <View style={ordersNavigation.container}>
        <Table>
          <Row
            data={tableHead}
            style={ordersNavigation.head}
            textStyle={ordersNavigation.headText}
          />
          <TableWrapper style={ordersNavigation.wrapper}>
            <Col
              data={tableTitle}
              heightArr={[48, 48]}
              textStyle={ordersNavigation.headText}
            />
            <Rows
              data={tableData}
              flexArr={[1, 1, 1]}
              style={ordersNavigation.row}
              textStyle={ordersNavigation.dataText}
            />
          </TableWrapper>
        </Table>
      </View>
    );
  };

  return (
    <Modal
      visible={props.visible}
      transparent={true}
      onRequestClose={() => props.onClose()}>
      <View style={ordersNavigation.centeredView} />
      <View style={ordersNavigation.modalView}>
        <TouchableOpacity onPress={() => props.onClose()}>
          <AntDesign
            name="close"
            size={24}
            color={'black'}
            style={{alignSelf: 'flex-end'}}
          />
        </TouchableOpacity>
        <View style={ordersNavigation.modalCompanyTitleView}>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.name}>{props.data?.symbol}</Text>
            <Text style={ordersNavigation.eqCombined}>
              {props.data?.exchange}
            </Text>
          </View>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.todaysPlTxt}>Today's P/L : </Text>
            <Text style={ordersNavigation.todaysPlValue}>0.05(0.71%)</Text>
          </View>
        </View>
        <Text style={netPositionSheet.expiryTxt}>{`${moment(
          modalData?.expiry_date,
        ).format("DD MMM'YY")} FUT`}</Text>
        <View style={ordersNavigation.modalCompanyTitleView}>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.buyTxt}>Sell : </Text>
            <Text
              style={
                netPositionSheet.marketLotNetPrice
              }>{`${props.data?.market_lot} Qty@ ₹${props.data?.net_price}`}</Text>
          </View>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.ltpTxt}>LTP : </Text>
            <Text style={ordersNavigation.ltpValue}>7.05(0.71%)</Text>
          </View>
        </View>
        <Text style={ordersNavigation.delivery}>Carryforward</Text>
        <TouchableOpacity
          style={ordersNavigation.additionalDetailsTxt}
          onPress={() => setAdditionalDetailsVisible(prevState => !prevState)}>
          <Text style={ordersNavigation.additionalDetailsText}>
            Additional Details
          </Text>
          {!additionalDetailsVisible ? (
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={{paddingLeft: '4%'}}
            />
          ) : (
            <AntDesign
              name="caretup"
              size={10}
              color={'black'}
              style={{paddingLeft: '4%'}}
            />
          )}
        </TouchableOpacity>
        {additionalDetailsVisible ? <>{addtionalDetailsComp()}</> : null}
        <View style={ordersNavigation.btnContainer}>
          <TouchableOpacity
            style={ordersNavigation.btns}
            onPress={toggleChooseProductTypeModal}>
            <Text style={ordersNavigation.btnTxt}>Convert Position</Text>
          </TouchableOpacity>
          <View style={ordersNavigation.btns}>
            <Text style={ordersNavigation.btnTxt}>Add More</Text>
          </View>
        </View>
        <TouchableOpacity
          style={ordersNavigation.squareOffBtn}
          onPress={()=>navigateToSquareOff(props.data)}>
          <Text style={ordersNavigation.btnTxt}>Square Off</Text>
        </TouchableOpacity>
        <Modal visible={productTypeModal} transparent={true}>
          <View style={productTypeModalStyles.background} />
          <View
            style={[
              productTypeModalStyles.modalContainer,
              {height: conversionView ? '42%' : '50%'},
            ]}>
            {!conversionView ? (
              <View>
                <TouchableOpacity onPress={toggleChooseProductTypeModal}>
                  <AntDesign
                    name="close"
                    size={24}
                    color={root.color_text}
                    style={productTypeModalStyles.close}
                  />
                </TouchableOpacity>
                <Text style={productTypeModalStyles.titletxt}>Choose</Text>
                <Text style={productTypeModalStyles.titletxt}>
                  Product Type
                </Text>
                <View
                  style={productTypeModalStyles.productTypesContainer}>
                  <View>
                    {productType.map(item => {
                      return (
                        <View style={productTypeModalStyles.particularProductType}>
                          <RadioButton
                            color={root.color_text}
                            value={item}
                            onPress={() => setSelectedProductType(item)}
                            status={
                              selectedProductType === item
                                ? 'checked'
                                : 'unchecked'
                            }
                          />
                          <Text style={productTypeModalStyles.itemTxt}>
                            {item}
                          </Text>
                        </View>
                      );
                    })}
                  </View>
                  <TouchableOpacity
                    onPress={() => setConversionView(prev => !prev)}
                    style={productTypeModalStyles.changeQty}>
                    <Text
                      style={productTypeModalStyles.qtyTxt}>{`Qty : 5`}</Text>
                    <MaterialCommunityIcons
                      name="pencil"
                      size={15}
                      color={root.color_text}
                    />
                  </TouchableOpacity>
                </View>
                <TouchableOpacity
                  style={productTypeModalStyles.btnContainer}
                  onPress={toggleSuccessModal}>
                  <Text style={productTypeModalStyles.btnTxt}>
                    Convert Position
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={{flex: 1}}>
                <TouchableOpacity onPress={() => setConversionView(prev => !prev)}>
                  <AntDesign
                    name="close"
                    size={24}
                    color={root.color_text}
                    style={conversionModalStyles.close}
                  />
                </TouchableOpacity>
                <Text style={conversionModalStyles.titleTxt}>Convert to</Text>
                <Text style={conversionModalStyles.titleTxt}>
                  Intraday Order
                </Text>
                <Text style={conversionModalStyles.qtyTxt}>Qty</Text>
                <TextInput style={conversionModalStyles.txtIp} />
                <Text
                  style={conversionModalStyles.qty}>{`Net Qty: 5 NSE : 5`}</Text>
                <TouchableOpacity
                  style={conversionModalStyles.btn}
                  onPress={() => {
                    setConversionView(prev => !prev);
                    toggleSuccessModal();
                  }}>
                  <Text style={conversionModalStyles.btnTxt}>
                    Convert Position
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </Modal>
        <SuccessModal visible={successModal} onClose={goToMain} />
      </View>
    </Modal>
  );
};

const productTypeModalStyles = StyleSheet.create({
  background: {
    flex: 1,
    backgroundColor: 'black',
    position: 'relative',
  },
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
    flex: 1,
  },
  titletxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
    paddingHorizontal: 16,
  },
  itemTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
    color: root.color_text,
    paddingLeft: 10,
  },
  qtyTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 14,
    color: root.color_text,
    paddingRight: 12,
  },
  btnContainer: {
    height: 40,
    backgroundColor: root.client_background,
    borderRadius: 10,
    ...alignment.alignC_justifyC,
    marginTop: 16,
    marginHorizontal: 16,
  },
  btnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
  },
  close:{
    alignSelf: 'flex-end',
    paddingHorizontal: 26,
    paddingTop: 16,
  },
  productTypesContainer:{
    ...alignment.row_SpaceB,
    paddingTop: 16,
    paddingHorizontal: 16,
  },
  particularProductType:{
    ...alignment.row_alignC, paddingTop: 16
  },
  changeQty:{
    ...alignment.row,
    alignItems: 'flex-start',
    paddingTop: 24,
  }
});

const conversionModalStyles = StyleSheet.create({
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
    paddingHorizontal: 16,
  },
  qtyTxt: {
    paddingTop: 26,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 14,
    paddingHorizontal: 16,
  },
  txtIp: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 30,
    color: root.color_text,
    width: '40%',
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
    marginHorizontal: 16,
  },
  btn: {
    height: 40,
    backgroundColor: root.client_background,
    ...alignment.alignC_justifyC,
    marginTop: 32,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  btnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
  },
  close:{
    alignSelf: 'flex-end',
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  qty:{
    paddingHorizontal: 16,fontFamily:Cfont.rubik_regular,color:root.color_text
  }
});

export default React.memo(DetailsModal);

import React, {useEffect, useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {Announce, NewsComp, messageSearchModal} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';
import DropDownIcon from '../../../assets/DropDownIcon';
import moment from 'moment';
import NewsListComponent from '../Component/NewsListComponent';

const timeSince = (date: any) => {
  const now = new Date();

  var seconds = Math.floor((now.getTime() - date) / 1000);

  var interval = seconds / 31536000;
  if (interval > 1) {
    return Math.floor(interval) + ' years ago';
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + ' months ago';
  }
  interval = seconds / 604800;
  if (interval > 1) {
    return Math.floor(interval) + ' weeks ago';
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + ' days ago';
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + ' hours ago';
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + ' minutes ago';
  }
  return 'now';
};

const HotPersuitSearchDialog = ({visible, onClose}: any) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const [news, setNews] = useState([]);

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      const filterTempList = news.filter((item: any) => {
        return item.Heading.toLowerCase().includes(value.toLowerCase());
      });
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const loadNewsList = async () => {
    const headers = new Headers();
    headers.append('jTenantToken', '1');
    headers.append('jTenantid', '1404');
    fetch('https://pre-prod1.odinwave.com/cds/1404/v1/10/GetHotPursuitData', {
      method: 'GET',
      headers: headers,
    })
      .then(response => {
        return response.json();
      })
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setNews(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadNewsList();
  }, []);

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={{flex: 1}}>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
              setTextInputValue('');
              setFilterData([]);
            }}>
            <BackIcon style={Announce.back} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search Broker Messages"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: 'white', flex: 1}}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={messageSearchModal.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={({item}: any) => {
                return (
                  <NewsListComponent
                    title={item.Heading}
                    stockName={item.ScripData_NSE.Symbol}
                    price={'123.20'}
                    change={'-2.05 (-17%)'}
                    time={item.Time}
                    clickLeft={() => {
                      // setDialog(true);
                    }}
                  />
                );
              }}
            />
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default HotPersuitSearchDialog;

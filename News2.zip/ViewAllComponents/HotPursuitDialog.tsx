import React, {useEffect, useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  Modal,
  TouchableNativeFeedback,
  ScrollView,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import CloseIcon from '../../../assets/CloseIcon';
import {TouchableHighlight} from '@gorhom/bottom-sheet';
import {TextInput} from 'react-native-gesture-handler';
import SearchIcon from '../../../assets/SearchIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import {HotpurDialog} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';

const HotPursuitDialog = (props: any) => {
  const [viewMore, setViewMore] = useState(false);
  const {item, visible, onClose} = props;

  const list = [1, 2, 2, 4, 4, 1];

  return (
    <Modal
      // visible={props.visible} onClose={props.onClose}
      //  visible={visible}
      //  onRequestClose={() => {
      // }}
      //   transparent={true}
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={HotpurDialog.main}
        onPress={() => onClose()}
        activeOpacity={1}></TouchableOpacity>

      <View style={HotpurDialog.MainDialog}>
        <View style={HotpurDialog.TimeView}>
          <Text style={HotpurDialog.Time}>7/10/2023 12:00:00 AM</Text>
          <View style={HotpurDialog.HeadingView}>
            <Text style={HotpurDialog.Heading}>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </Text>
          </View>
          <ScrollView>
            <View>
              <View style={HotpurDialog.Submain}>
                <Text style={HotpurDialog.SubHeading}>
                  Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard.Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard.Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard. Lorem Ipsum is simply dummy text of the printing and
                  typesetting industry. Lorem Ipsum has been the industry's
                  standard
                </Text>
              </View>
              <View style={HotpurDialog.BackgroundView}>
                <View style={HotpurDialog.View1}>
                  <Text style={HotpurDialog.Dont}>Don't miss out</Text>
                  <View style={HotpurDialog.round}>
                    <Text style={HotpurDialog.roundtxt}>2</Text>
                  </View>
                </View>

                <View style={HotpurDialog.Stockmain}>
                  <TouchableOpacity>
                    <View style={HotpurDialog.StockView}>
                      <Text style={HotpurDialog.Exc}>NSE</Text>
                      <Text style={HotpurDialog.stock}>ASHOKELAY</Text>
                      <Text style={HotpurDialog.price}>123</Text>
                      <Text style={HotpurDialog.percent}>-120.0(-0.3%)</Text>
                    </View>
                  </TouchableOpacity>
                  <TouchableOpacity>
                    <View>
                      <Text style={HotpurDialog.Exc}>NSE</Text>
                      <Text style={HotpurDialog.stock}>RELIANCE</Text>
                      <Text style={HotpurDialog.price}>123</Text>
                      <Text style={HotpurDialog.percent}>-120.0(-0.3%)</Text>
                    </View>
                  </TouchableOpacity>
                </View>
                {viewMore && (
                  <TouchableOpacity>
                    <View style={HotpurDialog.StockView}>
                      <Text style={HotpurDialog.Exc}>NSE</Text>
                      <Text style={HotpurDialog.stock}>AXIS BANK</Text>
                      <Text style={HotpurDialog.price}>820</Text>
                      <Text style={HotpurDialog.percent}>+20.0(56.3%)</Text>
                    </View>
                  </TouchableOpacity>
                )}
                <TouchableOpacity
                  onPress={() => {
                    setViewMore(prev => !prev);
                  }}>
                  <View style={HotpurDialog.ShowmoreMain}>
                    <Text style={HotpurDialog.Show}>
                      Show {viewMore ? 'Less' : 'More'}
                    </Text>
                    <ExpandIcon style={HotpurDialog.Expand} />
                  </View>
                </TouchableOpacity>
              </View>
              <Text style={HotpurDialog.OtherNews}>Other News</Text>
              <FlatList
                data={list}
                renderItem={({i}: any) => {
                  return (
                    <View
                      style={{borderRadius: 32, overflow: 'hidden'}}
                      key={i}>
                      <TouchableNativeFeedback>
                        <View style={HotpurDialog.FlatMain}>
                          <Text style={HotpurDialog.FlatHeader}>
                            Reliance Industries Ltd Surgies 1.99%. Reliance
                            Industries Ltd Surgies 1.99%.
                          </Text>
                          <View>
                            <Text style={HotpurDialog.FlatDes}>
                              Powered by Capital Market
                            </Text>
                            <Text style={HotpurDialog.FlatTime}>
                              12/12/2023 12.00 AM
                            </Text>
                          </View>
                        </View>
                      </TouchableNativeFeedback>
                    </View>
                  );
                }}
                keyExtractor={(_, index) => `item-${index}`}
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                horizontal={true}
              />
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
};
export default HotPursuitDialog;

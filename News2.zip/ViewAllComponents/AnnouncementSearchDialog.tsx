import React, {useEffect, useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {Announce, messageSearchModal} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';
import DropDownIcon from '../../../assets/DropDownIcon';

const AnnouncementItem = ({announcement, expanded, setExpanded}: any) => {
  // const [expanded, setExpanded] = useState(false);
  const [showSelectExchange, setShowSelectExchange] = useState(false);
  const [selectedExchange, setSelectedExchange] = useState('NSE');

  return (
    <TouchableOpacity
      key={announcement.Symbol}
      onPress={() => {
        setExpanded();
        // setSelectedNews(item);
        // setNewsDialog(true);
      }}>
      <View style={Announce.CardBack} key={announcement.SNo}>
        <Text style={Announce.Cap}>{announcement.Caption}</Text>
        {expanded && <Text style={Announce.Memo}>{announcement.Memo}</Text>}

        <Text style={Announce.date}>{announcement.Date}</Text>
        <View
          style={[Announce.SearchMain,
            {transform: [{rotateZ: expanded ? '180deg' : '0deg'}]}
          ]}>
          <DropDownIcon style={Announce.DropDown} />
        </View>
      </View>
    </TouchableOpacity>
  );
};

const AnnouncementSearchDialog = ({visible, onClose}: any) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const [announcement, setAnnouncements] = useState([]);
  const [expandedSymbol, setExpandedSymbol] = useState(-1);

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      const filterTempList = announcement.filter((item: any) => {
        return item.Caption.toLowerCase().includes(value.toLowerCase());
      });
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };

  useEffect(() => {
    const loadData = async () => {
      const headers = new Headers();
      headers.append('jTenantToken', '1');
      headers.append('jTenantid', '1404');
      fetch(
        'https://pre-prod1.odinwave.com/cds/1404/v1/NSE/1/10/GetAnnoucementsData',
        {
          method: 'GET',
          headers: headers,
        },
      )
        .then(response => {
          return response.json();
        })
        .then((data): any => {
          if (data.ResponseObject.type === 'success') {
            const temp: any = announcement.map(i => i);
            temp.push(data.ResponseObject.resultset);
            setAnnouncements(data.ResponseObject.resultset);
          }
        })
        .catch(error => console.log('error', error));
    };
    loadData();
  }, []);

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={{flex: 1}}>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
              setTextInputValue('');
              setFilterData([]);
            }}>
            <BackIcon style={Announce.back} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search Market News"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: 'lightgrey', flex: 1}}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={messageSearchModal.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={(item: any) => {
                return (
                  <AnnouncementItem
                    announcement={item.item}
                    key={item.item.CompanyCode}
                    expanded={item.item.Symbol === expandedSymbol}
                    setExpanded={() => {
                      if (expandedSymbol === item.item.Symbol)
                        setExpandedSymbol(-1);
                      else setExpandedSymbol(item.item.Symbol);
                    }}
                  />
                );
              }}
            />
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default AnnouncementSearchDialog;

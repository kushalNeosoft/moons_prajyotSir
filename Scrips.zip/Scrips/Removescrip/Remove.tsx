import * as React from 'react';
import {
  TouchableOpacity,
} from 'react-native-gesture-handler';
import {Removescripstyle} from '../../../../theme/light';
import {View, Text, FlatList} from 'react-native';
import {demoData} from '../../../../assets/demoData';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';
import Toast from 'react-native-toast-message';


const Remove = ({setLength}) => {
  const [todos, setTodos] = React.useState(demoData);

  React.useEffect(() => {
    const todosWithSelected = demoData.map(todo => ({...todo, selected: true}));
    setTodos(todosWithSelected);
  }, []);

  const handleToggleTodo = id => {
    setTodos(prevTodos => {
      const updatedTodos = prevTodos.map(todo => {
        if (todo.id === id) {
          return {...todo, selected: !todo.selected};
        }
        return todo;
      });
      const allUnselected = updatedTodos.every(todo => !todo.selected);
      if (allUnselected) {
        const lastSelectedIndex = prevTodos.findIndex(todo => todo.selected);

        updatedTodos[lastSelectedIndex].selected = true;
        Toast.show({
          type: 'tomatoToast',
          props: 'Alleast one should be selected',
          position: 'bottom',
        });
      }

      const result = updatedTodos.filter(
        updatedTodos => updatedTodos.selected == false,
      );
      setLength(result.length);
      return updatedTodos;
    });
  };

  const renderRemovelist = ({item}: any) => {
    return (
      <TouchableOpacity
        key={item?.id}
        onPress={() => handleToggleTodo(item.id)}
        style={[
          Removescripstyle.removeconatiner,
          {backgroundColor: item.selected ? root.color_negative_rgb : null},
        ]}>
        <View style={Removescripstyle.innercontainer}>
          <Text style={Removescripstyle.tittxtstyle}>{item?.stockName}</Text>
          <Text style={Removescripstyle.nsetxt}>{item?.stockfrom}</Text>
          <Text style={Removescripstyle.eqtxt}>EQ</Text>
        </View>
        {item.selected ? (
          <AntDesign name="pluscircleo" size={24} color={'black'} />
        ) : (
          <AntDesign name="minuscircleo" size={24} color={'black'} />
        )}
      </TouchableOpacity>
    );
  };
  return (
    <FlatList
      nestedScrollEnabled
      data={todos}
      renderItem={renderRemovelist}
      keyExtractor={item => item.id}
    />
  );
};

export default Remove;

import React = require('react');
import {TouchableOpacity} from 'react-native-gesture-handler';
import DraggableFlatList, {
  ScaleDecorator,
} from 'react-native-draggable-flatlist';
import {Removescripstyle} from '../../../../theme/light';
import {View, Text} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {demoData} from '../../../../assets/demoData';

const Reorder = ({setScrollValue}) => {
  const [todos, setTodos] = React.useState(demoData);

  const renderListViewtwo = ({item, index, drag, isActive}: any) => {
    return (
      <ScaleDecorator>
        <TouchableOpacity
          style={[Removescripstyle.removeconatiner]}
          onLongPress={drag}>
          <View style={Removescripstyle.innercontainer}>
            <Text style={Removescripstyle.tittxtstyle}>{item?.stockName}</Text>
            <Text style={Removescripstyle.nsetxt}>{item?.stockfrom}</Text>
            <Text style={Removescripstyle.eqtxt}>EQ</Text>
          </View>

          <Entypo name="menu" size={24} color={'black'} />
        </TouchableOpacity>
      </ScaleDecorator>
    );
  };
  return (
    <DraggableFlatList
      data={todos}
      onDragEnd={({data}: any) => {
        setTodos(data);
      }}
      keyExtractor={item => item.id}
      renderItem={renderListViewtwo}
      style={{maxHeight: '100%'}}
    />
  );
};

export default Reorder;

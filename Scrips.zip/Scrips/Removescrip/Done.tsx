import React = require("react");
import { View,Text } from "react-native";
import AntDesign from "react-native-vector-icons/AntDesign";
import { root } from "../../../../styles/colors";
import { Donestyle } from "../../../../theme/light";

const Done =()=>{
    return(
<View style={Donestyle.maincon}>
    <AntDesign name="checkcircle" size={30} color={root.client_background}/>
    <Text style={Donestyle.donetxt}>Done</Text>
    
</View>
    )
}

export default Done;
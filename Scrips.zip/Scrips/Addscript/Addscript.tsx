import { useNavigation } from '@react-navigation/native';
import * as React from 'react';
import {TouchableOpacity} from 'react-native';
import {TextInput} from 'react-native';
import {View, Text} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  PartofIndices,
  recommdata,
  trendingmmdata,
} from '../../../../assets/demoData';
import {Addscripstyle} from '../../../../theme/light';

const Addscrip = () => {
    const navigation=useNavigation()
  return (
    <View style={Addscripstyle.Maincontainer}>
      <View style={Addscripstyle.textinput}>
        <TouchableOpacity onPress={()=>navigation.goBack()}>
          <Entypo name="cross" size={24} color={'black'} />
        </TouchableOpacity>
        <TextInput placeholder="Search eg:infy fut, gold mcx, acc opt" />
        <MaterialCommunityIcons name="microphone" size={24} color={'black'} />
      </View>
      <View style={Addscripstyle.innerconatiner}>
        <Text style={Addscripstyle.recomtxt}>
          <MaterialCommunityIcons name="thumb-up" size={24} /> Recommendation
        </Text>
      </View>
      <View style={Addscripstyle.flexallign}>
        {recommdata.map(item => {
          return (
            <View style={Addscripstyle.recomdata}>
              <Text style={Addscripstyle.rcomtxt}>{item.title}</Text>
            </View>
          );
        })}
      </View>

      <View style={Addscripstyle.innerconatiner}>
        <Text style={Addscripstyle.recomtxt}>
          <Ionicons name="trending-up" size={24} /> Trending
        </Text>
      </View>
      <View style={Addscripstyle.flexallign}>
        {trendingmmdata.map(item => {
          return (
            <View style={Addscripstyle.recomdata}>
              <Text style={Addscripstyle.rcomtxt}>{item.title}</Text>
            </View>
          );
        })}
      </View>

      <View style={Addscripstyle.bottomconatiner}>
        <View>
          <Text style={Addscripstyle.addtxt}>Add scrip to</Text>
          <View style={Addscripstyle.rowconatiner}>
            <Text style={Addscripstyle.watchlisttitle}>PRAGATI</Text>
            <Text style={Addscripstyle.numtxt}>7</Text>
          </View>
        </View>
        <TouchableOpacity style={Addscripstyle.doneconatiner}>
          <Text style={Addscripstyle.donetxt}>Done</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Addscrip;

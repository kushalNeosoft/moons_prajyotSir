import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

function HeartIcon(props: any) {
  return (
    <Svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" {...props}>
      <Path d="M439-156l-53-49Q262-320 171-424.5T80-643q0-90 60.5-150.5T290-854q51 0 101 24.5t89 80.5q44-56 91-80.5t99-24.5q89 0 149.5 60.5T880-643q0 114-91 218.5T574-205l-53 49q-17 16-41 16t-41-16zm15-527q-27-49-71-80t-93-31q-66 0-108 42.5T140-643q0 58 39 121.5T272-398q54 60 112 111.5t96 86.5q38-34 96-86t112-112.5q54-60.5 93-124T820-643q0-66-42.5-108.5T670-794q-50 0-93.5 30.5T504-683q-5 8-11 11.5t-14 3.5q-8 0-14.5-3.5T454-683zm26 186z" />
    </Svg>
  );
}

export default HeartIcon;

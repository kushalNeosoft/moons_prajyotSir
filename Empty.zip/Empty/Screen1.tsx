// import React, {useState} from 'react';
// import {View, Text, Dimensions, TouchableOpacity} from 'react-native';

// import Tab2 from '../../assets/tab-background-latest.svg';
// import SpreadOrderEntryDialog from './SpreadOrderEntryDialog';

// const Screen1 = ({}) => {
//   const [showDialog, setShowDialog] = useState(true);
//   const [showFullText, setShowFullText] = useState(false);

//   const [showFullText, setShowFullText] = useState(false);

//   const toggleTextDisplay = () => {
//     setShowFullText(!showFullText);
//   };
//   const text='Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.'

//   return (
//     <View
//       style={{
//         flex: 1,
//            flexDirection:'row'
//       }}>
//       <View
//         style={{
//           height:112,
//           width: 112,
//           backgroundColor: 'yellow',
//           borderWidth: 1,
//         }}>
//         <Text>Hello</Text>
//       </View>
//       <View
//         style={{
//           height: Dimensions.get('window').width * 0.272,
//           width: Dimensions.get('window').width * 0.272,

//           backgroundColor: 'pink',
//           borderWidth: 1,
//         }}>
//         <Tab2
//           width={'100%'}
//           height={128}
//           style={{
//             position: 'absolute',
//             alignSelf: 'center',
//             backgroundColor: '#0000000',
//             opacity: 0.1 / 4,
//             bottom: -30,
//             shadowColor: '#000',
//             shadowOffset: {
//               width: 0,
//               height: 2,
//             },
//             shadowOpacity: 0.23,
//             shadowRadius: 2.62,

//             elevation: 24,
//           }}
//         />
//       </View>

//       {/* <Tabsvg
//         width={500}
//         style={{
//           position: 'absolute',
//           alignSelf:'center',
//           bottom: -10,

//           width:'100%',
//           shadowColor: '#000',
//           shadowOffset: {
//             width: 0,
//             height: 12,
//           },
//           shadowOpacity: 0.58,
//           shadowRadius: 16.0,

//           elevation: 24,
//         }}
//       /> */}
//       {/* <Tab2 fill={'red'} height={200} width={200} /> */}
//       {/* <Tabnew/>
//         <TabComponent/> */}
//     </View>
//   //   <>
//   //   <Text
//   //     numberOfLines={showFullText ? undefined : 4}
//   //     ellipsizeMode="tail"
//   //   >
//   //     {text}
//   //   </Text>
//   //   {text.length > 3 && (
//   //     <TouchableOpacity onPress={toggleTextDisplay}>
//   //       <Text>{showFullText ? 'Show Less' : 'Show More'}</Text>
//   //     </TouchableOpacity>
//   //   )}
//   // </>
//   );
// };
// export default Screen1;

// import React from 'react';
// import {View, StyleSheet, Text, FlatList, Switch, SafeAreaView, TouchableOpacity, Modal } from 'react-native';

// export default (props) => {
//   const [open, setOpen] = React.useState(false)
//   const [data, setData] = React.useState([
//     { label: 'temperature', selected:false },
//     { label: 'humidity', },
//     { label: 'light', },
//     { label: 'move', },
//     { label: 'sound', },
//     { label: 'carbon dioxide', },
//     { label: 'air pollution', }
//   ])
//   const openList = () => setOpen(true)
//   const closeList = () => setOpen(false)
//   const onUpdateValue = (index, value) => { data[index].selected = value; return setData([...data]);}
//   const renderItem = ({ item, index }) => <ItemRenderer key={index} index={index} selected={item.selected} label={item.label} onUpdateValue={onUpdateValue} />
//   return (
//     <SafeAreaView style={styles.container}>
//       <View style={{ flex: 1, backgroundColor: '#FFF', padding: 16 }}>
//         <TouchableOpacity onPress={openList}>
//           <View style={{ padding: 16, borderWidth: 1, borderColor: '#000' }}>
//             <Text>Select Items</Text>
//           </View>
//         </TouchableOpacity>
//         <View>
//           <Text>Selected Items</Text>
//           {data.filter(item => item.selected).map(item => <Text key={item.label}>{item.label}</Text>)}
//         </View>
//       </View>
//       <Modal animationType='slide' transparent={true} visible={open === true}>
//         <TouchableOpacity activeOpacity={1} onPress={closeList} style={{ flex: 1 }}>
//           <View style={{ flex: 1, marginTop: 250 }}>
//             <View style={styles.listWrapper}>
//               <View style={styles.listContainer}>
//                 <FlatList
//                   data={data}
//                   renderItem={renderItem}
//                   keyExtractor={item => item.label}
//                 />
//               </View>
//             </View>
//           </View>
//         </TouchableOpacity>
//       </Modal>
//     </SafeAreaView>
//   );
// }

// const ItemRenderer = ({ index, label, selected, onUpdateValue }) => <View style={styles.item}>
//   <Text style={styles.title}>{label}</Text>
//   <Switch value={selected} onValueChange={(value) => onUpdateValue(index, value)} />
// </View>

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },
//   listWrapper: {
//     flex: 1,
//     shadowColor: '#000000',
//     shadowOffset: { width: 0, height: 4 },
//     shadowOpacity: .5,
//     elevation: 10,
//     shadowRadius: 5
//   },
//   listContainer: {
//     flex: 1,
//     backgroundColor: '#FFF',
//     borderTopLeftRadius: 15,
//     borderTopRightRadius: 15
//   },
//   item: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     justifyContent: 'space-between',
//     padding: 12,
//     borderBottomWidth: 1,
//     borderBottomColor: '#CCCCCC55'
//   },
//   tabHeading: {
//     padding: 20,
//     flexDirection: 'row',
//   },
//   title: {
//     textTransform: 'capitalize',
//     color: '#000'
//   }
// });

// import React, { useState } from 'react';
// import { View, FlatList, TouchableOpacity, Text } from 'react-native';

// const data = [
//   { id: 1, name: 'Item 1' },
//   { id: 2, name: 'Item 2' },
//   { id: 3, name: 'Item 3' },
//   // Add more items here
// ];

// const Screen1 = () => {
//   const [selectedItems, setSelectedItems] = useState([]);

//   const handleSelectItem = (itemId) => {
//     setSelectedItems(prevSelectedItems => {
//       if (prevSelectedItems.includes(itemId)) {
//         return prevSelectedItems.filter(item => item !== itemId);
//       } else {
//         return [...prevSelectedItems, itemId];
//       }
//     });
//   };

//   const handleSelectAll = () => {
//     setSelectedItems(data.map(item => item.id));
//   };

//   const handleDeselectAll = () => {
//     setSelectedItems([]);
//   };

//   return (
//     <View>
//       <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
//         <TouchableOpacity onPress={handleSelectAll}>
//           <Text>Select All</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={handleDeselectAll}>
//           <Text>Deselect All</Text>
//         </TouchableOpacity>
//       </View>
//       <FlatList
//         data={data}
//         keyExtractor={(item) => item.id.toString()}
//         renderItem={({ item }) => (
//           <TouchableOpacity onPress={() => handleSelectItem(item.id)}>
//             <Text>{item.name}</Text>
//             {selectedItems.includes(item.id) && <Text>Selected</Text>}
//           </TouchableOpacity>
//         )}
//       />
//     </View>
//   );
// };

// export default Screen1;

// import React, {useState} from 'react';
// import {View, FlatList, TouchableOpacity, Text} from 'react-native';

// const firstFlatListData = [
//   {id: 1, name: 'Equity'},
//   {id: 2, name: 'Equity F&O'},
//   // Add more items here
// ];

// const secondFlatListData = [
//   {id: 1, name: 'BSE'},
//   {id: 2, name: 'NSE'},
//   // Add more items here
// ];

// const Screen1 = () => {
//   const [firstSelectedItems, setFirstSelectedItems] = useState([]);
//   const [secondSelectedItems, setSecondSelectedItems] = useState([]);

//   const handleSelectItem = (itemId, list) => {
//     if (list === 'first') {
//       setFirstSelectedItems(prevSelectedItems => {
//         if (prevSelectedItems.includes(itemId)) {
//           if(prevSelectedItems.filter(item => item !== itemId).length==0){
//             setSecondSelectedItems([]);
//           }
//           return prevSelectedItems.filter(item => item !== itemId);
//         } else {
//           return [...prevSelectedItems, itemId];
//         }
//       });
//       console.log(firstSelectedItems, 'demo screen one first flatlist');
//       if (firstSelectedItems.length == 0) {
//         setSecondSelectedItems(secondFlatListData.map(item => item.id));
//       }
//       else if(firstSelectedItems.length<0){
//       setSecondSelectedItems([]);

//       }
//     } else {
//       setSecondSelectedItems(prevSelectedItems => {
//         if (prevSelectedItems.includes(itemId)) {
//           if(prevSelectedItems.filter(item => item !== itemId).length==0){
//             setFirstSelectedItems([]);
//           }
//           return prevSelectedItems.filter(item => item !== itemId);
//         } else {
//           return [...prevSelectedItems, itemId];
//         }
//       });
//       if (secondSelectedItems.length == 0) {
//         setFirstSelectedItems(firstFlatListData.map(item => item.id));
//       }

//     }
//   };

//   const handleSelectAll = list => {
//     if (list === 'first') {
//       setFirstSelectedItems(firstFlatListData.map(item => item.id));
//     } else {
//       setSecondSelectedItems(secondFlatListData.map(item => item.id));
//     }
//   };

//   const handleDeselectAll = list => {
//     if (list === 'first') {
//       setFirstSelectedItems([]);
//     } else {
//       setSecondSelectedItems([]);
//     }
//   };

//   return (
//     <View>
//       <View
//         style={{
//           flexDirection: 'row',
//           justifyContent: 'space-around',
//           marginTop: 20,
//         }}>
//         <TouchableOpacity onPress={() => handleSelectAll('first')}>
//           <Text>Select All (First List)</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={() => handleDeselectAll('first')}>
//           <Text>Deselect All (First List)</Text>
//         </TouchableOpacity>
//       </View>
//       <FlatList
//         data={firstFlatListData}
//         keyExtractor={item => item.id.toString()}
//         renderItem={({item}) => (
//           <TouchableOpacity onPress={() => handleSelectItem(item.id, 'first')}>
//             <Text>{item.name}</Text>
//             {firstSelectedItems.includes(item.id) && <Text>Selected</Text>}
//           </TouchableOpacity>
//         )}
//       />
//       <View
//         style={{
//           flexDirection: 'row',
//           justifyContent: 'space-around',
//           marginTop: 20,
//         }}>
//         <TouchableOpacity onPress={() => handleSelectAll('second')}>
//           <Text>Select All (Second List)</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={() => handleDeselectAll('second')}>
//           <Text>Deselect All (Second List)</Text>
//         </TouchableOpacity>
//       </View>
//       <FlatList
//         data={secondFlatListData}
//         keyExtractor={item => item.id.toString()}
//         renderItem={({item}) => (
//           <TouchableOpacity onPress={() => handleSelectItem(item.id, 'second')}>
//             <Text>{item.name}</Text>
//             {secondSelectedItems.includes(item.id) && <Text>Selected</Text>}
//           </TouchableOpacity>
//         )}
//       />
//     </View>
//   );
// };

// export default Screen1;

// import React, { useState } from 'react';
// import { View, FlatList, Text, TouchableOpacity } from 'react-native';

// const Screen1 = () => {
//   const [selectedItems, setSelectedItems] = useState([]);

//   const data = [
//     { id: 1, name: 'Item 1' },
//     { id: 2, name: 'Item 2' },
//     { id: 3, name: 'Item 3' },
//     // Add more items as needed
//   ];

//   const handleItemPress = (item) => {
//     setSelectedItems((prevSelectedItems) =>
//       prevSelectedItems.some((selectedItem) => selectedItem.id === item.id)
//         ? prevSelectedItems.filter((selectedItem) => selectedItem.id !== item.id) // Deselect the item
//         : [...prevSelectedItems, item] // Select the item
//     );
//   };

//   const renderItem = ({ item }) => {
//     const isSelected = selectedItems.some((selectedItem) => selectedItem.id === item.id);

//     return (
//       <TouchableOpacity onPress={() => handleItemPress(item)}>
//         <View style={{ backgroundColor: isSelected ? 'lightblue' : 'white', padding: 10 }}>
//           <Text>{item.name}</Text>
//         </View>
//       </TouchableOpacity>
//     );
//   };

//   return (
//     <View>
//       <FlatList
//         data={data}
//         renderItem={renderItem}
//         keyExtractor={(item) => item.id.toString()}
//       />
//       {/* Display the selected item names */}
//       {selectedItems.length > 0 && (
//         <Text>Selected Items: {selectedItems.map((item) => item.name).join(', ')}</Text>
//       )}
//     </View>
//   );
// };

// export default Screen1;

// import React, { useEffect, useState } from 'react';
// import { View, FlatList, TouchableOpacity, Text, Button } from 'react-native';
// import { ScrollView } from 'react-native-gesture-handler';

// const firstFlatListData = [
//   { id: 1, name: 'Equity' },
//   { id: 2, name: 'Equity F&O' },
//   // Add more items here
// ];

// const secondFlatListData = [
//   { id: 1, name: 'BSE' },
//   { id: 2, name: 'NSE' },
//   { id: 3, name: 'NSE' },
//   { id: 4, name: 'NSE' },
//   { id: 5, name: 'NSE' },
//   { id: 6, name: 'NSE' },
//   { id: 7, name: 'NSE' },
//   { id: 8, name: 'NSE' },
//   { id: 9, name: 'NSE' },
//   { id: 10, name: 'NSE' },
//   { id: 11, name: 'NSE' },
//   // Add more items here
// ];

// const Screen1 = () => {
//   const [firstSelectedItems, setFirstSelectedItems] = useState([]);
//   const [secondSelectedItems, setSecondSelectedItems] = useState([]);

//   const handleSelectItem = (item, list) => {
//     if (list === 'first') {
//             setFirstSelectedItems((prevSelectedItems) => {
//         if (prevSelectedItems.includes(item.name)) {
//           if (prevSelectedItems.filter((name) => name !== item.name).length == 0) {
//             setSecondSelectedItems([]);
//           }
//           return prevSelectedItems.filter((name) => name !== item.name);
//         } else {
//           return [...prevSelectedItems, item.name];
//         }
//       })
//       // setFirstSelectedItems((prevSelectedItems) =>
//       //   prevSelectedItems.includes(item.name)
//       //     ? prevSelectedItems.filter((name) => name !== item.name)
//       //     : [...prevSelectedItems, item.name]
//       // );
//       if (firstSelectedItems.length == 0) {
//         setSecondSelectedItems(secondFlatListData.map(item => item.name));
//       }
//     } else {
//       setSecondSelectedItems((prevSelectedItems) =>
//         prevSelectedItems.includes(item.name)
//           ? prevSelectedItems.filter((name) => name !== item.name)
//           : [...prevSelectedItems, item.name]
//       );
//       if (secondSelectedItems.length == 0) {
//         setFirstSelectedItems(firstFlatListData.map(item => item.name));
//       }
//     }
//   };

//   const handleSelectAll = (list) => {
//     if (list === 'first') {
//       setFirstSelectedItems(firstFlatListData.map((item) => item.name));
//     } else {
//       setSecondSelectedItems(secondFlatListData.map((item) => item.name));
//     }
//   };

//   const handleDeselectAll = (list) => {
//     if (list === 'first') {
//       setFirstSelectedItems([]);
//     } else {
//       setSecondSelectedItems([]);
//     }
//   };
//   //  setCombo([...firstSelectedItems,...secondSelectedItems])
//   // console.log(combo,"newcomboarray");

//   // useEffect(() => {
//   //   setCombo(firstSelectedItems.concat(secondSelectedItems))
//   // },[]);
//     const aminarray=firstSelectedItems.concat(secondSelectedItems)
//   const [combo, setCombo] = useState([]);
//   // console.log(combo,"new added deleted list");

//   const pressDelete=(i:any)=>{
//     console.log("new log===>>>");
//     const del=[...combo]
//     del.splice(i,1)
//     setCombo(del)

//     }
//      const onPressApply=()=>{
//       setCombo(aminarray)
//      }

//   return (
//     <View>
//       <View
//         style={{
//           flexDirection: 'row',
//           justifyContent: 'space-around',
//           marginTop: 20,
//         }}
//       >
//         <TouchableOpacity onPress={() => handleSelectAll('first')}>
//           <Text>Select All (First List)</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={() => handleDeselectAll('first')}>
//           <Text>Deselect All (First List)</Text>
//         </TouchableOpacity>
//       </View>
//       <FlatList
//         data={firstFlatListData}
//         keyExtractor={(item) => item.id.toString()}
//         renderItem={({ item }) => (
//           <TouchableOpacity onPress={() => handleSelectItem(item, 'first')}>
//             <Text>{item.name}</Text>
//             {firstSelectedItems.includes(item.name) && <Text>Selected</Text>}
//           </TouchableOpacity>
//         )}
//       />
//       <View
//         style={{
//           flexDirection: 'row',
//           justifyContent: 'space-around',
//           marginTop: 20,
//         }}
//       >
//         <TouchableOpacity onPress={() => handleSelectAll('second')}>
//           <Text>Select All (Second List)</Text>
//         </TouchableOpacity>
//         <TouchableOpacity onPress={() => handleDeselectAll('second')}>
//           <Text>Deselect All (Second List)</Text>
//         </TouchableOpacity>
//       </View>
//       <FlatList
//         data={secondFlatListData}
//         keyExtractor={(item) => item.id.toString()}
//         renderItem={({ item }) => (
//           <TouchableOpacity onPress={() => handleSelectItem(item, 'second')}>
//             <Text>{item.name}</Text>
//             {secondSelectedItems.includes(item.name) && <Text>Selected</Text>}
//           </TouchableOpacity>
//         )}
//       />

//       <TouchableOpacity onPress={onPressApply}>
//         <Text style={{fontSize:25,color:'black'}}>Apply</Text>
//       </TouchableOpacity>
//       {/* Display the selected names */}
//       {/* {firstSelectedItems.length ==1||secondSelectedItems.length ==1 && ( */}
//          {/* <Text>{firstSelectedItems.concat(secondSelectedItems).join(', ')}</Text> */}
//        {/* )} */}

//     <View style={{marginTop:20}}>
//     {/* {firstSelectedItems.concat(secondSelectedItems).map((item,i) => {
//         return (
//           <View style={{flexDirection:'row'}}>
//             <Text >{item}</Text>
//             <TouchableOpacity onPress={()=>handleSelectItem(item)}>
//                 <Text style={{marginLeft:20}} >X</Text>
//             </TouchableOpacity>
//           </View>
//         );
//       })}  */}

//    <ScrollView style={{flexDirection:'row',backgroundColor:'red',height:25}} horizontal>

//     {combo.map((person,i) => {
//         return (
//           <View style={{flexDirection:'row'}}>
//             <Text >{person}</Text>
//             <TouchableOpacity onPress={()=>pressDelete(i)}>
//                 <Text style={{marginLeft:20}} >X</Text>
//             </TouchableOpacity>
//           </View>
//         );
//       })}
//    </ScrollView>
//     {/* {aminarray.map((person,i) => {
//         return (
//           <View style={{flexDirection:'row'}}>
//             <Text >{person}</Text>
//             <TouchableOpacity onPress={()=>pressDelete(i)}>
//                 <Text style={{marginLeft:20}} >X</Text>
//             </TouchableOpacity>
//           </View>
//         );
//       })} */}
//     </View>

//     </View>
//   );
// };

// export default Screen1;

// import React, { useState } from 'react';
// import { View, FlatList, TouchableOpacity, Text } from 'react-native';

// const Screen1 = () => {
//   const initialData = [
//     { id: 1, name: 'Item 1' },
//     { id: 2, name: 'Item 2' },
//     { id: 3, name: 'Item 3' },
//     // Add more items as needed
//   ];

//   const [data, setData] = useState(initialData);
//   const [selectedItems, setSelectedItems] = useState([]);

//   const handleItemPress = (item) => {
//     setData((prevData) => prevData.filter((dataItem) => dataItem.id !== item.id));
//     setSelectedItems((prevSelectedItems) => [...prevSelectedItems, item]);
//   };

//   const renderItem = ({ item }) => (
//     <TouchableOpacity onPress={() => handleItemPress(item)}>
//       <View style={{ backgroundColor: 'lightblue', padding: 10 }}>
//         <Text>{item.name}</Text>
//       </View>
//     </TouchableOpacity>
//   );

//   return (
//     <View>
//       <FlatList
//         data={data}
//         renderItem={renderItem}
//         keyExtractor={(item) => item.id.toString()}
//       />
//       {/* Display the selected items */}
//       {selectedItems.length > 0 && (
//         <View>
//           <Text>Selected Items:</Text>
//           {selectedItems.map((item) => (
//             <Text key={item.id}>{item.name}</Text>
//           ))}
//         </View>
//       )}
//     </View>
//   );
// };

// export default Screen1;

// import React, { useState } from 'react';
// import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
// import Screen3 from './Screen3';

// interface DataItem {
//   id: number;
//   text: string;
// }

// const Screen1: React.FC = () => {
//   const [data, setData] = useState<DataItem[]>([
//     { id: 1, text: 'Item 1' },
//     { id: 2, text: 'Item 2' },
//     { id: 3, text: 'Item 3' },
//     { id: 4, text: 'Item 4' },
//     { id: 5, text: 'Item 5' },
//     { id: 6, text: 'Item 6' },
//     { id: 7, text: 'Item 7' },
//     { id: 8, text: 'Item 8' },
//     { id: 9, text: 'Item 9' },
//     { id: 10, text: 'Item 10' },
//     { id: 11, text: 'Item 11' },
//     { id: 12, text: 'Item 12' },
//     { id: 13, text: 'Item 13' },
//     { id: 14, text: 'Item 14' },
//     { id: 15, text: 'Item 15' },

//     // Add more items as needed
//   ]);

//   const removeItem = (itemId: number) => {
//     setData(prevData => prevData.filter(item => item.id !== itemId));
//   };

//   return (
//     <View style={styles.container}>
//       <ScrollView horizontal={true}>
//         {data.map(item => (
//           <TouchableOpacity
//             key={item.id}
//             style={styles.itemContainer}
//             onPress={() => removeItem(item.id)}
//           >
//             <Text style={styles.itemText}>{item.text}</Text>
//           </TouchableOpacity>
//         ))}
//       </ScrollView>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     paddingTop: 20,
//     paddingHorizontal: 10,
//     backgroundColor: '#fff',

//   },
//   itemContainer: {
//     padding: 10,
//     marginHorizontal: 5,
//     backgroundColor: '#e0e0e0',
//     borderRadius: 8,
//     height:40
//   },
//   itemText: {
//     fontSize: 16,
//   },
// });

// export default Screen1;

// import React, { useState } from 'react';
// import { View, Text, Button, StyleSheet } from 'react-native';
// import Screen3 from './Screen3';

// const Screen1: React.FC = () => {
//   const [array1, setArray1] = useState<number[]>([1, 2, 3, 4, 5]);
//   const [array2, setArray2] = useState<number[]>([3, 4, 5, 6, 7]);

//   const removeCommonElements = () => {
//     const uniqueArray1 = array1.filter(item => array2.includes(item));
//     const uniqueArray2 = array2.filter(item => array1.includes(item));
//     setArray1(uniqueArray1);
//     setArray2(uniqueArray2);
//   };

//   return (
//     <View style={styles.container}>
//       <Text>Array 1: {JSON.stringify(array1)}</Text>
//       <Text>Array 2: {JSON.stringify(array2)}</Text>
//       <Button title="Remove Common Elements" onPress={removeCommonElements} />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     backgroundColor: '#fff',
//   },
// });

// export default Screen1;

// import React, {useEffect, useRef, useState} from 'react';
// import {View, Text, StyleSheet, FlatList} from 'react-native';
// import CallPutList from '../Indices/OptionChain/components/CallPullList/CallPullList';
// import {optionChainScreen} from '../../theme/light';

// const Screen1: React.FC = () => {
//   const [data, setData] = useState<Array>([]);
//   const flatListRef = useRef<any>(null);

//   useEffect(() => {
//     pushData();
//   }, []);

//   useEffect(() => {
//     if (data.length > 90) {
//       handleScrollToIndex();
//     }
//   }, [data]);

//   const handleScrollToIndex = () => {
//     flatListRef.current.scrollToIndex({index: 50, animated: true});
//   };

//   const pushData = () => {
//     var arr = [];

//     for (let i = 0; i < 100; i++) {
//       arr.push({
//         calls: {
//           ltp: 'LTP',
//           value: '0.000.00',
//           IV: 'IV',
//           ivValue: '0',
//           OI: 'OI',
//           oiValue: '0.00',
//         },
//         put: {
//           ltp: 'LTP',
//           value: '0.000.00',
//           IV: 'IV',
//           ivValue: '0',
//           OI: 'OI',
//           oiValue: '0.00',
//         },
//         value: i,
//         flag: false,
//       });
//     }
//     setData(arr);
//   };

//   const renderList = ({item, index}: any) => {
//     return (
//       <View>
//         <View style={optionChainScreen.callsPutContainer}>
//           <View style={optionChainScreen.callsPutInner}>
//             <CallPutList
//               ltpTxt={item.calls.ltp}
//               ltpValue={item.calls.value}
//               ivTxt={item.calls.IV}
//               ivValue={item.calls.ivValue}
//               oiTxt={item.calls.OI}
//               oiValue={item.calls.oiValue}
//               leftView={true}
//               index={index}
//             />
//             <View style={optionChainScreen.dayValueTxtContainer}>
//               <Text
//                 style={optionChainScreen.dayValue}>{`${item.value}.00`}</Text>
//             </View>
//             <CallPutList
//               ltpTxt={item.calls.ltp}
//               ltpValue={item.calls.value}
//               ivTxt={item.calls.IV}
//               ivValue={item.calls.ivValue}
//               oiTxt={item.calls.OI}
//               oiValue={item.calls.oiValue}
//               leftView={false}
//               index={index}
//             />
//           </View>
//         </View>
//       </View>
//     );
//   };
//   const text =
//     'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Itaque ab molestias assumenda vero nemo rem laborum eaque facilis, molestiae, ut qui similique quasi! Dignissimos illo architecto tenetur ex, est maiores.';

//   // Step 2: Filter the data based on the common names and store them in separate arrays
//   const dataArrays = commonNames.map(name =>
//     data.filter(item => item.name === name)
//   );

//   // State to keep track of selected data objects
// const [selectedItems, setSelectedItems] = useState<any[]>([]);

// // Function to handle data object selection
// const handleSelectItem = (item: any) => {
//   setSelectedItems(prevState => {
//     if (prevState.some(obj => obj.id === item.id)) {
//       // If the data object is already in the selectedItems array, remove it
//       return prevState.filter(obj => obj.id !== item.id);
//     } else {
//       // Otherwise, add it to the selectedItems array
//       return [...prevState, item];
//     }
//   });
// };

// // Function to check if a data object is selected
// const isItemSelected = (item: any) => selectedItems.some(obj => obj.id === item.id);

//   // Render the FlatLists for each data array
//   return (
//     <View style={{flex: 1}}>
//       <FlatList
//         ref={flatListRef}
//         data={data}
//         getItemLayout={(data, index) => ({
//           length: 150,
//           offset: 150 * index,
//           index,
//         })}
//         renderItem={renderList}
//       />
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//   },
// });

// export default Screen1;

import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ScrollView,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, root} from '../../styles/colors';
import {Allstyle} from '../../theme/light';

const screenWidth = Dimensions.get('window').width;

const Screen1: React.FC = () => {
  const navigation = useNavigation();

  const data = [
    {id: 1, name: 'Apple', value: 'A', fut: 'true'},
    {id: 2, name: 'Apple', value: 'b', fut: 'true'},
    {id: 3, name: 'Apple', value: 'c', fut: 'true'},
    {id: 4, name: 'Apple', value: 'd', spred: 'true'},
    {id: 5, name: 'Apple', value: 'e', spred: 'true'},
    {id: 6, name: 'Bat', value: 'f', fut: 'true'},
    {id: 7, name: 'Bat', value: 'g', fut: 'true'},
    {id: 8, name: 'Bat', value: 'h', fut: 'true'},
    {id: 9, name: 'Bat', value: 'i', spred: 'true'},
    {id: 10, name: 'Bat', value: 'j', spred: 'true'},
    {id: 11, name: 'cat', value: 'k', fut: 'true'},
    {id: 12, name: 'cat', value: 'l', fut: 'true'},
    {id: 13, name: 'cat', value: 'm', fut: 'true'},
    {id: 14, name: 'cat', value: 'n', spred: 'true'},
    {id: 15, name: 'cat', value: 'o', spred: 'true'},
    {id: 16, name: 'Apple', value: 'p', spred: 'true'},
    {id: 17, name: 'Apple', value: 'q', spred: 'true'},
    {id: 18, name: 'Apple', value: 'r', spred: 'true'},
  ];

  // Step 1: Identify the common names
  const commonNames = data.reduce((acc, current) => {
    if (!acc.includes(current.name)) {
      acc.push(current.name);
    }
    return acc;
  }, []);

  // Step 2: Filter the data based on the common names and store them in separate arrays
  const dataArrays = commonNames.map(name =>
    data.filter(item => item.name === name),
  );

  // State to keep track of selected data objects
  const [selectedItems, setSelectedItems] = useState<any[]>([]);

  // Function to handle data object selection
  const handleSelectItem = (item: any) => {
    setSelectedItems(prevState => {
      if (prevState.some(obj => obj.id === item.id)) {
        // If the data object is already in the selectedItems array, remove it
        return prevState.filter(obj => obj.id !== item.id);
      } else {
        // Otherwise, add it to the selectedItems array
        return [...prevState, item];
      }
    });
  };
  // Function to check if a data object is selected
  const isItemSelected = (item: any) =>
    selectedItems.some(obj => obj.id === item.id);

  // Render the FlatLists for each data array
  return (
    <ScrollView style={styles.container}>
      <View>
        {dataArrays.map((dataArray, index) => (
          <React.Fragment key={index}>
            <View style={{paddingHorizontal: 10}}>
              <Text style={Allstyle.tittxtstyle}>{commonNames[index]} EQ</Text>
              <View style={Allstyle.innercontainer}>
                <Text style={Allstyle.nsetxt}>
                  NSE
                  {/* {item?.stockfrom} */}
                </Text>
                <Text style={Allstyle.banktxt}>STATE BANK OF INDIA</Text>
              </View>
            </View>
            <View style={{height: 132}}>
              <FlatList
                horizontal
                data={dataArray.filter(neo => neo.fut === 'true')}
                keyExtractor={item => item.id.toString()}
                renderItem={({item}) => (
                  <TouchableOpacity onPress={() => handleSelectItem(item)}
               
                  >
                    <View
                      style={[
                        isItemSelected(item)
                          ? styles.selectedItem
                          : styles.constiner,
                        //  styles.constiner
                        //  ,{backgroundColor:isItemSelected(item)?root.color_negative_rgb:root.color_active,
                        //   elevation:isItemSelected(item)? 0:10, }
                      ]}>
                      <Text style={styles.dattxt}>
                        {/* {item?.date} */}31 AUG
                        <Text style={styles.yrtxt}>
                          {/* {item?.year} */} '23
                        </Text>{' '}
                      </Text>
                      {/* <Text>
                        {item.name}: {item.value}
                      </Text> */}
                      <View style={styles.endcontainer}>
                        <TouchableOpacity
                          style={styles.bottonView}
                          onPress={() => {
                            navigation.navigate('BuySell', {
                              item: item,
                            });
                          }}>
                          <Text style={{fontWeight: 'bold', color: 'black'}}>
                            T
                          </Text>
                        </TouchableOpacity>

                        {isItemSelected(item) ? (
                          <AntDesign
                            name="minuscircleo"
                            size={20}
                            color={'black'}
                          />
                        ) : (
                          <AntDesign
                            name="pluscircleo"
                            size={20}
                            color={'black'}
                          />
                        )}
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              />
            </View>
            <Text style={styles.lengthone}>
              {dataArray.filter(neo => neo.fut === 'true').length} Expiries
              available till OCT '23
            </Text>

            <View style={{height: 132}}>
              <FlatList
                horizontal
                data={dataArray.filter(neo => neo.spred === 'true')}
                keyExtractor={item => item.id.toString()}
                renderItem={({item}) => (
                  <TouchableOpacity
                    // style={[
                    //   styles.item,
                    //   isItemSelected(item) && styles.selectedItem,
                    // ]}
                    onPress={() => handleSelectItem(item)}>
                    <View
                      style={[
                        isItemSelected(item)
                          ? styles.selectedItem
                          : styles.constiner,

                        // isItemSelected(item) ? styles.selectedItem:styles.constiner,
                      ]}>
                      {/* <Text>
                        {item.name}: {item.value}
                      </Text> */}
                      <Text style={styles.txtname}>{item.name}-1</Text>
                      <Text style={styles.txttwoname}>
                        {/* {item.date} */}31 AUG - SEP '23'
                        </Text>
                      <View style={styles.endcontainer}>
                        <TouchableOpacity
                          style={styles.bottonView}
                          onPress={() => {
                            navigation.navigate('BuySell', {
                              item: item,
                            });
                          }}>
                          <Text style={{fontWeight: 'bold', color: 'black'}}>
                            T
                          </Text>
                        </TouchableOpacity>

                        {isItemSelected(item) ? (
                          <AntDesign
                            name="minuscircleo"
                            size={20}
                            color={'black'}
                          />
                        ) : (
                          <AntDesign
                            name="pluscircleo"
                            size={20}
                            color={'black'}
                          />
                        )}
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              />
            </View>

            <Text style={styles.lengthone}>
              {dataArray.filter(neo => neo.spred === 'true').length} Expiries
              available till OCT '23
            </Text>
          </React.Fragment>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // paddingVertical: 20,
    paddingHorizontal: 10,
    backgroundColor: 'white',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  item: {
    padding: 10,
    marginVertical: 15,
    borderRadius: 8,
    borderWidth: 1,
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    borderColor: '#ccc',
  },
  selectedItem: {
    backgroundColor: root.color_negative_rgb,
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 6,
    marginVertical: 12,
    marginRight: 9,
    marginLeft: 8,
    paddingVertical: 12,
    paddingHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.53,
    shadowRadius: 13.97,

    elevation: 0,
  },
  constiner: {
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    backgroundColor: root.color_active,
    borderRadius: 6,
    marginVertical: 12,
    marginRight: 9,
    marginLeft: 8,
    paddingVertical: 12,
    paddingHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.53,
    shadowRadius: 13.97,
    elevation: 10,
  },
  lengthone: {
    paddingHorizontal: 10,
    marginBottom: 16,
    fontSize: 10,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 20,
    height: 20,
    borderRadius: 24 / 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  endcontainer: {
    flexDirection: 'row',
    marginTop: 25,
    alignSelf: 'flex-end',
  },
  dattxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
  },
  yrtxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
    color: root.color_text,
  },
  txtname: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txttwoname: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

export default Screen1;

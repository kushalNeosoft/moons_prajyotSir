import React, {useEffect, useMemo, useRef, useState} from 'react';
//import {View, Text} from 'react-native';
import {
  View,
  Text,
  Modal,
  TouchableNativeFeedback,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Animated,
  Easing,
} from 'react-native';
import {TouchableHighlight} from '@gorhom/bottom-sheet';
import {TextInput} from 'react-native-gesture-handler';
import {useNavigation} from '@react-navigation/native';
import {Cfont, root} from '../../styles/colors';
import CloseIcon from '../../assets/CloseIcon';
import InfoIcon from '../../assets/InfoIcon';
import AddIcon from '../../assets/AddIcon';
import MinusIcon from '../../assets/MinusIcon';
import ShareIcon from '../../assets/ShareIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import ConfirmPlaceOrderDialog from './ConfirmPlaceOrderDialog';
import MultiLegConfirmPlaceOrderDialog from '../BuySell/components/MultiLegConfirmPlaceOrderDialog';
import MarketDepthDialog from '../BuySell/components/MarketDepthDialog';
import {Popable} from 'react-native-popable';

const SpreadOrderEntryDialog = ({visible, onClose, item}: any) => {
  const [switchState, setSwitchState] = useState(0);

  const [operation, setOperation] = useState<string>('MARKET');
  const [lots, setLots] = useState<number>(0);

  const animatedColor = useRef(new Animated.Value(0)).current;

  const [confirmDialog, setConfirmDialog] = useState(false);
  const [multiConfirmDialog, setMultiConfirmDialog] = useState(false);
  const [marketDepthDailogVisible, setMarketDepthDialogVisible] =
    useState(false);

  const leftColor = animatedColor.interpolate({
    inputRange: [0, 1],
    outputRange: [root.color_negative, root.color_positive], // Replace with the colors you want to animate between
  });
  const rightColor = animatedColor.interpolate({
    inputRange: [0, 1],
    outputRange: [root.color_positive, root.color_negative], // Replace with the colors you want to animate between
  });

  const navigation = useNavigation();
  return (
    <>
      <Modal
        visible={visible}
        onRequestClose={() => onClose()}
        transparent={true}>
        <TouchableOpacity
          style={{
            flex: 1,
            backgroundColor: 'rgba(52, 52, 52, 0.8)',
            position: 'relative',
          }}
          onPress={() => onClose()}
          activeOpacity={1}></TouchableOpacity>

        <View
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: 'white',
            borderTopLeftRadius: 16,
            borderTopRightRadius: 16,
          }}>
          <View style={{width: '100%', height: '100%', padding: 16}}>
            <Text
              style={{
                marginTop: 16,
                fontSize: 16,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                fontWeight: 'bold',
              }}>
              FINNS - 1: 29 AUG'23 - 31 AUG'23
            </Text>
            <TouchableOpacity
              onPress={() => {
                onClose();
              }}>
              <View style={{position: 'absolute', right: 6, top: -34}}>
                <CloseIcon
                  style={{height: 24, width: 24, color: root.color_text}}
                />
              </View>
            </TouchableOpacity>
            <View
              style={{
                flexDirection: 'row',
                marginTop: 12,
                alignItems: 'center',
              }}>
              <Text
                style={{
                  color: 'grey',
                  fontSize: 10,
                  backgroundColor: '#EFF2F2',
                  borderRadius: 2,
                  paddingVertical: 1,
                  paddingHorizontal: 4,
                  alignSelf: 'center',
                  fontFamily: Cfont.rubik_medium,
                }}>
                NSE
              </Text>
              <Text
                style={{
                  color: 'black',
                  fontSize: 12,
                  paddingHorizontal: 4,
                  fontFamily: Cfont.rubik_regular,
                  fontWeight: 'bold',
                }}>
                0.00
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  paddingHorizontal: 4,
                  fontFamily: Cfont.rubik_regular,
                }}>
                0.00 (0.00)
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                marginTop: 16,
                position: 'relative',
              }}>
              <Animated.View
                style={{
                  flex: 1,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  backgroundColor: leftColor,
                  borderTopLeftRadius: 8,
                  borderBottomLeftRadius: 8,
                }}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontWeight: 'bold',
                    fontSize: 16,
                  }}>
                  {switchState === 1 ? 'Buy' : 'Sell'}
                </Text>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    marginTop: 8,
                    fontSize: 20,
                  }}>
                  <Text style={{fontWeight: 'bold'}}>29 Aug'</Text>
                  <Text>23</Text>
                </Text>
              </Animated.View>
              <View style={{width: 4}}></View>
              <Animated.View
                style={{
                  flex: 1,
                  paddingHorizontal: 16,
                  paddingVertical: 12,
                  // backgroundColor: 'green',
                  backgroundColor: rightColor,
                  borderTopRightRadius: 8,
                  borderBottomRightRadius: 8,
                }}>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    fontWeight: 'bold',
                    fontSize: 16,
                  }}>
                  {switchState == 0 ? 'Buy' : 'Sell'}
                </Text>
                <Text
                  style={{
                    color: 'white',
                    textAlign: 'center',
                    marginTop: 8,
                    fontSize: 20,
                  }}>
                  <Text style={{fontWeight: 'bold'}}>29 Aug'</Text>
                  <Text>23</Text>
                </Text>
              </Animated.View>
              <View
                style={{
                  top: 0,
                  position: 'absolute',
                  flexDirection: 'row',
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: '100%',
                  height: '100%',
                }}>
                <View
                  style={{
                    width: 48,
                    height: 48,
                    backgroundColor: 'white',
                    borderRadius: 24,
                  }}>
                  <View
                    style={{
                      margin: 6,
                      backgroundColor: 'white',
                      borderRadius: 20,
                      shadowColor: '#000',
                      shadowOffset: {
                        width: 0,
                        height: 2,
                      },
                      shadowOpacity: 0.23,
                      shadowRadius: 2.62,
                      elevation: 4,
                    }}>
                    <TouchableNativeFeedback
                      onPress={() => {
                        if (switchState === 0) {
                          Animated.timing(animatedColor, {
                            toValue: 1,
                            duration: 500, // Duration of the animation in milliseconds
                            useNativeDriver: false, // Set to true if you want to use the native driver for better performance
                          }).start();
                          setSwitchState(1);
                        } else {
                          Animated.timing(animatedColor, {
                            toValue: 0,
                            duration: 500, // Duration of the animation in milliseconds
                            useNativeDriver: false, // Set to true if you want to use the native driver for better performance
                          }).start();
                          setSwitchState(0);
                        }
                      }}
                      background={TouchableNativeFeedback.Ripple(
                        'white',
                        true,
                      )}>
                      <View style={{padding: 6}}>
                        <CloseIcon
                          style={{width: 24, height: 24, color: 'black'}}
                        />
                      </View>
                    </TouchableNativeFeedback>
                  </View>
                </View>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                marginTop: 16,
                justifyContent: 'space-between',
              }}>
              <View style={{}}>
                <Text
                  style={{fontSize: 16, color: 'black', fontWeight: 'bold'}}>
                  What Price?
                </Text>
                <View style={{marginTop: 12}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      borderWidth: 1,
                      borderColor: 'lightgrey',
                      borderRadius: 16,
                      flexShrink: 1,
                      flexGrow: 1,
                    }}>
                    <View style={{borderRadius: 15, overflow: 'hidden'}}>
                      <TouchableNativeFeedback
                        background={TouchableNativeFeedback.Ripple(
                          'white',
                          false,
                        )}
                        onPress={() => {
                          // navigation.goBack();
                          setOperation('MARKET');
                        }}>
                        <View>
                          <Text
                            style={{
                              fontSize: 11,
                              fontFamily: Cfont.rubik_medium,
                              paddingVertical: 6,
                              paddingHorizontal: 12,
                              backgroundColor:
                                operation == 'MARKET'
                                  ? root.client_background
                                  : 'transparent',
                              borderRadius: 16,
                              color:
                                operation == 'MARKET'
                                  ? 'white'
                                  : root.color_text,
                            }}>
                            Market
                          </Text>
                        </View>
                      </TouchableNativeFeedback>
                    </View>
                    <View style={{borderRadius: 15, overflow: 'hidden'}}>
                      <TouchableNativeFeedback
                        background={TouchableNativeFeedback.Ripple(
                          'white',
                          false,
                        )}
                        onPress={() => {
                          // navigation.goBack();
                          setOperation('LIMIT');
                        }}>
                        <View>
                          <Text
                            style={{
                              fontSize: 11,
                              fontFamily: Cfont.rubik_medium,
                              paddingVertical: 6,
                              paddingHorizontal: 12,
                              backgroundColor:
                                operation == 'LIMIT'
                                  ? root.client_background
                                  : 'transparent',
                              borderRadius: 16,
                              color:
                                operation == 'LIMIT'
                                  ? 'white'
                                  : root.color_text,
                            }}>
                            Limit
                          </Text>
                        </View>
                      </TouchableNativeFeedback>
                    </View>
                  </View>
                  <Text
                    style={{fontSize: 12, color: 'black', fontWeight: 'bold'}}>
                    (Tick: 0.05)
                  </Text>
                </View>
              </View>
              <View style={{}}>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'flex-end',
                    alignItems: 'center',
                  }}>
                  <Popable
                    style={{
                      width: 300,
                      padding: 11,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon style={{width: 16, height: 16, color: 'black'}} />
                  </Popable>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple('gray', true)}
                    onPress={() => {
                      setMarketDepthDialogVisible(true);
                    }}>
                    <Text
                      style={{
                        fontSize: 16,
                        color: root.client_background,
                        fontWeight: 'bold',
                        marginLeft: 8,
                      }}>
                      Market Dept
                    </Text>
                  </TouchableNativeFeedback>
                </View>
                <Text
                  style={{
                    fontSize: 16,
                    color: 'black',
                    fontWeight: 'bold',
                    marginLeft: 8,
                    marginTop: 12,
                    textAlign: 'right',
                  }}>
                  0.00
                </Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 16,
              }}>
              <Text style={{fontSize: 16, color: 'black', fontWeight: 'bold'}}>
                How Many Lots?
              </Text>
              <View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple('white', false)}
                    onPress={() => {
                      if (lots > 0) setLots(prev => prev - 1);
                    }}>
                    <View style={{padding: 4}}>
                      <MinusIcon
                        style={{width: 16, height: 16, color: 'black'}}
                      />
                    </View>
                  </TouchableNativeFeedback>
                  <Text
                    style={{
                      // flex: 1,
                      marginHorizontal: 8,
                      paddingHorizontal: 8,
                      // textAlign: 'center',
                      fontSize: 16,
                    }}>
                    {lots}
                  </Text>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple('white', false)}
                    onPress={() => {
                      setLots(prev => prev + 1);
                    }}>
                    <View style={{padding: 4}}>
                      <AddIcon
                        style={{width: 16, height: 16, color: 'black'}}
                      />
                    </View>
                  </TouchableNativeFeedback>
                </View>
                <Text style={{textAlign: 'right'}}>40</Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginTop: 16,
              }}>
              <Text style={{fontSize: 16, color: 'black', fontWeight: 'bold'}}>
                Validity
              </Text>
              <Text style={{fontSize: 16, color: 'black'}}>DAY</Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                marginTop: 16,
                alignItems: 'center',
              }}>
              <Text style={{fontSize: 12, marginRight: 4}}>
                Spread Order Has Margin Benefits
              </Text>
              <Popable
                style={{
                  width: 300,
                  padding: 11,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                content="Something"
                position="bottom">
                <InfoIcon style={{height: 16, width: 16, color: 'black'}} />
              </Popable>
            </View>
            <TouchableOpacity
              onPress={() => {
                // setMultiConfirmDialog(true);
                navigation.navigate('BuySell', {
                  item: {
                    stockName: 'AVc',
                    price: '100',
                    changes: '100',
                    future: true,
                  },
                });
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  marginTop: 16,
                  alignItems: 'center',
                }}>
                <ShareIcon
                  style={{height: 24, width: 24, color: root.client_background}}
                />
                <Text
                  style={{
                    fontSize: 16,
                    marginLeft: 8,
                    color: root.client_background,
                    fontWeight: 'bold',
                  }}>
                  Convert To Multileg Order
                </Text>
              </View>
            </TouchableOpacity>

            <View
              style={{
                marginTop: 16,
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text
                style={{
                  fontSize: 12,
                  color: root.client_background,
                  fontFamily: Cfont.rubik_medium,
                }}>
                Brokerage and charges
              </Text>
              <ArrowForwardIcon
                style={{width: 28, height: 24, color: root.client_background}}
              />
            </View>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('white', false)}
              onPress={() => {
                setConfirmDialog(true);
                // setConfirmOrderVisible(true);
              }}>
              <Text
                style={{
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                  backgroundColor: root.client_background,
                  fontSize: 16,
                  color: 'white',
                  borderRadius: 8,
                  textAlign: 'center',
                  marginTop: 16,
                  fontFamily: Cfont.rubik_semibold,
                }}>
                Place Order
              </Text>
            </TouchableNativeFeedback>
          </View>
        </View>
      </Modal>
      <ConfirmPlaceOrderDialog
        onClose={() => {
          setConfirmDialog(false);
        }}
        visible={confirmDialog}
        item={{
          stockName: 'AVc',
          price: '100',
          changes: '100',
        }}
      />
      <MultiLegConfirmPlaceOrderDialog
        onClose={() => {
          setMultiConfirmDialog(false);
        }}
        visible={multiConfirmDialog}
        item={{
          stockName: 'AVc',
          price: '100',
          changes: '100',
        }}
        legs={[{name: 'Something', lots: 10, operation: 'BUY', price: '100'}]}
      />
      <MarketDepthDialog
        visible={marketDepthDailogVisible}
        onClose={() => {
          setMarketDepthDialogVisible(false);
        }}
        item={item}
      />
    </>
  );
};
export default SpreadOrderEntryDialog;

import { use } from 'i18next';
import React, {useState} from 'react';
import {
  Dimensions,
  FlatList,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';

import {
  VictoryAxis,
  VictoryBar,
  VictoryChart,
  VictoryGroup,
  VictoryLabel,
  VictoryLine,
  VictoryPie,
} from 'victory-native';
import {
  Annualdata,
  colortrenddata,
  Financialdata,
  Management,
  Mutualdata,
  Piedatatwo,
  trenddata,
} from '../../../../assets/demoData';
import {Cfont, root} from '../../../../styles/colors';
import {Analysisstyle, CompanyStyle} from '../../../../theme/light';
import {Fundmodal, FundmodalAnnual} from './Fundmodal';

const Fundamentals = () => {
  
    
  const [selectedItemtrend, setSelectedItemtrend] = useState(0);
  const [selectedItemfinance, setSelectedItemfinance] = useState(0);
  const [selectedItemannual, setSelectedItemannual] = useState(0);

  const [managemodalvisible, setManagemodalvisible] = useState(false);
 

  const [annualmodal, setAnnualmodal] = useState(false);

  const [annualvalue,setAnnualvalue]=useState('CONSOLIDATE')
  const [funddata, setFunddata] = useState([]);

  const onNewsModalClose = () => {
    setManagemodalvisible(prevState => !prevState);
  };

  const onNewsModalAnnual = () => {
    setAnnualmodal(prevState => !prevState);
  };

  const renderItemfinance = ({item, index}: any) => (
    <TouchableOpacity
      onPress={() => {
        setSelectedItemfinance(index);
      }}>
      {selectedItemfinance === index ? (
        <>
          <View style={Analysisstyle({}).menuitemthree}>
            <Text style={Analysisstyle({}).titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={Analysisstyle({}).menuitemfour}>
            <Text style={Analysisstyle({}).titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  const renderItemtrend = ({item, index}: any) => (
    <TouchableOpacity
      onPress={() => {
        setSelectedItemtrend(index);
      }}>
      {selectedItemtrend === index ? (
        <>
          <View style={Analysisstyle({}).menuitemthree}>
            <Text style={Analysisstyle({}).titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={Analysisstyle({}).menuitemfour}>
            <Text style={Analysisstyle({}).titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );

  const renderItemannual = ({item, index}: any) => (
    <TouchableOpacity
      onPress={() => {
        setSelectedItemannual(index);
      }}>
      {selectedItemannual === index ? (
        <>
          <View style={Analysisstyle({}).menuitemthree}>
            <Text style={Analysisstyle({}).titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={Analysisstyle({}).menuitemfour}>
            <Text style={Analysisstyle({}).titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  return (
    <>
      {/* Health Score card */}
      <View style={Analysisstyle({}).supportcon}>
        <Text style={Analysisstyle({}).txtstyle}>Health Score</Text>
      </View>
      <View style={Analysisstyle({}).healthconatiner}>
        <Text>No Data</Text>
      </View>
      {/* Financial Ratio */}
      <View style={Analysisstyle({}).supportcon}>
        <Text style={Analysisstyle({}).txtstyle}>Financial Ratios</Text>
      </View>

      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Financialdata}
          renderItem={renderItemfinance}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>

      <View style={Analysisstyle({}).OUcontainer}>
        <Text style={Analysisstyle({}).Ouheader}></Text>
        <Text
          style={[Analysisstyle({}).Ouheader, {textAlign: 'right', flex: 1}]}>
          Mar 2022
        </Text>
        <Text
          style={[Analysisstyle({}).Ouheader, {textAlign: 'right', flex: 1}]}>
          Mar 2021
        </Text>
      </View>
      {Financialdata.map((events, i) => {
        if (selectedItemfinance == i) {
          return (
            <>
              {events.data.map(item => {
                return (
                  <View style={Analysisstyle({}).Outitle}>
                    <Text style={[Analysisstyle({}).outitlstand]}>
                      {item.tabvalue}
                    </Text>
                    <Text style={Analysisstyle({}).outitlethree}>
                      {item.t2}
                    </Text>
                    <Text style={Analysisstyle({}).outitlethree}>
                      {item.t3}
                    </Text>
                  </View>
                );
              })}
            </>
          );
        }
      })}
      {/* Trend Analysis modal */}

      <View style={Analysisstyle({}).supportcon}>
        <Text style={Analysisstyle({}).txtstyle}>Trend Analysis</Text>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={trenddata}
          renderItem={renderItemtrend}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>
      {trenddata.map((events, i) => {
        if (selectedItemtrend == i) {
          return (
            <>
              <View
                style={{
                  // display: 'flex',
                  // flexWrap: 'wrap',
                  // backgroundColor: 'red',
                  height: Dimensions.get('window').width * 0.438,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <VictoryChart
                  width={Dimensions.get('window').width * 0.92}
                  height={230}
                  domainPadding={30}>
                  <VictoryAxis
                    tickLabelComponent={
                      <VictoryLabel
                        textAnchor="middle"
                        style={{fontSize: 10}}
                      />
                    }
                    style={{axis: {strokeWidth: 0}}}
                  />
                  <VictoryAxis
                    dependentAxis
                    standalone={false}
                    style={{axis: {strokeWidth: 0}}}
                    tickLabelComponent={
                      <VictoryLabel
                        textAnchor="end"
                        verticalAnchor="middle"
                        style={{fontSize: 10}}
                      />
                    }
                  />
                  <VictoryAxis
                    orientation="right"
                    dependentAxis
                    standalone={false}
                    style={{axis: {strokeWidth: 0}}}
                    tickLabelComponent={
                      <VictoryLabel
                        textAnchor="end"
                        verticalAnchor="middle"
                        style={{fontSize: 10}}
                      />
                    }
                  />

                  <VictoryGroup colorScale={['#6FA9E2', '#464983']}>
                    <VictoryBar
                      alignment="middle"
                      barWidth={25}
                      data={events.data}
                      x="x"
                      y="earnings"
                      animate={{
                        onLoad: {duration: 1000},
                        duration: 1000,
                      }}
                    />
                    <VictoryLine
                      animate={{
                        onLoad: {duration: 1000},
                        duration: 1000,
                        easing: 'sin',
                      }}
                      standalone={false}
                      interpolation="natural"
                      style={{
                        parent: {border: '1px solid #ccc'},
                      }}
                      data={events.data}
                      x="x"
                      y="earnings"
                    />
                  </VictoryGroup>
                </VictoryChart>
              </View>

              <View style={Analysisstyle({}).colorpie}>
                {colortrenddata.map(item => {
                  return (
                    <View style={Analysisstyle({}).colorpiefour}>
                      <View
                        style={[
                          Analysisstyle({}).colourpieFive,
                          {backgroundColor: item.color},
                        ]}
                      />
                      <Text style={Analysisstyle({}).colourpiesix}>
                        {item.title}
                      </Text>
                    </View>
                  );
                })}
              </View>
            </>
          );
        }
      })}
      <View style={Analysisstyle({}).supportcon}>
        <Text style={Analysisstyle({}).txtstyle}>Share Holdlng</Text>
      </View>
      <View style={Analysisstyle({}).sharehold}>
        <VictoryPie
          width={120}
          height={120}
          colorScale={['#81CBFF', '#464983', '#5F88C3', '#6FA9E2']}
          innerRadius={55}
          style={{labels: {fill: 'none'}}}
          radius={27}
          data={[
            {x: 'Cats', y: 35},
            {x: 'Dogs', y: 40},
            {x: 'Birds', y: 55},
            {x: 'Birds', y: 55},
          ]}
        />

        <View>
          {Piedatatwo.map(item => {
            return (
              <View style={Analysisstyle({}).colorepieone}>
                <View
                  style={[
                    Analysisstyle({}).colorpietwo,
                    {backgroundColor: item.color},
                  ]}
                />
                <Text style={Analysisstyle({}).colorpieThree}>
                  {item.title}
                </Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* Anual report */}
      <View style={Analysisstyle({}).supportcon}>
        <Text style={Analysisstyle({}).txtstyle}>Annual Report</Text>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Annualdata}
          renderItem={renderItemannual}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>

      <View style={[Analysisstyle({}).OUcontainer,{justifyContent:'center'}]}>
        <TouchableOpacity onPress={()=>{setAnnualmodal(true)
        }} >

        <Text style={Analysisstyle({}).Ouheader}>{annualvalue}</Text>
        </TouchableOpacity>
        <View style={{flex: 1, alignItems: 'flex-end'}}>
          <Text style={[Analysisstyle({}).Ouheader]}>Mar</Text>

          <Text style={[Analysisstyle({}).Ouheader]}>2022(Cr.)</Text>
        </View>
        <View style={{flex: 1, alignItems: 'flex-end'}}>
          <Text style={[Analysisstyle({}).Ouheader]}>Mar</Text>

          <Text style={[Analysisstyle({}).Ouheader]}>2021(Cr.)</Text>
        </View>
      </View>
      {Annualdata.map((events, i) => {
        if (selectedItemannual == i) {
          return (
            <>
              {events.data.map(item => {
                return (
                  <View style={Analysisstyle({}).Outitle}>
                    <Text style={[Analysisstyle({}).outitlstand]}>
                      {item.tabvalue}
                    </Text>
                    <Text style={Analysisstyle({}).outitlethree}>
                      {item.t2}
                    </Text>
                    <Text style={Analysisstyle({}).outitlethree}>
                      {item.t3}
                    </Text>
                  </View>
                );
              })}
            </>
          );
        }
      })}
      {/* <View style={Analysisstyle({}).healthconatiner}>
        <Text>No Data</Text>

      </View> */}

      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Mutual Fund HoldIngs</Text>
      </View>
      {Mutualdata.map(item => {
        return (
          <TouchableOpacity
            onPress={() => {
              setManagemodalvisible(true);
              setFunddata(item);
            }}>
            <View style={Analysisstyle({}).listmanage}>
              <View style={[Analysisstyle({}).innermanage]}>
                <Text style={[Analysisstyle({}).txtstylemange]}>
                  {item.title}
                </Text>
                <View style={Analysisstyle({}).allignprice}>
                  <Text style={[Analysisstyle({}).txtstylemagegreen]}>
                    {item.price}
                  </Text>
                  <Text style={Analysisstyle({}).txtstylemagetwo}>
                    {item.date}
                  </Text>
                </View>
              </View>
              <Entypo
                name="chevron-small-right"
                size={20}
                color={root.client_background}
              />
            </View>
          </TouchableOpacity>
        );
      })}
      <Fundmodal
        visible={managemodalvisible}
        onClose={onNewsModalClose}
        funddata={funddata}
        
      />
      <FundmodalAnnual
      visible={annualmodal}
      onClose={onNewsModalAnnual}
      callfun={(e:any)=>{setAnnualvalue(e)}}
      />
    </>
  );
};

export default Fundamentals;

import React, {useState} from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import {Cfont, root} from '../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {RadioButton} from 'react-native-paper';

const PivotPointsModal = (props: any) => {
  const [price, setPrice] = useState('');
  const data = [
    {
      title: 'S1',
      value: '1957',
    },
    {
      title: 'S2',
      value: '1957',
    },
    {
      title: 'S3',
      value: '1957',
    },
    {
      title: 'S4',
      value: '1957',
    },
    {
      title: 'S5',
      value: '1957',
    },
    {
      title: 'S6',
      value: '1957',
    },
    {
      title: 'S7',
      value: '1957',
    },
    {
      title: 'S8',
      value: '1957',
    },
    {
      title: 'S9',
      value: '1957',
    },
    {
      title: 'S10',
      value: '1957',
    },
    {
      title: 'S11',
      value: '1957',
    },
    {
      title: 'S12',
      value: '1957',
    },
  ];

  const onSubmit = (item: any) => {
    setPrice(item.title);
    props.onClose();
    props.setPivotPoint(item.title);
  };

  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <View
        style={{
          flex: 1,
          backgroundColor: 'black',
          position: 'relative',
        }}
      />
      <View style={pivotPointsModal.container}>
        <TouchableOpacity
          style={{alignItems: 'flex-end'}}
          onPress={() => props.onClose()}>
          <AntDesign name="close" color={root.color_text} size={20} />
        </TouchableOpacity>
        <Text style={pivotPointsModal.title}>Select</Text>
        <Text style={pivotPointsModal.title}>Price</Text>
        <FlatList
          data={data}
          style={{paddingTop: 16}}
          renderItem={({item}) => {
            return (
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                <TouchableOpacity
                  onPress={() => onSubmit(item)}
                  style={{flexDirection: 'row', alignItems: 'center'}}>
                  <RadioButton
                    color={root.color_text}
                    value={item.title}
                    onPress={() => onSubmit(item)}
                    status={item.title === price ? 'checked' : 'unchecked'}
                  />
                  <Text style={pivotPointsModal.item}>{item.title}</Text>
                </TouchableOpacity>
                <Text style={pivotPointsModal.item}>{item.value}</Text>
              </View>
            );
          }}
        />
      </View>
    </Modal>
  );
};

const pivotPointsModal = StyleSheet.create({
  container: {
    position: 'absolute',
    height: '70%',
    bottom: 0,
    backgroundColor: root.color_active,
    padding: 16,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
    right: 0,
    left: 0,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
  },
  item: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 14,
  },
});

export default PivotPointsModal;

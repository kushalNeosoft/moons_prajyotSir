import React, {useEffect, useState} from 'react';
import {
  View,
  Modal,
  TouchableOpacity,
  TextInput,
  FlatList,
  Text,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Removescripstyle, ordersNavigation} from '../../../../theme/light';
import {Cfont, root} from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';
import { Switch } from 'react-native-switch';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

const SearchManageAlerts = (props: any) => {
  const [filterData, setFilterData] = useState<any>();
  const [indexVal, setIndexVal] = useState();
  const [searchKey, setSearchKey] = useState<string>('');
  const [toggle, setToggle] = useState(true);
  const [alertModal, setAlertModal] = useState(false);
  const [confirmationModal, setConfirmationModal] = useState(false);
  const [filteredArr, setFilterdArr] = useState(props.data);

  useEffect(() => {
    const searchFilterOnList = (value: string) => {
      if (value && value.length > 0) {
        var mainList = [];
        mainList = props.data;
        const filterTempList = mainList.filter((item: any) =>
          item.symbol.toLowerCase().includes(value.toLowerCase()),
        );
        setFilterData(filterTempList);
      } else {
        setFilterData([]);
      }
    };

    searchFilterOnList(searchKey);
  }, [searchKey]);

  const toggleSwitch = (index: any) => {
    setIndexVal(index);
    setToggle(prev => !prev);
    setConfirmationModal(prev => !prev);
  };

  const confirmed = (index: any) => {
    var arr = [...filteredArr];
    if (index !== -1) {
      arr.splice(index, 1);
    }
    setFilterdArr(arr);
    setConfirmationModal(prev => !prev);
    setToggle(prev => !prev);
  };

  return (
    <Modal
      transparent={false}
      visible={props.visible}
      onRequestClose={() => props.onClose()}>
      <View style={ordersNavigation.searchModal}>
        <View style={ordersNavigation.searchModalHeader}>
          <View style={ordersNavigation.searchModalTxt}>
            <TouchableOpacity
              onPress={() => {
                props.onClose();
                setSearchKey('');
              }}>
              <Ionicons name="close" size={25} color="black" />
            </TouchableOpacity>
            <TextInput
              placeholder="Search"
              autoCapitalize={'characters'}
              value={searchKey}
              placeholderTextColor={root.color_textual}
              style={ordersNavigation.searchModalTxtip}
              onChangeText={text => {
                setSearchKey(text);
              }}
            />
          </View>
          {searchKey?.length !== 0 ? (
            <TouchableOpacity
              onPress={() => {
                setSearchKey('');
              }}>
              <Text style={ordersNavigation.clearTxt}>Clear</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity>
              <MaterialCommunityIcons
                name="microphone"
                size={24}
                color={root.color_text}
              />
            </TouchableOpacity>
          )}
        </View>
        <FlatList
          data={filterData}
          renderItem={({item,index}) => {
            return (
              <View style={manageAlerts.card}>
              <View style={manageAlerts.cardInnerContainer}>
                <View style={{width: '90%'}}>
                  <View style={manageAlerts.symbolView}>
                    <Text style={manageAlerts.symbol}>{item.symbol}</Text>
                    {/* <Text>{item.exchange}</Text> */}
                  </View>
                  <Text style={manageAlerts.notice}>
                    {`Price : ${item.notice}`}
                  </Text>
                  <View style={manageAlerts.priceView}>
                    <Text style={manageAlerts.price}>{item.price}</Text>
                    <TouchableOpacity
                      style={{paddingLeft: 10}}
                      onPress={() => setAlertModal(prev => !prev)}>
                      <FontAwesome5
                        name="pen"
                        color={root.color_text}
                        size={10}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
                <Switch
                  value={indexVal === index ? toggle : true}
                  onValueChange={() => toggleSwitch(index)}
                  activeText={''}
                  inActiveText={''}
                  backgroundActive={root.color_positive}
                  backgroundInactive={root.color_subtext}
                  circleSize={10}
                  switchRightPx={2}
                  switchLeftPx={2}
                  barHeight={15}
                  circleBorderWidth={0}
                  switchWidthMultiplier={3}
                />
              </View>
              <Modal visible={confirmationModal} transparent={true}>
                <TouchableOpacity
                  style={manageAlerts.centeredView}
                  onPress={() => {
                    setConfirmationModal(prev => !prev);
                    setToggle(prev => !prev);
                  }}
                  activeOpacity={1}></TouchableOpacity>
                <View style={manageAlerts.modalView}>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                      fontSize: 16,
                    }}>
                    Alert
                  </Text>
                  <Text style={[Removescripstyle.desptxt, {paddingTop: 16}]}>
                    Are you sure you want to delete alert?
                  </Text>
                  <View
                    style={{
                      ...alignment.row_alignC,
                      paddingTop: 16,
                      justifyContent: 'flex-end',
                    }}>
                    <TouchableOpacity
                      style={[Removescripstyle.yescontainer, {marginRight: 10}]}
                      onPress={() => confirmed(indexVal)}
                    >
                      <Text style={Removescripstyle.yestxt}>Yes</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={Removescripstyle.nocontainer}
                      onPress={() => {
                        setConfirmationModal(prev => !prev);
                        setToggle(prev => !prev);
                      }}>
                      <Text style={Removescripstyle.notxt}>No</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </Modal>
            </View>
            );
          }}
        />
      </View>
    </Modal>
  );
};

const manageAlerts = StyleSheet.create({
  card: {
    backgroundColor: root.color_active,
    padding: 14,
    marginTop: 18,
    marginVertical: 6,
    shadowColor: '#000',
    marginHorizontal: 16,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 8,
  },
  cardInnerContainer: {
    ...alignment.row_alingC_SpaceB,
  },
  symbolView: {
    ...alignment.row_alignC,
  },
  symbol: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  notice: {
    paddingTop: 16,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
  priceView: {
    ...alignment.row_alignC,
  },
  price: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
  modalView: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: root.color_active,
    marginTop: Dimensions.get('window').height * 0.4,
    borderRadius: 6,
    padding: 16,
    width: '70%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
    paddingLeft: 10,
    paddingTop: 10,
  },
});

export default SearchManageAlerts;

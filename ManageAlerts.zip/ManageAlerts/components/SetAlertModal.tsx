import React, {useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  FlatList,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, root} from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';
import PivotPointsModal from './PivotPointsModal';

const SetAlertModal = (props: any) => {
  const [pivotPointsModal, setPivotPointsModal] = useState(false);
  const [pivotPoint, setPivotPoint] = useState('Select Pivot Points');
  const [type, setType] = useState('Above');
  const alertType = ['Above', 'Below'];
  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        // onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={setAlertModal.modalConatiner}>
        <TouchableOpacity
          onPress={() => props.onClose()}
          style={{alignItems: 'flex-end'}}>
          <AntDesign name="close" size={20} color={root.color_text} />
        </TouchableOpacity>
        <Text style={setAlertModal.titleTxt}>Set Price Alert</Text>
        <View style={setAlertModal.symbolView}>
          <Text style={setAlertModal.symbolTxt}>ACC</Text>
          <Text>NSE</Text>
        </View>
        <View style={setAlertModal.priceView}>
          <Text style={setAlertModal.priceTxt}>1800.00</Text>
          <Text style={setAlertModal.priceChange}>{`0.00(0.00)`}</Text>
        </View>
        <Text style={setAlertModal.alertTxt}>Alert me when the price goes</Text>
        <View style={{paddingTop: 16}}>
          <FlatList
            data={alertType}
            style={{
              borderWidth: 0.3,
              alignSelf: 'flex-start',
              borderRadius: 15,
            }}
            horizontal={true}
            renderItem={({item}) => {
              return (
                <TouchableOpacity
                  onPress={() => setType(item)}
                  style={{
                    borderRadius: 15,
                    backgroundColor:
                      item === type
                        ? item === 'Above'
                          ? root.color_positive
                          : root.color_negative
                        : root.color_active,
                  }}>
                  <Text
                    style={{
                      paddingHorizontal: 10,
                      paddingVertical: 5,
                      color:
                        item === type ? root.color_active : root.color_text,
                      fontFamily: Cfont.rubik_medium,
                      fontSize: 12,
                    }}>
                    {item}
                  </Text>
                </TouchableOpacity>
              );
            }}
          />
        </View>
        <Text style={setAlertModal.setPriceText}>Set Price</Text>
        <View style={setAlertModal.settingsView}>
          <View style={{width: '45%'}}>
            <Text style={setAlertModal.qtyTxt}>Enter Price</Text>
            <TextInput
              style={setAlertModal.txtIp}
              // onChangeText={text => setQuantity(text)}
              placeholder="0"
            />
          </View>
          <Text>Or</Text>
          <TouchableOpacity
            style={setAlertModal.pivotContainer}
            onPress={() => setPivotPointsModal(prev => !prev)}>
            <Text style={setAlertModal.pivotTxt}>{pivotPoint}</Text>
            <AntDesign
              name="caretdown"
              size={10}
              color={root.color_text}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={setAlertModal.btn}>
          <Text style={setAlertModal.btnTxt}>Set Alert</Text>
        </TouchableOpacity>
        <PivotPointsModal
          setPivotPoint={setPivotPoint}
          visible={pivotPointsModal}
          onClose={() => setPivotPointsModal(prev => !prev)}
        />
      </View>
    </Modal>
  );
};

const setAlertModal = StyleSheet.create({
  modalConatiner: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '60%',
    flex: 1,
    backgroundColor: root.color_active,
    padding: 16,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
  },
  symbolView: {
    ...alignment.row_alignC,
    paddingTop: 10,
  },
  symbolTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  priceView: {
    ...alignment.row_alignC,
    paddingTop: 10,
  },
  priceTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 14,
  },
  priceChange: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
    paddingLeft: 5,
  },
  alertTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
    color: root.color_text,
    paddingTop: 24,
  },
  setPriceText: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
    color: root.color_text,
    paddingTop: 16,
  },
  settingsView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  qtyTxt: {
    paddingTop: 18,
    fontFamily: Cfont.rubik_regular,
    fontSize: 14,
    color: root.color_text,
  },
  txtIp: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 24,
    color: root.color_text,
    borderBottomWidth: 1,
    borderBottomColor: 'grey',
    paddingBottom: -10,
    width: 120,
  },
  pivotContainer: {
    ...alignment.row_alignC,
    width: '45%',
    justifyContent: 'flex-end',
  },
  pivotTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
    paddingRight:10
  },
  btn: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.client_background,
    height: 40,
    width: '100%',
    marginTop: 36,
    borderRadius: 10,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
    fontSize: 16,
  },
});

export default SetAlertModal;

import React, {useRef, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Dimensions,
} from 'react-native';
import {Cfont, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import SetAlertModal from './components/SetAlertModal';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Fontisto from 'react-native-vector-icons/Fontisto';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import ManageAlertsFilter from './components/Filter';
import SortFilterBottomSheet from '../../../components/BottomSheet/SortFilterBottomSheet';
import BottomSheet from '@gorhom/bottom-sheet';
import SearchManageAlerts from './components/SearchModal';
import {Switch} from 'react-native-switch';
import {Removescripstyle, screenFilter} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';

const ManageAlerts = () => {
  const [searchModal, setSearchModal] = useState(false);
  const [categoryF, setCategoryF] = useState('');
  const [alertF, setAlertF] = useState('');
  const [indexVal, setIndexVal] = useState();
  const [alertModal, setAlertModal] = useState(false);
  const [toggle, setToggle] = useState(true);
  const [confirmationModal, setConfirmationModal] = useState(false);
  const navigation = useNavigation();

  const setCategoryFilter = (value: string) => {
    setCategoryF(value);
  };

  const setAlertFilter = (value: string) => {
    setAlertF(value);
  };

  const clearCategoryFilter = () => {
    setCategoryF('');
  };

  const clearAlertFilter = () => {
    setAlertF('');
  };

  const setFilteredArray = data => {
    setFilterdArr(data);
  };

  const data = [
    {
      symbol: 'ACC',
      exchange: 'NSE',
      notice: 'Alert me when the price goes above',
      price: '1850.00',
    },
    {
      symbol: 'AXIS',
      exchange: 'NSE',
      notice: 'Alert me when the price goes above',
      price: '1850.00',
    },
    {
      symbol: 'MRF',
      exchange: 'NSE',
      notice: 'Alert me when the price goes above',
      price: '1850.00',
    },
    {
      symbol: 'LT',
      exchange: 'NSE',
      notice: 'Alert me when the price goes above',
      price: '1850.00',
    },
  ];
  const [filteredArr, setFilterdArr] = useState(data);

  const bottomSheetRef = useRef<BottomSheet>(null);

  const closeSheet = () => {
    bottomSheetRef.current.forceClose();
  };

  const toggleSwitch = (index: any) => {
    setIndexVal(index);
    setToggle(prev => !prev);
    setConfirmationModal(prev => !prev);
  };

  const confirmed = (index: any) => {
    var arr = [...filteredArr];
    if (index !== -1) {
      arr.splice(index, 1);
    }
    setFilterdArr(arr);
    setConfirmationModal(prev => !prev);
    setToggle(prev => !prev);
  };

  return (
    <View style={manageAlerts.conatiner}>
      <View style={manageAlerts.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={24} color={root.color_text} />
        </TouchableOpacity>
        <View style={manageAlerts.headerRightComponentView}>
          <TouchableOpacity onPress={() => setSearchModal(prev => !prev)}>
            <Fontisto name="search" size={20} color={root.color_text} />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => bottomSheetRef.current.snapToIndex(0)}>
            <FontAwesome5
              name="sliders-h"
              color={'black'}
              size={20}
              style={{paddingLeft: 16}}
            />
          </TouchableOpacity>
        </View>
      </View>
      {/* <View style={{height: 50, backgroundColor: 'yellow'}}></View> */}
      <Text style={manageAlerts.titleTxt}>Manage Alerts</Text>
      {categoryF !== '' || alertF !== '' ? (
        <View style={{...alignment.row_alignC, paddingHorizontal: 16}}>
          <Text style={screenFilter.filterTitle}>Filters:</Text>
          {categoryF !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Category:</Text>
              <Text style={screenFilter.filterTagData}>{categoryF}</Text>
              <TouchableOpacity onPress={clearCategoryFilter}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
          {alertF !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Alerts:</Text>
              <Text style={screenFilter.filterTagData}>{alertF}</Text>
              <TouchableOpacity onPress={clearAlertFilter}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      ) : null}
      <FlatList
        data={filteredArr}
        renderItem={({item, index}) => {
          return (
            <View style={manageAlerts.card}>
              <View style={manageAlerts.cardInnerContainer}>
                <View style={{width: '90%'}}>
                  <View style={manageAlerts.symbolView}>
                    <Text style={manageAlerts.symbol}>{item.symbol}</Text>
                    {/* <Text>{item.exchange}</Text> */}
                  </View>
                  <Text style={manageAlerts.notice}>
                    {`Price : ${item.notice}`}
                  </Text>
                  <View style={manageAlerts.priceView}>
                    <Text style={manageAlerts.price}>{item.price}</Text>
                    <TouchableOpacity
                      style={{paddingLeft: 10}}
                      onPress={() => setAlertModal(prev => !prev)}>
                      <FontAwesome5
                        name="pen"
                        color={root.color_text}
                        size={10}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
                <Switch
                  value={indexVal === index ? toggle : true}
                  onValueChange={() => toggleSwitch(index)}
                  activeText={''}
                  inActiveText={''}
                  backgroundActive={root.color_positive}
                  backgroundInactive={root.color_subtext}
                  circleSize={10}
                  switchRightPx={2}
                  switchLeftPx={2}
                  barHeight={15}
                  circleBorderWidth={0}
                  switchWidthMultiplier={3}
                />
              </View>
              <Modal visible={confirmationModal} transparent={true}>
                <TouchableOpacity
                  style={manageAlerts.centeredView}
                  onPress={() => {
                    setConfirmationModal(prev => !prev);
                    setToggle(prev => !prev);
                  }}
                  activeOpacity={1}></TouchableOpacity>
                <View style={manageAlerts.modalView}>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                      fontSize: 16,
                    }}>
                    Alert
                  </Text>
                  <Text style={[Removescripstyle.desptxt, {paddingTop: 16}]}>
                    Are you sure you want to delete alert?
                  </Text>
                  <View
                    style={{
                      ...alignment.row_alignC,
                      paddingTop: 16,
                      justifyContent: 'flex-end',
                    }}>
                    <TouchableOpacity
                      style={[Removescripstyle.yescontainer, {marginRight: 10}]}
                      onPress={() => confirmed(indexVal)}
                      // onPress={()=>console.log(indexVal)}
                    >
                      <Text style={Removescripstyle.yestxt}>Yes</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={Removescripstyle.nocontainer}
                      onPress={() => {
                        setConfirmationModal(prev => !prev);
                        setToggle(prev => !prev);
                      }}>
                      <Text style={Removescripstyle.notxt}>No</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </Modal>
            </View>
          );
        }}
      />
      <SetAlertModal
        visible={alertModal}
        onClose={() => setAlertModal(prev => !prev)}
      />
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        index={-1}
        closesheet={closeSheet}>
        <ManageAlertsFilter
          bottomSheetRef={bottomSheetRef}
          setCategoryFilter={setCategoryFilter}
          setAlertFilter={setAlertFilter}
          categoryFilters={categoryF}
          alertFilters={alertF}
        />
      </SortFilterBottomSheet>
      <SearchManageAlerts
        visible={searchModal}
        onClose={() => setSearchModal(prev => !prev)}
        data={filteredArr}
        setFilteredArray={setFilteredArray}
      />
    </View>
  );
};

const manageAlerts = StyleSheet.create({
  conatiner: {
    flex: 1,
    backgroundColor: root.color_active,
    padding: 16,
  },
  card: {
    backgroundColor: root.color_active,
    padding: 14,
    marginTop: 18,
    marginVertical: 6,
    shadowColor: '#000',
    marginHorizontal: 1,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerRightComponentView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 30,
    color: root.color_text,
    paddingTop: 32,
  },
  cardInnerContainer: {
    ...alignment.row_alingC_SpaceB,
  },
  symbolView: {
    ...alignment.row_alignC,
  },
  symbol: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  notice: {
    paddingTop: 10,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
  priceView: {
    ...alignment.row_alignC,
  },
  price: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 12,
  },
  modalView: {
    position: 'absolute',
    alignSelf: 'center',
    backgroundColor: root.color_active,
    marginTop: Dimensions.get('window').height * 0.4,
    borderRadius: 6,
    padding: 16,
    width: '70%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
    paddingLeft: 10,
    paddingTop: 10,
  },
});

export default ManageAlerts;

import React from 'react';
import {View, Text, Image} from 'react-native';
import {messageOrder} from '../../../theme/light';

const MessageOrder = props => {
  return (
    <View style={messageOrder.mainView}>
      <Image
        style={messageOrder.messageOrderImg}
        resizeMode="contain"
        source={require('../../../assets/Broker.png')}
      />
      <View>
        <Text style={messageOrder.messageOrderText}>{props?.title}</Text>
        <Text style={messageOrder.messageOrderDate}>{props?.date}</Text>
      </View>
    </View>
  );
};
export default MessageOrder;

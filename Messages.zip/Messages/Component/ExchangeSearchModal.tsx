import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {messageSearchModal} from '../../../theme/light';
import MessageOrder from './MessageOrder';
const ExchangeSearchModal = ({modalVisible, setModalVisible, data}) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter(item =>
        item.title.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const renderItem = ({item}: any) => {
    return <MessageOrder title={item?.title} date={item?.date} />;
  };

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(false);
      }}>
      <View>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
              setTextInputValue('');
              setFilterData([]);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search exchange Messages"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        {filterData?.length === 0 && textInputValue !== '' ? (
          <Text style={messageSearchModal.noDataText}>No data Found</Text>
        ) : (
          <FlatList
            data={filterData}
            keyExtractor={(_, index) => `item-${index}`}
            renderItem={renderItem}
          />
        )}
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default ExchangeSearchModal;

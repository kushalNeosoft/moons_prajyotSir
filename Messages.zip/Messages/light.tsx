// Replace style
// first
export const sideDrawerMessages = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  headerView: {
    ...alignment.row_alingC_SpaceB,
    height: 56,
    ...p.h_18,
  },
  backIconHeaderView: {
    ...alignment.row_alignC,
  },
  headerText: {
    ...size_family.rm_17,
    ...color.text,
    ...p.l_20,
  },
  headerBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  headerSearchIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  dropDownIcon: {
    fontSize: Font.font_normal_three,
    ...p.r_11,
  },
  scrollBarView: {
    ...alignment.row,
    borderRadius: 25,
    height: 32,
    ...p.h_18,
  },
  brokerTopBarTextBg: {
    ...m.r_10,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    borderColor: root.color_text,
    width: 78,
  },
  brokerTopBarText: {
    ...size_family.rm_11,
    ...p.h_9,
  },
  ordersTopBarTextBg: {
    ...m.r_5,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    width: 78,
  },
  ordersTopBarText: {
    ...size_family.rm_11,
    ...p.h_9,
  },
  nseTopBarTextBg: {
    ...m.r_5,
    height: 32,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
  },
  nseTopBarText: {
    ...size_family.rm_11,
    ...p.l_20,
    ...p.r_6,
  },
  topBarBackgroundView: {
    width: "100%",
    ...alignment.row,
    ...p.t_7,
  },
  activityIndicatore: {
    ...m.t_15,
    ...m.b_5,
    fontSize: 25,
  },
  noDataText: {
    ...m.t_40,
    ...size_family.rr_14,
    ...color.subtext,
    alignSelf: "center",
  },
  row: {
    ...alignment.row_alignC,
  },
  flatelist: {
    ...m.t_15,
    ...m.b_5,
  },
});

//second

export const messageSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: "100%",
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: "center",
    ...m.t_100,
  },
});

// third

export const messageOrder = StyleSheet.create({
  mainView: {
    width: "100%",
    backgroundColor: root.color_chipFilter,
    ...alignment.row,
    ...m.b_5,
  },
  messageOrderImg: {
    borderRadius: 25,
    height: 35,
    width: 35,
    ...bgColor.color_active,
    ...m.t_10,
    ...m.m_l_17,
  },
  messageOrderText: {
    ...size_family.rr_11,
    ...p.t_9,
    ...p.l_25,
    ...p.r_30,
    ...color.text,
    ...m.r_30,
  },
  messageOrderDate: {
    ...size_family.rl_9,
    ...p.l_25,
    ...color.text,
    ...p.t_3,
    ...p.b_10,
  },
});

//fourth

export const messagesModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: "100%",
    height: 51,
    ...bgColor.color_active,
    ...alignment.row_alingC_SpaceB,
  },
  modalItemTitle: {
    color: root.ion_rb_2,
    ...size_family.rm_13,
  },
  radioBtn: {
    color: root.ion_rb_2,
    fontSize: Font.font_normal_twenty_six,
  },
  modalDataFlatelist: {
    ...m.t_8,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
});

// latest margin and padding ->

// margin

export const margin = {
  m_l_5: {
    marginLeft: 5,
  },
  m_l_6: {
    marginLeft: 6,
  },
  m_l_4: {
    marginLeft: 4,
  },
  m_l_3: {
    marginLeft: 3,
  },
  m_l_10: {
    marginLeft: 10,
  },
  m_l_9: {
    marginLeft: 9,
  },
  m_l_15: {
    marginLeft: 15,
  },
  m_l_13: {
    marginLeft: 13,
  },
  m_l_16: {
    marginLeft: 16,
  },
  m_l_17: {
    marginLeft: 17,
  },
  m_l_70: {
    marginLeft: 70,
  },
  t_26: {
    marginTop: 26,
  },
  t_25: {
    marginTop: 25,
  },
  t_18: {
    marginTop: 18,
  },
  t_20: {
    marginTop: 20,
  },
  t_21: {
    marginTop: 21,
  },
  t_17: {
    marginTop: 17,
  },
  t_23: {
    marginTop: 23,
  },
  t_22: {
    marginTop: 22,
  },
  t_28: {
    marginTop: 28,
  },
  t_10: {
    marginTop: 10,
  },
  t_11: {
    marginTop: 11,
  },
  t_58: {
    marginTop: 58,
  },
  t_14: {
    marginTop: 14,
  },
  t_15: {
    marginTop: 15,
  },
  t_12: {
    marginTop: 12,
  },
  t_13: {
    marginTop: 13,
  },
  t_30: {
    marginTop: 30,
  },
  t_31: {
    marginTop: 30,
  },
  t_34: {
    marginTop: 30,
  },
  t_35: {
    marginTop: 35,
  },
  t_36: {
    marginTop: 36,
  },
  t_42: {
    marginTop: 42,
  },
  t_40: {
    marginTop: 40,
  },
  t_41: {
    marginTop: 41,
  },
  t_45: {
    marginTop: 45,
  },
  t_8: {
    marginTop: 8,
  },
  t_48: {
    marginTop: 48,
  },
  t_50: {
    marginTop: 50,
  },
  t_100: {
    marginTop: 50,
  },
  t_16: {
    marginTop: 16,
  },
  t_6: {
    marginTop: 6,
  },
  t_5: {
    marginTop: 5,
  },
  t_2: {
    marginTop: 2,
  },
  b_8: {
    marginBottom: 8,
  },
  b_7: {
    marginBottom: 7,
  },
  b_12: {
    marginBottom: 12,
  },
  b_16: {
    marginBottom: 16,
  },
  b_18: {
    marginBottom: 18,
  },
  b_20: {
    marginBottom: 20,
  },
  b_23: {
    marginBottom: 23,
  },
  b_30: {
    marginBottom: 30,
  },
  b_5: {
    marginBottom: 5,
  },
  b_32: {
    marginBottom: 32,
  },
  b_35: {
    marginBottom: 35,
  },
  b_60: {
    marginBottom: 60,
  },
  b_15: {
    marginBottom: 15,
  },
  b_14: {
    marginBottom: 14,
  },
  b_6: {
    marginBottom: 6,
  },
  b_9: {
    marginBottom: 9,
  },
  h_13: {
    marginHorizontal: 13,
  },
  h_16: {
    marginHorizontal: 16,
  },
  h_35: {
    marginHorizontal: 35,
  },
  r_12: {
    marginRight: 12,
  },
  r_13: {
    marginRight: 13,
  },
  r_15: {
    marginRight: 12,
  },
  r_25: {
    marginRight: 25,
  },
  r_30: {
    marginRight: 30,
  },
  r_10: {
    marginRight: 10,
  },
  r_5: {
    marginRight: 5,
  },
  v_20: {
    marginVertical: 20,
  },
  v_10: {
    marginVertical: 10,
  },

  v_16: {
    marginVertical: 16,
  },
};

//padding

const padding = {
  16: {
    padding: 16,
  },
  l_25: {
    paddingLeft: 25,
  },
  l_20: {
    paddingLeft: 20,
  },
  r_15: {
    paddingRight: 15,
  },
  r_30: {
    paddingRight: 30,
  },
  r_10: {
    paddingRight: 10,
  },
  r_6: {
    paddingRight: 6,
  },
  r_11: {
    paddingRight: 11,
  },
  h_3: {
    paddingHorizontal: 3,
  },
  l_5: {
    paddingLeft: 5,
  },
  l_4: {
    paddingLeft: 4,
  },
  l_8: {
    paddingLeft: 8,
  },
  l_16: {
    paddingLeft: 16,
  },
  h_6: {
    paddingHorizontal: 6,
  },
  h_5: {
    paddingHorizontal: 5,
  },
  h_8: {
    paddingHorizontal: 8,
  },
  h_9: {
    paddingHorizontal: 9,
  },
  v_2: {
    paddingVertical: 2,
  },
  t_3: {
    paddingTop: 3,
  },
  t_1: {
    paddingTop: 1,
  },
  t_8: {
    paddingTop: 8,
  },
  t_9: {
    paddingTop: 9,
  },
  t_7: {
    paddingTop: 7,
  },
  h_7: {
    paddingHorizontal: 7,
  },
  h_10: {
    paddingHorizontal: 10,
  },
  h_12: {
    paddingHorizontal: 12,
  },
  v_8: {
    paddingVertical: 8,
  },
  v_10: {
    paddingVertical: 10,
  },
  h_16: {
    paddingHorizontal: 16,
  },
  t_20: {
    paddingTop: 20,
  },
  h_14: {
    paddingHorizontal: 14,
  },
  h_15: {
    paddingHorizontal: 15,
  },
  h_18: {
    paddingHorizontal: 18,
  },
  h_20: {
    paddingHorizontal: 20,
  },
  t_40: {
    paddingTop: 40,
  },
  t_35: {
    paddingTop: 35,
  },
  t_36: {
    paddingTop: 36,
  },
  t_37: {
    paddingTop: 37,
  },
  t_18: {
    paddingTop: 18,
  },
  t_19: {
    paddingTop: 19,
  },
  b_17: {
    paddingBottom: 17,
  },
  b_10: {
    paddingBottom: 10,
  },
  b_2: {
    paddingBottom: 2,
  },
  b_30: {
    paddingBottom: 30,
  },
  t_5: {
    paddingTop: 10,
  },
  t_10: {
    paddingTop: 10,
  },
  p_11: {
    padding: 11,
  },
  p_10: {
    padding: 10,
  },
  p_6: {
    padding: 6,
  },
  p_5: {
    padding: 5,
  },
  p_7: {
    padding: 7,
  },
  p_1: {
    padding: 1,
  },
  p_3: {
    padding: 3,
  },
  p_2: {
    padding: 2,
  },
  l_10: {
    paddingLeft: 10,
  },
  t_12: {
    paddingTop: 12,
  },
  l_12: {
    paddingLeft: 12,
  },
  h_24: {
    paddingHorizontal: 24,
  },
  v_12: {
    paddingVertical: 12,
  },
};

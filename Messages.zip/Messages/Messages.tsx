import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {sideDrawerMessages, messagesModal} from '../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
import MessagesModal from './Component/MessagesModal';
import MessageOrder from './Component/MessageOrder';
import BrokerSearchModal from './Component/BrokerSearchModal';
import OrderSearchModal from './Component/OrderSearchModal';
import ExchangeSearchModal from './Component/ExchangeSearchModal';
import {root} from '../../styles/colors';
const modalData = [
  {
    title: 'NSE CASH',
  },
];

let ordersData: ArrayLike<any> | null | undefined = [];
let brokersData: ArrayLike<any> | null | undefined = [];
let exchangeData: ArrayLike<any> | null | undefined = [];

const Messages = () => {
  const [index, setIndex] = useState(0);
  const [visibleModal, setVisibleModal] = useState(false);
  const [modalChip, setModalChip] = useState(modalData[0].title);
  const [modalVisible, setModalVisible] = useState(false);
  const [orderModal, setOrderModal] = useState(false);
  const [exchangeModal, setExchangeModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigation = useNavigation();
  const exchangeGlobalData = [
    {
      title: 'Attn. Members:',
      date: '14 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'Upper price range of WIPRO is Being relaxed',
      date: '17 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'From 10% to 15%',
      date: '18 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
      date: '19 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'Attn. Members:',
      date: '20 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'Lower Price range Of Wipro is Being Realxed',
      date: '20 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
      date: '19 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'EOD Trade Message : 14Jun 2023 : NSEBUYITC EQ @10.00',
      date: '14 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'BUY nifty @ 19000',
      date: '17 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'Real Time Trade messages : 6/14/2023 YKRAF',
      date: '18 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
  ];
  const [exchangeData, setExchangeData] = useState([
    {
      title: 'Attn. Members:',
      date: '14 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'Upper price range of WIPRO is Being relaxed',
      date: '17 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'From 10% to 15%',
      date: '18 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
      date: '19 Jun 23 17:50PM',
      segment: 'NSE CASH',
    },
    {
      title: 'Attn. Members:',
      date: '20 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'Lower Price range Of Wipro is Being Realxed',
      date: '20 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
      date: '19 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'EOD Trade Message : 14Jun 2023 : NSEBUYITC EQ @10.00',
      date: '14 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'BUY nifty @ 19000',
      date: '17 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
    {
      title: 'Real Time Trade messages : 6/14/2023 YKRAF',
      date: '18 Jun 23 17:50PM',
      segment: 'BSE CASH',
    },
  ]);

  const fetchData = () => {
    // Replace this with your actual data fetching logic
    setTimeout(() => {
      ordersData = [
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '15 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '16 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '17 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '18 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '19 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '20 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '21 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '22 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '23 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '24 Jun 23 17:50PM',
        },
      ];
      brokersData = [
        {
          title: 'EOD Trade Message : 14Jun 2023 : NSEBUYITC EQ @10.00',
          date: '14 Jun 23 17:50PM',
        },
        {
          title: 'BUY nifty @ 19000',
          date: '17 Jun 23 17:50PM',
        },
        {
          title: 'Real Time Trade messages : 6/14/2023 YKRAF',
          date: '18 Jun 23 17:50PM',
        },
        {
          title:
            'Real Time Trade Messages : 6/14/2023 11:40:01 AM NSE BUY ITC EQ @10.00 Order #21600 Trade #15607 init By Wave_Mobile Mod By ',
          date: '19 Jun 23 17:50PM',
        },
        {
          title:
            'Orders Details : 6/14/2023 11:40:01 AM NSE BUY ITC EQ VAlidity up To That @10.00 Order #21600 Trade #15607 init By Wave_Mobile Mod By ',
          date: '20 Jun 23 17:50PM',
        },
      ];

      setIsLoading(false);
    }, 2000);
  };
  useEffect(() => {
    fetchData();
  }, []);

  const renderItem = ({item}: any) => {
    return <MessageOrder title={item?.title} date={item?.date} />;
  };

  const topBar = () => {
    return (
      <View style={sideDrawerMessages.scrollBarView}>
        <TouchableOpacity
          style={[
            sideDrawerMessages.brokerTopBarTextBg,
            {
              backgroundColor: index == 0 ? root.color_textual : 'transparent',
              borderWidth: index != 0 ? 0.9 : 0,
            },
          ]}
          onPress={() => {
            setIndex(0);
          }}>
          <Text
            style={[
              sideDrawerMessages.brokerTopBarText,
              {
                color: index == 0 ? root.color_active : root.color_text,
              },
            ]}>
            Broker
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            sideDrawerMessages.ordersTopBarTextBg,
            {
              backgroundColor: index == 1 ? root.color_textual : 'transparent',
              borderWidth: index != 1 ? 0.9 : 0,
            },
          ]}
          onPress={() => {
            setIndex(1);
          }}>
          <Text
            style={[
              sideDrawerMessages.ordersTopBarText,
              {
                color: index == 1 ? root.color_active : root.color_text,
              },
            ]}>
            Order
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            sideDrawerMessages.nseTopBarTextBg,
            {
              backgroundColor: index == 2 ? root.color_textual : 'transparent',
              borderWidth: index != 2 ? 0.9 : 0,
            },
          ]}
          onPress={() => {
            setIndex(2);
            setVisibleModal(true);
          }}>
          <View style={sideDrawerMessages.row}>
            <Text
              style={[
                sideDrawerMessages.nseTopBarText,
                {color: index == 2 ? root.color_active : root.color_subtext},
              ]}>
              {modalChip}
            </Text>
            <MaterialIcons
              name="keyboard-arrow-down"
              style={[
                sideDrawerMessages.dropDownIcon,
                {
                  color: index == 2 ? root.color_active : root.color_text,
                },
              ]}
            />
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  const onSearch = () => {
    if (index === 0) {
      setModalVisible(true);
    } else if (index === 1) {
      setOrderModal(true);
    } else if (index === 2) {
      setExchangeModal(true);
    }
  };
  useEffect(() => {
    let arr = [...exchangeGlobalData];
    arr = arr.filter((item, index) => {
      return item.segment.toLowerCase() == modalChip.toLowerCase();
    });
    console.log('setData', arr);
    setExchangeData(arr);
  }, [modalChip]);

  return (
    <View style={sideDrawerMessages.mainView}>
      {/* Header */}
      <View style={sideDrawerMessages.headerView}>
        <View style={sideDrawerMessages.backIconHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <Ionicons
              name="arrow-back"
              style={sideDrawerMessages.headerBackIcon}
            />
          </TouchableOpacity>
          <Text style={sideDrawerMessages.headerText}>Messages</Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            onSearch();
          }}>
          <Ionicons
            name="search-sharp"
            style={sideDrawerMessages.headerSearchIcon}
          />
        </TouchableOpacity>
      </View>

      {/* TabBar */}

      <View style={sideDrawerMessages.topBarBackgroundView}>{topBar()}</View>
      {isLoading ? (
        <ActivityIndicator style={sideDrawerMessages.activityIndicatore} />
      ) : (
        <>
          {index === 0 && brokersData && brokersData.length > 0 ? (
            <FlatList
              data={brokersData}
              renderItem={renderItem}
              style={sideDrawerMessages.flatelist}
            />
          ) : index === 1 && ordersData && ordersData.length > 0 ? (
            <FlatList
              data={ordersData}
              renderItem={renderItem}
              style={sideDrawerMessages.flatelist}
            />
          ) : index === 2 && exchangeData && exchangeData.length > 0 ? (
            <FlatList
              data={exchangeData}
              renderItem={renderItem}
              style={sideDrawerMessages.flatelist}
            />
          ) : (
            <Text style={sideDrawerMessages.noDataText}>No data Found</Text>
          )}
        </>
      )}

      <MessagesModal
        visibleModal={visibleModal}
        setVisibleModal={setVisibleModal}
        modalChip={modalChip}
        setModalChip={setModalChip}
      />
      <BrokerSearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={brokersData}
      />
      <OrderSearchModal
        modalVisible={orderModal}
        setModalVisible={setOrderModal}
        data={ordersData}
      />
      <ExchangeSearchModal
        modalVisible={exchangeModal}
        setModalVisible={setExchangeModal}
        data={exchangeData}
      />
    </View>
  );
};
export default Messages;

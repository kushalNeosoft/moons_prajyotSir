
export const assets={
    cross:require('../replacement-svg/cross.png'),
    delete:require('../replacement-svg/delete.png'),
    filter:require('../replacement-svg/filter.png'),
    heart:require('../replacement-svg/heart.png'),
    market:require('../replacement-svg/market.png'),
    options:require('../replacement-svg/options.png'),
    orders:require('../replacement-svg/orders.png'),
    password:require('../replacement-svg/password.png'),
    portfolio:require('../replacement-svg/portfolio.jpeg'),
    radio_checked:require('../replacement-svg/radio_checked.png'),
    radio_unchecked:require('../replacement-svg/radio_unchecked.png'),
    rupees:require('../replacement-svg/rupees.png'),
    search:require('../replacement-svg/search.png'),
    settings:require('../replacement-svg/settings.png'),
    watchlist:require('../replacement-svg/watchlist.png'),
    plus:require('../replacement-svg/add.png'),
    minus:require('../replacement-svg/remove.png'),
    menu:require('../replacement-svg/menu.png'),
    pencil:require('../replacement-svg/pencil.png'),
    
}
export enum SignupAction {
  UPDATE_NAME = 'update_name',
  UPDATE_PHONE_NUMBER = 'update_phone_number',
  UPDATE_STATE = 'update_state',
  UPDATE_CITY = 'update_city',
  UPDATE_EMAIL = 'update_email',
  UPDATE_ERROR = 'update_error',
}

interface SignupActionModel {
  payload: {
    name?: string;
    phoneNumber?: string;
    email?: string;
    state?: string;
    city?: string;
    error?: {
      email: string;
      password: string;
    };
  };
  type?: SignupAction;
}
export const signupReducer = (signup: any, action: SignupActionModel) => {
  switch (action.type) {
    case SignupAction.UPDATE_NAME:
      return {
        ...signup,
        name: action.payload.name,
        error: {
          ...signup.error,
          name: null,
        },
      };
    case SignupAction.UPDATE_PHONE_NUMBER:
      return {
        ...signup,
        phoneNumber: action.payload.phoneNumber,
        error: {
          ...signup.error,
          phoneNumber: null,
        },
      };

    case SignupAction.UPDATE_STATE:
      return {
        ...signup,
        state: action.payload.state,
        error: {
          ...signup.error,
          state: null,
        },
      };
    case SignupAction.UPDATE_CITY:
      return {
        ...signup,
        city: action.payload.city,
        error: {
          ...signup.error,
          city: null,
        },
      };
    case SignupAction.UPDATE_EMAIL:
      return {
        ...signup,
        email: action.payload.email,
        error: {
          ...signup.error,
          email: null,
        },
      };

    case SignupAction.UPDATE_ERROR:
      return {
        ...signup,
        error: action.payload.error,
      };
  }
};

import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {styles} from '../../navigators/Curverbottom';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import SquareOffList from './Component/SquareOffList';

const SquareOff = () => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [render, setRender] = useState(false);
  const overallData = [
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 0,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 1,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 2,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 3,
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      id: 4,
    },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
  ];
  const navigation = useNavigation();

  const onItemPress = pressedItem => {
    let arr = [...selectedItems];

    let idx = arr.findIndex((itm, index) => itm.id == pressedItem.id);

    if (idx == -1) {
      arr.push(pressedItem);
    } else {
      arr.splice(idx, 1);
    }

    setSelectedItems([...arr]);
  };

  const renderItem = ({item}) => {
    return (
      <SquareOffList
        onPress={onItemPress}
        stockName={item.companyName}
        buy={item.buy}
        item={item}
        selectedItems={selectedItems}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };
  const onSelectAllPress = () => {
    if (selectedItems.length === overallData.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems([...overallData]);
    }
  };
  return (
    <View style={squareOff.container}>
      <View style={squareOff.subContainer}>
        <View style={squareOff.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="arrowleft" style={squareOff.backIcon} />
          </TouchableOpacity>
          <Text style={squareOff.squareOffText}>Square Off</Text>
        </View>
        <View style={squareOff.orderHeadView}>
          <Text style={squareOff.orderText}>Orders(8)</Text>
          <TouchableOpacity
            onPress={onSelectAllPress}
            style={squareOff.selectAllTextIconView}>
            {selectedItems.length > 0 ? (
              <Text style={squareOff.selectAllText}>
                Selected ({selectedItems.length})
              </Text>
            ) : (
              <Text style={squareOff.selectAllText}>Select All</Text>
            )}
            {selectedItems.length === 0 ? (
              <MaterialIcons
                name="check-box-outline-blank"
                style={squareOff.selectAllIcon}
              />
            ) : selectedItems.length === overallData.length ? (
              <AntDesign name="checksquare" style={squareOff.selectAllIcon} />
            ) : (
              <AntDesign name="minussquare" style={squareOff.selectAllIcon} />
            )}
          </TouchableOpacity>
        </View>
        <View style={squareOff.headerBorder}></View>
        {/* FlateList code */}
        <FlatList
          data={overallData}
          renderItem={renderItem}
          contentContainerStyle={{
            marginTop: 13,
            paddingBottom: 70,
          }}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View style={squareOff.bottomView}>
        <View style={squareOff.bottominnerView}>
          <View>
            <Text style={squareOff.bottomSquareOffText}>square-off</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                // justifyContent: 'center',
              }}>
              <Text style={squareOff.bottomSelectedText}>Selected Orders</Text>
              {selectedItems.length > 0 ? (
                <View style={squareOff.bottomCountView}>
                  <Text style={squareOff.bottomCountText}>
                    {selectedItems.length}
                  </Text>
                </View>
              ) : (
                <></>
              )}
            </View>
          </View>
          <TouchableOpacity style={squareOff.bottomDoneBtn}>
            <Text style={squareOff.bottomDoneText(selectedItems.length)}>
              Done
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default SquareOff;

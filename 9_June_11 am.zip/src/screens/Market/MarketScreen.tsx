import React, {useState, useRef, useEffect, useCallback} from 'react';
import {Text, View, TouchableOpacity, ScrollView} from 'react-native';
import WhatsNew from './MarketScreenComponent/WhatsNew';
import NewProducts from './MarketScreenComponent/NewProducts';
import Indices from './MarketScreenComponent/Indices';
import MyScreeners from './MarketScreenComponent/MyScreeners';
import NewsAndAnnouncement from './MarketScreenComponent/NewsAndAnnouncement';
import Events from './MarketScreenComponent/Events';
import IPO from './MarketScreenComponent/IPO';
import {root, Font} from '../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import {marketScreen} from '../../theme/light';
import {MenuIcon} from '../../components/Svg/Svg';

const MarketScreen = () => {
  const scrollViewRef = useRef();
  const [index, setIndex] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const scrollRef = useRef();
  const [clickedOnTopHeader, setClickOnTopHeader] = useState(false);

  // Scrollable Top bar code
  const topHeader = useCallback(() => {
    return (
      <ScrollView
        horizontal={true}
        ref={scrollRef}
        contentContainerStyle={marketScreen.scrollBarView}
        showsHorizontalScrollIndicator={false}
        style={marketScreen.scrollView}>
        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 0 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(0);
            indexScroll = 0;
            scrollViewRef.current.scrollTo({y: 0});
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 0 ? root.color_active : root.color_subtext},
            ]}>
            New
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 1 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(1);
            indexScroll = 1;
            scrollViewRef.current.scrollTo({y: 400});
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 1 ? root.color_active : root.color_subtext},
            ]}>
            Indices
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 2 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);

            setIndex(2);
            indexScroll = 2;
            scrollViewRef.current.scrollTo({y: 600});

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 2 ? root.color_active : root.color_subtext},
            ]}
            numberOfLines={1}>
            Screeners
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 3 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(3);
            indexScroll = 3;
            scrollViewRef.current.scrollTo({y: 880});

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 3 ? root.color_active : root.color_subtext},
            ]}>
            News
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 4 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);

            setIndex(4);
            indexScroll = 4;
            scrollViewRef.current.scrollTo({y: 1300});
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 4 ? root.color_active : root.color_subtext},
            ]}>
            Events
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            marketScreen.scrollBarTextBg,
            {backgroundColor: index == 5 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(5);
            indexScroll = 5;
            scrollViewRef.current.scrollTo({y: 2500});
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              marketScreen.scrollBarText,
              {color: index == 5 ? root.color_active : root.color_subtext},
            ]}>
            IPO
          </Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }, [index]);
  const navigation = useNavigation();

  // MarketScreen View Start

  return (
    <View style={marketScreen.marketContainer}>
      {/* Market Header Code */}
      <View style={marketScreen.marketHeaderView}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
          <MenuIcon />
        </TouchableOpacity>
        <Text style={marketScreen.marketHeaderText}>Market</Text>
      </View>
      {/* market header code ends */}
      <View style={marketScreen.scrollBarBackgroundView}>{topHeader()}</View>

      <ScrollView
        ref={scrollViewRef}
        onScroll={event => {
          if (clickedOnTopHeader) {
            return;
          }

          setScrollY(event.nativeEvent.contentOffset.y);
          // update index based on scroll position
          if (
            event.nativeEvent.contentOffset.y >= 0 &&
            event.nativeEvent.contentOffset.y < 350
          ) {
            setIndex(0);
            indexScroll = 0;
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 350 &&
            event.nativeEvent.contentOffset.y < 550
          ) {
            setIndex(1);
            indexScroll = 1;
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 550 &&
            event.nativeEvent.contentOffset.y < 880
          ) {
            setIndex(2);
            indexScroll = 2;
          } else if (
            event.nativeEvent.contentOffset.y >= 880 &&
            event.nativeEvent.contentOffset.y < 1300
          ) {
            setIndex(3);
            indexScroll = 3;
          } else if (
            event.nativeEvent.contentOffset.y >= 1300 &&
            event.nativeEvent.contentOffset.y < 1500
          ) {
            setIndex(4);
            indexScroll = 4;
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 1500 &&
            event.nativeEvent.contentOffset.y < 1800
          ) {
            setIndex(5);
            indexScroll = 5;
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });
          }
        }}>
        <WhatsNew />
        <NewProducts />
        <Indices />
        <MyScreeners />
        <NewsAndAnnouncement />
        <Events />
        <IPO />
      </ScrollView>
    </View>
  );
};
export default MarketScreen;

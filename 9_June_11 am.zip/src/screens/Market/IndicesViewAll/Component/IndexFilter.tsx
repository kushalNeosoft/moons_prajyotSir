import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {indexFilter} from '../../../../theme/light';

const IndexFilter = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [priceValue, setPriceValue] = useState('');
  const [percentageValue, setPercentageValue] = useState('');
  const alphabet = ['A-Z', 'Z-A'];
  const price = ['High to Low', 'Low to High'];
  const percentage = ['High to Low', 'Low to High'];

  return (
    <View>
      <View style={indexFilter().Maincon}>
        <View style={indexFilter().space}>
          <View style={indexFilter().spaceinner}>
            <Text style={indexFilter().titleText}>Alphabetically</Text>
          </View>

          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabetValue(item)}
                style={
                  indexFilter({selected: alphabetValue === item})
                    .commonHtZSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={indexFilter().spacetwo}>
          <View style={indexFilter().spacetwoinner}>
            <Text style={indexFilter().titleText}>Price</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setPriceValue(item)}
                style={
                  indexFilter({selected: priceValue === item}).commonHtLSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>

        <View style={indexFilter().spacetwo}>
          <View style={indexFilter().spacetwoinner}>
            <Text style={indexFilter().titleText}>Percentage</Text>
          </View>

          <FlatList
            horizontal={true}
            data={percentage}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setPercentageValue(item)}
                style={
                  indexFilter({selected: percentageValue === item})
                    .commonHtLSelected
                }>
                <Text style={indexFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    </View>
  );
};
export default IndexFilter;

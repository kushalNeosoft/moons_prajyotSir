import React, {useState} from 'react';
import {
  View,
  Modal,
  StyleSheet,
  ScrollView,
  Text,
  FlatList,
  TouchableOpacity,
  TouchableHighlight,
  TextInput,
} from 'react-native';
import { filterModal } from '../../../../../theme/light';
import alignment from '../../../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import { root } from '../../../../../styles/colors';

const FilterModal = (props: any) => {
  const [modalHeight, setModalHeight] = useState(true);
  const [selectedCard, setSelectedCard] = useState('');
  const [selectedFund, setSelectedFund] = useState('');

  const setDisableScroll = () => {
    setModalHeight(false);
  };

  const transactionData = [
    'Current Month',
    'Last Month',
    'Last 3 Month',
    'Last 6 Month',
    'FY 21-22',
    'FY 22-23',
    'FY 23-24',
    'Custom Date',
  ];
  const fundsData = ['Add', 'Withdrawal', 'Transferred'];

  const renderTransactions = ({item}) => {
    return (
      <TouchableHighlight
        underlayColor={'grey'}
        activeOpacity={0.2}
        style={
          selectedCard === item ? filterModal.cardSelected : filterModal.cardUnselcted
        }
        onPress={() => setSelectedCard(item)}>
        <Text style={filterModal.itemTxt}>{item}</Text>
      </TouchableHighlight>
    );
  };

  const renderFunds = ({item}) => {
    return (
      <TouchableHighlight
        underlayColor={'grey'}
        activeOpacity={0.2}
        style={
          selectedFund === item ? filterModal.cardSelected : filterModal.cardUnselcted
        }
        onPress={() => setSelectedFund(item)}>
        <Text style={filterModal.itemTxt}>{item}</Text>
      </TouchableHighlight>
    );
  };

  return (
    <Modal
      transparent={true}
      visible={props.visible}
      onRequestClose={() => props.onClose()}>
              <TouchableOpacity style={filterModal.centeredView} onPress={() => props.onClose()} activeOpacity={1}></TouchableOpacity>
      <View
        style={
          modalHeight ? filterModal.modalContainerHalf : filterModal.modalContainerFull
        }>
        <ScrollView
          onScrollBeginDrag={() => setDisableScroll()}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="always"
          scrollEnabled={modalHeight}>
            {modalHeight? <View style={filterModal.top}>
            <Text style={filterModal.filter}>Filter</Text>
            <Entypo name='cross' size={29} color={'black'} />
            </View>:null}
          {!modalHeight ? (
            <View style={filterModal.header}>
              <View style={filterModal.titleContainer}>
                <TouchableOpacity onPress={()=>{
                    setModalHeight(prevState=>!prevState)
                    props.onClose()}}
                activeOpacity={1}
                >
                <AntDesign name="arrowleft" size={24} color={root.color_text} />
                </TouchableOpacity>
                <Text style={filterModal.titleTxt}>Sort & Filter</Text>
              </View>
              <Text style={filterModal.clearTxt}>Clear</Text>
            </View>
          ) : null}
          <Text style={filterModal.particularTitle}>Transactions</Text>
          <FlatList
            data={transactionData}
            style={{paddingTop: 12}}
            renderItem={renderTransactions}
            numColumns={2}
          />
          <Text style={filterModal.particularTitle}>Amount</Text>

          <View style={{...alignment.row, paddingTop: 12, paddingLeft: 16}}>
            <View style={filterModal.inputView}>
              <View style={filterModal.inputContainer}>
                <Text style={filterModal.itemTxt}>Min</Text>
                <View style={filterModal.txtInputStyle}>
                  <TextInput
                    style={filterModal.input}
                    keyboardType="numeric"
                    textAlign="right">
                    <Text>0</Text>
                  </TextInput>
                </View>
              </View>
            </View>

            <View style={[filterModal.inputView, {}]}>
              <View style={filterModal.inputContainer}>
                <Text style={filterModal.itemTxt}>Max</Text>
                <View style={filterModal.txtInputStyle}>
                  <TextInput
                    style={filterModal.input}
                    keyboardType="numeric"
                    textAlign="right">
                    <Text>0</Text>
                  </TextInput>
                </View>
              </View>
            </View>
          </View>

          <Text style={filterModal.particularTitle}>Funds</Text>
          <FlatList data={fundsData} renderItem={renderFunds} numColumns={2} />
        </ScrollView>
      </View>
    </Modal>
  );
};

export default FilterModal;

import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableWithoutFeedback,
  Keyboard,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FundsModal from '../AddFunds/components/Modal/Modal';
import { withDrawFunds } from '../../../theme/light';

const WithDrawFunds = (props: any) => {
  const [amount, setAmount] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [account, setAccount] = useState<string>(
    props?.route.params?.fundName ? props.route.params.fundName : 'TEST123',
  );

  const closeModal = () => {
    setShowModal(prevState => !prevState);
  };

  const setCurrentAccount = (value: string) => {
    setAccount(value);
  };

  const data = [
    {
      name: 'TEST123',
      available: '10000',
    },
    {
      name: 'BSE EQUITIES',
      available: '10000',
    },
    {
      name: 'NSE DERIVATIVE',
      available: '10000',
    },
    {
      name: 'NSE EQUITIES',
      available: '10000',
    },
  ];
  const navigation = useNavigation();
  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={withDrawFunds.container}>
        <View style={withDrawFunds.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={withDrawFunds.name}
            onPress={() => setShowModal(prevState => !prevState)}>
            <Text style={withDrawFunds.title}>{account}</Text>
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={withDrawFunds.caretDown}
            />
          </TouchableOpacity>
        </View>
        <View style={withDrawFunds.amountContainer}>
          <View style={withDrawFunds.addFundsTxtContainer}>
            <Text style={withDrawFunds.addFundsTxt}>Withdraw</Text>
            <Text style={withDrawFunds.addFundsTxt}>Funds</Text>
          </View>
          <View style={withDrawFunds.enterAmountContainer}>
            <View style={withDrawFunds.txtIpContainer}>
              <FontAwesome name="rupee" size={30} color={'black'} />
              <TextInput
                keyboardType="numeric"
                placeholder="0"
                style={withDrawFunds.txtIp}
                value={amount}
                onChangeText={amount => setAmount(amount)}
              />
            </View>
          </View>
        </View>
        <Text style={withDrawFunds.availableFund}>{`Available funds for withdrawal: ₹ 9999999999.99`}</Text>
        <TouchableOpacity
          style={withDrawFunds.addFundsBtn}
          activeOpacity={1}
          disabled={amount === '' || amount === undefined}>
          <Text
            style={
              amount === '' || amount === undefined
                ? withDrawFunds.addFundsBtnTxtDisabled
                : withDrawFunds.addFundsBtnTxt
            }>
            Request for Withdrawal
          </Text>
        </TouchableOpacity>
        <FundsModal
          onClose={closeModal}
          visible={showModal}
          data={data}
          setCurrentAccount={setCurrentAccount}
          account={account}
        />
      </View>
    </TouchableWithoutFeedback>
  );
};

export default WithDrawFunds;

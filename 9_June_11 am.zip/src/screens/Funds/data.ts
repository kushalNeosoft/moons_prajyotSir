export const data = [
  {
    title: 'Cash Desposit',
    value: '99,99,99,99,9999.99',
    indicator: 'Deposit',
  },
  {
    title: 'Notional Desposit',
    value: '0.00',
    indicator: 'Deposit',
  },
  {
    title: 'Adhoc Desposit',
    value: '0.00',
    indicator: 'Deposit',
  },
  {
    title: 'Overdraft Limit',
    value: '0.00',
    indicator: 'Deposit',
  },
  {
    title: 'Misc. Desposit',
    value: '0.00',
    indicator: 'Deposit',
  },
  {
    title: 'Manual Collateral',
    value: '0.00',
    indicator: 'Deposit',
  },
  {
    title: 'Funds Transferred Today',
    value: '0.00',
    indicator: 'Funds Transferred Today',
  },
  {
    title: 'DP Collateral',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'Pool Collateral',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'SAR Collateral',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'DP Pledged Collateral',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'Pool Pledged Collateral',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'Maximum Collateral Limit',
    value: '0.00',
    indicator: 'Collateral',
  },
  {
    title: 'DP CFS',
    value: '0.00',
    indicator: 'Credit For Sale',
  },
  {
    title: 'Pool CFS',
    value: '0.00',
    indicator: 'Credit For Sale',
  },
  {
    title: 'SAR CFS',
    value: '0.00',
    indicator: 'Credit For Sale',
  },
  {
    title: 'Maximum CFS Limit',
    value: '0.00',
    indicator: 'Credit For Sale',
  },
  {
    title: 'Maximum Option CFS',
    value: '0.00',
    indicator:'Option CFS',
  },
  {
    title: 'Equity Position',
    value: '0.00',
    indicator: 'Limit Utilization',
  },
  {
    title: 'Derivative Position',
    value: '0.00',
    indicator: 'Limit Utilization',
  },
  {
    title: 'Commodity Position',
    value: '0.00',
    indicator: 'Limit Utilization',
  },
  {
    title: 'Currency Position',
    value: '0.00',
    indicator: 'Limit Utilization',
  },
  {
    title: 'Funds Withdrawal/Allocation',
    value: '0.00',
    indicator: 'Funds Withdrawal/Allocation',
  },
  {
    title: 'Equity Position',
    value: '0.00',
    indicator: 'MTM Profit/Loss',
  },
  {
    title: 'Commodity Position',
    value: '0.00',
    indicator: 'MTM Profit/Loss',
  },
  {
    title: 'Currency Position',
    value: '0.00',
    indicator: 'MTM Profit/Loss',
  },
  {
    title: 'Derivative Position',
    value: '0.00',
    indicator: 'MTM Profit/Loss',
  },
  {
    title: 'Equity Position',
    value: '0.00',
    indicator: 'Booked Profit/Loss',
  },
  {
    title: 'Derivative Position',
    value: '0.00',
    indicator: 'Booked Profit/Loss',
  },
  {
    title: 'Commodity Position',
    value: '0.00',
    indicator: 'Booked Profit/Loss',
  },
  {
    title: 'Currency Position',
    value: '0.00',
    indicator: 'Booked Profit/Loss',
  },
];

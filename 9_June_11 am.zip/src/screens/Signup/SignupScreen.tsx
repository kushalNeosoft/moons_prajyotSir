import React, {useEffect, useReducer} from 'react';
import {
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';

import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import Validator from '../../helpers/Validator';
import useStyles from '../../styles/useStyles';

import {useTranslation} from 'react-i18next';
import {createSignupStyles} from './signup.styles';

import BackIcon from '../../assets/BackIcon';
import {SignupAction, signupReducer} from '../../redux/sigupRedux';
import { root } from '../../styles/colors';
import { SignupStyles } from '../../theme/light';

const SignupScreen = ({navigation}: any) => {
  const {t} = useTranslation();

  const {colors, styles} = useStyles(createSignupStyles);

  const [signup, dispatch] = useReducer(signupReducer, {
    error: {},
  });

  const signupSubmit = () => {
    const error = validate();

    if (error) {
      dispatch({
        type: SignupAction.UPDATE_ERROR,
        payload: {
          error,
        },
      });
    } else {
      console.log('Do Something');
    }
    // navigation.navigate('PhoneVerificationScreen');
  };
  const validate = (): any => {
    console.log(signup);

    const error: any = {};
    if (!Validator.genericValidator(signup.name)) {
      error.name = 'Name Cant Be Empty';
    }
    if (!Validator.genericValidator(signup.state)) {
      error.state = 'State Cant Be Empty';
    }
    if (!Validator.genericValidator(signup.city)) {
      error.city = 'City Cant Be Empty';
    }
    if (!Validator.phoneValidator(signup.phoneNumber)) {
      error.phoneNumber = 'Invalid Phone Number';
    }
    if (!Validator.emailValidator(signup.email)) {
      error.email = 'Invalid Email';
    }

    if (Object.keys(error).length === 0) {
      return null;
    }
    return error;
  };
  useEffect(() => {}, []);
  return (
    <ScrollView style={SignupStyles.scrollContainer}>
      <View style={SignupStyles.container}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            console.log('Here');
            navigation.goBack();
          }}>
          <View style={{width: 32, height: 32}}>
            <BackIcon style={SignupStyles.backIcon} />
          </View>
        </TouchableNativeFeedback>
        <Text style={[SignupStyles.heading, {marginTop: 30,marginBottom: 14}]}>Register Now!</Text>
        <View style={[SignupStyles.inputContainer, {marginTop: 16}]}>
          <TextInput
            style={SignupStyles.input}
            placeholder={'Name'}
            onChangeText={text =>
              dispatch({
                type: SignupAction.UPDATE_NAME,
                payload: {
                  name: text,
                },
              })
            }
            placeholderTextColor={'grey'}
          />
        </View>
        {signup.error.name && (
          <Text style={{color: 'red'}}>{signup.error.name}</Text>
        )}
        <View style={[SignupStyles.inputContainer, {marginTop: 16}]}>
          <TextInput
            style={SignupStyles.input}
            placeholder={'Phone Number'}
            keyboardType="phone-pad"
            onChangeText={text =>
              dispatch({
                type: SignupAction.UPDATE_PHONE_NUMBER,
                payload: {
                  phoneNumber: text,
                },
              })
            }
            placeholderTextColor={'grey'}
          />
        </View>
        {signup.error.phoneNumber && (
          <Text style={{color: 'red'}}>{signup.error.phoneNumber}</Text>
        )}
        <View style={[SignupStyles.inputContainer, {marginTop: 16}]}>
          <TextInput
            style={SignupStyles.input}
            placeholder={'Enter State'}
            onChangeText={text =>
              dispatch({
                type: SignupAction.UPDATE_STATE,
                payload: {
                  state: text,
                },
              })
            }
            placeholderTextColor={'grey'}
          />
        </View>
        {signup.error.state && (
          <Text style={{color: 'red'}}>{signup.error.state}</Text>
        )}
        <View style={[SignupStyles.inputContainer, {marginTop: 16}]}>
          <TextInput
            style={SignupStyles.input}
            placeholder={'Enter City'}
            onChangeText={text =>
              dispatch({
                type: SignupAction.UPDATE_CITY,
                payload: {
                  city: text,
                },
              })
            }
            placeholderTextColor={'grey'}
          />
        </View>
        {signup.error.city && (
          <Text style={{color: 'red'}}>{signup.error.city}</Text>
        )}
        <View style={[SignupStyles.inputContainer, {marginTop: 16}]}>
          <TextInput
            style={SignupStyles.input}
            placeholder={t('login.email')!}
            keyboardType="email-address"
            onChangeText={text =>
              dispatch({
                type: SignupAction.UPDATE_EMAIL,
                payload: {
                  email: text,
                },
              })
            }
            placeholderTextColor={'grey'}
          />
        </View>
        {signup.error.email && (
          <Text style={{color: 'red'}}>{signup.error.email}</Text>
        )}
        <View style={SignupStyles.block1ButtonContainer}>
          <View
            style={{
              borderRadius: 8,
              marginTop: 32,
            }}>
            <TouchableNativeFeedback
             disabled={
              !(
                signup.name &&
                signup.phoneNumber &&
                signup.state &&
                signup.city &&
                signup.email
              )
            }
              background={TouchableNativeFeedback.Ripple('blue', true)}
              onPress={() => {
                signupSubmit();
              }}>
               <View
                style={[
                  SignupStyles.buttonContainer,
                  // {
                  //   backgroundColor:
                  //     signup.name &&
                  //     signup.phoneNumber &&
                  //     signup.state &&
                  //     signup.city &&
                  //     signup.email
                  //       ? 
                  //       : 'lightblue',
                  // },
                ]}>
                <Text style={[SignupStyles.buttonText,{
                    color:
                    signup.name &&
                    signup.phoneNumber &&
                    signup.state &&
                    signup.city &&
                    signup.email
                          ? root.color_active
                          : root.color_disable,
                        opacity: signup.name &&
                        signup.phoneNumber &&
                        signup.state &&
                        signup.city &&
                        signup.email
                        ? 1
                        : 0.3,
                  }]}>Submit</Text>
                <ArrowForwardIcon style={[SignupStyles.buttonImage,,{
                    color:
                    signup.name &&
                    signup.phoneNumber &&
                    signup.state &&
                    signup.city &&
                    signup.email
                          ? root.color_active
                          : root.color_disable,
                        opacity: signup.name &&
                        signup.phoneNumber &&
                        signup.state &&
                        signup.city &&
                        signup.email
                        ? 1
                        : 0.3,
                  }]} />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
      </View>
    </ScrollView>
  );
};

export default SignupScreen;

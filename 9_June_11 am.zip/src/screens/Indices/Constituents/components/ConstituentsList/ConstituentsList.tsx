import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import alignment from '../../../../../components/utils/alignment';
import { constituentsListComponent } from '../../../../../theme/light';
import PlusIcon from '../../../../../components/Icons-remove/PlusIcon';

const ConstituentsList = (props: any) => {
  return (
    <View style={constituentsListComponent.container}>
      <View>
        <View style={{...alignment.row}}>
          <Text style={constituentsListComponent.stockName}>
            {props.stockName}
          </Text>
          <Text style={constituentsListComponent.nseTxt}>NSE</Text>
        </View>
        <View style={{...alignment.row}}>
          {props.showIcon === true && (
            <MaterialCommunityIcons
              name="crown-circle"
              size={16}
              color="#ffd700"
            />
          )}
          {props.showIcon === true ? (
            <Text
              style={
                props.title === 'Vol.Gainer'
                  ? constituentsListComponent.volGainerTxt
                  : props.title === 'Pr.Loser'
                  ? constituentsListComponent.prLoserTxt
                  : constituentsListComponent.defaultTxt
              }>
              {props.title}
            </Text>
          ) : null}
        </View>
      </View>

      <View style={{...alignment.row_alignC}}>
        <View
          style={
            props.price > 200 && props.price < 300
              ? constituentsListComponent.rightValuesView_200_300
              : props.price > 300 && props.price < 500
              ? constituentsListComponent.rightValuesView_300_500
              : constituentsListComponent.rightValuesDefault
          }>
          <Text style={constituentsListComponent.currentPriceTxt}>
            {props.price}
          </Text>
          <Text style={constituentsListComponent.changes}>{props.changes}</Text>
        </View>
        <TouchableOpacity style={constituentsListComponent.bottonView}>
          <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() =>
            props.addToScripts(props.index, props.stockName, true)
          }>
          <PlusIcon
            size={26}
            style={{marginHorizontal: 5}}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ConstituentsList;

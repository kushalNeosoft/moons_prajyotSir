import React, {memo} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Fontisto from 'react-native-vector-icons/Fontisto';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {MenuIcon} from '../../../components/Svg/Svg';
import {Cfont, Font, root} from '../../../styles/colors';
import { useSelector } from 'react-redux';
import { headerComp } from '../../../theme/light';

const HeaderComp = (props: any) => {
  const getScriptName=useSelector(state=>state.Reducer.scriptName);
  console.log('ScriptName in header Component',getScriptName)
  return (
    <View style={headerComp.headerView}>
      <View style={headerComp.headerLeftContainer}>
        <MenuIcon />
        <TouchableOpacity
          style={headerComp.chooseOrderContainer}
          onPress={() => props.orderModalToggle()}>
          <View>
            <Text style={headerComp.orderTxt}>Orders</Text>
            <Text style={headerComp.chosenOrderTxt}>{props.scriptName}</Text>
          </View>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
      </View>
      <View style={{...alignment.row}}>
        <Fontisto
          name="search"
          size={20}
          color={'black'}
          style={{paddingRight: '5%'}}
        />
        <FontAwesome5 name="sliders-h" color={'black'} size={20} />
      </View>
    </View>
  );
};

export default memo(HeaderComp);

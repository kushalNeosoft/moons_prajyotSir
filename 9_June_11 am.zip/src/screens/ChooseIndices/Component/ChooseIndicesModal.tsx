import React, {useState} from 'react';
import {TouchableOpacity, FlatList} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {TextInput} from 'react-native';
import {chooseIndicesModal} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import IndicesList from './IndicesList';
const ChooseIndicesModal = ({modalVisible, setModalVisible, onPress}: any) => {
  const chipData = ['NSE', 'BSE', 'NSECDS'];
  const [dropDownChip, setDropDownChip] = useState<string>(chipData[0]);
  const [dropDown, setDropDown] = useState<boolean>(false);

  const stockData = [
    {
      stockName: 'NIFTY MNC',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY NEXT 50',
      price: 16727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY 50',
      price: 13427.48,
      changes: '-4.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY IT',
      price: 17746.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY BANK',
      price: 17464.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY 100',
      price: 16627.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY PSE',
      price: 15727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY PHARAMA',
      price: 16527.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY CPSE',
      price: 17777.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY ENERGY',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'SHA 50',
      price: 16527.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'CONDIS',
      price: 15527.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'INDSTR',
      price: 17627.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'TELCOM',
      price: 13727.48,
      changes: '-3.71(-0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'MIDSEL',
      price: 12727.48,
      changes: '-2.71(-0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'MSX7N10YIR',
      price: 17727.46,
      changes: '+48.71(+0.30%)',
      chip: 'nsecds',
    },
    {
      stockName: 'NIFTY HGDA',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY HSHA',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JDHS',
      price: 17727.48,
      changes: '+78.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JHSN',
      price: 17727.48,
      changes: '+54.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JDJDJ',
      price: 17827.48,
      changes: '+47.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCJD',
      price: 17727.48,
      changes: '+33.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCHD',
      price: 13727.48,
      changes: '-48.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCJD',
      price: 12727.48,
      changes: '-8.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNJDKDC',
      price: 11727.48,
      changes: '-2.71(-0.30%)',
      chip: 'nse',
    },
  ];

  const renderItem = ({item}: any) => {
    if (item.chip == dropDownChip.toLocaleLowerCase()) {
      return (
        <IndicesList
          stockName={item.stockName}
          price={item.price}
          changes={item.changes}
          setModalVisible={setModalVisible}
          item={item}
          onPress={onPress}
        />
      );
    } else {
      return null;
    }
  };
  const chipRenderItem = ({item}: any) => {
    return (
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          setDropDownChip(item);
          setDropDown(false);
        }}>
        <Text style={chooseIndicesModal.dropDownItems}>{item}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      style={chooseIndicesModal.modal}
      animationType="none"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={chooseIndicesModal.headerView}>
        <View style={chooseIndicesModal.headerInsideView}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(false);
            }}>
            <Ionicons name="close-sharp" style={chooseIndicesModal.crossIcon} />
          </TouchableOpacity>
          <View style={{zIndex: 100}}>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                setDropDown(!dropDown);
              }}
              style={chooseIndicesModal.dropDown}>
              <Text style={chooseIndicesModal.dropDownText}>
                {dropDownChip}
              </Text>
              <MaterialIcons
                name="keyboard-arrow-down"
                style={chooseIndicesModal.arrowIcon}
              />
            </TouchableOpacity>
            {dropDown ? (
              <View style={chooseIndicesModal.dropDownListView}>
                <FlatList
                  data={chipData}
                  renderItem={chipRenderItem}
                  contentContainerStyle={{marginBottom: 2, paddingTop: 2}}
                  keyExtractor={(_, index) => `item-${index}`}
                />
              </View>
            ) : (
              <></>
            )}
          </View>

          <Text style={chooseIndicesModal.headerTitle}>Choose Indices</Text>
        </View>
        <TouchableOpacity onPress={() => {}}>
          <MaterialIcons name="search" style={chooseIndicesModal.searchIcon} />
        </TouchableOpacity>
      </View>
      <View style={chooseIndicesModal.listView(dropDown)}>
        <FlatList
          data={stockData}
          renderItem={renderItem}
          contentContainerStyle={{marginBottom: 8, paddingTop: 22}}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
    </Modal>
  );
};
export default ChooseIndicesModal;

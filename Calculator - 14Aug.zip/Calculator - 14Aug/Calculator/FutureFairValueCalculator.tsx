import {Text, TextInput, TouchableNativeFeedback, View} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import MinusIcon from '../../assets/MinusIcon';
import {Popable} from 'react-native-popable';
import InfoIcon from '../../assets/InfoIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import CloseIcon from '../../assets/CloseIcon';
import React, {useState} from 'react';
import {useNavigation} from '@react-navigation/native';
import {future} from '../../theme/light';

const FutureFairValueCalculator = () => {
  const [scrip, setScrip] = useState<string>('');
  const [price, setPrice] = useState<string>('');
  const [contract, setContract] = useState<string>('');
  const [expiryDays, setExpiryDays] = useState<number>(0);
  const [interestRate, setInterestRate] = useState<number>(0);
  const [dividend, setDividend] = useState<string>('');

  const navigation = useNavigation();

  const clear = () => {
    setScrip('');
    setPrice('');
    setContract('');
    setExpiryDays(0);
    setInterestRate(0);
    setDividend('');
  };
  console.log('scrip', scrip);
  console.log('price', price);

  const FutureFairCallBack = (name, price) => {
    setScrip(name);
    setPrice(price);
  };

  const handleFocus = () => {
    navigation.navigate('CalculatorLookup', {
      name: 'Future Fair Value',
      FutureFairCallBack: FutureFairCallBack,
    });
  };

  return (
    <View style={future.main}>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
        onPress={() => navigation.goBack()}>
        <View style={future.main1}>
          <CloseIcon style={future.closeIcon} />
        </View>
      </TouchableNativeFeedback>
      <Text style={future.Future}>Future Fair</Text>
      <Text style={future.value}>Value Calculator</Text>
      <View style={future.top}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={clear}>
          <View style={future.clearView}>
            <Text style={future.clear}>Clear</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
      <View>
        <View style={future.sub}>
          <View style={future.sub1}>
            <Text style={future.txt}>Scrip</Text>
            <View>
              <TextInput
                style={future.textInput}
                placeholder="Search Scrip"
                placeholderTextColor={root.color_subtext}
                value={scrip}
                onChangeText={value => setScrip(value)}
                onFocus={handleFocus}
              />
            </View>
          </View>
          <View style={future.sub2}>
            <Text style={future.txt}>Scrip Price</Text>
            <View>
              <TextInput
                style={future.textInput}
                keyboardType="number-pad"
                placeholderTextColor={root.color_subtext}
                placeholder=""
                value={price}
                onChangeText={value => setPrice(value)}
              />
            </View>
          </View>
        </View>
        <View style={{marginTop: 28}}>
          <Text style={future.txt}>Contract Days</Text>
          <View style={future.inputView}>
            <TextInput
              style={future.Expiry}
              placeholder="Enter Expiry"
              placeholderTextColor={root.color_subtext}
              value={contract}
              onChangeText={value => setContract(value)}
            />
            <View style={{flex: 1, flexDirection: 'row'}}>
              <View style={{}}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setExpiryDays(prev => prev - 1);
                  }}>
                  <View>
                    <MinusIcon style={future.Minus} />
                  </View>
                </TouchableNativeFeedback>
              </View>
              <View style={{flex: 1}}>
                <Text style={{textAlign: 'center'}}>{expiryDays}</Text>
              </View>
              <Text style={future.Days}>Days</Text>
              <View
                style={{
                  marginHorizontal: 12,
                }}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setExpiryDays(prev => prev + 1);
                  }}>
                  <View>
                    <AddIcon style={future.AddIcon} />
                  </View>
                </TouchableNativeFeedback>
              </View>
            </View>
          </View>
        </View>
        <View style={future.sub3}>
          <View style={future.sub1}>
            <Text style={future.txt}>Interest Rate (%)</Text>
            <View style={future.inputView}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                onPress={() => {
                  setInterestRate(prev => prev - 0.1);
                }}>
                <View style={{padding: 8}}>
                  <MinusIcon style={future.MinusOne} />
                </View>
              </TouchableNativeFeedback>
              <TextInput
                style={future.textZero}
                placeholder="0.00"
                placeholderTextColor={root.color_subtext}
                value={interestRate?.toString()}
                onChangeText={(value: any) => setInterestRate(value)}
              />
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                onPress={() => {
                  setInterestRate(prev => prev + 0.1);
                }}>
                <View style={{padding: 8}}>
                  <AddIcon style={future.AddOne} />
                </View>
              </TouchableNativeFeedback>
            </View>
            <View style={future.popMain}>
              <Popable
                style={future.pop}
                content="Something1"
                position="bottom">
                <InfoIcon style={future.Info} />
              </Popable>

              <Text style={future.range}>Range:</Text>
              <Text style={future[99]}>0-99%</Text>
            </View>
          </View>
          <View style={future.Div}>
            <Text style={future.txt}>Dividend</Text>
            <View>
              <TextInput
                style={future.textInput}
                keyboardType="number-pad"
                placeholder="Enter Value"
                placeholderTextColor={root.color_subtext}
                value={dividend}
                onChangeText={value => setDividend(value)}
              />
            </View>

            <View style={future.popMain}>
              <Popable style={future.pop} content="Something" position="bottom">
                <InfoIcon style={future.Info} />
              </Popable>

              <Text style={future.range}>Range:</Text>
              <Text style={future[99]}>0-99%</Text>
            </View>
          </View>
        </View>

        <View style={future.btnMain}>
          <Text style={future.btnTxt}>Calculate</Text>
          <ArrowForwardIcon style={future.Arrow} />
        </View>
      </View>
    </View>
  );
};
export default FutureFairValueCalculator;

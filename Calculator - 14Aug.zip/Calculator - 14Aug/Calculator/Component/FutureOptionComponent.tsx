import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import Theme from '../../../theme/Theme';
import FutureOptionValueStyle from '../../../styles/Views/FutureOptionValueStyle';
import {useNavigation} from '@react-navigation/native';

const FutureOptionComponent = ({
  data,
  name,
  FutureFairCallBack,
  OptionValueCallBack,
}: any) => {
  const navigation = useNavigation();
  const {FutureOptionValueStyles} = FutureOptionValueStyle();
  const {root} = Theme();
  const onSubmit = () => {
    if (name === 'Future Fair Value') {
      FutureFairCallBack(data.title, data.price);
    } else if (name === 'Option Value') {
      OptionValueCallBack(data.title, data.price);
    }
    navigation.goBack();
  };
  return (
    <TouchableOpacity
      onPress={onSubmit}
      style={FutureOptionValueStyles.mainView}
      activeOpacity={1}>
      <Feather name="circle" size={23} color={root.color_text} />
      <View style={FutureOptionValueStyles.detailView}>
        <View style={FutureOptionValueStyles.rowCenter}>
          <Text style={FutureOptionValueStyles.title}>{data.title}</Text>
          <Text style={FutureOptionValueStyles.price}>{data.price}</Text>
        </View>
        <View style={FutureOptionValueStyles.rowCenter}>
          <Text style={FutureOptionValueStyles.chip}>{data.exchange}</Text>
          <Text style={FutureOptionValueStyles.subTitle}>{data.subTitle}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default FutureOptionComponent;

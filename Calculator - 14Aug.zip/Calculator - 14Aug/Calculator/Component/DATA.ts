
 export const recommdata = [
    {
      title: 'ICICIGI',
    },
    {
      title: 'VGUARD',
    },
    {
      title: 'KKCL',
    },
    {
      title: 'ALKEM',
    },
    {
      title: 'TCS',
    },
  ];

  export const TrendingData = [
    {
      title: 'ICICIGI',
    },
    {
      title: 'VGUARD',
    },
    {
      title: 'KKCL',
    },
    {
      title: 'ALKEM',
    },
    {
      title: 'KALPATPOWR',
    },
    {
      title: 'CREDITACC',
    },
    {
      title: 'HDFCLIFE',
    },
  ];


export const FutureFairAndOptionData =[{
    title:'ICICIGI',
    price:'1327.85',
    exchange:"NSE",
    subTitle:'ICICI LOMBARK LIMITED'
},{
    title:'ICICIGI',
    price:'13268.15',
    exchange:"NSE",
    subTitle:'ICICIGI A'
},
{
    title:'ICICIGI 31 AUG FUT',
    price:'13438.04',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC LTD'
},
{
    title:'ICICIGI 28 SEP',
    price:'132.143',
    exchange:"NSE",
    subTitle:'ICICI GHT KKT'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},{
    title:'VGUARD',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'VGAURD IND LTD.'
},
{
    title:'VGUARD',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'VGAURD A'
},
{
    title:'KKCL',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'KEWAL KIRAN LTD.'
},
{
    title:'KKCL',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'KEWAL B'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ALKM LTD.'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"BSE",
    subTitle:'ALKM LTD IND B.'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"BSE",
    subTitle:'ALKM B.'
}
]

export const SpanMarginData =[{
    title:'ICICIGI',
    price:'1327.85',
    exchange:"NSE",
    subTitle:'ICICI LOMBARK LIMITED'
},{
    title:'ICICIGI',
    price:'13268.15',
    exchange:"NSE",
    subTitle:'ICICIGI A'
},
{
    title:'ICICIGI 31 AUG FUT',
    price:'13438.04',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC LTD'
},
{
    title:'ICICIGI 28 SEP',
    price:'132.143',
    exchange:"NSE",
    subTitle:'ICICI GHT KKT'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},
{
    title:'ICICIGI 15 SEP 600.00 PE',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ICICIGI A GIC'
},{
    title:'VGUARD',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'VGAURD IND LTD.'
},
{
    title:'VGUARD',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'VGAURD A'
},
{
    title:'KKCL',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'KEWAL KIRAN LTD.'
},
{
    title:'KKCL',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'KEWAL B'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"NSE",
    subTitle:'ALKM LTD.'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"BSE",
    subTitle:'ALKM LTD IND B.'
},
{
    title:'ALKEM',
    price:'1326.15',
    exchange:"BSE",
    subTitle:'ALKM B.'
}
]
import React, {useEffect, useState} from 'react';
import {FlatList, View, Text} from 'react-native';
import SpanMarginComponent from './SpanMarginComponent';
import SpanMarginFutureOption from '../../../styles/Views/SpanMarginFutureOption';
import {SpanMarginData} from './DATA';
import Theme from '../../../theme/Theme';
import SkeletonPlaceholder from '../../../components/Skeleton/SkeletonConstituents';

const SpanMarginOption = ({textInputValue}: any) => {
  const {SpanMarginFutureOptionStyles} = SpanMarginFutureOption();
  const {root} = Theme();
  const [filterData, setFilterData] = useState<any>('');
  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = SpanMarginData;
      const filterTempList = mainList.filter(item =>
        item.title.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  useEffect(() => {
    searchFilterOnList(textInputValue);
  }, [textInputValue]);

  const renderItem = ({item}) => {
    return <SpanMarginComponent data={item} />;
  };
  return (
    <View style={SpanMarginFutureOptionStyles.mainView}>
      <View style={SpanMarginFutureOptionStyles.flateListView}>
        {filterData?.length === 0 && textInputValue !== '' ? (
          <Text style={SpanMarginFutureOptionStyles.noDataText}>
            No data Found
          </Text>
        ) : (
          <FlatList
            data={filterData}
            keyExtractor={(_, index) => `item-${index}`}
            renderItem={renderItem}
          />
        )}
        {/* <SkeletonPlaceholder />  // use this Loader when api call will happen */}
      </View>
    </View>
  );
};
export default SpanMarginOption;

import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {TextInput} from 'react-native';
import CalculatorLookupStyle from '../../../styles/Views/CalculatorLookupStyle';
import {useNavigation} from '@react-navigation/native';
import Theme from '../../../theme/Theme';
import FutureOptionComponent from './FutureOptionComponent';
import {FutureFairAndOptionData, recommdata, TrendingData} from './DATA';
import TopTab from './TopTab';
import SkeletonPlaceholder from '../../../components/Skeleton/SkeletonConstituents';

const CalculatorLookup = ({route}) => {
  const {name} = route.params;
  const {FutureFairCallBack} = route.params;
  const {OptionValueCallBack} = route.params;
  const navigation = useNavigation();
  const {CalculatorLookupStyles} = CalculatorLookupStyle();
  const {root} = Theme();
  const [filterData, setFilterData] = useState<any>(''); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = FutureFairAndOptionData;
      const filterTempList = mainList.filter(item =>
        item.title.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const onRecentSearch = val => {
    setTextInputValue(val);
    searchFilterOnList(val);
  };
  const renderItem = ({item}) => {
    return (
      <FutureOptionComponent
        data={item}
        name={name}
        FutureFairCallBack={FutureFairCallBack}
        OptionValueCallBack={OptionValueCallBack}
      />
    );
  };
  return (
    <View style={CalculatorLookupStyles.container}>
      <View style={CalculatorLookupStyles.headerView}>
        <TouchableOpacity
          onPress={() => {
            setTextInputValue('');
            navigation.goBack();
          }}>
          <AntIcon name="close" size={23} color={root.color_text} />
        </TouchableOpacity>
        <TextInput
          style={CalculatorLookupStyles.textInput}
          placeholder="Search eg: Axis Reliance"
          placeholderTextColor={root.color_subtext}
          value={textInputValue}
          onChangeText={val => {
            searchFilterOnList(val);
            setTextInputValue(val);
          }}
          keyboardType="visible-password"
        />
        {textInputValue.length === 0 ? (
          <TouchableOpacity onPress={() => {}}>
            <MaterialCommunityIcons
              name="microphone"
              size={23}
              color={root.color_text}
            />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={CalculatorLookupStyles.clearBtn}>Clear</Text>
          </TouchableOpacity>
        )}
      </View>
      {textInputValue.length === 0 ? (
        <View>
          <View style={CalculatorLookupStyles.recentInnerconatiner}>
            <MaterialIcons name="search" size={24} color={root.color_text} />
            <Text style={CalculatorLookupStyles.recentSearchText}>
              Recently Searched
            </Text>
          </View>
          <View style={CalculatorLookupStyles.flexallign}>
            {recommdata.map(item => {
              return (
                <TouchableOpacity onPress={() => onRecentSearch(item.title)}>
                  <View style={CalculatorLookupStyles.recentListView}>
                    <Text style={CalculatorLookupStyles.listText}>
                      {item.title}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
          {/* Trending Search */}
          <View style={CalculatorLookupStyles.recentInnerconatiner}>
            <MaterialIcons
              name="trending-up"
              size={24}
              color={root.color_text}
            />
            <Text style={CalculatorLookupStyles.recentSearchText}>
              Trending
            </Text>
          </View>
          <View style={CalculatorLookupStyles.flexallign}>
            {TrendingData.map(item => {
              return (
                <TouchableOpacity onPress={() => onRecentSearch(item.title)}>
                  <View style={CalculatorLookupStyles.recentListView}>
                    <Text style={CalculatorLookupStyles.listText}>
                      {item.title}
                    </Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      ) : textInputValue.length != 0 && name === 'Span Margin' ? (
        <TopTab textInputValue={textInputValue} />
      ) : (
        <View style={CalculatorLookupStyles.flateListView}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={CalculatorLookupStyles.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={renderItem}
            />
          )}
          {/* <SkeletonPlaceholder /> use when Api is implemted */}
        </View>
      )}
    </View>
  );
};
export default CalculatorLookup;

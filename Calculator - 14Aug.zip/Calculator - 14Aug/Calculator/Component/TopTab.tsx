import React, {useCallback} from 'react';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {useNavigation} from '@react-navigation/native';
import {Cfont, root} from '../../../styles/colors';
import SpanMarginFuture from './SpanMarginFuture';
import SpanMarginOption from './SpanMarginOption';
const Tab = createMaterialTopTabNavigator();

function TopTab({textInputValue}: any) {
  const Future = useCallback(() => {
    return <SpanMarginFuture textInputValue={textInputValue} />;
  }, [textInputValue]);

  const Option = useCallback(() => {
    return <SpanMarginOption textInputValue={textInputValue} />;
  }, [textInputValue]);

  return (
    <>
      <Tab.Navigator
        screenOptions={{
          tabBarScrollEnabled: false,
          lazy: true,
          tabBarStyle: {
            height: 38,
            elevation: 10,
          },
          tabBarLabelStyle: {
            fontSize: 12,
            textTransform: 'none',
            fontFamily: Cfont.rubik_medium,
          },
          tabBarIndicatorStyle: {
            width: '43%',
            marginLeft: 12,
            backgroundColor: root.client_background,
          },
          tabBarActiveTintColor: root.client_background,
          tabBarInactiveTintColor: root.color_subtext,
          swipeEnabled: false,
        }}>
        <Tab.Screen name="Futures" component={Future} />
        <Tab.Screen name="Options" component={Option} />
      </Tab.Navigator>
    </>
  );
}
export default TopTab;

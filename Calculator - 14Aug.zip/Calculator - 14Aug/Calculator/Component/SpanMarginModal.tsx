import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import CommonModal from '../../../components/CommonModal/CommonModal';
import SpanMarginComponentStyle from '../../../styles/Views/SpanMarginComponentStyle';
import Theme from '../../../theme/Theme';

const SpanMarginModal = ({visibleModal, setVisibleModal}) => {
  const data = {
    title: 'ICICI AUG FUT',
    date: "31 AUG '23 ",
    IBM: '99393',
    ISM: '395456',
    EBM: '78398',
    ESM: '8933',
    TBM: '383883',
    TSM: '67383',
  };
  const {root} = Theme();
  const {SpanMarginComponentStyles} = SpanMarginComponentStyle();
  return (
    <CommonModal
      visible={visibleModal}
      onClose={() => {
        // setVisibleModal(false);
      }}>
      <View style={SpanMarginComponentStyles.modalContainer}>
        <View style={SpanMarginComponentStyles.rowCenterSpace}>
          <Text style={SpanMarginComponentStyles.modalTitle}>{data.title}</Text>
          <AntDesign
            name="close"
            size={21}
            color={root.color_text}
            onPress={() => {
              setVisibleModal(false);
            }}
          />
        </View>
        <Text style={SpanMarginComponentStyles.modalSubTitle}>{data.date}</Text>
        <View style={SpanMarginComponentStyles.line} />
        <View style={SpanMarginComponentStyles.additionDetailView}>
          <View
            style={{
              flex: 1,
            }}>
            <Text
              style={SpanMarginComponentStyles.additionalDetailsTitle}></Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsTitle}>
              Intitial Margin
            </Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsTitle}>
              Exposure Margin
            </Text>
          </View>
          <View
            style={{
              alignItems: 'flex-end',
              justifyContent: 'flex-end',
              flex: 1,
            }}>
            <Text style={SpanMarginComponentStyles.additionalDetailsTitle}>
              Buy Margin
            </Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.IBM}
            </Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.EBM}
            </Text>
          </View>
          <View
            style={{
              alignItems: 'flex-end',
              justifyContent: 'flex-end',
              flex: 1,
            }}>
            <Text style={SpanMarginComponentStyles.additionalDetailsTitle}>
              Sell Margin
            </Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.ISM}
            </Text>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.ESM}
            </Text>
          </View>
        </View>
        <View style={SpanMarginComponentStyles.lineBottom} />
        <View style={SpanMarginComponentStyles.additionDetailView}>
          <View
            style={{
              flex: 1,
            }}>
            <Text style={SpanMarginComponentStyles.additionalDetailsTitle}>
              Total Margin
              <Text style={SpanMarginComponentStyles.star}>{''}*</Text>
            </Text>
          </View>

          <View
            style={{
              alignItems: 'flex-end',
              justifyContent: 'flex-end',
              flex: 1,
            }}>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.TBM}
            </Text>
          </View>

          <View
            style={{
              alignItems: 'flex-end',
              justifyContent: 'flex-end',
              flex: 1,
            }}>
            <Text style={SpanMarginComponentStyles.additionalDetailsValues}>
              {data.TSM}
            </Text>
          </View>
        </View>
        <Text style={SpanMarginComponentStyles.note}>
          <Text style={SpanMarginComponentStyles.star}>*</Text>
          Displayed margin is indiactive margin as per current price for 1lot
        </Text>
      </View>
    </CommonModal>
  );
};
export default SpanMarginModal;

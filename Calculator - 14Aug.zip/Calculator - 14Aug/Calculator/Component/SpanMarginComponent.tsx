import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import Theme from '../../../theme/Theme';
import SpanMarginComponentStyle from '../../../styles/Views/SpanMarginComponentStyle';
import SpanMarginModal from './SpanMarginModal';

const SpanMarginComponent = ({data}) => {
  const [visibleModal, setVisibleModal] = useState(false);
  const {SpanMarginComponentStyles} = SpanMarginComponentStyle();
  const {root} = Theme();
  const onSubmit = () => {
    setVisibleModal(true);
  };
  return (
    <TouchableOpacity
      onPress={onSubmit}
      style={SpanMarginComponentStyles.mainView}
      activeOpacity={1}>
      <View style={SpanMarginComponentStyles.detailView}>
        <View style={SpanMarginComponentStyles.rowCenter}>
          <Text style={SpanMarginComponentStyles.title}>{data.title}</Text>
          <Text style={SpanMarginComponentStyles.price}>{data.price}</Text>
        </View>
        <View style={SpanMarginComponentStyles.rowCenter}>
          <Text style={SpanMarginComponentStyles.chip}>{data.exchange}</Text>
          <Text style={SpanMarginComponentStyles.subTitle}>
            ICICI LOMBARD GIC LTD
          </Text>
        </View>
      </View>
      <View style={SpanMarginComponentStyles.iconView}>
        <SimpleLineIcons
          name="arrow-right-circle"
          size={23}
          color={root.color_text}
        />
      </View>
      <SpanMarginModal
        visibleModal={visibleModal}
        setVisibleModal={setVisibleModal}
      />
    </TouchableOpacity>
  );
};
export default SpanMarginComponent;

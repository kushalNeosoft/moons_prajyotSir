import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function SpanMarginFutureOption() {
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const SpanMarginFutureOptionStyles = StyleSheet.create({
    mainView: {
      flex: 1,
      paddingHorizontal: 18,
      backgroundColor: root.color_active,
    },
    noDataText: {
      color: root.color_subtext,
      fontSize: font.size_16,
      fontFamily: font_Family.regular,
      alignSelf: 'center',
      marginTop: 60,
    },
    flateListView: {
      flex: 1,
      backgroundColor: root.color_active,
      marginTop: 20,
      paddingBottom: 20,
    },
  });

  return {SpanMarginFutureOptionStyles};
}

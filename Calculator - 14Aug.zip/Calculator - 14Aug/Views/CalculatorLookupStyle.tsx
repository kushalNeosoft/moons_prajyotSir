import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function CalculatorLookupStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const CalculatorLookupStyles = StyleSheet.create({
    container: {
      width: Dimensions.get('window').width,
      backgroundColor: root.color_active,
      flex: 1,
    },
    headerView: {
      flexDirection: 'row',
      alignItems: 'center',
      elevation: 10,
      paddingHorizontal: 18,
      backgroundColor: root.color_active,
    },
    textInput: {
      flex: 1,
      fontSize: font.size_14,
      fontFamily: font_Family.regular,
      color: root.color_text,
      marginLeft: 15,
      textTransform: 'uppercase',
    },
    noDataText: {
      color: root.color_subtext,
      fontSize: font.size_16,
      fontFamily: font_Family.regular,
      alignSelf: 'center',
      marginTop: 60,
    },
    clearBtn: {
      fontSize: font.size_14,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    flateListView: {
      paddingHorizontal: 18,
      flex: 1,
      backgroundColor: root.color_active,
      marginTop: 20,
      paddingBottom: 20,
    },
    recentInnerconatiner: {
      paddingHorizontal: 18,
      marginTop: 18,
      flexDirection: 'row',
      alignItems: 'center',
    },
    recentSearchText: {
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      color: root.color_text,
      marginLeft: 7,
    },
    recentListView: {
      justifyContent: 'center',
      height: 28,
      marginTop: 12,
      marginRight: 12,
      borderRadius: 6,
      borderWidth: 1,
      borderColor: root.color_border,
      paddingHorizontal: 12,
    },
    listText: {
      fontSize: font.size_11,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    flexallign: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      paddingHorizontal: 16,
    },
  });

  return {CalculatorLookupStyles};
}

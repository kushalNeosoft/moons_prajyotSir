import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function FutureOptionValueStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const FutureOptionValueStyles = StyleSheet.create({
    mainView: {
      width: '100%',
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 16,
    },
    rowCenter: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    title: {
      fontFamily: font_Family.medium,
      fontSize: font.size_14,
      color: root.color_text,
    },
    price: {
      fontFamily: font_Family.regular,
      fontSize: font.size_14,
      color: root.color_text,
      marginLeft: 5,
    },
    chip: {
      fontFamily: font_Family.medium,
      fontSize: font.size_10,
      backgroundColor: root.color_watchlist_chip,
      color: root.color_subtext,
      padding: 3,
    },
    subTitle: {
      fontFamily: font_Family.regular,
      fontSize: font.size_12,
      color: root.color_text,
      marginLeft: 5,
    },
    detailView: {
      marginLeft: 15,
    },
  });

  return {FutureOptionValueStyles};
}

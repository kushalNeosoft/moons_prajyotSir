import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function SpanMarginComponentStyle() {
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const SpanMarginComponentStyles = StyleSheet.create({
    mainView: {
      width: '100%',
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 16,
    },
    rowCenter: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    rowCenterSpace: {
      flexDirection: 'row',

      justifyContent: 'space-between',
    },
    title: {
      fontFamily: font_Family.medium,
      fontSize: font.size_14,
      color: root.color_text,
    },
    price: {
      fontFamily: font_Family.regular,
      fontSize: font.size_12,
      color: root.color_text,
      marginLeft: 5,
    },
    chip: {
      fontFamily: font_Family.medium,
      fontSize: font.size_10,
      backgroundColor: root.color_watchlist_chip,
      color: root.color_subtext,
      padding: 3,
    },
    subTitle: {
      fontFamily: font_Family.regular,
      fontSize: font.size_12,
      color: root.color_text,
      marginLeft: 5,
    },
    detailView: {
      marginLeft: 15,
      flex: 0.5,
    },
    iconView: {
      justifyContent: 'flex-end',
      flex: 0.5,
      alignItems: 'flex-end',
    },
    modalContainer: {
      paddingHorizontal: 15,
    },
    modalTitle: {
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    modalSubTitle: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      color: root.color_text,
      marginTop: 5,
    },
    line: {
      backgroundColor: root.color_subtext,
      height: 0.8,
      marginTop: 20,
      opacity: 0.3,
      marginBottom: 5,
    },
    lineBottom: {
      backgroundColor: root.color_subtext,
      height: 0.8,
      opacity: 0.3,
      marginTop: 5,
      marginBottom: 7,
    },
    additionDetailView: {
      flexDirection: 'row',
      // justifyContent: 'space-between',
    },
    additionalDetailsTitle: {
      color: root.color_text,
      marginVertical: 7,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    additionalDetailsValues: {
      color: root.color_text,
      marginVertical: 7,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
    },
    note: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginBottom: 5,
      marginTop: 5,
    },
    star: {
      color: root.color_negative,
    },
  });

  return {SpanMarginComponentStyles};
}

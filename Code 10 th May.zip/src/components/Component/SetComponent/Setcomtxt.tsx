export interface ISetcom {
  id: string;
  title: string;
  nameOne: string;
  nameTwo: string;
  nameThree: string;
  nameFour: string;
  index: string;
  drawerType: string;
  navigateTo: string;
}

export const Setcomtxt = [
  {
    title: 'Theme',
    nameOne: 'Light Theme',
    nameTwo: 'Dark Theme',
    index: '1',
    drawerType: 'Radio',
    navigateTo: 'P',
  },
  {
    title: 'Order Preferences',
    nameOne: 'Default Product Type',
    nameTwo: '',
    index: '2',
    drawerType: 'Arrow',
    navigateTo: 'P',
  },
  {
    title: 'Chart Preferences',
    nameOne: 'Chart IQ',
    nameTwo: 'Trading View',
    index: '3',
    drawerType: 'Radio',
    navigateTo: 'P',
  },
  {
    title: 'App Notifications',
    nameOne: 'Push Notifications',
    nameTwo: 'Trading Message',
    index: '4',
    drawerType: 'Arrow',
    drawerTypetwo: 'Switch',
    navigateTo: 'P',
  },
  {
    title: 'Security Setting',
    nameOne: 'Fingerprint/FaceID',
    nameTwo: 'Change M-Pin',
    nameThree: 'Change Password',
    nameFour: 'Enable TOTP',
    index: '5',
    drawerType: 'Arrow',
    drawerTypetwo: 'Switch',
    navigateTo: 'P',
  },
  {
    title: 'Take Me To',
    nameOne: 'Change Default',
    index: '6',
    drawerType: 'Arrow',
    navigateTo: 'P',
  },
];

import {StyleSheet} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../utils/alignment';

export const styles = StyleSheet.create({

});

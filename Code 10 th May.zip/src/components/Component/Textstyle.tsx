import { StyleSheet } from 'react-native';


export const Textstyle = StyleSheet.create({

    inputStyle: {
        color: '#000',
        
        fontSize: 18,
       // lineHeight: 23,
        textAlign:"left",
        flex: 2

    }, labelStyle: {
        paddingLeft: 20,
        fontSize: 18,
        flex: 1

    },
    containerStyle:
    {
        flexDirection: 'row',
        height: 40,
        //alignItems: 'center',
        flex: 1,
    }

});

import React from 'react';
import {View, Text, StyleSheet,TouchableOpacity} from 'react-native';

interface ListItem {
  id: string;
  title: string;
}

const data: ListItem[] = [
  {id: '1', title: 'NSE CASH'},
  {id: '2', title: 'NSE DERIVATIVES'},
  {id: '3', title: 'BSE CASH'},
  {id: '4', title: 'MCX FUTURES'},
  {id: '5', title: 'NCDEX FUTURES'},
  {id: '6', title: 'NSECDS'},
  {id: '7', title: 'BSECDS'},
  {id: '8', title: 'ICEX FUTURES'},
];

const Userinfo = () => {
  
  return (
    <View style={styles.maincon}>
      <View style={{ paddingVertical: '10%'}}>
        <Text style={styles.Headertext}>User Information</Text>
        <View style={styles.allin}>
          <Text style={styles.fields}>Phone</Text>
          <Text style={styles.fielinfo}>9111111111</Text>
        </View>
        <View style={styles.allin}>
          <Text style={styles.fields}>Email</Text>
          <Text style={styles.fielinfo}>omprakash.dashore@63moons.com</Text>
        </View>
        <View style={styles.allin}>
          <Text style={styles.fields}>Pan No.</Text>
          <Text style={styles.fielinfo}>*******234A</Text>
        </View>
        <View style={styles.allinFlat}>
          <Text style={styles.fields}>Segments Allowed</Text>
          <View style={{flexWrap:"wrap",height:'100%',width:"50%",flexDirection:'row',justifyContent:"flex-end"}}>
            {data.map(data => {
              return (
                <View style={styles.Flatcolor}>
                  <Text style={styles.txtsize}>{data.title}</Text>
                </View>
              );
            })}
          </View>
        </View>
      </View>
      <View style={{marginBottom: '10%'}}>
        <Text style={styles.Headertext}>Bank Account</Text>
        <View style={styles.allin}>
          <Text style={styles.fields}>HDFC BANK</Text>
          <Text style={styles.fielinfo}>*********3235</Text>
        </View>
      </View>
      <View style={{marginBottom: '10%'}}>
        <Text style={styles.Headertext}>Demat Information</Text>
        <View style={styles.allinborder}>
          <Text style={styles.fields}>DP ID</Text>
          <Text style={styles.fields}>Beneficiary ID</Text>
        </View>
        <View style={styles.allin}>
          <Text style={styles.fields}>IN3000940</Text>
          <Text style={styles.fielinfo}>65893256</Text>
        </View>
        <View>
            <TouchableOpacity style={styles.close}>
                <Text style={{color:'black'}}>Close Accoount</Text>
            </TouchableOpacity>
        </View>
      </View>
      
    </View>
  );
};

const styles = StyleSheet.create({
  maincon: {
    flex: 1,
    backgroundColor: 'white',
    justifyContent: 'space-around',
    padding: 15,
    paddingTop: 0,
    paddingBottom: 0,
    paddingVertical: 3,
  },
  Innercon: {},
  Headertext: {
    color: 'black',
    fontSize: 25,
    fontWeight: 'bold',
  },
  fields: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
  },
  fielinfo: {
    color: 'black',
    fontSize: 15,
  },
  allin: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: '4%',
  },
  allinFlat: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    flexWrap:"wrap",
    height:"30%"
  },
  allinborder:{
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: '4%',
    borderBottomWidth:1,
    borderBottomColor:'#E8E8E8'
  },
  Flatcolor: {
    backgroundColor: '#F5F5F5',
    borderRadius: 20,
    alignItems:'center',
    justifyContent:"center",
    padding:5,
    paddingLeft:10,
    paddingRight:10,
    margin:'1%'
  },
  txtsize:{
    fontSize:10,
    color:'black',
    fontWeight:'bold',
  },
  close:{
    borderWidth:1,
    borderColor:'black',
    borderRadius:20,
    width:140,
    height:30,
    alignItems:'center',
    justifyContent:'center',

    
  }
});
export default Userinfo;

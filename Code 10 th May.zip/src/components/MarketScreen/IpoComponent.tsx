import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import {Font, root, Cfont} from '../../styles/colors';
import {ipoComp} from '../../Globalstyles/Globalstyle';

const IPOComponent = props => {
  return (
    <TouchableOpacity
      style={ipoComp.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <View style={ipoComp.innerView}>
        <View style={ipoComp.titleAndImgView}>
          <View style={ipoComp.imageView}>
            <Text style={ipoComp.imageText}>LI</Text>
          </View>
          <Text style={ipoComp.title}>{props.title}</Text>
        </View>
        <Text style={ipoComp.subTitle}>ONGOING</Text>
        <Text style={ipoComp.pricerRange}>{props.range}</Text>
        <Text style={ipoComp.issueDate}>Issue Date</Text>
        <Text style={ipoComp.date}>{props.date}</Text>
        <View style={ipoComp.minQtyAndAmmountView}>
          <View>
            <Text style={ipoComp.minQty}>Min. Qty</Text>
            <Text style={ipoComp.qty}>{props.minQty}</Text>
          </View>
          <View>
            <Text style={ipoComp.minAmount}>Min. Amount</Text>
            <Text style={ipoComp.amount}>{props.minAmount}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default IPOComponent;
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: 'white',
//     height: 238,
//     width: 195,
//     borderRadius: 8,
//     marginTop: 20,
//     marginVertical: 10,
//     marginRight: 13,
//     marginLeft: 3,
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,

//     elevation: 3,
//     overflow: 'hidden',
//   },
//   imageView: {
//     backgroundColor: '#FF6700',
//     height: 40,
//     width: 40,
//     borderRadius: 25,
//     marginTop: 10,
//     opacity: 0.7,
//     justifyContent: 'center',
//   },
//   title: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_medium,
//     fontSize: 11,
//     width: '60%',
//     marginTop: 10,
//     marginLeft: 6,
//   },
//   subTitle: {
//     color: 'white',
//     fontFamily: Cfont.rubik_medium,
//     backgroundColor: '#4CAF50',
//     fontSize: 9,
//     width: 65,
//     height: 17,
//     textAlign: 'center',
//     borderRadius: 25,
//     marginTop: 12,
//   },
//   pricerRange: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_regular,
//     marginTop: 36,
//     fontSize: 11,
//   },
//   issueDate: {
//     color: root.color_text,
//     marginTop: 12,
//     fontSize: 11,
//     fontFamily: Cfont.rubik_medium,
//   },
//   date: {
//     color: root.color_text,
//     fontSize: 11,
//     fontFamily: Cfont.rubik_regular,
//   },
//   minQty: {
//     color: root.color_text,
//     marginTop: 12,
//     fontSize: 11,
//     fontFamily: Cfont.rubik_medium,
//   },
//   qty: {
//     color: '#303030',
//     fontSize: 11,
//     fontFamily: Cfont.rubik_regular,
//   },
//   minAmount: {
//     color: root.color_text,
//     marginTop: 12,
//     fontSize: 11,
//     fontFamily: Cfont.rubik_medium,
//   },
//   amount: {
//     color: root.color_text,
//     fontSize: 11,
//     fontFamily: Cfont.rubik_regular,
//   },
// });

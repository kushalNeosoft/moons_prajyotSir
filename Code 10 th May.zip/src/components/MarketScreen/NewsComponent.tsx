import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {Font, root, Cfont} from '../../styles/colors';
import {newsComp} from '../../Globalstyles/Globalstyle';

const NewsComponent = props => {
  return (
    <TouchableOpacity style={newsComp.container}>
      <Ionicons
        name="md-notifications-circle"
        size={20}
        color={'white'}
        style={newsComp.icon}
      />
      <Text style={newsComp.title}>{props.title}</Text>
      <Text style={newsComp.subTitle}>{props.subTitle}</Text>
    </TouchableOpacity>
  );
};
export default NewsComponent;
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: root.color_text,
//     height: 175,
//     width: 150,
//     marginVertical: 15,
//     borderRadius: 8,
//     marginLeft: 16,
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,

//     elevation: 3,
//     overflow: 'hidden',
//   },
//   title: {
//     color: root.color_active,
//     fontFamily: Cfont.rubik_medium,
//     fontSize: 13,
//     marginLeft: 12,
//     marginRight: 15,
//     marginBottom: 8,
//     marginTop: -7,
//   },
//   subTitle: {
//     color: root.color_active,
//     fontSize: 12,
//     fontFamily: Cfont.rubik_regular,
//     marginLeft: 12,
//     marginRight: 17,
//   },
//   icon: {
//     textAlign: 'right',
//     padding: 3,
//   },
// });

import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {Font, root, Cfont} from '../../styles/colors';
import {newsListComp} from '../../Globalstyles/Globalstyle';

const NewsListComponent = props => {
  return (
    <View style={newsListComp.container}>
      <TouchableOpacity style={newsListComp.newsLeftView}>
        <Text style={newsListComp.title}>{props.title}</Text>
        <Text style={newsListComp.time}>{props.time}</Text>
      </TouchableOpacity>
      <View style={newsListComp.line}></View>
      <TouchableOpacity style={{}}>
        <Text style={newsListComp.nse}>NSE</Text>
        <Text style={newsListComp.stockName}>{props.stockName}</Text>
        <Text style={newsListComp.price}>{props.price}</Text>
        <Text style={newsListComp.changes}>{props.change}</Text>
      </TouchableOpacity>
    </View>
  );
};
export default NewsListComponent;
// const styles = StyleSheet.create({
//   container: {
//     // backgroundColor: '#fff',
//     height: 90,
//     width: '90%',
//     marginTop: 5,
//     alignSelf: 'center',
//     flexDirection: 'row',
//     marginLeft: 16,
//   },
//   title: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_medium,
//     fontSize: 13,
//     marginRight: 5,
//     paddingBottom: 8,
//   },
//   time: {
//     color: '#303030',
//     fontSize: 9,
//     paddingTop: 6,
//     fontFamily: Cfont.rubik_regular,
//   },
//   nse: {
//     color: root.color_text,
//     fontSize: 9,
//     fontFamily: Cfont.rubik_medium,
//     paddingBottom: 8,
//   },
//   stockName: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_medium,
//     fontSize: 13,
//     paddingBottom: 2,
//   },
//   price: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_regular,
//     fontSize: 13,
//     paddingBottom: 2,
//   },
//   changes: {
//     color: root.indices_red,
//     fontFamily: Cfont.rubik_regular,
//     fontSize: 11,
//   },
// });

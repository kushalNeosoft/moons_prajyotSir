import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import {indicesComp} from '../../Globalstyles/Globalstyle';

const IndicesComponent = props => {
  return (
    <TouchableOpacity style={indicesComp.container}>
      <Text style={indicesComp.title}>{props.title}</Text>
      <Text style={indicesComp.price}>{props.price}</Text>
      <Text style={indicesComp.changes}>{props.changes}</Text>
      <Text style={indicesComp.date}>{props.date}</Text>
    </TouchableOpacity>
  );
};
export default IndicesComponent;
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: root.indices_red,
//     height: 133,
//     width: 145,
//     marginVertical: 15,
//     borderRadius: 8,
//     marginRight: 13,
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,

//     elevation: 3,
//     overflow: 'hidden',
//   },
//   title: {
//     color: root.color_active_text,
//     fontFamily: Cfont.rubik_medium,
//     marginLeft: 12,
//     marginTop: 10,
//     paddingBottom: 25,
//     fontSize: 13,
//   },
//   price: {
//     color: root.color_active_text,
//     fontFamily: Cfont.rubik_regular,
//     marginLeft: 12,
//     paddingBottom: 2,
//     fontSize: 17,
//   },
//   changes: {
//     color: root.color_active_text,
//     fontFamily: Cfont.rubik_regular,
//     marginLeft: 12,
//     fontSize: 11,
//   },
//   date: {
//     color: root.color_active_text,
//     fontFamily: Cfont.rubik_light,
//     marginLeft: 12,
//     marginTop: 14,
//     fontSize: 9,
//   },
// });

import {Dimensions, StatusBar, StyleSheet, useColorScheme} from 'react-native';
import {Cfont, Font, root, TColors} from '../../styles/colors';

// console.log(height);

export const createFooterStyles = (colors: TColors) => {
  return StyleSheet.create({
    footerContainer: {
      padding: 16,
     
     
      flexDirection: 'row',
      justifyContent: 'space-between',
      backgroundColor:'white',
    },
    itemContainer: {
      paddingHorizontal: 12,
      paddingVertical: 4,
    },
    text: {
      fontSize: Font.font_normal_six,
      color:root.client_background,
      fontFamily: Cfont.rubik_medium,
    },
    cliper: {
      borderRadius: 16,
    },
  });
};

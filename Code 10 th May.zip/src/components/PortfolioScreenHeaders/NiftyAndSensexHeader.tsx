import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  TouchableOpacity,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {Cfont, root} from '../../styles/colors';
import {portFolioScreen} from '../../Globalstyles/Globalstyle';

const NiftyAndSensexHeader = ({scrollValue}) => {
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  const navigation = useNavigation();
  return (
    <Animated.View
      style={{
        opacity: headerOpacity2,
      }}>
      <View style={portFolioScreen.currentAndInvestedView}>
        <View>
          <Text style={portFolioScreen.currentValue}>Current value</Text>
          <Text style={portFolioScreen.currentValueNumber}>
            ₹ 18,73,38,879.00
          </Text>
          <Text style={portFolioScreen.overAllPl}>Overall P/L</Text>
          <Text style={portFolioScreen.overAllPlNumber}>
            ₹ 83,73,660.00(98.36%)
          </Text>
        </View>
        <View style={{marginRight: 10}}>
          <Text style={portFolioScreen.investedValue}>Invested value</Text>
          <Text style={portFolioScreen.investedValueNumber}>
            ₹ 18,73,38,879.00
          </Text>
          <Text style={portFolioScreen.todaysPl}>Todays P/L</Text>
          <Text style={portFolioScreen.todaysNumber}>
            ₹ 83,73,660.00(98.36%)
          </Text>
        </View>
      </View>
    </Animated.View>
  );
};
export default NiftyAndSensexHeader;

// const styles = StyleSheet.create({
//   sensexTitle: {
//     fontSize: 14,
//     color: '#303030',
//     fontFamily: Cfont.rubik_medium,
//     paddingLeft: 40,
//   },
//   sensexPrice: {
//     fontSize: 14,
//     color: '#303030',
//     fontFamily: Cfont.rubik_medium,
//     paddingLeft: 40,
//   },
//   sensexChanges: {
//     fontSize: 11,
//     color: '#4CAF50',
//     fontFamily: Cfont.rubik_regular,
//     paddingLeft: 30,
//   },
//   niftyTitle: {
//     fontSize: 14,
//     color: '#303030',
//     fontFamily: Cfont.rubik_medium,
//     paddingLeft: 40,
//   },
//   niftyPrice: {
//     fontSize: 14,
//     color: '#303030',
//     fontFamily: Cfont.rubik_medium,
//     paddingLeft: 40,
//   },
//   niftyChanges: {
//     fontSize: 11,
//     color: '#4CAF50',
//     fontFamily: Cfont.rubik_regular,
//     paddingLeft: 30,
//   },
//   currentValue: {
//     fontSize: 10,
//     color: '#303030',
//     fontFamily: Cfont.rubik_medium,
//     marginLeft: 16,
//   },
//   currentValueNumber: {
//     fontSize: 18,
//     color: 'black',
//     fontWeight: '500',
//     marginLeft: 15,
//   },
//   overAllPl: {
//     fontSize: 12,
//     color: 'black',
//     fontWeight: '500',
//     marginLeft: 15,
//     marginTop: 3,
//   },
//   overAllPlNumber: {
//     fontSize: 12,
//     color: 'green',
//     fontWeight: '500',
//     marginLeft: 15,
//   },
//   investedValue: {
//     fontSize: 11,
//     color: 'black',
//     fontWeight: '500',
//     paddingLeft: 55,
//   },
//   investedValueNumber: {
//     fontSize: 15,
//     color: 'black',
//     fontWeight: '500',
//   },
//   todaysPl: {
//     fontSize: 12,
//     color: 'black',
//     fontWeight: '500',
//     marginTop: 9,
//     paddingLeft: 65,
//   },
//   todaysNumber: {
//     fontSize: 12,
//     color: 'red',
//     fontWeight: '500',
//   },
// });

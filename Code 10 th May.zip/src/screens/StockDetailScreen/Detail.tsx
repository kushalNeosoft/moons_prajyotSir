import React from 'react';
import {View, Text} from 'react-native';
import {useRoute} from '@react-navigation/native';
const Detail = () => {
  const route = useRoute();
  const detail = route.params?.detail;
  console.log('AOSOSOSOSOSOSOSO------------->>>>', detail);

  return (
    <View>
      <Text style={{fontSize: 60, backgroundColor: 'red'}}>
        {detail?.item?.stockName}
      </Text>
    </View>
  );
};

export default Detail;

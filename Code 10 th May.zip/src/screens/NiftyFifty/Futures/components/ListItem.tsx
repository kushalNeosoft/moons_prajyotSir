import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {listItem} from '../../../../Globalstyles/Globalstyle';

const ListItem = (props: any) => {
  return (
    <View style={listItem.card}>
      <View style={listItem.conatiner}>
        <View style={listItem.dayPriceContainer}>
          <View>
            <View style={listItem.dateYearContainer}>
              <Text style={listItem.date}>{props.date}</Text>
              <Text
                style={listItem.yearText}>
                {props.year}
              </Text>
            </View>
            <View style={listItem.priceChangeContainer}>
              <Text style={listItem.price}>{props.price}</Text>
              <Text style={listItem.change}>{props.change}</Text>
            </View>
          </View>

          <View style={listItem.iconsContainer}>
            <TouchableOpacity style={listItem.bottonView}>
              <Text style={listItem.T_text}>T</Text>
            </TouchableOpacity>
            <AntDesign
              name="pluscircleo"
              size={26}
              color="black"
              style={listItem.plusCircleIcon}
            />
          </View>
        </View>

        <View style={listItem.discountConatiner}>
          <Text style={listItem.discountTxt}>Premium Discount</Text>
          <Text style={listItem.discount}>{props.discount}</Text>
        </View>
      </View>
    </View>
  );
};

export default ListItem;

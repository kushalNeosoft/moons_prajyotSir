import React from 'react';
import {View, FlatList} from 'react-native';
import ListItem from './components/ListItem';
import { futureScreen } from '../../../Globalstyles/Globalstyle';

function Futures() {
  const data = [
    {
      date: "25 MAY",
      year:"'23",
      price: '17879.00',
      change: '35.35(-0.20%)',
      discount: '-103.65',
    },
    {
      date: "29 JUN",
      year:"'23",
      price: '17931.70',
      change: '24.65(-0.14%)',
      discount: '-149.76',
    },
    {
      date: "27 JUL",
      year:"'23",
      price: '18339.45',
      change: '00.00(-0.00)',
      discount: '-661.65',
    },
  ];

  const renderItem = ({item}: any) => {
    return (
      <ListItem
        date={item.date}
        price={item.price}
        change={item.change}
        discount={item.discount}
        year={item.year}
      />
    );
  };

  return (
    <View style={futureScreen.container}>
      <FlatList data={data} renderItem={renderItem} />
    </View>
  );
}

export default Futures;

import React from 'react';
import {View, Text} from 'react-native';
import { Cfont, Font, root } from '../../../styles/colors';
//import {View, Text, TouchableOpacity} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import CommonModalone from '../../../components/Component/CommonModal/CommonModalone';

const MembershipDialog = (props: any) => {
  return (
    <CommonModalone visible={props.visible} onClose={props.onClose} >
    <View style={{width: '100%',height:'80%'}}>
      <Text
        style={{
          fontSize: Font.font_title,
          fontFamily: Cfont.rubik_medium,
          color: root.color_text,
        }}>
       Membership Details
      </Text>
      <View style={{marginTop: 42}}>
        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 1}}></View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              MEMBER ID
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              SEBI REG NO
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 25}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.client_background,fontFamily:Cfont.rubik_medium,}}>
              NSE
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              77781
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 15}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.client_background,fontFamily:Cfont.rubik_medium,}}>
              BSE
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              555555
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              4545
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 15}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.client_background,fontFamily:Cfont.rubik_medium,}}>
              NDCEX
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              784544
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              3232
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 15}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.client_background,fontFamily:Cfont.rubik_medium,}}>
              MCX
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              78923
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              260607435
            </Text>
          </View>
        </View>
      </View>
    </View>
    </CommonModalone>
  );

};
export default MembershipDialog;

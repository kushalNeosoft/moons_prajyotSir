import React from "react";
import { View,Text, Dimensions } from "react-native";

const Screen1=()=>{
    return(
       <View style={{backgroundColor:'white',flexDirection:'row',flex:1,}}>
        <View style={{height:112,width:'30%',backgroundColor:'yellow',borderWidth:1,}}>

        </View>
        <View style={{height:Dimensions.get('window').width * 0.272,width:'30%',backgroundColor:'pink',borderWidth:1,}}>

        </View>
       </View>
    )
}
export default Screen1;
import {
  Text,
  TextInput,
  TextInputProps,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import useStyles from '../../../styles/useStyles';
import {createMpinStyles} from '../styles/mpin.styles';
import React, {useRef, useState} from 'react';
import {useNavigation} from '@react-navigation/native';
import BottomSheet, {
  BottomSheetProps,
} from '../../../components/BottomSheet/BottomSheet';
import WatchlistDialog from './WatchlistDialog';
import { Cfont, Font, root } from '../../../styles/colors';
import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import DropDownIcon from '../../../assets/DropDownIcon';
import { MpinStyles } from '../../../Globalstyles/Globalstyle';
const options = ['Option 1', 'Option 2', 'Option 3'];

const MPinComponent = ({props}) => {
  const watchlistSheetRef = useRef<BottomSheetProps>(null);
  const {colors, styles} = useStyles(createMpinStyles);
  const [watchModalVisible, setWatchModalVisible] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);


  const navigation = useNavigation();
  const navtoWatch = () => {
    navigation.navigate('TestScreen');
  };
  const onNorClose = () => {
    setWatchModalVisible(prevState => !prevState);
  };
  const showDeleteModal = () => {
    setDeleteModal(prevState => !prevState);
  };
  const oneRef = useRef<TextInput>(null);
  const twoRef = useRef<TextInput>(null);
  const threeRef = useRef<TextInput>(null);
  const fourRef = useRef<TextInput>(null);
  return (
    <View style={{backgroundColor:root.color_active,
    }}>
      <View style={MpinStyles.titleContainer}>
        <Text style={MpinStyles.title}>Enter M-Pin</Text>
      </View>

      <View style={MpinStyles.pinContainer}>
        <TextInput
          style={MpinStyles.pinInput}
          // placeholdercolor={'gray'}
          
          keyboardType="number-pad"
          ref={oneRef}
          onChangeText={text => {
            if (text.length > 0) {
              twoRef.current?.focus();
            }
          }}
        />
        <TextInput
          ref={twoRef}
          style={[
            MpinStyles.pinInput,
            {
              marginLeft: 8,
            },
          ]}
          maxLength={1}
          keyboardType="number-pad"
          onChangeText={text => {
            if (text.length > 0) {
              threeRef.current?.focus();
            } else if (text.length === 0) {
              oneRef.current?.focus();
            }
          }}
        />
        <TextInput
          ref={threeRef}
          style={[
            MpinStyles.pinInput,
            {
              marginLeft: 8,
            },
          ]}
          maxLength={1}
          keyboardType="number-pad"
          onChangeText={text => {
            if (text.length > 0) {
              fourRef.current?.focus();
            } else if (text.length === 0) {
              twoRef.current?.focus();
            }
          }}
        />
        <TextInput
          ref={fourRef}
          style={[
            MpinStyles.pinInput,
            {
              marginLeft: 8,
            },
          ]}
          maxLength={1}
          keyboardType="number-pad"
          onChangeText={text => {
            if (text.length === 0) {
              threeRef.current?.focus();
            }
          }}
          onChange={navtoWatch}
        />
      </View>

      <View style={MpinStyles.secondaryContainer}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
      
          <Text style={{fontSize: Font.font_normal_one,color:root.color_text,fontFamily:Cfont.rubik_light}}>Take Me To</Text>

          <View
            style={{
              borderRadius: 16,
            }}>
            <TouchableNativeFeedback
              // background={TouchableNativeFeedback.Ripple('gray', true)}
              onPress={() => setWatchModalVisible(true)}
      
              >
               
               <View
                style={{
                  flexDirection: 'row',

                  paddingLeft: 12,
                  paddingRight: 6,
                  paddingVertical: 4,
                }}>
                <Text
                  style={{color:root.client_background , fontFamily:Cfont.rubik_medium, fontSize: Font.font_normal_one, paddingVertical: 4}}>
                  Watchlist
                </Text>
                <DropDownIcon
                  style={{
                    height: 22,
                    width: 22,
                    color: root.client_background,
                  }}
                  />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <View
          style={{
            borderRadius: 16,
          }}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => navigation.navigate('ForgotMpin')}
            >
            <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
              <Text style={{color:root.client_background , fontFamily:Cfont.rubik_medium, fontSize: Font.font_normal_one}}>
                Forgot M-Pin?
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
     
      {/* <BottomSheet
        ref={watchlistSheetRef}
        height={314}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 16,
          },
        }}> */}
        <WatchlistDialog 
        visible={watchModalVisible}
        onClose={onNorClose}
        
        />
        
      {/* </BottomSheet> */}
    </View>
  );
};
export default MPinComponent;

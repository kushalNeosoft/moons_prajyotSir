import React, {useRef, useState} from 'react';
import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';

import useStyles from '../../styles/useStyles';

import {useTranslation} from 'react-i18next';

import {createProfileStyles} from './styles/profile.styles';
import MPinComponent from './components/MPinComponent';
import PasswordComponent from './components/PasswordComponent';
import DropDownIcon from '../../assets/DropDownIcon';
import Footer from '../../components/Footer/Footer';
import Dropdown from '../../components/Dropdown/Dropdown';
import BottomSheet, {
  BottomSheetProps,
} from '../../components/BottomSheet/BottomSheet';
// import SwitchDialog from './components/SwitchDialog';
import SwitchDialog from './components/SwitchDialog';
import {Cfont, Font, root} from '../../styles/colors';
import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import WatchlistDialog from './WatchlistDialog';
import { ProfileStyles } from '../../Globalstyles/Globalstyle';
// import React, {useRef, useState} from 'react';


const options = ['Option 1', 'Option 2', 'Option 3'];
const ProfileScreen = ({navigation}: any) => {
  const switchSheetRef = useRef<BottomSheetProps>(null);

  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [switchhModalVisible, setSwitchModalVisible] = useState(false);

  const onNorClose = () => {
    setSwitchModalVisible(prevState => !prevState);
  };
  const handleSelect = (option: string) => {
    setSelectedOption(option);
  };
  const [selectedTab, setSelectedTab] = useState('MPIN');
  const {colors, styles} = useStyles(createProfileStyles);
  const {t} = useTranslation();
  return (
    // <ScrollView style={styles.scrollContainer}>
    <View style={ProfileStyles.container}>
      <View style={ProfileStyles.headerContainer}>
        <View style={ProfileStyles.userContainer}>
          <View style={ProfileStyles.userProfilePic} />
          <View style={ProfileStyles.userInfoContainer}>
            <Text style={ProfileStyles.userName}>OM</Text>
            <Text style={ProfileStyles.userId}>
              User ID:{' '}
              <Text
                style={{
                  fontSize: Font.font_normal_two,
                  color: root.color_text,
                  fontFamily: Cfont.rubik_light,
                }}>
                OM
              </Text>
            </Text>
            <View
              style={{
                borderRadius: 16,
                // flex: 1,
                justifyContent: 'center',
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                // onPress={() => {
                //   //  navigation.navigate('ForgotPasswordScreen');
                //   // i18next.changeLanguage('en');
                  
                //   // switchSheetRef.current?.open();
                // }}
                onPress={() => setSwitchModalVisible(true)}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View style={ProfileStyles.switchAccountContainer}>
                  <Text
                    style={{
                      color: root.client_background,
                      fontFamily: Cfont.rubik_medium,
                      fontSize: Font.font_normal_one,
                    }}>
                    Switch Account
                  </Text>
                  <DropDownIcon style={ProfileStyles.dropDownIcon} />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
        </View>
        <View style={ProfileStyles.tabContainer}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              console.log('Here');
              setSelectedTab('MPIN');
            }}>
            <View style={ProfileStyles.tabItem}>
              <Text
                style={[
                  ProfileStyles.itemText,
                  {
                    color: selectedTab === 'MPIN' ? colors.primary : 'gray',
                  },
                ]}>
                M-Pin
              </Text>
              <View style={ProfileStyles.itemUnderlineContainer}>
                <View
                  style={[
                    ProfileStyles.itemUnderline,
                    {
                      backgroundColor:
                        selectedTab === 'MPIN' ? colors.primary : 'transparent',
                    },
                  ]}
                />
              </View>
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              setSelectedTab('PASSWORD');
            }}>
            <View style={ProfileStyles.tabItem}>
              <Text
                style={[
                  ProfileStyles.itemText,
                  {
                    color: selectedTab === 'PASSWORD' ? colors.primary : 'gray',
                  },
                ]}>
                Password
              </Text>
              <View style={ProfileStyles.itemUnderlineContainer}>
                <View
                  style={[
                    ProfileStyles.itemUnderline,
                    {
                      backgroundColor:
                        selectedTab === 'PASSWORD'
                          ? colors.primary
                          : 'transparent',
                    },
                  ]}
                />
              </View>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>

      <View style={ProfileStyles.bodyContainer}>
        {selectedTab === 'MPIN' && <MPinComponent />}
        {selectedTab === 'PASSWORD' && (
          <PasswordComponent navigation={navigation} />
        )}
      </View>
      <Footer />
      {/* <BottomSheet
        ref={switchSheetRef}
        height={208}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            // borderRadius: 16,
            borderTopRightRadius:16,
            borderTopLeftRadius:16
          }, */}
      {/* }}> */}
      <SwitchDialog visible={switchhModalVisible} onClose={onNorClose} />
      {/* </BottomSheet> */}
    </View>
    // </ScrollView>
  );
};

export default ProfileScreen;

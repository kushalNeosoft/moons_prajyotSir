import {NavigationContainer} from '@react-navigation/native';


import RootNavigator from '../RootNavigator';


import {FC, useEffect} from 'react';
import React from 'react';




const MainNavigator: FC = () => {
  
  return (
    <NavigationContainer>
     <RootNavigator/>
    </NavigationContainer>
  );
};

export default MainNavigator;

import React from 'react';
import {
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import CommonModaltwo from '../../../../components/CommonModal/CommonModaltwo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, root} from '../../../../styles/colors';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Feather from 'react-native-vector-icons/Feather';

const MenuModal = (props: any) => {
  const data = [
    {
      title: 'Filter',
      onPress:props.onFilterPress,
      iconType: Ionicons,
      iconName: "options-outline",
    },
    {
      title: 'Search',
      onPress:props.openSearchModal,
      iconType: AntDesign,
      iconName: 'search1',
    },
    {
      title: 'Square Off',
      onPress:props.navigateToSquareOff,
      iconType: Feather,
      iconName: 'book',
    },
    {
      title: 'Position Summary',
      onPress:props.openPositionSummary,
      iconType: MaterialCommunityIcons,
      iconName: 'card-text-outline',
    },
  ];
  return (
    <CommonModaltwo visible={props.visible}>
      <TouchableOpacity
        onPress={() => props.onClose()}
        style={{alignItems: 'flex-end'}}>
        <AntDesign name="close" size={24} color={root.color_text} />
      </TouchableOpacity>
      <FlatList
        data={data}
        renderItem={({item}) => {
          return (
            <TouchableOpacity style={menuModalStyles.item}
            onPress={()=>item.onPress()}
            >
              <item.iconType name={item.iconName} size={24} 
              color={root.color_text}
              />
              <Text style={menuModalStyles.text}>{item.title}</Text>
            </TouchableOpacity>
          );
        }}
      />
    </CommonModaltwo>
  );
};

const menuModalStyles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop:16
  },
  text:{
    fontFamily:Cfont.rubik_regular,
    color:root.color_text,
    fontSize:16,paddingLeft:10
  }
});

export default MenuModal;

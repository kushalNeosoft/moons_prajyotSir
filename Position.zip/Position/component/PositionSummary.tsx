import React, {useState} from 'react';
import {Modal, TouchableOpacity} from 'react-native';
import {View, Text, StyleSheet} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { Cfont, root } from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';

const PositionSummaryModal = (props: any) => {
  const [title, setTitle] = useState('Todays');
  const [keyVal, setKeyVal] = useState('All');

  const allData = [
    {
      title: 'Net Value',
      value: '-61227.50',
    },
    {
      title: 'Today Buy Value',
      value: '118466500.00',
    },
    {
      title: 'Today Sell Value',
      value: '11785422.50',
    },
    {
      title: title === 'Todays' ? 'Realised P/L' : 'Todays P/L',
      value: '0.00',
    },
    {
      title: title === 'Todays' ? 'Unrealised P/L' : 'Actual P/L',
      value: '-15930',
    },
  ];

  const showDetails = (value: string) => {
    setKeyVal(prevState => {
      if (value === prevState) {
        return '';
      } else {
        return value;
      }
    });
  };



  return (
    <Modal
      transparent={false}
      visible={props.visible}
      onRequestClose={() => {}}>
      <View style={positionSummary.modalView}>
        <View style={positionSummary.header}>
          <TouchableOpacity onPress={()=>props.onClose()}>
            <AntDesign name="arrowleft" size={24} color={root.color_text} />
          </TouchableOpacity>
          <Text style={positionSummary.titleTxt}>Position Summary</Text>
        </View>
        <View style={positionSummary.titleSelectionView}>
          <TouchableOpacity
            style={[
              positionSummary.titleContainerLeft,
              {
                backgroundColor:
                  title === 'Todays'
                    ? root.client_background
                    : root.color_active,
              },
            ]}
            onPress={() => setTitle('Todays')}>
            <Text
              style={[
                positionSummary.title,
                {
                  color:
                    title === 'Todays' ? root.color_active : root.color_text,
                },
              ]}>
              Today's
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              positionSummary.titleContainerRight,
              {
                backgroundColor:
                  title === 'Overall'
                    ? root.client_background
                    : root.color_active,
              },
            ]}
            onPress={() => setTitle('Overall')}>
            <Text
              style={[
                positionSummary.title,
                {
                  color:
                    title === 'Overall' ? root.color_active : root.color_text,
                },
              ]}>
              Overall
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{paddingTop: 30}}>
          <TouchableOpacity
            style={[positionSummary.headView]}
            activeOpacity={1}
            onPress={() => showDetails('All')}>
            <Text style={positionSummary.headTitle}>All</Text>
            <AntDesign
              name={keyVal === 'All' ? 'up' : 'down'}
              size={14}
              color={'black'}
            />
          </TouchableOpacity>
          {keyVal === 'All' ? (
            <View style={{paddingTop: 10}}>
              {allData.map(item => (
                <View style={positionSummary.headView}>
                  <Text style={positionSummary.childTitleTxt}>
                    {item.title}
                  </Text>
                  <Text
                    style={
                      positionSummary.childValue
                    }>{`₹ ${item.value}`}</Text>
                </View>
              ))}
            </View>
          ) : null}
          <TouchableOpacity
            style={[positionSummary.headView, {paddingTop: 36}]}
            onPress={() => showDetails('Equity')}
            activeOpacity={1}>
            <Text style={positionSummary.headTitle}>Equity</Text>
            <AntDesign
              name={keyVal === 'Equity' ? 'up' : 'down'}
              size={14}
              color={'black'}
            />
          </TouchableOpacity>
          {keyVal === 'Equity' ? (
            <View style={{paddingTop: 10}}>
              {allData.map(item => (
                <View style={positionSummary.headView}>
                  <Text style={positionSummary.childTitleTxt}>
                    {item.title}
                  </Text>
                  <Text
                    style={
                      positionSummary.childValue
                    }>{`₹ ${item.value}`}</Text>
                </View>
              ))}
            </View>
          ) : null}
          <TouchableOpacity
            style={[positionSummary.headView, {paddingTop: 36}]}
            onPress={() => showDetails('EQ FnO')}
            activeOpacity={1}>
            <Text style={positionSummary.headTitle}>EQ FnO</Text>
            <AntDesign
              name={keyVal === 'EQ FnO' ? 'up' : 'down'}
              size={14}
              color={'black'}
            />
          </TouchableOpacity>
          {keyVal === 'EQ FnO' ? (
            <View style={{paddingTop: 10}}>
              {allData.map(item => (
                <View style={positionSummary.headView}>
                  <Text style={positionSummary.childTitleTxt}>
                    {item.title}
                  </Text>
                  <Text
                    style={
                      positionSummary.childValue
                    }>{`₹ ${item.value}`}</Text>
                </View>
              ))}
            </View>
          ) : null}
          <TouchableOpacity
            style={[positionSummary.headView, {paddingTop: 36}]}
            onPress={() => showDetails('Commodity')}
            activeOpacity={1}>
            <Text style={positionSummary.headTitle}>Commodity</Text>
            <AntDesign
              name={keyVal === 'Commodity' ? 'up' : 'down'}
              size={14}
              color={'black'}
            />
          </TouchableOpacity>
          {keyVal === 'Commodity' ? (
            <View style={{paddingTop: 10}}>
              {allData.map(item => (
                <View style={positionSummary.headView}>
                  <Text style={positionSummary.childTitleTxt}>
                    {item.title}
                  </Text>
                  <Text
                    style={
                      positionSummary.childValue
                    }>{`₹ ${item.value}`}</Text>
                </View>
              ))}
            </View>
          ) : null}
          <TouchableOpacity
            style={[positionSummary.headView, {paddingTop: 36}]}
            onPress={() => showDetails('Currency')}
            activeOpacity={1}>
            <Text style={positionSummary.headTitle}>Currency</Text>
            <AntDesign
              name={keyVal === 'Currency' ? 'up' : 'down'}
              size={14}
              color={'black'}
            />
          </TouchableOpacity>
          {keyVal === 'Currency' ? (
            <View style={{paddingTop: 10}}>
              {allData.map(item => (
                <View style={positionSummary.headView}>
                  <Text style={positionSummary.childTitleTxt}>
                    {item.title}
                  </Text>
                  <Text
                    style={
                      positionSummary.childValue
                    }>{`₹ ${item.value}`}</Text>
                </View>
              ))}
            </View>
          ) : null}
        </View>
      </View>
    </Modal>
  );
};

const positionSummary = StyleSheet.create({
  header: {
    ...alignment.row_alignC,
    height: 56,
  },
  titleTxt: {
    fontSize: 20,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingLeft: 16,
  },
  titleSelectionView: {
    ...alignment.row,
  },
  titleContainerLeft: {
    height: 30,
    width: '50%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 0.3,
    borderTopLeftRadius: 15,
    borderBottomLeftRadius: 15,
  },
  titleContainerRight: {
    height: 30,
    width: '50%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 0.3,
    borderTopRightRadius: 15,
    borderBottomRightRadius: 15,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  headView: {
    ...alignment.row_alingC_SpaceB,
    paddingVertical: 7,
  },
  headTitle: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  childTitleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
    color: root.color_text,
  },
  childValue: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
  },
  modalView: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    bottom: 0,
    paddingHorizontal: 16,
  },
});

export default PositionSummaryModal;

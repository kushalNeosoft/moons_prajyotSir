import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { root } from '../../styles/colors';
// import { root } from '../../../styles/colors';

function PlusIcon(props: any) {
  return (
    <AntDesign
      name="pluscircleo"
      size={props.size}
      color={root.color_text}
      {...props}
    />
  );
}

export default PlusIcon;

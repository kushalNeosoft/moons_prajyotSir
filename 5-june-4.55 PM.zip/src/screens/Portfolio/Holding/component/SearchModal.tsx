import React, {useState} from 'react';
import {TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {SafeAreaView} from 'react-native';
import {HoldingSearchModal} from '../../../../theme/light';
const SearchModal = ({modalVisible, setModalVisible}) => {
  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={HoldingSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View>
        <View style={HoldingSearchModal.headerView}>
          <TouchableOpacity
            style={HoldingSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={HoldingSearchModal.textInput}
            placeholder="Search your holdings eg: Axis, Reliance"
            placeholderTextColor={'grey'}
          />
          <TouchableOpacity onPress={() => {}}>
            <Text style={HoldingSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default SearchModal;

import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {positionScreen} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import TodaysOverallList from './component/TodayOverallList';
import TopHeader from '../Holding/component/TopHeader';
import PositionSearchModal from './component/positionSearchModal';
import {useNavigation} from '@react-navigation/native';
const Positions = ({bottomSheetRef, setTabFilter}: any) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState([]);
  const [handleRefresh, setHandleRefresh] = useState(false);
  const navigation = useNavigation();

  const todayPl = -73737.9;
  const actualPl = '0.00';

  const overallData = [
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
    },
  ];

  useEffect(() => {
    pushStockData();
  }, []);
  const pushStockData = () => {
    setHandleRefresh(true);
    let StockArraydata = [];

    for (let i = 0; i < 7; i++) {
      StockArraydata.push({
        companyName: 'TCS',
        buy: '1 Qty @ ₹ 4570.00',
        todaysPL: '-18.65(-0.28)',
        LTP: '3316.25',
        titleChip: 'EQ Combined',
        bottomChip: 'DELIVERY',
        index: 'NSE',
        value: 1035.78 + Math.floor(Math.random() * 999),
        changes: '+3.65(+0.44%)',
        invested: 3315000.56 + 47 * i,
        cmv: 3315000.42 + 92 * i,
        status: 'Buy : ',
      });
    }

    setStockData(StockArraydata);
    setHandleRefresh(false);
  };
  const renderItem = ({item}) => {
    return (
      <TodaysOverallList
        stockName={item.companyName}
        buy={item.buy}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };
  return (
    <View style={positionScreen({selectedIndex}).mainView}>
      <TopHeader
        leftTopText={'Current value'}
        leftBottomText={'Overall P/L'}
        rightTopText={'Invested value'}
        rightBottomText={'Todays P/L'}
        currentVal={'18,73,38,879.00'}
        investedVal={'18,73,38,879.00'}
        overallPL={'83,73,60.00(98.36%)'}
        todaysPL={'83,73,60.00(98.36%)'}
      />
      <View style={positionScreen({selectedIndex}).switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={positionScreen({selectedIndex}).todaysView}>
          <Text style={positionScreen({selectedIndex}).todayText}>
            Today's ({stockData.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={positionScreen({selectedIndex}).overallView}>
          <Text style={positionScreen({selectedIndex}).overallText}>
            Overall ({overallData.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* filter header */}

      <View style={positionScreen({}).header}>
        <View>
          <View style={positionScreen({}).todayPlTextValueView}>
            <Text style={positionScreen({}).todaysPlText}>Today's P/L : </Text>
            <Text style={positionScreen({}).todaysPlValue}>₹ {todayPl}</Text>
          </View>
          {selectedIndex === 1 ? (
            <View style={positionScreen({}).actualPlTextValueView}>
              <Text style={positionScreen({}).actualPlText}>Actual P/L : </Text>
              <Text style={positionScreen({}).actualPlValue}>₹ {actualPl}</Text>
            </View>
          ) : (
            <></>
          )}
        </View>

        <View style={positionScreen({}).headerIconsView}>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('SquareOff');
            }}
            style={positionScreen({}).squareOffView}>
            <Text style={positionScreen({}).squareOffViewText}>Square-Off</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              // open Search modal here
              setModalVisible(true);
            }}>
            <Ionicons
              name="search-sharp"
              size={22}
              color="#303030"
              style={positionScreen({}).headerSearchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              // dispatch(showAnimatedOverlay(true));
              setTabFilter('Position');
              bottomSheetRef?.current?.snapToIndex?.(0);
            }}>
            <Ionicons
              name="options-outline"
              size={22}
              color="#303030"
              style={positionScreen({}).headerFilterIcon}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Flatelist code start from here  */}

      <PositionSearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />

      <FlatList
        data={selectedIndex === 0 ? stockData : overallData}
        renderItem={renderItem}
        contentContainerStyle={{paddingBottom: 70}}
        keyExtractor={(_, index) => `item-${index}`}
        refreshing={handleRefresh}
        onRefresh={() => {
          pushStockData();
        }}
      />
    </View>
  );
};

export default Positions;

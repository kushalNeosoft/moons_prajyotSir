export const buyData = [
    {
      qty: 319,
      orders: 4,
      bid: 145.35,
    },
    {
      qty: 319,
      orders: 4,
      bid: 145.35,
    },
    {
      qty: 319,
      orders: 4,
      bid: 145.35,
    },
    {
      qty: 319,
      orders: 4,
      bid: 145.35,
    },
    {
      qty: 319,
      orders: 4,
      bid: 145.35,
    },
  ];

  export const sellData = [
    {
      ask: 145.5,
      orders: 1,
      qty: 181,
    },
    {
      ask: 145.5,
      orders: 1,
      qty: 181,
    },
    {
      ask: 145.5,
      orders: 1,
      qty: 181,
    },
    {
      ask: 145.5,
      orders: 1,
      qty: 181,
    },
    {
      ask: 145.5,
      orders: 1,
      qty: 181,
    },
  ];
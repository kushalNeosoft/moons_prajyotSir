import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { goodTillDateSheet } from '../../../theme/light';
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { useSelector } from 'react-redux';

const GoodTillDateComp =(props: any) => {
  const storeGoodTillDateData = useSelector(state => state.Reducer.bottomSheetData);
  const orderdetails = [
    {
      title: 'Product Type',
      value: props.allData.productType,
    },
    {
      title: 'Order Type',
      value: props.allData.quantity,
    },
    {
      title: 'Ordered Qty',
      value: props.allData.price,
    },
    {
      title: 'Traded Qty',
      value: props.allData.validity,
    },
    {
      title: 'Open Qty',
      value: props.allData.stopLoss,
    },
    {
      title: 'Quantity',
      value: props.allData.stopLoss,
    },
    {
      title: 'Price',
      value: 300,
    },
    {
      title: 'Validity',
      value: "29 May'23",
    },
    {
      title: 'Stop Loss',
      value: '0.00',
    },
  ];

  const additionalDetails = [
    {
      title: 'Date & Time',
      value: props.allData.dateAndTime,
    },
    {
      title: 'Exchange date & Time',
      value: props.allData.exgDateAndTime,
    },
    {
      title: 'Exchange Order No.',
      value: props.allData.exgOrderNo,
    },
    {
      title: 'GTD Order ID',
      value: props.allData.initiatedFrom,
    },
    {
      title: 'GTD Order Status',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Order Entry Date',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Initiated From',
      value: props.allData.modifiedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={goodTillDateSheet.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={goodTillDateSheet.companyName}>{props.allData.name}</Text>
          )}
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={goodTillDateSheet.buyTxt}>Buy : </Text>
            <Text style={goodTillDateSheet.marketRate}>{props.allData.buy}</Text>
          </View>
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={goodTillDateSheet.dayTxt}>
              {`Valid till ${props.allData.validity}`}{' '}
            </Text>
            <Text style={goodTillDateSheet.delivery}>GTD</Text>
            <Text style={goodTillDateSheet.delivery}>DELIVERY</Text>
          </View>
          <Text style={goodTillDateSheet.active}>COMPLETED</Text>
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 20, ...alignment.row}}>
              <Text style={goodTillDateSheet.activeTxt}>Completed</Text>
              <AntDesign name="checkcircle" size={15} color={'#4caf50'} />
            </View>
          )}
          <Text style={goodTillDateSheet.qty}>{props.allData.qty}</Text>
          <Text style={goodTillDateSheet.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
        </View>
      </View>
      {/*  */}
      <TouchableOpacity style={goodTillDateSheet.reOrderBtn}>
        <Text style={goodTillDateSheet.reOrderTxt}>Re-Order</Text>
      </TouchableOpacity>
      {/*  */}
      <Text style={goodTillDateSheet.orderHistoryTxt}>Order History</Text>
      <Text style={goodTillDateSheet.noOrdersTxt}>No order so far</Text>
      {/*  */}
      <Text style={goodTillDateSheet.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={goodTillDateSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={goodTillDateSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={goodTillDateSheet.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={goodTillDateSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={goodTillDateSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
    </>
  );
};


export default GoodTillDateComp;

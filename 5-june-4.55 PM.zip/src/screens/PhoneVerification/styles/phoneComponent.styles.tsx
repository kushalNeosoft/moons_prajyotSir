import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../../styles/colors';

export const createPhoneComponentStyles = (colors: TColors) => {
  return StyleSheet.create({
    heading: {
      fontSize: Font.font_title,
      fontFamily:Cfont.rubik_medium,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: 'grey',
    },
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
      flexDirection: 'row',
    },
    buttonText: {
      // color: root.color_active,
      fontSize: Font.font_normal_three,
      // alignSelf: 'center',
    },
    buttonImage: {
      color: 'white',
      width: 24,
      marginLeft: 16,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_text,
      borderWidth: 0.8,
      color:root.color_text,
     
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
      color:root.color_text,
    
    },
  });
};

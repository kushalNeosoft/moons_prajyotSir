import React from 'react';
import {FlatList, View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';

const List = (props: any) => {
  const renderItem = ({item}: any) => {
    let Texts = [];
    if(item.city==='Mumbai'){
     Texts.push(
          <View style={styles.detailsContainer}>
            <Text style={styles.titleTxt}>{item.name}</Text>
            <Text style={styles.valueTxt}>{item.age}</Text>
          </View>,
        );
    }

      return Texts;
  };

  return <FlatList data={props.data} renderItem={renderItem} />;
};

const styles = StyleSheet.create({
  detailsContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 10,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valueTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
});

export default List;

import React, {useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import {RadioButton} from 'react-native-paper';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { chooseBankModal } from '../../../../../theme/light';

const ChooseBankModal = (props: any) => {
  const [bank, setBank] = useState<string>(props.modalAccountName);

  const setBankAndClose = (value: string) => {
    props.setBankAccount(value);
    setBank(value);
    props.onClose();
  };

  const renderBanks = ({item}: any) => {
    return (
      <TouchableOpacity
        style={chooseBankModal.accountsContainer}
        onPress={() => setBankAndClose(item)}>
        <View style={chooseBankModal.selectAccount}>
          <RadioButton
            color={root.color_text}
            value={item}
            onPress={() => setBankAndClose(item)}
            status={bank == item ? 'checked' : 'unchecked'}
          />
          <Text style={chooseBankModal.name}>{item}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      transparent={true}
      onRequestClose={() => props.onClose()}
      visible={props.visible}>
      <TouchableOpacity
        style={chooseBankModal.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={chooseBankModal.modalView}>
      <View style={chooseBankModal.headerView}>
          <Text style={chooseBankModal.accountsTxt}>Mapped Banks</Text>
          <AntDesign name="close" size={24} color={'black'} />
        </View>
        <FlatList
          data={props.data}
          renderItem={renderBanks}
          style={chooseBankModal.accountList}
          showsVerticalScrollIndicator={false}
          scrollEnabled={false}
        />
      </View>
    </Modal>
  );
};



export default ChooseBankModal;

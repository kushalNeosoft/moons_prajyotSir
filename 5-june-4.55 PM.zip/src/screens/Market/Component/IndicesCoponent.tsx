import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
import {indicesComp} from '../../../theme/light';

const IndicesComponent = props => {
  return (
    <TouchableOpacity style={indicesComp.container}>
      <Text style={indicesComp.title}>{props.title}</Text>
      <Text style={indicesComp.price}>{props.price}</Text>
      <Text style={indicesComp.changes}>{props.changes}</Text>
      <Text style={indicesComp.date}>{props.date}</Text>
    </TouchableOpacity>
  );
};
export default IndicesComponent;

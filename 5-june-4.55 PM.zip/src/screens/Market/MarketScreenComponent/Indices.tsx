import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {indicesData} from './SampleData';
import IndicesComponent from '../Component/IndicesCoponent';
import {marketScreen} from '../../../theme/light';
const Indices = () => {
  const renderIndicesItem = ({item}) => {
    return (
      <IndicesComponent
        title={item.title}
        price={item.price}
        changes={item.changes}
        date={item.date}
      />
    );
  };
  return (
    <View>
      <View style={marketScreen.indicesHeadView}>
        <Text style={marketScreen.indicesHeadText}>Indices</Text>
        <TouchableOpacity>
          <Text style={marketScreen.indicesViewAllBtn}>View All</Text>
        </TouchableOpacity>
      </View>
      <View>
        <FlatList
          data={indicesData}
          renderItem={renderIndicesItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          style={marketScreen.indicesFlateList}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
    </View>
  );
};
export default Indices;

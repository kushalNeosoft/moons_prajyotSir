import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import { useNavigation } from '@react-navigation/native';
import { addToWatchList } from '../../theme/light';

function AddToWatchList() {
    const navigation=useNavigation();
  return (
    <View style={addToWatchList.container}>
      <View style={addToWatchList.innerContainer}>
        <View style={addToWatchList.topContainerView}>
            <TouchableOpacity onPress={()=>navigation.goBack()}>
          <BackIcon style={addToWatchList.backIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={addToWatchList.skipContainer}>
            <Text style={addToWatchList.skipTxt}>Skip</Text>
          </TouchableOpacity>
        </View>
        <View style={addToWatchList.titleTxtContainer}>
          <Text style={addToWatchList.titleTxt}>
            Let's setup your new watchlist
          </Text>
        </View>
        <Text style={addToWatchList.subTitleTxt}>Create your watchlist</Text>
        <View style={addToWatchList.textIpContainer}>
          <TextInput
            style={addToWatchList.textIp}
            placeholder="Name your watchlist"
          />
          <TouchableOpacity style={addToWatchList.createBtnContainer}>
            <Text style={addToWatchList.createTxt}>Create</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default AddToWatchList;

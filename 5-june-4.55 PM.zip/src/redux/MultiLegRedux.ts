export enum MultiLegAction {
  UPDATE_LOT = 'update_lot',
  UPDATE_OPERATION = 'update_operation',
  EDIT_LEG = 'edit_leg',
}

interface MultiLegActionModel {
  payload: {
    id?: String;
    lots?: number;
    operation?: string;
    edit?: boolean;
  };
  type?: MultiLegAction;
}
export const multiLegReducer = (legs: any, action: MultiLegActionModel) => {
  console.log(legs);

  switch (action.type) {
    case MultiLegAction.UPDATE_LOT:
      return legs.map((leg: any) => {
        if (leg.id === action.payload.id) {
          return {
            ...leg,
            lots: action.payload.lots,
          };
        } else {
          return leg;
        }
      });
    case MultiLegAction.UPDATE_OPERATION:
      return legs.map((leg: any) => {
        if (leg.id === action.payload.id) {
          return {
            ...leg,
            operation: action.payload.operation,
          };
        } else {
          return leg;
        }
      });
    case MultiLegAction.EDIT_LEG:
      return legs.map((leg: any) => {
        if (leg.id === action.payload.id) {
          return {
            ...leg,
            edit: action.payload.edit,
          };
        } else {
          return leg;
        }
      });
  }
};

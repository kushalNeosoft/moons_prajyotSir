import React, {useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Fontisto from 'react-native-vector-icons/Fontisto';
import {marketStatus} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import MarketStatusBox from './Component/MarketStatusbox';
import SearchModal from './Component/SearchModal';

const Data = [
  {
    title: 'NSE CASH',
    chip: 'Close',
  },
  {
    title: 'NSE DERIVATIVES',
    chip: 'Close',
  },
  {
    title: 'BSE DERIVATIVES',
    chip: 'Open',
  },
  {
    title: 'BSE CASH',
    chip: 'Open',
  },
  {
    title: 'MCX FUTURES',
    chip: 'Unavailbe',
  },
  {
    title: 'NCDEX FUTURES',
    chip: 'Open',
  },
  {
    title: 'NSECDS',
    chip: 'Open',
  },
  {
    title: 'BSE COMM',
    chip: 'Unavailabe',
  },
  {
    title: 'UCX FUTURES',
    chip: 'Unavailabe',
  },
  {
    title: 'BSE CDS',
    chip: 'Unavailabe',
  },
];

const MarketStatus = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const navigation = useNavigation();

  const renderItem = ({item}: any) => {
    return <MarketStatusBox title={item.title} chip={item.chip} />;
  };
  return (
    <View style={marketStatus.mainView}>
      <View style={marketStatus.headerView}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons name="arrow-back" style={marketStatus.backIcon} />
        </TouchableOpacity>
        <View style={marketStatus.headerTextView}>
          <Text style={marketStatus.headerText}>Market Status</Text>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(true);
            }}>
            <Fontisto name="search" style={marketStatus.searchIcon} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={marketStatus.headerTextView}>
        <Text style={marketStatus.exchangeStatusText}>Exchange</Text>
        <Text style={marketStatus.exchangeStatusText}>Status</Text>
      </View>
      <View style={marketStatus.lineView}></View>
      <FlatList data={Data} renderItem={renderItem} />
      <MarketStatusBox />
      <SearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
    </View>
  );
};
export default MarketStatus;

import React, {useState} from 'react';
import {TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {SafeAreaView} from 'react-native';
import {marketStatusSearchModal} from '../../../theme/light';
const SearchModal = ({modalVisible, setModalVisible}) => {
  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={marketStatusSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View>
        <View style={marketStatusSearchModal.headerView}>
          <TouchableOpacity
            style={marketStatusSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={marketStatusSearchModal.textInput}
            placeholder="Search Exchanges"
            placeholderTextColor={'grey'}
          />
          <TouchableOpacity onPress={() => {}}>
            <Text style={marketStatusSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default SearchModal;

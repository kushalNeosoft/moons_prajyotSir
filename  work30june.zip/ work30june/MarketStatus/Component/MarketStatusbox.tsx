import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {marketStatus} from '../../../theme/light';
import {root} from '../../../styles/colors';

const MarketStatusBox = props => {
  return (
    <View style={marketStatus.boxView}>
      <Text style={marketStatus.boxText}>{props.title}</Text>
      <TouchableOpacity style={marketStatus.chipView}>
        <Text
          style={[
            marketStatus.chipText,
            {
              color:
                props.chip === 'Close'
                  ? root.color_negative
                  : props.chip === 'Open'
                  ? root.color_positive
                  : '#303030',
            },
          ]}>
          {props.chip}
        </Text>
      </TouchableOpacity>
    </View>
  );
};
export default MarketStatusBox;

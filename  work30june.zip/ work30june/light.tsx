// setting Screen style
export const settings = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  settingHeaderView: {
    ...alignment.row_alignC,
    // height: size.size_50,
    height: 50,
    ...p.h_14,
  },
  settingHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  settingHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    ...color.text,
  },
  scrollView: {
    ...p.h_18,
  },
  themeView: {
    ...p.t_40,
  },
  title: {
    ...size_family.rm_16,
    ...color.text,
  },
  subTitle: {
    ...size_family.rr_13,
    ...color.text,
  },
  lightDarkTheme: {
    ...size_family.rr_14,
    ...color.text,
  },
  radioButtonView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_26,
  },
  orderPreferenceView: {
    ...p.t_35,
  },
  rowDirectionView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_18,
  },
  arrowIcon: {
    ...color.text,
    fontSize: 22,
  },
  chartPreferenceView: {
    ...p.t_36,
  },
  appNotificationView: {
    ...p.t_35,
  },
  securityView: {
    ...p.t_35,
  },
  takeMeToView: {
    ...p.t_35,
  },
});

// Push notification styles
export const pushNotification = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    ...p.h_16,
  },
  notificationHeaderView: {
    ...alignment.row_alignC,
    height: 45,
  },
  notificationHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  notificationHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  subTitle: {
    ...size_family.rl_13,
    ...color.text,
    ...m.t_58,
  },
  notificationText: {
    ...size_family.rm_17,
    ...color.text,
    ...m.t_30,
    ...p.b_17,
  },
  listItemView: {
    ...alignment.row_alingC_SpaceB,
    ...p.b_30,
  },
  toggleTitle: {
    ...size_family.rr_13,
    ...color.text,
  },
});

// Take me To default style

export const takeMeTo = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...p.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: "100%",
    height: 51,
    ...bgColor.color_active,
    ...alignment.row_alignC,
  },
  modalItemTitle: {
    ...color.text,
    ...size_family.rm_13,
  },
  modalDataFlatelist: {
    height: 200,
    ...m.t_8,
    ...m.b_8,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
});

//Finger Print Face Id style

export const fingerFaceId = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 22,
    ...p.t_20,
  },
  headerView: {
    ...m.t_48,
    ...m.b_12,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_27,
  },
  detailView: {
    width: "100%",
    borderRadius: 7,
    borderColor: "#979797",
    borderWidth: 0.8,
    ...m.t_16,
  },
  detailText: {
    ...color.text,
    ...size_family.rr_13,
    ...p.p_11,
  },
  upperView: {
    flex: 1,
  },
  botton: {
    width: "100%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});

//ChangeMpin Style setting
export const changeMpin = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_42,
    ...m.b_30,
  },
  enterPinText: {
    ...color.text,
    ...size_family.rm_13,
  },
  botton: {
    width: "100%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  inputStyle: {
    width: "50%",
    height: 70,
    ...m.b_5,
  },
  codeInputFieldStyle: {
    width: 40,
    height: 42,
    borderWidth: 1,
    borderRadius: 7,
    ...color.text,
    borderColor: root.color_subtext,
  },
  codeInputHighlightStyle: {
    borderColor: "#000",
  },
});

//Change password styles

export const changePassword = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_40,
  },
  subHeader: {
    ...color.text,
    ...size_family.rl_11,
    ...m.t_14,
    ...m.b_32,
  },
  botton: {
    width: "100%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },

  inputContainer: {
    width: "100%",
    borderWidth: 1,
    borderColor: root.color_subtext,
    ...alignment.row_alingC_SpaceB,
    alignSelf: "center",
    borderRadius: 7,
    ...m.b_15,
  },
  input: {
    flex: 1,
    ...p.p_6,
    ...color.text,
  },
  iconContainer: {
    ...p.p_6,
  },
  rowView: {
    ...alignment.row_alignC,
  },
  passwordStrenthText: {
    ...color.text,
    ...size_family.rr_13,
    ...m.t_26,
  },
  passwordStrenth: {
    ...color.positive,
    ...size_family.rr_13,
    ...m.t_26,
  },
  conditionText: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_17,
    ...m.m_l_10,
  },
  checkIcon: {
    fontSize: 14,
    color: root.color_subtext,
    ...m.t_17,
  },
});

// Order Preferences screen style
export const orderPreferences = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    ...p.h_16,
  },
  orderHeaderView: {
    ...alignment.row_alignC,
    height: 45,
  },
  orderHeaderText: {
    ...size_family.rm_16,
    ...color.text,
    ...p.l_20,
  },
  orderHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  subTitle: {
    ...size_family.rr_11,
    ...color.text,
    ...m.t_50,
  },
  exchangeText: {
    ...size_family.rr_13,
    ...color.text,
    ...m.t_31,
    ...p.b_17,
  },
  botton: {
    width: "100%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.p_10,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  arrowIcon: {
    ...color.text,
    fontSize: 22,
  },
  plusMinusIcon: {
    ...color.text,
    fontSize: 13,
  },
  productTypeView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_20,
  },
  enterProtectionView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_17,
  },
  productTypeText: {
    ...size_family.rr_13,
    ...color.text,
  },
  rowView: {
    ...alignment.row_alignC,
  },

  // modal
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...m.t_12,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  itemMainView: {
    width: "100%",
    ...m.t_10,
    ...bgColor.color_active,
    ...alignment.row_alingC_SpaceB,
  },
  modalItemTitle: {
    ...color.text,
    ...size_family.rr_13,
  },
  modalDataFlatelist: {
    ...m.t_25,
  },
  modalFlatelistConatiner: {
    ...m.t_6,
  },
  input: {
    ...p.p_6,
    ...color.text,
    ...m.h_35,
  },
  listView: {
    borderColor: root.color_subtext,
    borderWidth: 0.8,
    borderRadius: 10,
    ...alignment.row,
    height: 33,
    // padding: 3,
  },
  listItemView: {
    ...alignment.justify_container_center,
    borderColor: root.color_subtext,
  },
  listItemText: {
    ...size_family.rr_11,
    ...p.h_10,
  },
});

//Enable TOTP style

export const enableTOTP = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_16,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_10,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_34,
  },
  subText: {
    ...color.text,
    ...m.t_10,
    ...size_family.rl_13,
    ...p.r_15,
  },
  subTextBold: {
    ...color.text,
    ...m.t_10,
    ...size_family.rm_13,
  },
  inputContainer: {
    width: "90%",
    borderWidth: 1,
    ...alignment.row_alingC_SpaceB,
    borderRadius: 7,
    ...m.t_31,
  },
  input: {
    flex: 1,
    ...p.p_6,
    ...color.text,
    ...m.m_l_10,
  },
  botton: {
    width: "36%",
    ...alignment.row_alingC_SpaceB,
    ...bgColor.client_background,
    ...m.b_16,
    borderRadius: 7,
    ...p.v_8,
    ...p.h_10,
    ...m.t_45,
    elevation: 5,
  },
  bottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
  bottonIcon: {
    ...color.active,
    fontSize: 23,
  },
  timerText: {
    ...color.text,
    ...m.t_10,
    ...size_family.rl_13,
  },
});

// Market Status styles
export const marketStatus = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
    ...p.h_18,
  },
  headerView: {
    paddingBottom: 10,
    // shadowColor: '#000',
    // shadowOffset: {width: 1, height: 1},
    // shadowOpacity: 0.4,
    // shadowRadius: 3,
    // elevation: 5,
  },
  backIcon: {
    ...color.text,
    fontSize: 25,
    ...p.t_18,
  },
  searchIcon: {
    ...color.text,
    fontSize: 20,
    ...p.t_18,
  },
  headerTextView: {
    ...alignment.row_alingC_SpaceB,
  },
  headerText: {
    ...color.text,
    ...size_family.rm_28,
    ...m.t_23,
  },
  exchangeStatusText: {
    ...color.text,
    ...size_family.rm_13,
    ...m.t_28,
  },
  lineView: {
    width: "100%",
    backgroundColor: root.color_subtext,
    height: 0.8,
    ...m.t_10,
    opacity: 0.3,
    ...m.b_6,
  },
  boxView: {
    ...alignment.row_alingC_SpaceB,
    ...m.b_9,
  },
  boxText: {
    ...color.text,
    ...size_family.rm_13,
  },
  chipView: {
    ...bgColor.backgroung_exchange_chip_color,
    ...alignment.alignC_justifyC,
    borderRadius: 25,
    ...p.p_7,
  },
  chipText: {
    ...size_family.rm_11,
  },
});

// Market Status Search Modal

export const marketStatusSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: 300,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.subtext,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
});

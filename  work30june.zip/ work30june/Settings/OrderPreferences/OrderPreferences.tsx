import React, {useRef, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList, TextInput} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {listItem, orderPreferences} from '../../../theme/light';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import SelectProductModal from './Component/SelectProductModal';
import {ScrollView} from 'react-native-gesture-handler';
import {root} from '../../../styles/colors';

const Data = [
  {
    title: 'NSE CASH',
  },
  {
    title: 'NSE DERIVATIVES',
  },
  {
    title: 'BSE DERIVATIVES',
  },
  {
    title: 'BSE CASH',
  },
  {
    title: 'MCX FUTURES',
  },
  {
    title: 'NCDEX FUTURES',
  },
  {
    title: 'NSECDS',
  },
  {
    title: 'BSE COMM',
  },
  {
    title: 'UCX FUTURES',
  },
  {
    title: 'BSE CDS',
  },
];

const OrderPreference = () => {
  const navigation = useNavigation();
  const [visibleModal, setVisibleModal] = useState(false);
  const [productType, setProductType] = useState('PTST');
  const [protectionValue, setProtectionValue] = useState('');
  const [selected, setSelected] = useState('NSE CASH');

  const scrollViewRef = useRef(null);

  const handleItemClick = item => {
    setSelected(item.title);

    const itemIndex = Data.findIndex(dataItem => dataItem.title === item.title);
    let midIndex = Data.length / 2;
    const itemWidth = itemIndex > midIndex ? 70 : 50;
    const offset = itemIndex * itemWidth;
    scrollViewRef.current.scrollTo({x: offset, animated: true});
  };

  const substractProtectionValue = () => {
    setProtectionValue(prevValue => prevValue - 1);
  };
  const addProtectionValue = () => {
    setProtectionValue(prevValue => prevValue + 1);
  };
  const changeProductType = val => {
    if (val == 'NSE CASH') {
      setProductType('PTST');
    } else {
      setProductType('Select Product Type');
    }
  };
  return (
    <View style={orderPreferences.mainView}>
      <View style={orderPreferences.orderHeaderView}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons
            name="arrow-back"
            style={orderPreferences.orderHeaderBackIcon}
          />
        </TouchableOpacity>
        <Text style={orderPreferences.orderHeaderText}>Order Preferences</Text>
      </View>

      <Text style={orderPreferences.subTitle}>
        Select default product type for each segment below :
      </Text>
      <Text style={orderPreferences.exchangeText}>Exchage Preferences</Text>
      <View>
        <ScrollView
          horizontal={true}
          ref={scrollViewRef}
          showsHorizontalScrollIndicator={false}>
          <View style={orderPreferences.listView}>
            {Data.map((item, index) => (
              <TouchableOpacity
                style={[
                  orderPreferences.listItemView,
                  {
                    borderWidth: selected === item.title ? 1 : 0,
                    backgroundColor:
                      selected === item.title
                        ? root.color_orderPreference_bg
                        : root.color_active,
                    borderRadius: selected === item.title ? 8 : 0,
                  },
                ]}
                onPress={e => {
                  handleItemClick(item);
                  changeProductType(item.title);
                }}>
                <Text
                  style={[
                    orderPreferences.listItemText,
                    {
                      color:
                        selected === item.title
                          ? root.color_text
                          : root.color_subtext,
                    },
                  ]}>
                  {item.title}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
      <View style={{flex: 1}}>
        <View style={orderPreferences.productTypeView}>
          <Text style={orderPreferences.productTypeText}>Product Type</Text>
          <TouchableOpacity
            style={orderPreferences.rowView}
            onPress={() => {
              setVisibleModal(true);
            }}>
            <Text style={orderPreferences.productTypeText}>{productType}</Text>
            <MaterialIcons
              name="keyboard-arrow-right"
              style={orderPreferences.arrowIcon}
            />
          </TouchableOpacity>
        </View>
        <View style={orderPreferences.enterProtectionView}>
          <Text style={orderPreferences.productTypeText}>Enter Protection</Text>
          <View style={orderPreferences.rowView}>
            <TouchableOpacity onPress={substractProtectionValue}>
              <AntDesign name="minus" style={orderPreferences.plusMinusIcon} />
            </TouchableOpacity>

            <TextInput
              style={orderPreferences.input}
              placeholder="0.00"
              placeholderTextColor="#979797"
              value={protectionValue.toString()}
              onChangeText={val => {
                const parsedValue = parseFloat(val);
                setProtectionValue(parsedValue);
              }}
              keyboardType="number-pad"
            />
            <TouchableOpacity onPress={addProtectionValue}>
              <AntDesign name="plus" style={orderPreferences.plusMinusIcon} />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <TouchableOpacity style={orderPreferences.botton}>
        <Text style={orderPreferences.bottonText}>Save</Text>
      </TouchableOpacity>
      <SelectProductModal
        visibleModal={visibleModal}
        setVisibleModal={setVisibleModal}
        productType={productType}
        setProductType={setProductType}
        selected={selected}
      />
    </View>
  );
};
export default OrderPreference;

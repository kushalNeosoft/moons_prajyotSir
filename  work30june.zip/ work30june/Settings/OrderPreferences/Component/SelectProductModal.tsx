import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {orderPreferences} from '../../../../theme/light';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import ProductType from './ProductType';

const nseData = [
  {
    title: 'DELIVERY',
  },
  {
    title: 'MARGIN',
  },
  {
    title: 'MTF',
  },
  {
    title: 'PTST',
  },
];
const data = [
  {
    title: 'CARRYFORWARD',
  },
  {
    title: 'INTRADAY',
  },
];

const SelectProductModal = props => {
  const modalRenderItem = ({item}: any) => {
    return (
      <ProductType
        title={item?.title}
        setVisibleModal={props.setVisibleModal}
        productType={props.productType}
        setProductType={props.setProductType}
      />
    );
  };

  return (
    <CommonModal visible={props.visibleModal} onClose={() => {}}>
      <View style={orderPreferences.modalMainView}>
        <View style={orderPreferences.headerAndIconView}>
          <Text style={orderPreferences.modalTitle}>Product Type</Text>
          <TouchableOpacity
            onPress={() => {
              props.setVisibleModal(false);
            }}>
            <AntDesign name="close" style={orderPreferences.modalCloseIcon} />
          </TouchableOpacity>
        </View>
        <FlatList
          scrollEnabled={false}
          data={props.selected == 'NSE CASH' ? nseData : data}
          renderItem={modalRenderItem}
          contentContainerStyle={orderPreferences.modalFlatelistConatiner}
          style={orderPreferences.modalDataFlatelist}
        />
      </View>
    </CommonModal>
  );
};
export default SelectProductModal;

import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {RadioButton} from 'react-native-paper';
import {orderPreferences} from '../../../../theme/light';

const ProductType = props => {
  const onChange = () => {
    props.setProductType(props.title);
    props.setVisibleModal(false);
  };
  return (
    <TouchableOpacity style={orderPreferences.itemMainView} onPress={onChange}>
      <Text style={orderPreferences.modalItemTitle}>{props?.title}</Text>
      <RadioButton
        value={props.title}
        status={props.title === props.productType ? 'checked' : 'unchecked'}
        onPress={onChange}
        color={'#303030'}
      />
    </TouchableOpacity>
  );
};
export default ProductType;

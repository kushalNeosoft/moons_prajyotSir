import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {changeMpin} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
import OTPInputView from '@twotalltotems/react-native-otp-input';

const ChangeMpin = () => {
  const [oldMpin, setOldMpin] = useState();
  const [newMpin, setNewMpin] = useState();
  const [cMpin, setCMpin] = useState();
  const navigation = useNavigation();
  const onChange = () => {};
  return (
    <View style={changeMpin.mainView}>
      <View style={{flex: 1}}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons name="arrow-back" style={changeMpin.backIcon} />
        </TouchableOpacity>
        <Text style={changeMpin.headerText}>Change M-PIN</Text>
        <Text style={changeMpin.enterPinText}>Enter Old M-PIN</Text>
        <OTPInputView
          style={changeMpin.inputStyle}
          pinCount={4}
          // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
          // onCodeChanged = {code => { this.setState({code})}}
          autoFocusOnLoad
          codeInputFieldStyle={changeMpin.codeInputFieldStyle}
          codeInputHighlightStyle={changeMpin.codeInputHighlightStyle}
          secureTextEntry={true}
          onCodeFilled={code => {
            setOldMpin(code);
          }}
        />
        <Text style={changeMpin.enterPinText}>Enter New M-PIN</Text>
        <OTPInputView
          style={changeMpin.inputStyle}
          pinCount={4}
          // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
          // onCodeChanged = {code => { this.setState({code})}}
          autoFocusOnLoad
          codeInputFieldStyle={changeMpin.codeInputFieldStyle}
          codeInputHighlightStyle={changeMpin.codeInputHighlightStyle}
          secureTextEntry={true}
          onCodeFilled={code => {
            setNewMpin(code);
          }}
        />
        <Text style={changeMpin.enterPinText}>Confirm New M-PIN</Text>
        <OTPInputView
          style={changeMpin.inputStyle}
          pinCount={4}
          // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
          // onCodeChanged = {code => { this.setState({code})}}
          autoFocusOnLoad
          codeInputFieldStyle={changeMpin.codeInputFieldStyle}
          codeInputHighlightStyle={changeMpin.codeInputHighlightStyle}
          secureTextEntry={true}
          onCodeFilled={code => {
            setCMpin(code);
          }}
        />
      </View>
      <TouchableOpacity style={changeMpin.botton}>
        <Text style={changeMpin.bottonText}>Change M-PIN</Text>
      </TouchableOpacity>
    </View>
  );
};
export default ChangeMpin;

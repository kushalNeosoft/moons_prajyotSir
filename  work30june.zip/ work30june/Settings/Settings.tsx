import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {settings} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import {ScrollView} from 'react-native-gesture-handler';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {root} from '../../styles/colors';
import {RadioButton} from 'react-native-paper';
import {Switch} from 'react-native-switch';
import TakeMeToModal from './Component/TakeMeToModal';
import EnableTOTP from './EnableTOTP/EnableTOTP';

const Settings = () => {
  const [theme, setTheme] = useState('light');
  const [chart, setChart] = useState('chart IQ');
  const [tradeMessage, setTradeMessage] = useState(false);
  const [fingerFaceID, setFingerFaceId] = useState(false);
  const [enableTOTP, setEnableTOTP] = useState(false);
  const [takeMeDefault, setTakeMeDefault] = useState('Watchlist');
  const [visibleModal, setVisibleModal] = useState(false);
  const navigation = useNavigation();

  const tradeMsgFun = () => {
    setTradeMessage(!tradeMessage);
  };
  const fingerFaceFun = () => {
    setFingerFaceId(!fingerFaceID);
    navigation.navigate('FingerPrintFaceID');
  };
  const enableTOTPFun = () => {
    setEnableTOTP(!enableTOTP);
  };
  useEffect(() => {
    setFingerFaceId(false);
  }, [fingerFaceID]);

  return (
    <View style={{flex: 1}}>
      {enableTOTP === true ? (
        <EnableTOTP setEnableTOTP={setEnableTOTP} />
      ) : (
        <View style={settings.mainView}>
          <View style={settings.settingHeaderView}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Ionicons
                name="arrow-back"
                style={settings.settingHeaderBackIcon}
              />
            </TouchableOpacity>
            <Text style={settings.settingHeaderText}>Settings</Text>
          </View>
          <ScrollView style={settings.scrollView}>
            <View style={settings.themeView}>
              <Text style={settings.title}>Theme</Text>
              <View style={settings.radioButtonView}>
                <Text style={settings.lightDarkTheme}>Light theme</Text>

                <RadioButton
                  value="light"
                  status={theme === 'light' ? 'checked' : 'unchecked'}
                  onPress={() => setTheme('light')}
                  color={'#303030'}
                />
              </View>
              <View style={settings.radioButtonView}>
                <Text style={settings.lightDarkTheme}>Dark Theme</Text>
                <RadioButton
                  value="dark"
                  status={theme === 'dark' ? 'checked' : 'unchecked'}
                  onPress={() => setTheme('dark')}
                  color={'#303030'}
                />
              </View>
            </View>

            <View style={settings.orderPreferenceView}>
              <Text style={settings.title}>Order Preferences</Text>
              <TouchableOpacity
                style={settings.rowDirectionView}
                onPress={() => {
                  navigation.navigate('OrderPreference');
                }}>
                <Text style={settings.subTitle}>Default Product Type</Text>

                <MaterialIcons
                  name="keyboard-arrow-right"
                  style={settings.arrowIcon}
                />
              </TouchableOpacity>
            </View>

            <View style={settings.chartPreferenceView}>
              <Text style={settings.title}>Chart Preferences</Text>
              <View style={settings.radioButtonView}>
                <Text style={settings.subTitle}>Chart IQ</Text>
                <RadioButton
                  value="chart IQ"
                  status={chart === 'chart IQ' ? 'checked' : 'unchecked'}
                  onPress={() => setChart('chart IQ')}
                  color={'#303030'}
                />
              </View>
              <View style={settings.radioButtonView}>
                <Text style={settings.subTitle}>Trading View</Text>
                <RadioButton
                  value="Trading View"
                  status={chart === 'Trading View' ? 'checked' : 'unchecked'}
                  onPress={() => setChart('Trading View')}
                  color={'#303030'}
                />
              </View>
            </View>

            <View style={settings.appNotificationView}>
              <Text style={settings.title}>App Notifications</Text>
              <TouchableOpacity
                style={settings.rowDirectionView}
                onPress={() => {
                  navigation.navigate('PushNotification');
                }}>
                <Text style={settings.subTitle}>Push Notification</Text>

                <MaterialIcons
                  name="keyboard-arrow-right"
                  style={settings.arrowIcon}
                />
              </TouchableOpacity>
              <View style={settings.rowDirectionView}>
                <Text style={settings.subTitle}>Trade Message</Text>
                <View>
                  <Switch
                    value={tradeMessage}
                    onValueChange={tradeMsgFun}
                    activeText={''}
                    inActiveText={''}
                    backgroundActive={root.color_positive}
                    backgroundInactive={root.color_subtext}
                    circleSize={10}
                    switchRightPx={2}
                    switchLeftPx={2}
                    barHeight={15}
                    circleBorderWidth={0}
                    switchWidthMultiplier={3}
                  />
                </View>
              </View>
            </View>

            <View style={settings.securityView}>
              <Text style={settings.title}>Security Setting</Text>
              <View style={settings.rowDirectionView}>
                <Text style={settings.subTitle}>Fingerprint / FaceID</Text>
                <Switch
                  value={fingerFaceID}
                  onValueChange={fingerFaceFun}
                  activeText={''}
                  inActiveText={''}
                  backgroundActive={root.color_positive}
                  backgroundInactive={root.color_subtext}
                  circleSize={10}
                  switchRightPx={2}
                  switchLeftPx={2}
                  barHeight={15}
                  circleBorderWidth={0}
                  switchWidthMultiplier={3}
                />
              </View>
              <TouchableOpacity
                style={settings.rowDirectionView}
                onPress={() => {
                  navigation.navigate('ChangeMpin');
                }}>
                <Text style={settings.subTitle}>Change M-Pin</Text>
                <MaterialIcons
                  name="keyboard-arrow-right"
                  style={settings.arrowIcon}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={settings.rowDirectionView}
                onPress={() => {
                  navigation.navigate('ChangePassword');
                }}>
                <Text style={settings.subTitle}>Change Password</Text>
                <MaterialIcons
                  name="keyboard-arrow-right"
                  style={settings.arrowIcon}
                />
              </TouchableOpacity>
              <View style={settings.rowDirectionView}>
                <Text style={settings.subTitle}>Enable TOTP</Text>
                <Switch
                  value={enableTOTP}
                  onValueChange={enableTOTPFun}
                  activeText={''}
                  inActiveText={''}
                  backgroundActive={root.color_positive}
                  backgroundInactive={root.color_subtext}
                  circleSize={10}
                  switchRightPx={2}
                  switchLeftPx={2}
                  barHeight={15}
                  circleBorderWidth={0}
                  switchWidthMultiplier={3}
                />
              </View>
            </View>
            <View style={settings.takeMeToView}>
              <Text style={settings.title}>Take Me To</Text>
              <TouchableOpacity
                style={settings.rowDirectionView}
                onPress={() => {
                  setVisibleModal(true);
                }}>
                <Text style={settings.subTitle}>Change Default</Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text style={settings.subTitle}>{takeMeDefault}</Text>
                  <MaterialIcons
                    name="keyboard-arrow-right"
                    style={settings.arrowIcon}
                  />
                </View>
              </TouchableOpacity>
            </View>
            <View style={{height: 35}}></View>
          </ScrollView>
          <TakeMeToModal
            visibleModal={visibleModal}
            setVisibleModal={setVisibleModal}
            setTakeMeDefault={setTakeMeDefault}
            takeMeDefault={takeMeDefault}
          />
        </View>
      )}
    </View>
  );
};
export default Settings;

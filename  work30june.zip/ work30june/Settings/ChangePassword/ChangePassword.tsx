import React, {useState} from 'react';
import {View, Text, TouchableOpacity, TextInput} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {changePassword} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import EnableTOTP from '../EnableTOTP/EnableTOTP';

const ChangePassword = () => {
  const [oldPassword, setOldPassword] = useState();
  const [newPassword, setNewPassword] = useState();
  const [cPassword, setCPassword] = useState();
  const navigation = useNavigation();
  const [isNewPasswordVisible, setIsNewPasswordVisible] = useState(false);
  const [isOldPasswordVisible, setIsOldPasswordVisible] = useState(false);
  const [isConfirmPasswordVisible, setIsConfirmPasswordVisible] =
    useState(false);

  const [passwordStrength, setPasswordStrength] = useState('Weak');

  return (
    <View style={changePassword.mainView}>
      <View style={{flex: 1}}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons name="arrow-back" style={changePassword.backIcon} />
        </TouchableOpacity>
        <Text style={changePassword.headerText}>Change Password</Text>
        <Text style={changePassword.subHeader}>
          Your password should be a combination of alphabets,numbers and must be
          of 6-12 characters.
        </Text>

        <View style={changePassword.inputContainer}>
          <TextInput
            style={changePassword.input}
            placeholder="Enter privious password"
            placeholderTextColor="#979797"
            value={oldPassword}
            onChangeText={val => {
              setOldPassword(val);
            }}
            secureTextEntry={isOldPasswordVisible}
          />
          <TouchableOpacity
            style={changePassword.iconContainer}
            onPress={() => {
              setIsOldPasswordVisible(!isOldPasswordVisible);
            }}>
            <MaterialIcons
              name={isOldPasswordVisible ? 'visibility-off' : 'visibility'}
              size={24}
              color="#979797"
            />
          </TouchableOpacity>
        </View>
        <View style={changePassword.inputContainer}>
          <TextInput
            style={changePassword.input}
            placeholder="Enter new password"
            placeholderTextColor="#979797"
            value={newPassword}
            onChangeText={val => {
              setNewPassword(val);
            }}
            secureTextEntry={isNewPasswordVisible}
          />
          <TouchableOpacity
            style={changePassword.iconContainer}
            onPress={() => {
              setIsNewPasswordVisible(!isNewPasswordVisible);
            }}>
            <MaterialIcons
              name={isNewPasswordVisible ? 'visibility-off' : 'visibility'}
              size={24}
              color="#979797"
            />
          </TouchableOpacity>
        </View>
        <View style={changePassword.inputContainer}>
          <TextInput
            style={changePassword.input}
            placeholder="Confirm new Password"
            placeholderTextColor="#979797"
            value={cPassword}
            onChangeText={val => {
              setCPassword(val);
            }}
            secureTextEntry={isConfirmPasswordVisible}
          />
          <TouchableOpacity
            style={changePassword.iconContainer}
            onPress={() => {
              setIsConfirmPasswordVisible(!isConfirmPasswordVisible);
            }}>
            <MaterialIcons
              name={isConfirmPasswordVisible ? 'visibility-off' : 'visibility'}
              size={24}
              color="#979797"
            />
          </TouchableOpacity>
        </View>
        <View style={changePassword.rowView}>
          <Text style={changePassword.passwordStrenthText}>
            Password Strength :
          </Text>
          <Text style={changePassword.passwordStrenth}>
            {' '}
            {passwordStrength}
          </Text>
        </View>
        <View style={changePassword.rowView}>
          <AntDesign name={'checkcircle'} style={changePassword.checkIcon} />
          <Text style={changePassword.conditionText}>
            Contains Uppercase (A-Z) & Lowercase letters (a-Z)
          </Text>
        </View>
        <View style={changePassword.rowView}>
          <AntDesign name={'checkcircle'} style={changePassword.checkIcon} />
          <Text style={changePassword.conditionText}>
            Contains numbers (0-9)
          </Text>
        </View>
        <View style={changePassword.rowView}>
          <AntDesign name={'checkcircle'} style={changePassword.checkIcon} />
          <Text style={changePassword.conditionText}>
            Contains special characters. Eg : & * - _ : $ # @ ! ?
          </Text>
        </View>
      </View>

      <TouchableOpacity style={changePassword.botton}>
        <Text style={changePassword.bottonText}>Change Password</Text>
      </TouchableOpacity>
    </View>
  );
};
export default ChangePassword;

import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {pushNotification} from '../../../../theme/light';
import {Switch} from 'react-native-switch';
import {root} from '../../../../styles/colors';

const NotificationToggle = props => {
  const [toggle, setToggle] = useState(props.subscribe);
  const onChange = () => {
    if (props.defaultSubscribe != true) {
      setToggle(!toggle);
    }
  };
  return (
    <View style={pushNotification.listItemView}>
      <Text style={pushNotification.toggleTitle}>{props.title}</Text>
      <View style={{opacity: props.defaultSubscribe ? 0.5 : 1}}>
        <Switch
          value={toggle}
          onValueChange={onChange}
          activeText={''}
          inActiveText={''}
          backgroundActive={root.color_positive}
          backgroundInactive={root.color_subtext}
          circleSize={10}
          switchRightPx={2}
          switchLeftPx={2}
          barHeight={15}
          circleBorderWidth={0}
          switchWidthMultiplier={3}
        />
      </View>
    </View>
  );
};
export default NotificationToggle;

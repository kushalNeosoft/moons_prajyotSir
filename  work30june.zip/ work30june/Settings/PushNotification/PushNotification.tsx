import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import {pushNotification} from '../../../theme/light';
import NotificationToggle from './Component/NotificationToggle';

const Data = [
  {
    title: 'MARKET NEWS',
    subscribe: true,
    defaultSubscribe: false,
  },
  {
    title: 'TRADE NOTIFICATION',
    subscribe: true,
    defaultSubscribe: false,
  },
  {
    title: 'PST NEWS',
    subscribe: true,
    defaultSubscribe: true,
  },
  {
    title: 'sann',
    subscribe: true,
    defaultSubscribe: true,
  },
  {
    title: 'cnn news',
    subscribe: true,
    defaultSubscribe: true,
  },
  {
    title: 'recommendation',
    subscribe: true,
    defaultSubscribe: false,
  },
  {
    title: 'tkt1048a',
    subscribe: true,
    defaultSubscribe: false,
  },
  {
    title: 'tkt1048b',
    subscribe: false,
    defaultSubscribe: false,
  },
];

const PushNotification = () => {
  const navigation = useNavigation();
  const renderItem = ({item}: any) => {
    return (
      <NotificationToggle
        title={item.title}
        subscribe={item.subscribe}
        defaultSubscribe={item.defaultSubscribe}
      />
    );
  };
  return (
    <View style={pushNotification.mainView}>
      <View style={pushNotification.notificationHeaderView}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons
            name="arrow-back"
            style={pushNotification.notificationHeaderBackIcon}
          />
        </TouchableOpacity>
        <Text style={pushNotification.notificationHeaderText}>
          Push Notifications
        </Text>
      </View>
      <Text style={pushNotification.subTitle}>
        Turn on the notifications you want to receive.
      </Text>
      <Text style={pushNotification.notificationText}>Notifications</Text>
      <FlatList data={Data} renderItem={renderItem} />
    </View>
  );
};
export default PushNotification;

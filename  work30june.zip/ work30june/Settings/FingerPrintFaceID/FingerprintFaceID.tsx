import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {fingerFaceId} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {root} from '../../../styles/colors';

const FingerPrintFaceID = () => {
  const navigation = useNavigation();
  const [index, setIndex] = useState(0);
  const data = {
    name: 'PRAGATI',
    email: '*******tive-poc@63moons.com',
    phone: '90********76',
  };
  return (
    <View style={fingerFaceId.mainView}>
      <View style={fingerFaceId.upperView}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons name="arrow-back" style={fingerFaceId.backIcon} />
        </TouchableOpacity>
        <View style={fingerFaceId.headerView}>
          <Text style={fingerFaceId.headerText}>Eanble</Text>
          <Text style={fingerFaceId.headerText}>Fingerprint/FaceID</Text>
        </View>
        <TouchableOpacity
          style={[
            fingerFaceId.detailView,
            {borderColor: index == 1 ? root.color_textual : root.color_subtext},
          ]}
          onPress={() => {
            setIndex(1);
          }}
          activeOpacity={1}>
          <Text style={fingerFaceId.detailText}>{data.name}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            fingerFaceId.detailView,
            {borderColor: index == 2 ? root.color_textual : root.color_subtext},
          ]}
          onPress={() => {
            setIndex(2);
          }}
          activeOpacity={1}>
          <Text style={fingerFaceId.detailText}>{data.email}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            fingerFaceId.detailView,
            {borderColor: index == 3 ? root.color_textual : root.color_subtext},
          ]}
          onPress={() => {
            setIndex(3);
          }}
          activeOpacity={1}>
          <Text style={fingerFaceId.detailText}>{data.phone}</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={fingerFaceId.botton}>
        <Text style={fingerFaceId.bottonText}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};
export default FingerPrintFaceID;

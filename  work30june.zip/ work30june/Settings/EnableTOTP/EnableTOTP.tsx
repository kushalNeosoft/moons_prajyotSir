import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, TextInput} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {enableTOTP} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
import {root} from '../../../styles/colors';

const data = {
  number: '90********87',
  mail: '*******tive-poc@63moons.com',
};
const EnableTOTP = props => {
  const [otp, setOtp] = useState('');
  const [time, setTime] = useState(56);
  const navigation = useNavigation();

  return (
    <View style={enableTOTP.mainView}>
      <TouchableOpacity
        onPress={() => {
          props.setEnableTOTP(false);
        }}>
        <Ionicons name="arrow-back" style={enableTOTP.backIcon} />
      </TouchableOpacity>
      <Text style={enableTOTP.headerText}>Verify OTP</Text>

      <Text style={enableTOTP.subText}>
        OTP sent to <Text style={enableTOTP.subTextBold}>{data.number}</Text>
        and <Text style={enableTOTP.subTextBold}>{data.mail}</Text>
      </Text>

      <View
        style={[
          enableTOTP.inputContainer,
          {borderColor: otp === '' ? root.color_subtext : root.color_textual},
        ]}>
        <TextInput
          style={enableTOTP.input}
          placeholder="Enter OTP"
          placeholderTextColor="#979797"
          value={otp}
          onChangeText={val => {
            setOtp(val);
          }}
          keyboardType="number-pad"
        />
      </View>
      <Text style={enableTOTP.timerText}>Resend OTP in {time} s</Text>
      <TouchableOpacity style={enableTOTP.botton}>
        <Text style={enableTOTP.bottonText}>Verify</Text>
        <Ionicons name="arrow-forward" style={enableTOTP.bottonIcon} />
      </TouchableOpacity>
    </View>
  );
};
export default EnableTOTP;

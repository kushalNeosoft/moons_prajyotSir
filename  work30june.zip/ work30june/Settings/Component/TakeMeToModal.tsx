import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {takeMeTo} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';
import ModalListItem from './ModalListItem';

const modalData = [
  {
    title: 'Watchlist',
  },
  {
    title: 'Market',
  },
  {
    title: 'Orders',
  },
  {
    title: 'Portfolio',
  },
];

const TakeMeToModal = props => {
  const modalRenderItem = ({item}: any) => {
    return (
      <ModalListItem
        title={item?.title}
        setVisibleModal={props.setVisibleModal}
        setTakeMeDefault={props.setTakeMeDefault}
        takeMeDefault={props.takeMeDefault}
      />
    );
  };

  return (
    <CommonModal visible={props.visibleModal} onClose={() => {}}>
      <View style={takeMeTo.modalMainView}>
        <View style={takeMeTo.headerAndIconView}>
          <Text style={takeMeTo.modalTitle}>Set Default</Text>
          <TouchableOpacity
            onPress={() => {
              props.setVisibleModal(false);
            }}>
            <AntDesign name="close" style={takeMeTo.modalCloseIcon} />
          </TouchableOpacity>
        </View>
        <FlatList
          scrollEnabled={false}
          data={modalData}
          renderItem={modalRenderItem}
          // contentContainerStyle={takeMeTo.modalFlatelistConatiner}
          style={takeMeTo.modalDataFlatelist}
        />
      </View>
    </CommonModal>
  );
};
export default TakeMeToModal;

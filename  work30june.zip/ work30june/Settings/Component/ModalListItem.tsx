import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {RadioButton} from 'react-native-paper';
import {takeMeTo} from '../../../theme/light';

const ModalListItem = props => {
  const onChange = () => {
    props.setTakeMeDefault(props.title);
    props.setVisibleModal(false);
  };
  return (
    <TouchableOpacity style={takeMeTo.itemMainView} onPress={onChange}>
      <RadioButton
        value={props.title}
        status={props.title === props.takeMeDefault ? 'checked' : 'unchecked'}
        onPress={onChange}
        color={'#303030'}
      />
      <Text style={takeMeTo.modalItemTitle}>{props?.title}</Text>
    </TouchableOpacity>
  );
};
export default ModalListItem;

import React, {useCallback, useRef, useState} from 'react';
//import {View, Text} from 'react-native';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
  Image,
  Dimensions,
  Animated,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Carousel from 'react-native-reanimated-carousel';
import {BannerData} from '../../navigators/SideDrawerNavigation/components/Customdrawer/Bannerdata';
import CloseIcon from '../../assets/CloseIcon';
import { Promo } from '../../theme/light';

const PromotionalDialog = ({visible, onClose}: any) => {
  const navigation = useNavigation();
  const windowWidth = Dimensions.get('window').width;

  const [selectedIndex, setSelectedIndex] = useState(0);
  const indexRef = useRef(selectedIndex);
  indexRef.current = selectedIndex;

  const onScroll = useCallback((event: any) => {
    const slideSize = event.nativeEvent.layoutMeasurement.width;
    const index = event.nativeEvent.contentOffset.x / slideSize;
    const roundIndex = Math.round(index);

    const distance = Math.abs(roundIndex - index);

    // Prevent one pixel triggering setIndex in the middle
    // of the transition. With this we have to scroll a bit
    // more to trigger the index change.
    const isNoMansLand = 0.4 < distance;

    if (roundIndex !== indexRef.current && !isNoMansLand) {
      setSelectedIndex(roundIndex);
    }
  }, []);

  const flatListOptimizationProps = {
    initialNumToRender: 0,
    maxToRenderPerBatch: 1,
    removeClippedSubviews: true,
    scrollEventThrottle: 16,
    windowSize: 2,
    keyExtractor: useCallback((e: any) => e.id, []),
    getItemLayout: useCallback(
      (_: any, index: any) => ({
        index,
        length: windowWidth,
        offset: index * windowWidth,
      }),
      [],
    ),
  };

  const Indicator = ({selected, style}: any) => {
    return (
      <>
        <Animated.View
          style={[
            Promo.AnimatedMain,
            {backgroundColor: selected ? 'white' : 'grey', ...style,}
          ]}
        />
      </>
    );
  };

  return (
    <Modal
      // animationType="slide"
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <View
        style={Promo.ModalMain}>
        <TouchableOpacity
          style={Promo.Modaltouch}
          onPress={() => onClose()}
          activeOpacity={1}
        />
        <TouchableOpacity
          onPress={() => onClose()}
          style={Promo.close}>
          <View>
            <CloseIcon style={Promo.CloseIcon} />
          </View>
        </TouchableOpacity>

        <View
          style={{
            width: windowWidth * 0.9,
            aspectRatio: 1,
          }}>
          <FlatList
            data={BannerData}
            style={{width: '100%'}}
            renderItem={({item}) => {
              return (
                <TouchableOpacity
                  onPress={() => {
                    Linking.openURL('https://google.com');
                  }}>
                  <View style={{width: windowWidth * 0.9}}>
                    <Image
                      source={{uri: item.url}}
                      style={Promo.Image}
                    />
                  </View>
                </TouchableOpacity>
              );
            }}
            pagingEnabled
            horizontal
            showsHorizontalScrollIndicator={false}
            onScroll={onScroll}
            {...flatListOptimizationProps}
          />
        </View>
        <View style={Promo.BannerMain}>
          {BannerData.map((item, index) => {
            return (
              <Indicator
                selected={selectedIndex == index}
                style={{marginLeft: index != 0 ? 4 : 0}}
              />
            );
          })}
        </View>
      </View>
    </Modal>
  );
};
export default PromotionalDialog;

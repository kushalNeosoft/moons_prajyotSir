import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PositionStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PositionStyles = StyleSheet.create({
    mainView: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    switchButtonView: {
      width: '100%',
      height: 30,
      alignSelf: 'center',
      borderRadius: 25,
      marginTop: 10,
      flexDirection: 'row',
      paddingHorizontal: 13,
    },
    todaysView: {
      height: 30,
      alignItems: 'center',
      justifyContent: 'center',
      width: '50%',
      flex: 1,
      borderTopLeftRadius: 25,
      borderBottomLeftRadius: 25,
    },
    todayText: {
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    overallView: {
      height: 30,
      alignItems: 'center',
      justifyContent: 'center',
      width: '50%',
      flex: 1,
      borderTopEndRadius: 25,
      borderBottomEndRadius: 25,
    },
    overallText: {
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    header: {
      color: root.color_active,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 45,
      marginTop: 5,
    },
    todayPlTextValueView: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    todaysPlText: {
      color: root.color_text,
      marginLeft: 16,
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
    },
    todaysPlValue: {
      color: root.color_negative,
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
    },
    actualPlTextValueView: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 2,
    },
    actualPlText: {
      color: root.color_text,
      marginLeft: 16,
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
    },
    actualPlValue: {
      color: root.color_text,
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
    },
    headerIconsView: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    headerSearchIcon: {
      marginRight: 15,
    },
    headerFilterIcon: {
      marginRight: 20,
    },
    squareOffView: {
      backgroundColor: root.color_textual,
      borderRadius: 25,
      width: 85,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 20,
      height: 24,
    },
    squareOffViewText: {
      color: root.color_active,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
    },
    filterMainView: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 1,
      paddingLeft: 16,
      flexWrap: 'wrap',
      marginTop: 3,
    },
    filterText: {
      fontSize: font.size_13,
      fontFamily: font_Family.regular,
      color: root.color_text,
    },
    filterTag: {
      fontSize: font.size_11,
      fontFamily: font_Family.light,
      color: root.color_text,
      marginLeft: 5,
    },
    ammountTag: {
      fontSize: font.size_11,
      fontFamily: font_Family.light,
      color: root.color_text,
      marginLeft: 8,
    },

    filterDataView: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: root.backgroung_exchange_chip_color,
      padding: 3,
      borderRadius: 5,
      marginLeft: 5,
      marginTop: 10,
    },
    filterTagData: {
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
      color: root.color_text,
      paddingLeft: 4,
    },
    closeIcon: {
      color: root.color_text,
      //   fontSize: 20,
      paddingLeft: 8,
    },
    item: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 16,
      marginTop: 4,
    },
    text: {
      fontFamily: font_Family.regular,
      color: root.color_text,
      fontSize: 16,
      paddingLeft: 10,
    },
  });
  return {PositionStyles};
}

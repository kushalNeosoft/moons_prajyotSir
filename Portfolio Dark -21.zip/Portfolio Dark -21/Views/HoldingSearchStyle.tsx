import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function HoldingSearchStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const HoldingSearchStyles = StyleSheet.create({
    modal: {
      width: Dimensions.get('window').width,
      height: '100%',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      backgroundColor: root.color_active,
    },
    headerView: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: root.search_Header_BG,
      shadowColor: '#000',
      shadowOffset: {width: 1, height: 1},
      shadowOpacity: 0.4,
      shadowRadius: 3,
      elevation: 5,
    },
    crossIcon: {
      marginHorizontal: 13,
    },
    textInput: {
      flex: 1,
      fontSize: font.size_13,
      fontFamily: font_Family.regular,
      color: root.color_text,
    },
    cleanBtn: {
      fontSize: font.size_13,
      fontFamily: font_Family.medium,
      marginHorizontal: 16,
      color: root.color_text,
    },
    noDataText: {
      color: root.color_subtext,
      fontSize: font.size_15,
      fontFamily: font_Family.regular,
      alignSelf: 'center',
      marginTop: 100,
    },
  });

  return {HoldingSearchStyles};
}

import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function HoldingFilterStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const HoldingFilterStyles = StyleSheet.create({
    Maincon: {
      width: Dimensions.get('window').width,
    },
    contentView: {
      marginBottom: 100,
      marginTop: 20,
    },
    space: {
      marginBottom: 8,
      backgroundColor: 'transparent',
    },
    spacetwo: {
      marginBottom: 8,
      backgroundColor: 'transparent',
    },
    spaceinner: {
      backgroundColor: 'transparent',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    spacetwoinner: {
      backgroundColor: 'transparent',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    titleText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    commonHtLSelected: {
      borderWidth: 1,
      borderRadius: 10,
      height: 40,
      width: 126,
      alignItems: 'center',
      justifyContent: 'center',
      margin: 12,
      marginRight: 0,
      marginBottom: 0,
      marginTop: 15,
    },

    commonAtZSelected: {
      borderWidth: 0.8,
      borderRadius: 10,
      height: 40,
      width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      margin: 12,
      marginRight: 0,
      marginBottom: 0,
      marginTop: 15,
    },
    text: {
      color: root.color_text,
      fontSize: font.size_14,
      fontFamily: font_Family.regular,
    },
    applyBtn: {
      width: '100%',
      backgroundColor: root.client_background,
      height: 50,
      alignItems: 'center',
      justifyContent: 'center',
      position: 'absolute',
      bottom: 0,
    },
    applyBottonText: {
      color: root.color_active_botten,
      fontSize: font.size_14,
      fontFamily: font_Family.medium,
    },
  });

  return {HoldingFilterStyles};
}

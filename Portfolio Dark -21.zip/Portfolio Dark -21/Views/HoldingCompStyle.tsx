import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function HoldingCompStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const HoldingCompStyles = StyleSheet.create({
    container: {
      backgroundColor: root.porfolio_Component_Bg,
      padding: 3,
      paddingLeft: 10,
      height: 75,
      borderRadius: 7,
      width: '94%',
      alignSelf: 'center',
      marginTop: 6,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 3,
      // overflow: 'hidden',
    },
    listTitle: {
      color: root.color_text,
      paddingTop: 2,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
    },
    listSubTitle: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      color: root.color_text,
      paddingTop: 7,
    },
    listPlLtpView: {
      alignItems: 'flex-end',
      marginRight: 5,
    },
    listPlText: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      color: root.color_text,
      marginTop: 10,
    },
    listLtpText: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      paddingTop: 2,
      color: root.color_text,
    },
    listPlValue: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      paddingTop: 10,
    },
    listLtpValue: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginTop: 2,
    },
    rowAlignC: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    rowSpaceBetween: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    rowSpaceBetweenCenter: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
  });

  return {HoldingCompStyles};
}

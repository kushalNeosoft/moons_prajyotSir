import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function HoldingBottomModalStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const HoldingBottomModalStyles = StyleSheet.create({
    modalView: {
      width: '100%',
      paddingHorizontal: 7,
    },
    stockName: {
      color: root.color_text,
      marginTop: 10,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
    },
    stockTitle: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginVertical: 6,
    },
    stockDetailsView: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 10,
      marginTop: 12,
    },
    stockDetailsText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginVertical: 6,
    },
    stockDetailsValue: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginVertical: 6,
    },
    additionalDetailsText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    additionalDetailsTitle: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginVertical: 8,
    },
    additionalDetailsValues: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginVertical: 8,
    },
    additionalTextIconView: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 17,
    },
    upDownIcon: {
      marginLeft: 9,
    },
    row: {
      flexDirection: 'row',
    },
    additionDetailView: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 28,
      marginTop: 22,
    },
    rowSpaceBtween: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    buySellConatiner: {
      borderRadius: 7,
      height: 40,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 16,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 3,
    },
    buySellBtnText: {
      color: root.color_active_botten,
      fontSize: font.size_14,
      fontFamily: font_Family.regular,
    },
  });

  return {HoldingBottomModalStyles};
}

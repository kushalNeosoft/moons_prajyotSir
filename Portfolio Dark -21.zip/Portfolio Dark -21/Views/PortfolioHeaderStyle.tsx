import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PortfolioHeaderStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PortfolioHeaderStyles = StyleSheet.create({
    container: {
      backgroundColor: root.color_active,
    },
    currentAndInvestedView: {
      marginTop: 8,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    currentValue: {
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
      color: root.color_text,
      marginLeft: 16,
    },
    currentValueNumber: {
      fontSize: font.size_17,
      fontFamily: font_Family.regular,
      color: root.color_text,
      marginLeft: 16,
    },
    overAllPl: {
      color: root.color_text,
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
      marginLeft: 16,
      marginTop: 3,
    },
    overAllPlNumber: {
      color: root.color_positive,
      fontFamily: font_Family.regular,
      fontSize: font.size_11,
      marginLeft: 16,
    },
    investedValue: {
      color: root.color_text,
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
    },
    investedValueNumber: {
      color: root.color_text,
      fontFamily: font_Family.regular,
      fontSize: font.size_11,
    },
    todaysPl: {
      color: root.color_text,
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
      flex: 1,
      paddingTop: 10,
    },
    todaysNumber: {
      color: root.color_negative,
      fontFamily: font_Family.regular,
      fontSize: font.size_11,
    },
  });

  return {PortfolioHeaderStyles};
}

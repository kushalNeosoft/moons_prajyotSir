import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PositionBottomModalStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PositionBottomModalStyles = StyleSheet.create({
    positionmodalView: {
      // height: 254,
      width: '100%',
      paddingHorizontal: 7,
    },
    positionlistTitle: {
      color: root.color_text,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      marginTop: 4,
    },
    positiontitleChip: {
      marginLeft: 5,
      backgroundColor: root.backgroung_exchange_chip_color,
      borderRadius: 2,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 4,
    },
    positiontitleChipText: {
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
      color: root.color_subtext,
    },
    positionbuyText: {
      color: root.color_positive,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginTop: 7,
    },
    positionlistSubTitle: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.light,
      marginTop: 7,
    },
    positionbottomChip: {
      backgroundColor: root.position_Bottomchip_Bg,
      borderRadius: 10,
      marginTop: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 2,
      paddingHorizontal: 4,
    },
    positionbottomChipText: {
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
      color: root.color_textual,
    },
    positionlistPlLtpView: {
      alignItems: 'flex-end',
      marginRight: 5,
    },
    positionlistPlText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginBottom: 10,
    },
    positionlistPlValue: {
      color: root.color_negative,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginBottom: 10,
    },
    positionlistLtpText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      // marginTop: 3,
    },
    positionlistLtpValue: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      // marginTop: 3,
    },
    positionadditionalDetailsText: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    positionadditionalDetailsTitle: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginVertical: 18,
    },
    positionadditionalDetailsHTitle: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginBottom: 6,
      marginTop: 12,
    },
    positionadditionalDetailsValues: {
      color: root.color_text,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginVertical: 18,
    },
    positionaddtionaldetailsView: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 10,
    },
    closeIcon: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      marginTop: 4,
    },
    additionalTextIconView: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 17,
    },
    upDownIcon: {
      marginLeft: 8,
    },
    row: {
      flexDirection: 'row',
    },
    rowAlignC: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    rowSpacebetween: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    subView: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    positionBtnConatiner: {
      // flex: 1,
      backgroundColor: 'transparent',
      borderWidth: 1,
      borderColor: root.color_textual,
      borderRadius: 7,
      height: 40,
      // width: 100,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 23,
      marginTop: 5,
    },
    positionBtnText: {
      fontFamily: font_Family.medium,
      fontSize: font.size_14,
      color: root.color_textual,
    },
  });
  return {PositionBottomModalStyles};
}

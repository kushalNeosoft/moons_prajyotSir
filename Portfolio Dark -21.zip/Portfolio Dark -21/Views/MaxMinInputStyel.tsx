import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function MaxMinInputStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const MaxMinInputStyles = StyleSheet.create({
    commonMinMaxSelected: {
      borderWidth: 1,
      borderRadius: 10,
      height: 40,
      width: 180,
      margin: 12,
      marginRight: 0,
      marginBottom: 0,
      flexDirection: 'row',
      alignItems: 'center',
    },
    minMaxTextInput: {
      borderBottomColor: root.color_subtext,
      height: 20,
      padding: 0,
      margin: 0,
      width: 130,
      flex: 1,
      marginRight: 5,
      textAlign: 'right',
      color: root.color_text,
      backgroundColor: 'transparent',
    },
    minMaxText: {
      color: root.color_text,
      fontSize: font.size_14,
      fontFamily: font_Family.regular,
      marginLeft: 17,
    },
    text: {
      color: root.color_text,
      fontSize: font.size_14,
      fontFamily: font_Family.regular,
    },
  });
  return {MaxMinInputStyles};
}

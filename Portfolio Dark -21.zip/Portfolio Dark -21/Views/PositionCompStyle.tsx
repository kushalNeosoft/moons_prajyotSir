import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PositionCompStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PositionCompStyles = StyleSheet.create({
    container: {
      padding: 3,
      paddingLeft: 10,
      flexDirection: 'row',
      justifyContent: 'space-between',
      height: 85,
      borderRadius: 7,
      width: '94%',
      alignSelf: 'center',
      backgroundColor: root.porfolio_Component_Bg,
      marginTop: 8,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 3,
    },
    listTitle: {
      color: root.color_text,
      FontSize: font.size_16,
      fontFamily: font_Family.medium,
      marginTop: 4,
    },
    titleChip: {
      marginLeft: 5,
      backgroundColor: root.backgroung_exchange_chip_color,
      borderRadius: 2,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 4,
    },
    titleChipText: {
      FontSize: font.size_9,
      fontFamily: font_Family.medium,
      color: root.color_subtext,
    },
    buyText: {
      color: root.color_positive,
      FontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginTop: 7,
    },
    listSubTitle: {
      FontSize: font.size_12,
      fontFamily: font_Family.light,
      color: root.color_text,
      marginTop: 7,
    },
    bottomChip: {
      backgroundColor: root.position_Bottomchip_Bg,
      borderRadius: 10,
      marginTop: 10,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 2,
      paddingHorizontal: 4,
    },
    bottomChipText: {
      FontSize: font.size_10,
      fontFamily: font_Family.medium,
      color: root.color_textual,
    },
    listPlLtpView: {
      alignItems: 'flex-end',
      marginRight: 5,
    },
    listPlText: {
      color: root.color_text,
      FontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginBottom: 10,
    },
    listPlValue: {
      color: root.color_text,
      FontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginBottom: 10,
    },
    listLtpText: {
      color: root.color_text,
      FontSize: font.size_12,
      fontFamily: font_Family.medium,
      marginTop: 4,
    },
    listLtpValue: {
      color: root.color_text,
      FontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginTop: 4,
    },
    rowAlignC: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    subView: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
    },
    row: {
      flexDirection: 'row',
    },
  });
  return {PositionCompStyles};
}

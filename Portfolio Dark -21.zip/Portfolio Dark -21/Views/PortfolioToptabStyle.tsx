import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PortfolioToptabStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PortfolioToptabStyles = StyleSheet.create({
    tabBarStyle: {
      backgroundColor: root.color_active,
      elevation: 10,
    },
    tabBarLabelStyle: {
      fontSize: 12,
      textTransform: 'none',
      fontFamily: font_Family.medium,
    },
    tabBarIndicatorStyle: {
      width: '45%',
      marginLeft: 9,
      backgroundColor: root.color_textual_tab,
    },
  });

  return {PortfolioToptabStyles};
}

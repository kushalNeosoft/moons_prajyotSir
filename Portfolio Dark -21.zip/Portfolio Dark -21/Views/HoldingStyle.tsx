import { forNoAnimation } from "@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators";
import React from "react";
import { Dimensions, StyleSheet } from "react-native";
import { useSelector } from "react-redux";
import globalStyleClass from "../../theme/globalStyleClass";
import Theme from "../../theme/Theme";
import FontSize from "../Common/FontSize";
import { font_Family } from "../Common/FontFamily";
const height = Dimensions.get("window").height;

export default function HoldingStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector((state) => state?.Reducer?.fontSize);
  const { root } = Theme();
  const { font } = FontSize(fontSize);
  const HoldingStyles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    header: {
      flexDirection: "row",
      height: 45,
      marginVertical: 1,
      justifyContent: "space-between",
      alignItems: "center",
    },
    headerScripsText: {
      color: root.color_text,
      marginLeft: 16,
      fontSize: font.size_14,
      fontFamily: font_Family.light,
    },
    headerIconsView: {
      flexDirection: "row",
      alignItems: "center",
    },
    headerInfoIcon: {
      marginRight: 15,
    },
    headerSearchIcon: {
      marginRight: 15,
    },
    headerFilterIcon: {
      marginRight: 20,
    },
    holdingFlatlistFooter: {
      width: "100%",
      height: Dimensions.get("window").height / 2.5,
      marginBottom: 50,
    },
    toolkitText: {
      color: root.color_active,
      fontSize: font.size_9,
      fontFamily: font_Family.regular,
    },
    toolkitView: {
      height: 38,
      width: 200,
      backgroundColor: root.color_text,
      borderRadius: 7,
    },
    filterMainView: {
      flexDirection: "row",
      alignItems: "center",
      padding: 1,
      marginLeft: 16,
      flexWrap: "wrap",
    },
    filterText: {
      fontSize: font.size_14,
      color: root.color_text,
      fontFamily: font_Family.regular,
    },
    filterTag: {
      fontSize: font.size_11,
      fontFamily: font_Family.light,
      color: root.color_text,
      marginLeft: 5,
    },
    ammountTag: {
      fontSize: font.size_11,
      fontFamily: font_Family.light,
      color: root.color_text,
      marginLeft: 8,
    },
    filterDataView: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: root.backgroung_exchange_chip_color,
      padding: 3,
      borderRadius: 5,
      marginLeft: 5,
      marginTop: 10,
    },
    filterTagData: {
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
      color: root.color_text,
      paddingLeft: 4,
    },
    closeIcon: {
      color: root.color_text_icon,
      fontSize: font.size_20,
      paddingLeft: 8,
    },
  });
  return { HoldingStyles };
}
//color_chipFilter:
//colorMode === 'light' ? '#F5F7FA' : 'rgba(92,117,190,0.16)',
// backgroung_exchange_chip_color:
//colorMode === 'light' ? '#9797971A' : '#EBEBEB29',
// porfolio_Component_Bg: colorMode === 'light' ? '#FFFFFF' : '#2C2C2C',
//bottom_Modal_BG: colorMode === 'light' ? '#FFFFFF' : '#2C2C2C',
//search_Header_BG: colorMode === 'light' ? '#FFFFFF' : '#2C2C2C',
//position_Bottomchip_Bg: colorMode === 'light' ? '#9AB3FF33' : '#728BD61A',

import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Logo from '../../assets/Logo';
import AddIcon from '../../assets/AddIcon';
import AddFunds from '../Funds/AddFunds/AddFunds';
import {MyFav, calculator, linkOne} from '../../theme/light';
import {FlatList} from 'react-native';

const MyFavourites = () => {
  const navigation = useNavigation();

  const [list, setList] = useState([]);
  const [categories, setCategories] = useState<any>([]);
  const [selectedCategory, setSelectedCategory] = useState('My Favourites');

  const loadData = async () => {
    fetch(
      'https://devwaveapi.odinwave.com/nontransactional/1404/v1/getAppWaveScannerDetails',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.status) {
          console.log(data.result);

          setList(data.result);
          const unique = [
            ...new Set(data.result.map((item: any) => item.Category)),
          ];
          unique.unshift('My Favourites');
          setCategories(unique);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View style={calculator.main}>
      <View style={calculator.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={calculator.backIcon} />
        </TouchableOpacity>
      </View>
      <Text style={MyFav.header}>My Favorites</Text>
      <Text style={MyFav.total}>Total {list.length}</Text>
      <View>
        <FlatList
          style={MyFav.flatListMain}
          horizontal={true}
          data={categories}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <TouchableOpacity
                key={item}
                onPress={() => {
                  setSelectedCategory(item.item);
                }}>
                <View
                  style={[
                    MyFav.mainView,
                    {backgroundColor:
                      selectedCategory == item.item
                        ? root.client_background
                        : 'transparent',}
                  ]}>
                  <Text
                    style={{
                      color:
                        selectedCategory == item.item
                          ? 'white'
                          : root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    {item.item}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      <ScrollView>
        <FlatList
          data={list.filter((item: any) => {
            if (selectedCategory === 'My Favourites') return true;
            return item.Category === selectedCategory;
          })}
          renderItem={(item: any) => {
            return (
              <TouchableNativeFeedback
                key={item.GroupId}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  //   console.log(item.item);
                  if (item.item.GroupName === 'FII/DII/MF Activity')
                    navigation.navigate('MfActivity', {data: item.item});
                  else if (item.item.GroupName === 'Bulk/Block Deals')
                    navigation.navigate('FavouriteBulkBlockDeals', {
                      data: item.item,
                    });
                  else if (item.item.GroupName === 'Merger & Acquisition') {
                    navigation.navigate('FavouriteMergerAndAcquisition', {
                      data: item.item,
                    });
                  } else navigation.navigate('Favourite', {data: item.item});
                }}>
                <View key={item.GroupId} style={MyFav.group}>
                  <Text style={MyFav.groupText}>{item.item.GroupName}</Text>
                  <Text style={MyFav.description}>{item.item.Description}</Text>
                  <View style={MyFav.imageMain}>
                    <Image
                      source={require('../../assets/Broker.png')}
                      style={MyFav.Image}
                    />
                  </View>
                </View>
              </TouchableNativeFeedback>
            );
          }}
        />
      </ScrollView>
    </View>
  );
};
export default MyFavourites;

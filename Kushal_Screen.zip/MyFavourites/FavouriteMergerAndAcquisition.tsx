import {useEffect, useState} from 'react';
import React from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import {useNavigation} from '@react-navigation/native';
import HeartIcon from '../../assets/HeartIcon';
import HeartFilledIcon from '../../assets/HeartFilledIcon';
import {Cfont, root} from '../../styles/colors';
import { FavOne, maregr } from '../../theme/light';
import SearchIcon from '../../assets/SearchIcon';
import moment from 'moment';
import BulkBlockFilterDialog from './components/BulkBlockFilterDialog';
import FilterIcon from '../../assets/FilterIcon';
import CloseIcon from '../../assets/CloseIcon';
import {TouchableOpacity} from 'react-native-gesture-handler';
import CalendarModal from '../Funds/RecentTransactions/components/CalendarModal/CalendarModal';
import MergerAcquisitionFilterDialog from './components/MergerAcquisitionFilterDialog';
import MergerAcquisitionSearchDialog from './components/MergerAcquisitionSearchDialog';
import FlashMessage from 'react-native-flash-message';

const FavouriteMergerAndAcquisition = ({route}: any) => {
  const fav = route.params.data;
  const [filterDialogVisibility, setFilterDialogVisibility] = useState(false);
  const [calendarModal, setCalendarModal] = useState(false);
  const [searchModal, setSearchModal] = useState(false);

  const [date, setDate] = useState('');

  const [list, setList] = useState<any>();
  const navigation = useNavigation();

  const [favourite, setFavourite] = useState(false);

  const toggleCalendarModal = () => {
    setCalendarModal(prev => !prev);
  };

  const loadData = async () => {
    setList([]);

    const currentDate = new Date();
    const prevDate = new Date();
    prevDate.setDate(prevDate.getDate() - 90);

    const headers = new Headers();
    headers.append('jTenantToken', '1');
    headers.append('jTenantid', '1404');

    const url =
      date === ''
        ? 'https://pre-prod.odinwave.com/cds/1404/v1/' +
          moment(prevDate).format('D-MMM-yyyy').toString() +
          '/' +
          moment(currentDate).format('D-MMM-yyyy').toString() +
          '/GetMergerDemergerData'
        : 'https://pre-prod1.odinwave.com/cds/1404/V1/1-Jul-2023/24-Jul-2023/GetMergerDemergerData';
    fetch(url, {
      method: 'GET',
      headers,
    })
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setList(data.ResponseObject.resultset);
          // setBulkDeals(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };

  useEffect(() => {
    loadData();
  }, [date]);

  const filter = (d: string) => {
    setDate(d);
  };

  return (
    <View style={maregr.flex}>
      <View style={maregr.background}>
        <View
          style={[
            FavOne.GroupView,
            {justifyContent: 'space-between', width: '100%'},
          ]}>
          <TouchableNativeFeedback
            onPress={() => {
              navigation.goBack();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <BackIcon style={FavOne.BackIcon} />
            </View>
          </TouchableNativeFeedback>

          <View style={{flexDirection: 'row'}}>
            <TouchableNativeFeedback
              onPress={() => {
                setFavourite(prev => !prev);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                {favourite ? (
                  <HeartFilledIcon style={FavOne.HeartFilled} />
                ) : (
                  <HeartIcon style={FavOne.HeartIcon} />
                )}
              </View>
            </TouchableNativeFeedback>
            <View style={{width: 16}} />
            <TouchableNativeFeedback
              onPress={() => {
                setSearchModal(true);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                <SearchIcon style={FavOne.FilterIcon} />
              </View>
            </TouchableNativeFeedback>

            <TouchableNativeFeedback
              onPress={() => {
                setFilterDialogVisibility(true);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={{paddingHorizontal: 8}}>
                <FilterIcon style={FavOne.FilterIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>

        <Text
          style={maregr.group}>
          {fav.GroupName}
        </Text>
        {date && (
          <View
            style={maregr.date}>
            <Text
              style={maregr.transaction}>
              Transactions:
            </Text>
            <View style={{flexDirection: 'row', gap: 4}}>
              {date && (
                <View
                  style={maregr.dateMain}>
                  <Text
                    style={maregr.textDate1}>
                    {date}
                  </Text>
                  <TouchableOpacity
                    style={{padding: 2}}
                    onPress={() => {
                      setDate('');
                    }}>
                    <CloseIcon
                      style={maregr.close}
                    />
                  </TouchableOpacity>
                </View>
              )}
            </View>
          </View>
        )}
      </View>

      <ScrollView
        style={
          {
            // backgroundColor: 'white',
          }
        }>
        <FlatList
          data={list}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <View
                style={maregr.flatMain}>
                <View style={{flexDirection: 'row'}}>
                  <View style={{flex: 1}}>
                    <Text style={{fontSize: 10}}>
                      Issue Date{' '}
                      <Text style={{color: root.color_text}}>
                        {item.item.XDate}
                      </Text>
                    </Text>
                    <Text style={{fontSize: 10}}>
                      Record Date{' '}
                      <Text style={{color: root.color_text}}>
                        {item.item.RecordDate}
                      </Text>
                    </Text>
                  </View>
                  <View style={{flex: 1}} />
                  <View style={{flex: 1}}>
                    <Text
                      style={[
                       maregr.flag,
                        {color:
                          item.item.Flag == 'Demerger' ? '#FFB13B' : '#093DD1'},
                        
                      ]}>
                      {item.item.Flag}
                    </Text>
                  </View>
                </View>
                <View style={maregr.viewCompany}>
                  <View style={{flex: 1}}>
                    <Text
                      style={maregr.textCompany}>
                      From Company
                    </Text>
                    <Text
                      style={maregr.textCompanyName}>
                      {item.item.MergedFrom_CompanyName}
                    </Text>
                  </View>
                  <View
                    style={maregr.margerMain}>
                    <Text
                      style={maregr.textMargerRatio}>
                      {item.item.MergerRatio}
                    </Text>
                  </View>
                  <View style={{flex: 1}}>
                    <Text style={{fontSize: 10}}>To Company</Text>
                    <Text
                      style={maregr.textMargedCompany}>
                      {item.item.MergedInto_CompanyName}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }}
        />
      </ScrollView>
      <MergerAcquisitionFilterDialog
        toggleCalendarModal={toggleCalendarModal}
        visible={filterDialogVisibility}
        onClose={() => {
          setFilterDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setFilterDialogVisibility(false);
        }}
        onFilter={(d: string) => {
          filter(d);
        }}
      />
      <MergerAcquisitionSearchDialog
        visible={searchModal}
        onClose={() => {
          setSearchModal(false);
        }}
        data={list}
      />
      <CalendarModal visible={calendarModal} onClose={toggleCalendarModal} />
    </View>
  );
};
export default FavouriteMergerAndAcquisition;

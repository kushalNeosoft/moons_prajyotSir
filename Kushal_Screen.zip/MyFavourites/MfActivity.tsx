import {useEffect, useState} from 'react';
import React from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import {useNavigation} from '@react-navigation/native';
import HeartIcon from '../../assets/HeartIcon';
import HeartFilledIcon from '../../assets/HeartFilledIcon';
import {Cfont, root} from '../../styles/colors';
import {FavOne, mfActivity} from '../../theme/light';
import SearchIcon from '../../assets/SearchIcon';
import FIIDIIMFActivitySearchDialog from './components/FIIDIIMFActivitySearchDialog';
//import { View } from 'react-native';

const MfActivity = ({route}: any) => {
  const fav = route.params.data;
  const [segment, setSegment] = useState('Equity');
  const [selectedTab, setSelectedTab] = useState(1);
  const [searchModal, setSearchModal] = useState(false);
  const [list1, setList1] = useState([]);
  const [list2, setList2] = useState([]);
  const [list3, setList3] = useState([]);
  const navigation = useNavigation();
  const [favourite, setFavourite] = useState(false);
  const loadData = async () => {
    setList1([]);
    setList2([]);
    setList3([]);

    const headers = new Headers();
    headers.append('jTenantToken', '1');
    headers.append('jTenantid', '1404');

    fetch('https://waveapi.odinwave.com/cds/1404/v1/FII/GetFIIDIIMFData', {
      method: 'GET',
      headers,
    })
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setList1(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));

    fetch('https://waveapi.odinwave.com/cds/1404/v1/DII/GetFIIDIIMFData', {
      method: 'GET',
      headers,
    })
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setList2(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
    fetch('https://waveapi.odinwave.com/cds/1404/v1/MF/GetFIIDIIMFData', {
      method: 'GET',
      headers,
    })
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setList3(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };

  useEffect(() => {
    loadData();
  }, []);

  const filter = () => {
    console.log('Filter');
  };

  return (
    <View style={{flex: 1}}>
      <View style={FavOne.GroupMain}>
        <View
          style={[
            FavOne.GroupView,
            {justifyContent: 'space-between', width: '100%'},
          ]}>
          <TouchableNativeFeedback
            onPress={() => {
              navigation.goBack();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <BackIcon style={FavOne.BackIcon} />
            </View>
          </TouchableNativeFeedback>

          <View style={{flexDirection: 'row'}}>
            <TouchableNativeFeedback
              onPress={() => {
                setFavourite(prev => !prev);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                {favourite ? (
                  <HeartFilledIcon style={FavOne.HeartFilled} />
                ) : (
                  <HeartIcon style={FavOne.HeartIcon} />
                )}
              </View>
            </TouchableNativeFeedback>
            <View style={{width: 16}} />
            <TouchableNativeFeedback
              onPress={() => {
                setSearchModal(true);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                <SearchIcon style={FavOne.FilterIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <Text
          style={mfActivity.group}>
          {fav.GroupName}
        </Text>
        <View style={FavOne.Flex}>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(1);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{}}>
              <Text
                style={[mfActivity.textFii,
                {color: selectedTab == 1 ? root.client_background : 'gray',}]}>
                FII
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 1 ? root.client_background : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(2);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{}}>
            <Text
                style={[mfActivity.textFii,
                {color: selectedTab == 2 ? root.client_background : 'gray',}]}>
                DII
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 2 ? root.client_background : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(3);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{}}>
            <Text
                style={[mfActivity.textFii,
                {color: selectedTab == 3 ? root.client_background : 'gray',}]}>
                Mutual Funds
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 3 ? root.client_background : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>

      {selectedTab === 1 ? (
        <FlatList
          data={list1}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <View style={{backgroundColor: 'white'}}>
                <View
                  style={mfActivity.flatMain}>
                  <Text
                    style={mfActivity.textFiiDate}>
                    {item.item.FIIDate}
                  </Text>
                  <Text
                    style={mfActivity.textEquity}>
                    Equity
                  </Text>
                  <Text
                    style={mfActivity.textDept}>
                    Dept
                  </Text>
                </View>

                <View>
                  <View
                    style={mfActivity.main2}>
                    <Text
                      style={mfActivity.textGross}>
                      Gross Purchase
                    </Text>
                    <Text
                      style={mfActivity.textGrossP}>
                      {item.item.EquityGrossPurchase}
                    </Text>
                    <Text
                      style={mfActivity.textDebtGross}>
                      {item.item.DebtGrossPurchase}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main3}>
                    <Text
                      style={mfActivity.textGrossSale}>
                      Gross Sales
                    </Text>
                    <Text
                      style={mfActivity.textEGross}>
                      {item.item.EquityGrossSales}
                    </Text>
                    <Text
                      style={mfActivity.textDGross}>
                      {item.item.DebtGrossSales}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main4}>
                    <Text
                      style={mfActivity.textNet}>
                      Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textNetEquity}>
                      {item.item.EquityNetInvestment}
                    </Text>
                    <Text
                      style={mfActivity.textDNet}>
                      {item.item.DebtNetInvestment}
                    </Text>
                  </View>
                  <View
                    style={mfActivity.main5}>
                    <Text
                      style={mfActivity.textCommu}>
                      Commulative Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textECommu}>
                      {item.item.EquityCumulativeNetInvestment}
                    </Text>
                    <Text
                      style={mfActivity.textDCumu}>
                      {item.item.DebtCumulativeNetInvestment}
                    </Text>
                  </View>
                </View>
              </View>
            );
          }}
        />
      ) : selectedTab === 2 ? (
        <FlatList
          data={list2}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <View style={{backgroundColor: 'white'}}>
                <View
                  style={mfActivity.main6}>
                  <Text
                    style={mfActivity.textTdate}>
                    {item.item.TransactionDate}
                  </Text>
                  <Text
                    style={mfActivity.textEquity2}>
                    Equity
                  </Text>
                </View>

                <View>
                  <View
                    style={mfActivity.main7}>
                    <Text
                      style={mfActivity.textBuy2}>
                      Buy Value
                    </Text>
                    <Text
                      style={mfActivity.textItemBuy}>
                      {item.item.BuyValue}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main8}>
                    <Text
                      style={mfActivity.textSell}>
                      Sell Value
                    </Text>
                    <Text
                      style={mfActivity.textItemSell}>
                      {item.item.SellValue}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main9}>
                    <Text
                      style={mfActivity.textNet2}>
                      Net Value
                    </Text>
                    <Text
                      style={mfActivity.textItemNet2}>
                      {item.item.NetValue}
                    </Text>
                  </View>
                </View>
              </View>
            );
            // return <Item item={item.item} />;
          }}
        />
      ) : (
        <FlatList
          data={list3}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <View style={{backgroundColor: 'white'}}>
                <View
                  style={mfActivity.flatMain}>
                  <Text
                    style={mfActivity.textFiiDate}>
                    {item.item.TransactionDate}
                  </Text>
                  <Text
                     style={mfActivity.textEquity}>
                    Equity
                  </Text>
                  <Text
                    style={mfActivity.textDept}>
                    Dept
                  </Text>
                </View>

                <View
                  style={mfActivity.style3}>
                  <View
                    style={mfActivity.main2}>
                    <Text
                      style={mfActivity.textGross}>
                      Gross Purchase
                    </Text>
                    <Text
                      style={mfActivity.textGrossP}>
                      {item.item.EquityGrossPurchase}
                    </Text>
                    <Text
                      style={mfActivity.textDebtGross}>
                      {item.item.DebtGrossPurchase}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main3}>
                    <Text
                      style={mfActivity.textGrossSale}>
                      Gross Sales
                    </Text>
                    <Text
                      style={mfActivity.textEGross}>
                      {item.item.EquityGrossSale}
                    </Text>
                    <Text
                      style={mfActivity.textDGross}>
                      {item.item.DebtGrossSales}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main4}>
                    <Text
                      style={mfActivity.textNet}>
                      Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textNetEquity}>
                      {item.item.EquityNetPurchaseSales}
                    </Text>
                    <Text
                      style={mfActivity.textDNet}>
                      {item.item.DebtNetPurchaseSales}
                    </Text>
                  </View>
                  <View
                    style={mfActivity.main5}>
                    <Text
                      style={mfActivity.textCommu}>
                      Commulative Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textECommu}>
                      {item.item.EquityNetPurchaseSales}
                    </Text>
                    <Text
                      style={mfActivity.textDCumu}>
                      {item.item.DebtNetPurchaseSales}
                    </Text>
                  </View>
                </View>
              </View>
            );
            // return <Item item={item.item} />;
          }}
        />
      )}
      <FIIDIIMFActivitySearchDialog
        visible={searchModal}
        onClose={() => {
          setSearchModal(false);
        }}
        list1={list1}
        list2={list2}
        list3={list3}
        selectedTab={selectedTab}
      />
    </View>
  );
};
export default MfActivity;

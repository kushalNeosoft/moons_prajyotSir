import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import {useNavigation} from '@react-navigation/native';
import {filterbulk} from '../../../theme/light';

const dates = [
  'Current Month',
  'Last Month',
  'Last 3 Months',
  'Last 6 Months',
  'FY 20-21',
  'Custom Date',
];
const indices = ['NSE', 'BSE'];
const BulkBlockFilterDialog = ({
  visible,
  onClose,
  onFilter,
  toggleCalendarModal,
}: any) => {
  const navigation = useNavigation();

  const [selectedDate, setSelectedDate] = useState('');
  const [selectedIndex, setSelectedIndex] = useState('');

  const onClick = (date: any) => {
    if (date !== 'Custom Date') {
      if (selectedDate === date) {
        setSelectedDate('');
      } else {
        setSelectedDate(date);
      }
      if (selectedIndex !== '') setSelectedIndex('');
    } else {
      toggleCalendarModal();
    }
  };

  return (
    <Modal
      // animationType="slide"
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={filterbulk.touchable}
        onPress={() => onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={filterbulk.main}>
        <View style={filterbulk.view}>
          <View style={filterbulk.header}>
            <Text style={filterbulk.choose}>Filter</Text>
            <TouchableNativeFeedback
              onPress={() => {
                onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={filterbulk.closeMain}>
                <CloseIcon style={filterbulk.closeIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <View style={filterbulk.main2}>
            <Text
              style={filterbulk.textDate}>
              Date
            </Text>
            <View
              style={filterbulk.Date2}>
              {dates.map((date, index) => {
                return (
                  <TouchableOpacity onPress={() => onClick(date)}>
                    <View
                      key={index}
                      style={[
                        filterbulk.main3,
                        {borderColor:
                          selectedDate === date
                            ? root.client_background
                            : '#f3f4f6',}
                      ]}>
                      <Text
                        style={filterbulk.Date3}>
                        {date}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
            <Text
              style={filterbulk.textIndices}>
              Indices
            </Text>
            <View
              style={filterbulk.mainIndices}>
              {indices.map((index, i) => {
                return (
                  <TouchableOpacity
                    onPress={() => {
                      if (selectedIndex === index) {
                        setSelectedIndex('');
                      } else {
                        setSelectedIndex(index);
                      }
                      if (selectedDate !== '') setSelectedDate('');
                    }}>
                    <View
                      key={i}
                      style={[
                        filterbulk.mainIndex,
                        {borderColor:
                          selectedIndex === index ? root.color_text : '#f3f4f6',}
                      ]}>
                      <Text
                        style={filterbulk.index}>
                        {index}
                      </Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
          <TouchableOpacity
            onPress={() => {
              onFilter(selectedDate, selectedIndex);
              onClose();
            }}
            style={filterbulk.ApplyBtn}>
            <Text
              style={filterbulk.textApply}>
              Apply
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
export default BulkBlockFilterDialog;

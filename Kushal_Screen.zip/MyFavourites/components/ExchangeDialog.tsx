import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import {useNavigation} from '@react-navigation/native';
import {ExDialog} from '../../../theme/light';

const list = [
  'NSE',
  'BSE',
  'NSE Index',
  'BSE Index',
  'NSE Sector',
  'BSE Sector',
];
const ExchangeDialog = ({visible, onClose, exchange, setExchange}: any) => {
  const navigation = useNavigation();

  return (
    <Modal
      // animationType="slide"
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => navigation.goBack()}
        activeOpacity={1}></TouchableOpacity>
      <View style={ExDialog.main}>
        <View style={ExDialog.view}>
          <View style={ExDialog.header}>
            <Text style={ExDialog.choose}>Choose</Text>
            <Text style={ExDialog.exc}>Exchange</Text>
            <TouchableNativeFeedback
              onPress={() => {
                onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={ExDialog.closeMain}>
                <CloseIcon style={ExDialog.closeIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>

          <FlatList
            style={{marginTop: 12}}
            data={list}
            showsHorizontalScrollIndicator={false}
            renderItem={(i: any) => {
              return (
                <TouchableNativeFeedback
                  key={i.item}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setExchange(i.item);
                    onClose();
                  }}>
                  <View style={ExDialog.mainTxt}>
                    <View style={ExDialog.mainTxt2}>
                      {exchange === i.item && <View style={ExDialog.border} />}
                    </View>
                    <Text style={ExDialog.txt}>{i.item}</Text>
                  </View>
                </TouchableNativeFeedback>
              );
            }}
          />
        </View>
      </View>
    </Modal>
  );
};
export default ExchangeDialog;

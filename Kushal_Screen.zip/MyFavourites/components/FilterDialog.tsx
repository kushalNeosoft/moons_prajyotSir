import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import SegmentDialog from './SegmentDialog';
import SectorDialog from './SectorDialog';
import ExchangeDialog from './ExchangeDialog';
import {filterDialog} from '../../../theme/light';
import InstrumentDialog from './InstrumentDialog';
import ExpiryDialog from './ExpiryDialog';

const FilterDialog = ({visible, onClose, onFilter}: any) => {
  const [exchangeDialogVisibility, setExchageDialogVisibility] =
    useState(false);

  const [exchange, setExchange] = useState('NSE Indices');
  const [segment, setSegment] = useState('Equity');
  const [sector, setSector] = useState('NIFTY 100');
  const [expiry, setExpiry] = useState('Next Month');
  const [instrument, setInstrument] = useState('All');

  const [SegmentDialogVisibility, setSegmentDialogVisibility] = useState(false);
  const [SectorDialogVisibility, setSectorDialogVisibility] = useState(false);
  const [expiryDialogVisibility, setExpiryDialogVisibility] = useState(false);
  const [instrumentDialogVisibility, setInstrumentDialogVisibility] =
    useState(false);

  return (
    <Modal
      // animationType="slide"
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={filterDialog.main}
        onPress={() => onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={filterDialog.main2}>
        <View style={filterDialog.dialogMain}>
          <View style={filterDialog.dialogMain2}>
            <Text style={filterDialog.headerText}>Sort & Filter</Text>
            <TouchableNativeFeedback
              onPress={() => {
                onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={filterDialog.closeView}>
                <CloseIcon style={filterDialog.closeIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <TouchableOpacity
            onPress={() => {
              setSegmentDialogVisibility(true);
            }}>
            <View style={filterDialog.Containt}>
              <Text style={filterDialog.Text}>Segment</Text>
              <View style={filterDialog.DropdownText}>
                <Text>{segment}</Text>
                <ExpandIcon style={filterDialog.ExpandIcon} />
              </View>
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setExchageDialogVisibility(true);
            }}>
            <View style={filterDialog.Containt2}>
              <Text style={filterDialog.Text}>Exchange</Text>
              <View style={filterDialog.DropdownText}>
                <Text>{exchange}</Text>
                <ExpandIcon style={filterDialog.ExpandIcon} />
              </View>
            </View>
          </TouchableOpacity>

          {segment !== 'Equity' && (
            <TouchableOpacity
              onPress={() => {
                setSectorDialogVisibility(true);
              }}>
              <View style={filterDialog.Containt}>
                <View style={{flex: 1}}>
                  <Text style={filterDialog.Text}>Index</Text>
                  <Text style={{fontSize: 10}}>Optional*</Text>
                </View>

                <View style={filterDialog.DropdownText}>
                  <Text>{sector}</Text>
                  <ExpandIcon style={filterDialog.ExpandIcon} />
                </View>
              </View>
            </TouchableOpacity>
          )}
          {segment === 'Equity' && (
            <TouchableOpacity
              onPress={() => {
                setExpiryDialogVisibility(true);
              }}>
              <View style={filterDialog.Containt}>
                <View style={{flex: 1}}>
                  <Text style={filterDialog.Text}>Expiry</Text>
                </View>

                <View style={filterDialog.DropdownText}>
                  <Text>{expiry}</Text>
                  <ExpandIcon style={filterDialog.ExpandIcon} />
                </View>
              </View>
            </TouchableOpacity>
          )}
          {segment !== 'Equity' && (
            <TouchableOpacity
              onPress={() => {
                setInstrumentDialogVisibility(true);
              }}>
              <View style={filterDialog.Containt}>
                <View style={{flex: 1}}>
                  <Text style={filterDialog.Text}>Instrument</Text>
                </View>

                <View style={filterDialog.DropdownText}>
                  <Text>{instrument}</Text>
                  <ExpandIcon style={filterDialog.ExpandIcon} />
                </View>
              </View>
            </TouchableOpacity>
          )}

          <TouchableNativeFeedback
            // disabled={!filled}
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              // setConfirmOrderVisible(true);
              onFilter(exchange, segment, sector, instrument, expiry);
            }}>
            <View style={filterDialog.ButtonMain}>
              <Text style={filterDialog.ButtonText}>Apply</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <ExchangeDialog
        visible={exchangeDialogVisibility}
        onClose={() => {
          setExchageDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setExchageDialogVisibility(false);
        }}
        exchange={exchange}
        setExchange={setExchange}
      />
      <SegmentDialog
        visible={SegmentDialogVisibility}
        onClose={() => {
          setSegmentDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSegmentDialogVisibility(false);
        }}
        segment={segment}
        setSegment={setSegment}
      />
      <SectorDialog
        visible={SectorDialogVisibility}
        onClose={() => {
          setSectorDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSectorDialogVisibility(false);
        }}
        sector={sector}
        setSector={setSector}
      />
      <InstrumentDialog
        visible={instrumentDialogVisibility}
        onClose={() => {
          setInstrumentDialogVisibility(false);
        }}
        instrument={instrument}
        setInstrument={setInstrument}
      />
      <ExpiryDialog
        visible={expiryDialogVisibility}
        onClose={() => {
          setExpiryDialogVisibility(false);
        }}
        expiry={expiry}
        setExpiry={setExpiry}
      />
    </Modal>
  );
};
export default FilterDialog;

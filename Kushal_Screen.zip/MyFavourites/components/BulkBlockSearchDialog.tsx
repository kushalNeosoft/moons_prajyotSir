import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {Bulkblock, messageSearchModal} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';

const BulkBlockSearchDialog = ({
  visible,
  onClose,
  blockDeals,
  bulkDeals,
  selectedTab,
}: any) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const Item = ({item}: any) => {
    return (
      <View
      style={Bulkblock.mainView}>
      <Text
        style={Bulkblock.textScrip}>
        {item.ScripName}
      </Text>
      <Text
        style={[
          Bulkblock.textB,
          {color:
            item.BuySell == 'B' ? root.color_positive : root.color_negative}
          
        ]}>
        <Text>{item.BuySell === 'B' ? 'Bought ' : 'Sold '}</Text>
        <Text>
          {item.QuantityShares}@{item.AveragePrice}
        </Text>
      </Text>
      <Text style={Bulkblock.textAvg}>
        <Text
          style={Bulkblock.transacted}>
          Transacted By:
        </Text>
        <Text
          style={Bulkblock.textClint}>
          {' '}
          {item.ClientName}
        </Text>
      </Text>
      <Text
        style={Bulkblock.textDate}>
        {item.Date}
      </Text>
    </View>
    );
  };

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = selectedTab === 1 ? bulkDeals : blockDeals;
      const filterTempList = mainList.filter((item: any) =>
        item.ScripName.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const renderItem = ({item}: any) => {
    return <View />;
  };

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={{flex: 1}}>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
              setTextInputValue('');
              setFilterData([]);
            }}>
            <BackIcon style={Bulkblock.BackIcon} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search Scrip"
            placeholderTextColor={'grey'}
            value={textInputValue}
            autoCapitalize = 'characters'
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
             
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: 'lightgrey', flex: 1}}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={messageSearchModal.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={(item: any) => {
                return <Item item={item.item} />;
              }}
            />
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default BulkBlockSearchDialog;

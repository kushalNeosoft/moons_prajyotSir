import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {Bulkblock, maregr, messageSearchModal} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';

const MergerAcquisitionSearchDialog = ({visible, onClose, data}: any) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter((item: any) =>
        item.MergedFrom_CompanyName.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const renderItem = ({item}: any) => {
    return <View />;
  };

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={{flex: 1}}>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
              setTextInputValue('');
              setFilterData([]);
            }}>
            <BackIcon style={Bulkblock.BackIcon} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search Broker Messages"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: 'lightgrey', flex: 1}}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={messageSearchModal.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={(item: any) => {
                return (
                  <View
                  style={maregr.flatMain}>
                  <View style={{flexDirection: 'row'}}>
                    <View style={{flex: 1}}>
                      <Text style={{fontSize: 10}}>
                        Issue Date{' '}
                        <Text style={{color: root.color_text}}>
                          {item.item.XDate}
                        </Text>
                      </Text>
                      <Text style={{fontSize: 10}}>
                        Record Date{' '}
                        <Text style={{color: root.color_text}}>
                          {item.item.RecordDate}
                        </Text>
                      </Text>
                    </View>
                    <View style={{flex: 1}} />
                    <View style={{flex: 1}}>
                      <Text
                        style={[
                         maregr.flag,
                          {color:
                            item.item.Flag == 'Demerger' ? '#FFB13B' : '#093DD1'},
                          
                        ]}>
                        {item.item.Flag}
                      </Text>
                    </View>
                  </View>
                  <View style={maregr.viewCompany}>
                    <View style={{flex: 1}}>
                      <Text
                        style={maregr.textCompany}>
                        From Company
                      </Text>
                      <Text
                        style={maregr.textCompanyName}>
                        {item.item.MergedFrom_CompanyName}
                      </Text>
                    </View>
                    <View
                      style={maregr.margerMain}>
                      <Text
                        style={maregr.textMargerRatio}>
                        {item.item.MergerRatio}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{fontSize: 10}}>To Company</Text>
                      <Text
                        style={maregr.textMargedCompany}>
                        {item.item.MergedInto_CompanyName}
                      </Text>
                    </View>
                  </View>
                </View>
                );
              }}
            />
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default MergerAcquisitionSearchDialog;

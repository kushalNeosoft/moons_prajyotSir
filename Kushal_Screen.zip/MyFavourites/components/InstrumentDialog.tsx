import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import {useNavigation} from '@react-navigation/native';
import {SegDialog, ExDialog} from '../../../theme/light';

const list = ['All', 'Futures', 'Options', 'Call', 'Put'];
const InstrumentDialog = ({
  visible,
  onClose,
  instrument,
  setInstrument,
}: any) => {
  const navigation = useNavigation();

  return (
    <Modal
      // animationType="slide"
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <TouchableOpacity
        style={SegDialog.close}
        onPress={() => navigation.goBack()}
        activeOpacity={1}></TouchableOpacity>
      <View style={SegDialog.main}>
        <View style={SegDialog.main1}>
          <View style={SegDialog.textView}>
            <Text style={SegDialog.choose}>Choose</Text>
            <Text style={SegDialog.seg}>Instrument</Text>
            <TouchableNativeFeedback
              onPress={() => {
                onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={SegDialog.closeView}>
                <CloseIcon style={SegDialog.closeIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <FlatList
            style={{marginTop: 12}}
            data={list}
            showsHorizontalScrollIndicator={false}
            renderItem={(i: any) => {
              return (
                <TouchableNativeFeedback
                  key={i.item}
                  // disabled={!filled}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setInstrument(i.item);
                    onClose();
                    // setConfirmOrderVisible(true);
                  }}>
                  <View style={ExDialog.mainTxt}>
                    <View style={ExDialog.mainTxt2}>
                      {instrument === i.item && (
                        <View style={ExDialog.border} />
                      )}
                    </View>
                    <Text style={ExDialog.txt}>{i.item}</Text>
                  </View>
                </TouchableNativeFeedback>
              );
            }}
          />
        </View>
      </View>
    </Modal>
  );
};
export default InstrumentDialog;

import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {messageSearchModal, mfActivity} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';

const FIIDIIMFActivitySearchDialog = ({
  visible,
  onClose,
  list1,
  list2,
  list3,
  selectedTab,
}: any) => {
  console.log(selectedTab);

  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = selectedTab === 1 ? list1 : selectedTab === 2 ? list2 : list3;
      const filterTempList = mainList.filter((item: any) => {
        if (selectedTab === 1) {
          return item.FIIDate.includes(value.toLowerCase());
        } else if (selectedTab === 2) {
          return item.TransactionDate.includes(value.toLowerCase());
        } else {
          return item.TransactionDate.includes(value.toLowerCase());
        }
      });
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={messageSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={{flex: 1}}>
        <View style={messageSearchModal.headerView}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
              setTextInputValue('');
              setFilterData([]);
            }}>
            <BackIcon style={{width: 24, height: 24, color: 'black'}} />
          </TouchableOpacity>
          <TextInput
            style={messageSearchModal.textInput}
            placeholder="Search Broker Messages"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={messageSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View style={{backgroundColor: 'lightgrey', flex: 1}}>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={messageSearchModal.noDataText}>No data Found</Text>
          ) : (
            <FlatList
              data={filterData}
              keyExtractor={(_, index) => `item-${index}`}
              renderItem={(item: any) => {
                if (selectedTab === 1) {
                  return (
                    <View style={{backgroundColor: 'white'}}>
                    <View
                      style={mfActivity.flatMain}>
                      <Text
                        style={mfActivity.textFiiDate}>
                        {item.item.FIIDate}
                      </Text>
                      <Text
                        style={mfActivity.textEquity}>
                        Equity
                      </Text>
                      <Text
                        style={mfActivity.textDept}>
                        Dept
                      </Text>
                    </View>
    
                    <View>
                      <View
                        style={mfActivity.main2}>
                        <Text
                          style={mfActivity.textGross}>
                          Gross Purchase
                        </Text>
                        <Text
                          style={mfActivity.textGrossP}>
                          {item.item.EquityGrossPurchase}
                        </Text>
                        <Text
                          style={mfActivity.textDebtGross}>
                          {item.item.DebtGrossPurchase}
                        </Text>
                      </View>
    
                      <View
                        style={mfActivity.main3}>
                        <Text
                          style={mfActivity.textGrossSale}>
                          Gross Sales
                        </Text>
                        <Text
                          style={mfActivity.textEGross}>
                          {item.item.EquityGrossSales}
                        </Text>
                        <Text
                          style={mfActivity.textDGross}>
                          {item.item.DebtGrossSales}
                        </Text>
                      </View>
    
                      <View
                        style={mfActivity.main4}>
                        <Text
                          style={mfActivity.textNet}>
                          Net Investment
                        </Text>
                        <Text
                          style={mfActivity.textNetEquity}>
                          {item.item.EquityNetInvestment}
                        </Text>
                        <Text
                          style={mfActivity.textDNet}>
                          {item.item.DebtNetInvestment}
                        </Text>
                      </View>
                      <View
                        style={mfActivity.main5}>
                        <Text
                          style={mfActivity.textCommu}>
                          Commulative Net Investment
                        </Text>
                        <Text
                          style={mfActivity.textECommu}>
                          {item.item.EquityCumulativeNetInvestment}
                        </Text>
                        <Text
                          style={mfActivity.textDCumu}>
                          {item.item.DebtCumulativeNetInvestment}
                        </Text>
                      </View>
                    </View>
                  </View>
                  );
                } else if (selectedTab === 2) {
                  return (
                    <View style={{backgroundColor: 'white'}}>
                    <View
                      style={mfActivity.main6}>
                      <Text
                        style={mfActivity.textTdate}>
                        {item.item.TransactionDate}
                      </Text>
                      <Text
                        style={mfActivity.textEquity2}>
                        Equity
                      </Text>
                    </View>
    
                    <View>
                      <View
                        style={mfActivity.main7}>
                        <Text
                          style={mfActivity.textBuy2}>
                          Buy Value
                        </Text>
                        <Text
                          style={mfActivity.textItemBuy}>
                          {item.item.BuyValue}
                        </Text>
                      </View>
    
                      <View
                        style={mfActivity.main8}>
                        <Text
                          style={mfActivity.textSell}>
                          Sell Value
                        </Text>
                        <Text
                          style={mfActivity.textItemSell}>
                          {item.item.SellValue}
                        </Text>
                      </View>
    
                      <View
                        style={mfActivity.main9}>
                        <Text
                          style={mfActivity.textNet2}>
                          Net Value
                        </Text>
                        <Text
                          style={mfActivity.textItemNet2}>
                          {item.item.NetValue}
                        </Text>
                      </View>
                    </View>
                  </View>
                  );
                } else {
                  return (
                    <View style={{backgroundColor: 'white'}}>
                <View
                  style={mfActivity.flatMain}>
                  <Text
                    style={mfActivity.textFiiDate}>
                    {item.item.TransactionDate}
                  </Text>
                  <Text
                     style={mfActivity.textEquity}>
                    Equity
                  </Text>
                  <Text
                    style={mfActivity.textDept}>
                    Dept
                  </Text>
                </View>

                <View
                  style={mfActivity.style3}>
                  <View
                    style={mfActivity.main2}>
                    <Text
                      style={mfActivity.textGross}>
                      Gross Purchase
                    </Text>
                    <Text
                      style={mfActivity.textGrossP}>
                      {item.item.EquityGrossPurchase}
                    </Text>
                    <Text
                      style={mfActivity.textDebtGross}>
                      {item.item.DebtGrossPurchase}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main3}>
                    <Text
                      style={mfActivity.textGrossSale}>
                      Gross Sales
                    </Text>
                    <Text
                      style={mfActivity.textEGross}>
                      {item.item.EquityGrossSale}
                    </Text>
                    <Text
                      style={mfActivity.textDGross}>
                      {item.item.DebtGrossSales}
                    </Text>
                  </View>

                  <View
                    style={mfActivity.main4}>
                    <Text
                      style={mfActivity.textNet}>
                      Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textNetEquity}>
                      {item.item.EquityNetPurchaseSales}
                    </Text>
                    <Text
                      style={mfActivity.textDNet}>
                      {item.item.DebtNetPurchaseSales}
                    </Text>
                  </View>
                  <View
                    style={mfActivity.main5}>
                    <Text
                      style={mfActivity.textCommu}>
                      Commulative Net Investment
                    </Text>
                    <Text
                      style={mfActivity.textECommu}>
                      {item.item.EquityNetPurchaseSales}
                    </Text>
                    <Text
                      style={mfActivity.textDCumu}>
                      {item.item.DebtNetPurchaseSales}
                    </Text>
                  </View>
                </View>
              </View>
                  );
                }
              }}
            />
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default FIIDIIMFActivitySearchDialog;

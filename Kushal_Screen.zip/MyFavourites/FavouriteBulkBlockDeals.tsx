import {useEffect, useRef, useState} from 'react';
import React from 'react';
import {
  Animated,
  Easing,
  FlatList,
  Image,
  ScrollView,
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import {useNavigation} from '@react-navigation/native';
import HeartIcon from '../../assets/HeartIcon';
import HeartFilledIcon from '../../assets/HeartFilledIcon';
import {Cfont, root} from '../../styles/colors';
import { Bulkblock, FavOne } from '../../theme/light';
import SearchIcon from '../../assets/SearchIcon';
import moment from 'moment';
import BulkBlockFilterDialog from './components/BulkBlockFilterDialog';
import FilterIcon from '../../assets/FilterIcon';
import CloseIcon from '../../assets/CloseIcon';
import {TouchableOpacity} from 'react-native-gesture-handler';
import CalendarModal from '../Funds/RecentTransactions/components/CalendarModal/CalendarModal';
import BulkBlockSearchDialog from './components/BulkBlockSearchDialog';
import { DateModal } from '../WatchList/Events/EventsComponent/EventsModal';

const FavouriteBulkBlockDeals = ({route}: any) => {
  const fav = route.params.data;
  const [filterDialogVisibility, setFilterDialogVisibility] = useState(false);
  const [calendarModal, setCalendarModal] = useState(false);
  const [searchModal, setSearchModal] = useState(false);

  const [date, setDate] = useState('');
  const [indices, setIndices] = useState('');

  const [selectedTab, setSelectedTab] = useState(1);

  const [bulkDeals, setBulkDeals] = useState([]);
  const [blockDeals, setBlockDeals] = useState([]);
  const navigation = useNavigation();

  const [favourite, setFavourite] = useState(false);

  const toggleCalendarModal = () => {
    setCalendarModal(prev => !prev);
  };

  const loadData = async () => {
    setBulkDeals([]);
    setBlockDeals([]);

    const currentDate = new Date();
    const prevDate = new Date();
    prevDate.setDate(prevDate.getDate() - 15);

    const headers = new Headers();
    headers.append('jTenantToken', '1');
    headers.append('jTenantid', '1404');
    fetch(
      'https://pre-prod.odinwave.com/cds/1404/v1/nse/bulk/' +
        moment(prevDate).format('D-MMM-yyyy').toString() +
        '/' +
        moment(currentDate).format('D-MMM-yyyy').toString() +
        '/1/10/GetBulkBlockDealData',
      {
        method: 'GET',
        headers,
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setBulkDeals(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
    fetch(
      'https://pre-prod.odinwave.com/cds/1404/v1/nse/block/' +
        moment(prevDate).format('D-MMM-yyyy').toString() +
        '/' +
        moment(currentDate).format('D-MMM-yyyy') +
        '/1/10/GetBulkBlockDealData',
      {
        method: 'GET',
        headers,
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.ResponseObject.type === 'success') {
          setBlockDeals(data.ResponseObject.resultset);
        }
      })
      .catch(error => console.log('error', error));
  };

  useEffect(() => {
    loadData();
  }, [date, indices]);

  const filter = (d: string, i: string) => {
    setDate(d);
    setIndices(i);
  };

  const Item = ({item}: any) => {
    return (
      <View
        style={Bulkblock.mainView}>
        <Text
          style={Bulkblock.textScrip}>
          {item.ScripName}
        </Text>
        <Text
          style={[
            Bulkblock.textB,
            {color:
              item.BuySell == 'B' ? root.color_positive : root.color_negative}
            
          ]}>
          <Text>{item.BuySell === 'B' ? 'Bought ' : 'Sold '}</Text>
          <Text>
            {item.QuantityShares}@{item.AveragePrice}
          </Text>
        </Text>
        <Text style={Bulkblock.textAvg}>
          <Text
            style={Bulkblock.transacted}>
            Transacted By:
          </Text>
          <Text
            style={Bulkblock.textClint}>
            {' '}
            {item.ClientName}
          </Text>
        </Text>
        <Text
          style={Bulkblock.textDate}>
          {item.Date}
        </Text>
      </View>
    );
  };

  const H_MAX_HEIGHT = 150 + (indices !== '' || date !== '' ? 30 : 0);
  const H_MIN_HEIGHT = 90 + (indices !== '' || date !== '' ? 30 : 0);
  const H_SCROLL_DISTANCE = H_MAX_HEIGHT - H_MIN_HEIGHT;

  const scrollOffsetY = useRef(new Animated.Value(0)).current;

  const headerScrollHeight = scrollOffsetY.interpolate({
    inputRange: [0, H_SCROLL_DISTANCE],
    outputRange: [H_MAX_HEIGHT, H_MIN_HEIGHT],
    extrapolate: 'clamp',
  });

  const scrollPaddingTop = scrollOffsetY.interpolate({
    inputRange: [0, H_SCROLL_DISTANCE],
    outputRange: [H_MAX_HEIGHT, 0],
    extrapolate: 'clamp',
  });
  const headerPositionTop = scrollOffsetY.interpolate({
    inputRange: [0, H_SCROLL_DISTANCE],
    outputRange: [58, 10],
    extrapolate: 'clamp',
  });
  const headerPositionLeft = scrollOffsetY.interpolate({
    inputRange: [0, H_SCROLL_DISTANCE],
    outputRange: [16, 48],
    extrapolate: 'clamp',
  });
  const headerFontSize = scrollOffsetY.interpolate({
    inputRange: [0, H_SCROLL_DISTANCE],
    outputRange: [30, 20],
    extrapolate: 'clamp',
  });

  return (
    <View style={{flex: 1}}>
      <Animated.View
        style={[
            Bulkblock.AnimatedMain,
          {height: headerScrollHeight,}
        ]}>
        <View
          style={Bulkblock.viewTop}>
          <TouchableNativeFeedback
            onPress={() => {
              navigation.goBack();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <BackIcon style={FavOne.BackIcon} />
            </View>
          </TouchableNativeFeedback>
          <View style={{flexDirection: 'row'}}>
            <TouchableNativeFeedback
              onPress={() => {
                setFavourite(prev => !prev);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                {favourite ? (
                  <HeartFilledIcon style={FavOne.HeartFilled} />
                ) : (
                  <HeartIcon style={FavOne.HeartIcon} />
                )}
              </View>
            </TouchableNativeFeedback>
            <View style={{width: 16}} />
            <TouchableNativeFeedback
              onPress={() => {
                setSearchModal(true);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View>
                <SearchIcon style={FavOne.FilterIcon} />
              </View>
            </TouchableNativeFeedback>

            <TouchableNativeFeedback
              onPress={() => {
                setFilterDialogVisibility(true);
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={{paddingHorizontal: 8}}>
                <FilterIcon style={FavOne.FilterIcon} />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <Animated.View
          style={{
            position: 'absolute',
            top: headerPositionTop,
            left: headerPositionLeft,
          }}>
          <Animated.Text
            style={[Bulkblock.Bulk,
              {fontSize: headerFontSize,}
            ]}>
            Bulk/Block Deals
          </Animated.Text>
        </Animated.View>
        <View style={{position: 'absolute', left: 0, right: 0, bottom: 0}}>
          {(indices !== '' || date !== '') && (
            <View
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                flexDirection: 'row',
                gap: 8,
                alignItems: 'center',
              }}>
              <Text
                style={Bulkblock.textFilter}>
                Filters:
              </Text>
              <View style={{flexDirection: 'row', gap: 4}}>
                {date && (
                  <View
                    style={Bulkblock.dateMain}>
                    <Text
                      style={Bulkblock.textDate1}>
                      {date}
                    </Text>
                    <TouchableOpacity
                      style={{padding: 2}}
                      onPress={() => {
                        setDate('');
                      }}>
                      <CloseIcon
                        style={Bulkblock.close}
                      />
                    </TouchableOpacity>
                  </View>
                )}
                {indices && (
                  <View
                    style={Bulkblock.indicesMain}>
                    <Text
                      style={Bulkblock.textindices}>
                      {indices}
                    </Text>
                    <TouchableOpacity
                      style={{padding: 2}}
                      onPress={() => {
                        setIndices('');
                      }}>
                      <CloseIcon
                        style={Bulkblock.close}
                      />
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </View>
          )}
          <View
            style={{
              flexDirection: 'row',
            }}>
            <TouchableNativeFeedback
              onPress={() => {
                setSelectedTab(1);
              }}
              background={TouchableNativeFeedback.Ripple('gray', false)}>
              <View style={{flex: 1}}>
                <Text
                  style={[
                    Bulkblock.tab1,
                    {color: selectedTab == 1 ? root.client_background : 'gray',}
                    
                  ]}>
                  Bulk Deals
                </Text>
                <View
                  style={{
                    height: 2,
                    backgroundColor:
                      selectedTab == 1 ? root.client_background : 'transparent',
                  }}
                />
              </View>
            </TouchableNativeFeedback>
            <TouchableNativeFeedback
              onPress={() => {
                setSelectedTab(2);
              }}
              background={TouchableNativeFeedback.Ripple('gray', false)}>
              <View style={{flex: 1}}>
              <Text
                  style={[
                    Bulkblock.tab1,
                    {color: selectedTab == 2 ? root.client_background : 'gray',}
                    
                  ]}>
                  Block Deals
                </Text>
                <View
                  style={{
                    height: 2,
                    backgroundColor:
                      selectedTab == 2 ? root.client_background : 'transparent',
                  }}
                />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
      </Animated.View>
    

      <Animated.ScrollView
        style={{
          backgroundColor: 'white',
          // paddingTop: 14,
          paddingTop: scrollPaddingTop,
          // height: '100%',
          // flex: 1,
        }}
        onScroll={Animated.event([
          {nativeEvent: {contentOffset: {y: scrollOffsetY}}},
        ])}
        scrollEventThrottle={16}>
        {selectedTab === 1 ? (
          <View style={{flex: 1}}>
            <View
              style={Bulkblock.olderMain}>
              <Text
                style={Bulkblock.textOlder}>
                Older
              </Text>
              <Text
                style={Bulkblock.textRecord}>
                {bulkDeals.length} Records
              </Text>
            </View>
            <FlatList
              data={bulkDeals}
              showsHorizontalScrollIndicator={false}
              renderItem={(item: any) => {
                return <Item item={item.item} />;
              }}
            />
          </View>
        ) : (
          <>
            <View
              style={Bulkblock.olderMain}>
              <Text
                style={Bulkblock.textOlder}>
                Older
              </Text>
              <Text
                style={Bulkblock.textRecord}>
                {bulkDeals.length} Records
              </Text>
            </View>
            <FlatList
              data={blockDeals}
              showsHorizontalScrollIndicator={false}
              renderItem={(item: any) => {
                return <Item item={item.item} />;
              }}
            />
          </>
        )}
      </Animated.ScrollView>

      <BulkBlockFilterDialog
        toggleCalendarModal={toggleCalendarModal}
        visible={filterDialogVisibility}
        onClose={() => {
          setFilterDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setFilterDialogVisibility(false);
        }}
        onFilter={(d: string, i: string) => {
          filter(d, i);
        }}
      />
      <CalendarModal visible={calendarModal} onClose={toggleCalendarModal} />
      <BulkBlockSearchDialog
        visible={searchModal}
        onClose={() => {
          setSearchModal(false);
        }}
        bulkDeals={bulkDeals}
        blockDeals={blockDeals}
        selectedTab={selectedTab}
      />
    </View>
  );
};
export default FavouriteBulkBlockDeals;

import React, {useCallback, useRef, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import Date from './components/Date/Date';
import {dateData, optionData} from './constData';
import CallModal from './components/CallModal/CallModal';
import PutModal from './components/PutModal/PutModal';
import CallPutList from './components/CallPullList/CallPullList';
import Hexagon from './components/hexagon/Hexagon';
import {optionChainScreen} from '../../../theme/light';
import AddToWatchListModal from '../../../components/AddToWatchlistModal/AddToWatchlistModal';
import OptionChainSkeleton from './components/Skeleton/Skeleton';

function OptionChain() {
  const [date, setDate] = useState('04');
  const [callModalVisible, setCallModalVisible] = useState(false);
  const [putModalVisible, setPutModalVisible] = useState(false);
  const [addToWatchlistModalVisible, setAddToWatchlistModalVisible] =
    useState(false);
  const [isVisible, setVisible] = useState(false);
  const flatListRef = useRef<any>(null);
  const [scrollIndex, setScrollIndex] = useState(3);
  const [position, setPosition] = useState('');

  const onPress = (value: string) => {
    setDate(value);
  };

  const handleScrollToIndex = () => {
    flatListRef.current.scrollToIndex({index: scrollIndex, animated: true});
  };

  const callModal = () => {
    setCallModalVisible(prevState => !prevState);
  };

  const putModalView = () => {
    setPutModalVisible(prevState => !prevState);
  };

  const addToWatchlistModalView = () => {
    setAddToWatchlistModalVisible(prevState => !prevState);
  };

  const showAddToWatchlistModal = () => {
    setAddToWatchlistModalVisible(prevState => !prevState);
  };

  const onViewableItemsChanged = useCallback(
    ({viewableItems, changed}: any) => {
      console.log(viewableItems)
      const getKey = viewableItems.some((item: any) => item.item.flag === true);
      if (
        viewableItems.some((item: any) => item.index >= 6) &&
        getKey === false
      ) {
        setPosition('Up');
      }
      if (
        viewableItems.some((item: any) => item.index <= 3) &&
        getKey === false
      ) {
        setPosition('Down');
      }
      setVisible(getKey);
    },
    [],
  );

  const _viewabilityConfig = {
    viewAreaCoveragePercentThreshold: 0,
  };

  const viewabilityConfigCallbackPairs = useRef<any>([{onViewableItemsChanged}]);

  const renderList = ({item, index}: any) => {
    return (
      <View>
        <View style={optionChainScreen.callsPutContainer}>
          <View style={optionChainScreen.callsPutInner}>
            <CallPutList
              ltpTxt={item.calls.ltp}
              ltpValue={item.calls.value}
              ivTxt={item.calls.IV}
              ivValue={item.calls.ivValue}
              oiTxt={item.calls.OI}
              oiValue={item.calls.oiValue}
              leftView={true}
              modalView={callModal}
              index={index}
              showAddToWatchlistModal={showAddToWatchlistModal}
            />
            <View style={optionChainScreen.dayValueTxtContainer}>
              <Text
                style={optionChainScreen.dayValue}>{`${item.value}.00`}</Text>
            </View>
            <CallPutList
              ltpTxt={item.calls.ltp}
              ltpValue={item.calls.value}
              ivTxt={item.calls.IV}
              ivValue={item.calls.ivValue}
              oiTxt={item.calls.OI}
              oiValue={item.calls.oiValue}
              leftView={false}
              index={index}
              modalView={putModalView}
              showAddToWatchlistModal={showAddToWatchlistModal}
            />
          </View>
        </View>
        {item.flag ? (
          <View>
            <Hexagon />
          </View>
        ) : null}
      </View>
    );
  };
  return (
    <View style={optionChainScreen.container}>
      <View>
        <FlatList
          data={dateData}
          horizontal={true}
          renderItem={({item}) => (
            <Date
              date={item.date}
              month={item.month}
              year={item.year}
              onPress={onPress}
              selectedDate={date}
            />
          )}
        />
      </View>
      <Text style={optionChainScreen.expiryTxt}>
        *18 Expires available till dec'27
      </Text>
      <View style={optionChainScreen.callsPutTxtContainer}>
        <Text style={optionChainScreen.callsTxt}>Calls</Text>
        <Text style={optionChainScreen.callsTxt}>Puts</Text>
      </View>
      {/* Main View */}
      <View style={{flex: 1}}>
        {!isVisible && position === 'Up' ? (
          <TouchableOpacity
            onPress={handleScrollToIndex}
            style={{
              position: 'absolute',
              width: '100%',
              zIndex: 1,
              alignSelf: 'center',
            }}>
            <Hexagon />
          </TouchableOpacity>
        ) : null}

        {!isVisible && position === 'Down' ? (
          <TouchableOpacity
            onPress={handleScrollToIndex}
            style={{
              position: 'absolute',
              width: '100%',
              zIndex: 1,
              alignSelf: 'center',
              bottom:0
            }}>
            <Hexagon />
          </TouchableOpacity>
        ) : null}
        {/* <FlatList
          data={optionData}
          ref={flatListRef}
          renderItem={renderList}
          contentContainerStyle={{marginTop: 12}}
          viewabilityConfig={_viewabilityConfig}
          viewabilityConfigCallbackPairs={
            viewabilityConfigCallbackPairs.current
          }
        /> */}
        <OptionChainSkeleton />
      </View>
      <CallModal
        visible={callModalVisible}
        onClose={() => setCallModalVisible(false)}
      />
      <PutModal
        visible={putModalVisible}
        onClose={() => setPutModalVisible(false)}
      />
      <AddToWatchListModal
        visible={addToWatchlistModalVisible}
        onClose={addToWatchlistModalView}
      />
    </View>
  );
}

export default OptionChain;

import React, { useEffect, useRef } from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import TopTabNavigator from './components/navigation/TopTabNavigatore';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {Cfont, root} from '../../styles/colors';
import Feather from 'react-native-vector-icons/Feather';
import {useNavigation} from '@react-navigation/native';
import SortFilterBottomSheet from '../../components/BottomSheet/SortFilterBottomSheet';
import BottomSheet from '@gorhom/bottom-sheet';
import OrdersFilter from '../Orders/Component/OrdersFilter';
import { useSelector } from 'react-redux';
import ConstituentsFilter from './Constituents/components/Filter/Filter';

function IndicesScreen() {
    const filter = useSelector(state => state?.Reducer?.openFilter);
    const bottomSheetRef = useRef<BottomSheet>(null);
  const navigation = useNavigation();
  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  useEffect(()=>{
    if(filter==='open'){
        bottomSheetRef?.current?.snapToIndex?.(0);
    }
    console.log('FIlter in indices',filter)
  },[filter])

  return (
    <View style={{flex: 1}}>
      <View style={styles.topContainer}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <Ionicons
              size={24}
              name="arrow-back-sharp"
              style={{marginRight: 10, color: '#303030'}}
              color="#303030"
            />
          </TouchableOpacity>

          <View>
            <Text style={styles.nifty50Txt}>Nifty 50</Text>
            <View style={{flexDirection: 'row'}}>
              <Text style={styles.value}>17632.75</Text>
              <Text
                style={[
                  styles.value,
                  {
                    color: '#4caf50',
                    marginLeft: 3,
                    fontSize: 14,
                    paddingTop: 2,
                  },
                ]}>
                -30 (-0.00%)
              </Text>
            </View>
            <Text
              style={{
                fontSize: 11,
                color: root.color_text,
                fontFamily: Cfont.rubik_light,
              }}>
              24 APR '23 10:10:10 AM
            </Text>
          </View>
        </View>

        <TouchableOpacity style={{borderWidth: 1.5, borderRadius: 25}}>
          <Feather name="bar-chart-2" size={20} color="black" />
        </TouchableOpacity>
      </View>
      <TopTabNavigator />
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        index={-1}
        closesheet={closeSheet}>
        <ConstituentsFilter bottomSheetRef={bottomSheetRef} closesheet={closeSheet}/>
      </SortFilterBottomSheet>
    </View>
  );
}

const styles = StyleSheet.create({
  topContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    paddingHorizontal: 15,
    backgroundColor: 'white',
  },
  image: {
    height: 25,
    width: 25,
    marginRight: 15,
  },
  nifty50Txt: {
    color: '#303030',
    fontSize: 20,
    fontFamily: Cfont.rubik_medium,
  },
  value: {
    color: '#303030',
    fontSize: 16,
    fontFamily: Cfont.rubik_regular,
  },
});

export default IndicesScreen;

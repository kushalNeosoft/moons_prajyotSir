import React, {useEffect, useState} from 'react';
import {View, FlatList, ActivityIndicator, Text, Image} from 'react-native';
import ListItem from './components/ListItem';
import {futureScreen} from '../../../theme/light';
import AddToWatchListModal from '../../../components/AddToWatchlistModal/AddToWatchlistModal';
import {useIsFocused} from '@react-navigation/native';
import { Cfont, root } from '../../../styles/colors';

function Futures() {
  const [addToWatchlistModalVisible, setAddToWatchlistModalVisible] =
    useState(false);
  const [loading, setLoading] = useState(true);

  const isFocused = useIsFocused();

  useEffect(() => {
    if (isFocused) {
      const hideLoading = setTimeout(() => {
        setLoading(false);
      }, 200);

      return () => clearTimeout(hideLoading);
    } else {
      setLoading(true);
    }
  }, [isFocused]);

  // const data = [
  //   {
  //     date: '25 MAY',
  //     year: "'23",
  //     price: '17879.00',
  //     change: '35.35(-0.20%)',
  //     discount: '-103.65',
  //   },
  //   {
  //     date: '29 JUN',
  //     year: "'23",
  //     price: '17931.70',
  //     change: '24.65(-0.14%)',
  //     discount: '-149.76',
  //   },
  //   {
  //     date: '27 JUL',
  //     year: "'23",
  //     price: '18339.45',
  //     change: '00.00(-0.00)',
  //     discount: '-661.65',
  //   },
  // ];

  const data = [];

  const showAddToWatchlistModal = () => {
    setAddToWatchlistModalVisible(prevState => !prevState);
  };

  const addToWatchlistModalView = () => {
    setAddToWatchlistModalVisible(prevState => !prevState);
  };

  const renderItem = ({item}: any) => {
    return (
      <ListItem
        date={item.date}
        price={item.price}
        change={item.change}
        discount={item.discount}
        year={item.year}
        showAddToWatchlistModal={showAddToWatchlistModal}
      />
    );
  };

  return (
    <View style={futureScreen.container}>
      {data.length > 0 ? (
        <FlatList data={data} renderItem={renderItem} />
      ) : (
        <View style={{flex:1,alignItems:'center',justifyContent:'center',backgroundColor:'white'}}>
          {loading ? (
            <ActivityIndicator size={'large'} color={'black'} />
          ) : (
            <>
            <Image source={require('../../../assets/blank_file.jpeg')}/>
            <Text style={{fontSize:18,fontFamily:Cfont.rubik_medium}}>No Data</Text>
            </>
          )}
        </View>
      )}
      <AddToWatchListModal
        visible={addToWatchlistModalVisible}
        onClose={addToWatchlistModalView}
      />
    </View>
  );
}

export default Futures;

import React, {
  useEffect,
  useState,
  useCallback,
  useRef,
  useContext,
  Suspense,
  useMemo,
  lazy,
} from 'react';
import {Alert, BackHandler, Image, LogBox} from 'react-native';
import {View, Text, FlatList, TouchableOpacity, Dimensions} from 'react-native';

LogBox.ignoreAllLogs();

const ConstituentsLazy = lazy(() => import('./Constituents'));

const ConstituentsScreen = () => {
  const constituentsLazyRender = useMemo(() => {
    return <ConstituentsLazy />;
  }, []);
  return (
    <View style={{flex: 1}}>
      <Suspense fallback={<Text>Loading</Text>}>
        {constituentsLazyRender}
      </Suspense>
    </View>
  );
};

export default React.memo(ConstituentsScreen);

import React, {useEffect, useState} from 'react';
import {
  View,
  Modal,
  TouchableOpacity,
  TextInput,
  FlatList,
  Text,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import StockListView from '../../../../components/StockListView/StockListView';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {ordersNavigation} from '../../../../theme/light';
import {root} from '../../../../styles/colors';
import { useNavigation } from '@react-navigation/native';

const SearchIndices = (props: any) => {
  const [filterData, setFilterData] = useState<any>();
  const [searchKey, setSearchKey] = useState<string>('');
const navigation=useNavigation();

  useEffect(() => {
    const searchFilterOnList = (value: string) => {
      if (value && value.length > 0) {
        var mainList = [];
        mainList = props.route.params.data;
        const filterTempList = mainList.filter((item: any) =>
          item.companyName.toLowerCase().includes(value.toLowerCase()),
        );
        setFilterData(filterTempList);
      } else {
        setFilterData([]);
      }
    };

    searchFilterOnList(searchKey);
  }, [searchKey]);

  const renderSearchItems = () => {
    return (
      <FlatList
        data={filterData}
        renderItem={({item}) => (
          <TouchableOpacity>
          <StockListView
            stockName={item.companyName}
            stockTtile={item.title}
            price={item.value}
            changes={item.changes}
            title={item.title}
            showIcon={item.showIcon}
            iconName={item.iconName}
            screenName="WatchList"
          />
          </TouchableOpacity>
        )}
      />
    );
  };

  return (
      <View style={ordersNavigation.searchModal}>
        <View style={ordersNavigation.searchModalHeader}>
          <View style={ordersNavigation.searchModalTxt}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
                setSearchKey('');
              }}>
              <Ionicons name="close" size={25} color="black" />
            </TouchableOpacity>
            <TextInput
              placeholder="Search"
              autoCapitalize={'characters'}
              value={searchKey}
              placeholderTextColor={root.color_textual}
              style={ordersNavigation.searchModalTxtip}
              onChangeText={text => {
                setSearchKey(text);
              }}
            />
          </View>
          {searchKey?.length !== 0 ? (
            <TouchableOpacity
              onPress={() => {
                setSearchKey('');
              }}>
              <Text style={ordersNavigation.clearTxt}>Clear</Text>
            </TouchableOpacity>
          ) : (
            <MaterialCommunityIcons
              name="microphone"
              size={24}
              color={root.color_text}
            />
          )}
        </View>
        {renderSearchItems()}
      </View>
  );
};

export default SearchIndices;

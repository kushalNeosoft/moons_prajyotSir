import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import SegmentDialog from './SegmentDialog';
import SectorDialog from './SectorDialog';
import ExchangeDialog from './ExchangeDialog';


const FilterDialog = (props: any) => {
  const {item, visible, onClose} = props;
  const [exchangeDialogVisibility, setExchageDialogVisibility] =
    useState(false);
    
    const [SegmentDialogVisibility, setSegmentDialogVisibility] =
    useState(false);
    const [SectorDialogVisibility, setSectorDialogVisibility] =
    useState(false);

  
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          paddingVertical: 18,
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
        }}>
       
          <View style={{width: '100%', height: '100%'}}>
            <View style={{paddingHorizontal: 16, position: 'relative'}}>
              <Text
                style={{
                  fontSize: Font.font_title,
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                }}>
                Sort & Filter
              </Text>
              <TouchableNativeFeedback
                onPress={() => {
                  props.onClose();
                }}
                background={TouchableNativeFeedback.Ripple('gray', true)}>
                <View style={{position: 'absolute', right: 16}}>
                  <CloseIcon style={{height: 24, width: 24, color: 'black'}} />
                </View>
              </TouchableNativeFeedback>
            </View>
            <TouchableOpacity
            onPress={() => {
              setSegmentDialogVisibility(true);
            }}>
              <View
                style={{
                  marginTop: 2,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 8,
                  paddingHorizontal: 16,
                }}>
                <Text
                  style={{
                    fontSize: 14,
                    color: root.color_text , 
                    fontFamily: Cfont.rubik_medium,
                    flex: 1,
                  }}>
                  Segment
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>Equity</Text>
                  <ExpandIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
            onPress={() => {
              setExchageDialogVisibility(true);
            }}>
              <View
                style={{
                  marginTop: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 8,
                  paddingHorizontal: 16,
                }}>
               <Text
                  style={{
                    fontSize: 14,
                    color: root.color_text , 
                    fontFamily: Cfont.rubik_medium,
                    flex: 1,
                  }}>
                  Exchange
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>NSE Index</Text>
                  <ExpandIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
            onPress={() => {
            setSectorDialogVisibility(true);
            }}>
              
              <View
                style={{
                  marginTop: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 8,
                  paddingHorizontal: 16,
                }}>
                <View style={{flex: 1}}>
                <Text
                  style={{
                    fontSize: 14,
                    color: root.color_text , 
                    fontFamily: Cfont.rubik_medium,
                    flex: 1,
                  }}>
                    Index
                  </Text>
                  <Text style={{fontSize:10}}>Optional*</Text>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>NIFTY 200</Text>
                  <ExpandIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableOpacity>
            <TouchableNativeFeedback
              // disabled={!filled}
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                // setConfirmOrderVisible(true);
              }}>
              <View
                style={{
                  backgroundColor: root.client_background,
                  marginTop: 32,
                  marginHorizontal: 16,
                  borderRadius: 8,
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                }}>
                <Text
                  style={{
                    fontSize: 16,
                    color: 'white',
                    textAlign: 'center',
                    fontFamily: Cfont.rubik_semibold,
                    opacity: 1,
                  }}>
                  Apply
                </Text>
              </View>
            </TouchableNativeFeedback>
          </View>
      </View>
      <ExchangeDialog
        visible={exchangeDialogVisibility}
        onClose={() => {
          setExchageDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setExchageDialogVisibility(false);
        }}
      />
      <SegmentDialog
        visible={SegmentDialogVisibility}
        onClose={() => {
          setSegmentDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSegmentDialogVisibility(false);
        }}
      />
       <SectorDialog
        visible={SectorDialogVisibility}
        onClose={() => {
          setSectorDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSectorDialogVisibility(false);
        }}
      />
    </Modal>
  );
};
export default FilterDialog;

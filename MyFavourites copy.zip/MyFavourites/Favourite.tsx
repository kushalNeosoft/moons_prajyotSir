import {useEffect, useState} from 'react';
import React from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import AddIcon from '../../assets/AddIcon';
import {useNavigation} from '@react-navigation/native';
import HeartIcon from '../../assets/HeartIcon';
import FilterIcon from '../../assets/FilterIcon';
import FilterDialog from './components/FilterDialog';
import {TouchableOpacity} from 'react-native-gesture-handler';
import DropDownIcon from '../../assets/DropDownIcon';
import ExpandIcon from '../../assets/ExpandIcon';
import ExchangeDialog from './components/ExchangeDialog';
import HeartFilledIcon from '../../assets/HeartFilledIcon';
import { Setalertstyle } from '../../theme/light';
import { Cfont, root } from '../../styles/colors';
import SegmentDialog from './components/SegmentDialog';
import SectorDialog from './components/SectorDialog';

const Favourite = ({route}: any) => {
  const fav = route.params.data;
  const [filterDialogVisibility, setFilterDialogVisibility] = useState(false);
  const [exchangeDialogVisibility, setExchageDialogVisibility] =
    useState(false);
    
    const [SegmentDialogVisibility, setSegmentDialogVisibility] =
    useState(false);
    const [SectorDialogVisibility, setSectorDialogVisibility] =
    useState(false);
  const [selectedTab, setSelectedTab] = useState(1);

  const [list1, setList1] = useState([]);
  const [list2, setList2] = useState([]);
  const navigation = useNavigation();

  const [favourite, setFavourite] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      //load List1
      fetch(
        'https://pre-prod1.odinwave.com/nontransactional/1404/1/getAnalyticsData/WaveScreener/1/Nifty%2050/' +
          fav.RedisKeyPrefix_1 +
          '/-/-',
        {
          method: 'GET',
        },
      )
        .then(response => response.json())
        .then((data): any => {
          if (data.status) {
            setList1(data.result);
          }
        })
        .catch(error => console.log('error', error));
      fetch(
        'https://pre-prod1.odinwave.com/nontransactional/1404/1/getAnalyticsData/WaveScreener/1/Nifty%2050/' +
          fav.RedisKeyPrefix_2 +
          '/-/-',
        {
          method: 'GET',
        },
      )
        .then(response => response.json())
        .then((data): any => {
          if (data.status) {
            setList2(data.result);
          }
        })
        .catch(error => console.log('error', error));
    };
    loadData();
  }, [fav]);

  const Item = ({item}: any) => {
    return (
      <View
        key={item.GroupId}
        style={{
          backgroundColor: 'white',
        }}>
        <View style={{flexDirection: 'row', padding:16}}>
          <View
            style={{
              flexDirection: 'row',
              // justifyContent: 'center',
              // alignItems: 'center',
              flex: 1,
            }}>
            <Text
              style={{
                color: root.color_text ,fontFamily: Cfont.rubik_medium,
                marginRight: 4,
                fontSize: 18,
              }}>
              {item.sSymbol}
            </Text>
            <View style={{}}>
              <Text
                style={Setalertstyle.nsetxt}>
                {item.sSeries}
              </Text>
            </View>
          </View>
          <View style={{flexDirection: 'row'}}>
            <View>
              <Text style={{textAlign: 'right', fontSize: 14,color: root.color_text ,   fontFamily: Cfont.rubik_medium}}>
                {item.nClose}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  color: item.nPercChange.includes('-') ? 'red' : 'green',
                  textAlign: 'right',
                }}>
                +{(item.nOpen - item.nClose).toFixed(2) +
                  '(' +
                  item.nPercChange +
                  ' %)'}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate('BuySell', {
                  item,
                });
              }}>
              <View
                style={{
                  borderWidth: 1,
                  borderColor: root.color_text,
                  height: 24,
                  width: 24,
                  borderRadius: 12,
                  marginLeft: 8,
                  marginTop: 8
                }}>
                <Text
                  style={{
                    textAlign: 'center',
                    fontWeight: 'bold',
                    fontFamily: Cfont.rubik_medium,
                    
                    color: root.color_text , 
                    fontSize: 16,
                  }}>
                  T
                </Text>
              </View>
            </TouchableOpacity>

            <View
              style={{
                borderWidth: 1.7,
                borderColor: 'black',
                height: 24,
                width: 24,
                borderRadius: 20,
                marginLeft: 10,
                marginTop: 8
              }}>
              <AddIcon
                style={{
                  height: 22,
                  width: 22,
                  color: 'black',
                  fontFamily: Cfont.rubik_medium
                 
                }}
              />
            </View>
          </View>
        </View>
        <View style={{height: 1, backgroundColor: 'lightgrey'}} />
      </View>
    );
  };

  return (
    <View>
      <View
        style={{
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.23,
          shadowRadius: 2.62,

          elevation: 4,
          backgroundColor: 'white',
          zIndex: 10,
        }}>
        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 16,
            paddingVertical: 8,
            marginVertical: 8,
            alignItems: 'center',
          }}>
          <TouchableNativeFeedback
            onPress={() => {
              navigation.goBack();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <BackIcon style={{width: 24, height: 24, color: 'black'}} />
            </View>
          </TouchableNativeFeedback>
          <Text
            style={{
              flex: 1,
              fontSize: 18,
              fontWeight: 'bold',
              marginHorizontal: 12,
              color: 'black',
            }}>
            {fav.GroupName}
          </Text>
          <TouchableNativeFeedback
            onPress={() => {
              setFavourite(prev => !prev);
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              {favourite ? (
                <HeartFilledIcon
                  style={{width: 24, height: 24, color: 'black', fill: 'black'}}
                />
              ) : (
                <HeartIcon style={{width: 24, height: 24, color: 'black'}} />
              )}
            </View>
          </TouchableNativeFeedback>
          <View style={{width: 16}} />
          <TouchableNativeFeedback
            onPress={() => {
              setFilterDialogVisibility(true);
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <FilterIcon style={{width: 24, height: 24, color: 'black'}} />
            </View>
          </TouchableNativeFeedback>
        </View>
        <View
          style={{
            paddingHorizontal: 16,
            paddingVertical: 8,
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Text style={{color: root.color_text , fontFamily: Cfont.rubik_regular}}>Filters :</Text>
          <TouchableOpacity
            onPress={() => {
              setSegmentDialogVisibility(true);
            }}>
            <View
              style={{
                marginLeft: 16,
                backgroundColor: '#EFEFEF',
                flexDirection: 'row',
                paddingHorizontal: 6,
                borderRadius: 4,
                alignItems: 'center',
              }}>
              <Text style={{paddingVertical: 4 , fontFamily: Cfont.rubik_medium, fontSize:12}}>Equity</Text>
              <ExpandIcon style={{height: 16, width: 16, color: root.color_text}} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setExchageDialogVisibility(true);
            }}>
          <View
            style={{
              marginLeft: 16,
              backgroundColor: '#EFEFEF',
              flexDirection: 'row',
              paddingHorizontal: 6,
              borderRadius: 4,
              alignItems: 'center',
            }}>
            <Text style={{paddingVertical: 4 , fontFamily: Cfont.rubik_medium, fontSize:12}}>NSE Indices</Text>
            <ExpandIcon style={{height: 16, width: 16, color: root.color_text}} />
            
          </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setSectorDialogVisibility(true);
            }}>
          <View
            style={{
              marginLeft: 16,
              backgroundColor: '#EFEFEF',
              flexDirection: 'row',
              paddingHorizontal: 6,
              borderRadius: 4,
              alignItems: 'center',
            }}>
            <Text style={{paddingVertical: 4 , fontFamily: Cfont.rubik_medium, fontSize:12}}>NIFTY 100</Text>
            <ExpandIcon style={{height: 16, width: 16, color: root.color_text}}  />
          </View>
          </TouchableOpacity>
        </View>
        <View
          style={{
            flexDirection: 'row',
          }}>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(1);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{flex: 1}}>
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 12,
                  paddingVertical: 12,
                  color: selectedTab == 1 ? root.client_background : 'gray',
                    fontFamily: Cfont.rubik_medium,
                }}>
                {fav.ScannerName_1}
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 1 ? root.client_background : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(2);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{flex: 1}}>
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 12,
                  paddingVertical: 12,
                  color: selectedTab == 2 ? root.client_background : 'gray',
                  fontFamily: Cfont.rubik_medium,
                }}>
                {fav.ScannerName_2}
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 2 ? root.client_background : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>

      {selectedTab === 1 ? (
        <FlatList
          data={list1}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return <Item item={item.item} />;
          }}
        />
      ) : (
        <FlatList
          data={list2}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return <Item item={item.item} />;
          }}
        />
      )}
      <FilterDialog
        visible={filterDialogVisibility}
        onClose={() => {
          setFilterDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setFilterDialogVisibility(false);
        }}
      />
      <ExchangeDialog
        visible={exchangeDialogVisibility}
        onClose={() => {
          setExchageDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setExchageDialogVisibility(false);
        }}
      />
      <SegmentDialog
        visible={SegmentDialogVisibility}
        onClose={() => {
          setSegmentDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSegmentDialogVisibility(false);
        }}
      />
       <SectorDialog
        visible={SectorDialogVisibility}
        onClose={() => {
          setSectorDialogVisibility(false);
        }}
        onChange={(t: string) => {
          setSectorDialogVisibility(false);
        }}
      />
    </View>
  );
};
export default Favourite;

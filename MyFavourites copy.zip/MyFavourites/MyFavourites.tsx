import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Logo from '../../assets/Logo';
import AddIcon from '../../assets/AddIcon';
import AddFunds from '../Funds/AddFunds/AddFunds';
import {calculator, linkOne} from '../../theme/light';
import {FlatList} from 'react-native';

const MyFavourites = () => {
  const navigation = useNavigation();

  const [list, setList] = useState([]);
  const [categories, setCategories] = useState<any>([]);
  const [selectedCategory, setSelectedCategory] = useState('My Favourites');

  const loadData = async () => {
    fetch(
      'https://devwaveapi.odinwave.com/nontransactional/1404/v1/getAppWaveScannerDetails',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.status) {
          console.log(data.result);

          setList(data.result);
          const unique = [
            ...new Set(data.result.map((item: any) => item.Category)),
          ];
          unique.unshift('My Favourites');
          setCategories(unique);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View style={calculator.main}>
      <View style={calculator.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={calculator.backIcon} />
        </TouchableOpacity>
      </View>
      <Text
        style={{fontSize: 28, color: root.color_text , fontFamily: Cfont.rubik_medium, padding: 16, marginTop: 18}}>
        My Favorites
      </Text>
      <Text
        style={{
          fontSize: 16,
          fontFamily: Cfont.rubik_regular,
          color: root.color_text ,
          paddingHorizontal: 16
        }}>
        Total {list.length}
      </Text>
      <View>
        <FlatList
          style={{marginHorizontal: 12, marginTop: 16, height: 43}}
          horizontal={true}
          data={categories}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return (
              <TouchableOpacity
                key={item}
                onPress={() => {
                  setSelectedCategory(item.item);
                }}>
                <View
                  style={{
                    borderRadius: 16,
                    paddingHorizontal: 16,
                    paddingVertical: 6,
                    borderWidth: 0.5,
                    marginLeft: 4,
                    borderColor: root.color_text ,
                    backgroundColor:
                      selectedCategory == item.item
                        ? root.client_background
                        : 'transparent',
                  }}>
                  <Text
                    style={{
                      color: selectedCategory == item.item ? 'white' : root.color_text,fontFamily: Cfont.rubik_medium
                    }}>
                    {item.item}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
        />
      </View>

      <ScrollView>
        <FlatList
          data={list.filter((item: any) => {
            if (selectedCategory === 'My Favourites') return true;
            return item.Category === selectedCategory;
          })}
          renderItem={(item: any) => {
            return (
              <TouchableNativeFeedback
                key={item.GroupId}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  navigation.navigate('Favourite', {data: item.item});
                }}>
                <View
                  key={item.GroupId}
                  style={{
                    backgroundColor: 'white',
                    padding: 14,
                    marginTop: 18,
                    marginHorizontal: 16,
                    marginVertical: 6,
                    shadowColor: '#000',
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.23,
                    shadowRadius: 2.62,
                    elevation: 4,
                    borderRadius: 8,
                  }}>
                  <Text
                    style={{color: root.color_text ,   fontFamily: Cfont.rubik_medium, fontSize: 14}}>
                    {item.item.GroupName}
                  </Text>
                  <Text style={{color: root.color_text,fontFamily: Cfont.rubik_regular, fontSize: 12, marginTop: 4}}>{item.item.Description}</Text>
                 
                </View>
                
              </TouchableNativeFeedback>
            );
          }}
        />
      </ScrollView>
    
    </View>
  );
};
export default MyFavourites;

import { StyleSheet } from 'react-native';
import {Cfont, root, Font} from '../styles/colors';


  const fontFamily = {
  rubic_medium: {
    fontFamily: Cfont.rubik_medium,
  },
  rubic_regular: {
    fontFamily: Cfont.rubik_regular,
  },
  rubic_light: {
    fontFamily: Cfont.rubik_light,
  },
  rubic_bold: {
    fontFamily: Cfont.rubik_bold,
  },
  rubic_black: {
    fontFamily: Cfont.rubik_black,
  },
  rubic_extrabold: {
    fontFamily: Cfont.rubik_extrabold,
  },
  rubic_semibold: {
    fontFamily: Cfont.rubik_semibold,
  },
};

 const color = {
  text: {
    color: root.color_text,
  },
  subtext: {
    color: root.color_subtext,
  },
  positive: {
    color: root.color_positive,
  },
  active: {
    color: root.color_active,
  },
  client_background:{
    color:root.client_background
  }
};

 const padding = {
  16:{
    padding:16,
  },
  l_25: {
    paddingLeft: 25,
  },
  l_20:{
    paddingLeft:20
  },
  r_15:{
    paddingRight:15
  },
  r_30:{
    paddingRight:30
  },
  r_10:{
    paddingRight:10
  },
  r_6:{
    paddingRight:6
  },
  r_11:{
    paddingRight:11
  },
  h_3: {
    paddingHorizontal: 3,
  },
  l_5: {
    paddingLeft: 5,
  },
  l_4: {
    paddingLeft: 4,
  },
  l_8: {
    paddingLeft: 8,
  },
  l_16: {
    paddingLeft: 16,
  },
  h_6: {
    paddingHorizontal: 6,
  },
  h_5: {
    paddingHorizontal: 5,
  },
  h_4: {
    paddingHorizontal: 4,
  },
  h_8: {
    paddingHorizontal: 8,
  },
  h_9: {
    paddingHorizontal: 9,
  },
  v_2: {
    paddingVertical: 2,
  },
  t_3: {
    paddingTop: 3,
  },
  t_2: {
    paddingTop: 2,
  },
  t_1: {
    paddingTop: 1,
  },
  t_8: {
    paddingTop: 8,
  },
  t_9: {
    paddingTop: 9,
  },
  t_7: {
    paddingTop: 7,
  },
  h_7: {
    paddingHorizontal: 7,
  },
  h_10: {
    paddingHorizontal: 10,
  },
  h_12: {
    paddingHorizontal: 12,
  },
  h_13: {
    paddingHorizontal: 13,
  },
  v_8: {
    paddingVertical: 8,
  },
  v_10: {
    paddingVertical: 10,
  },
  h_16:{
    paddingHorizontal:16
  },
  t_20:{
    paddingTop: 20,
  },
  h_14:{
    paddingHorizontal:14
  },
  h_15:{
    paddingHorizontal:15
  },
  h_18:{
    paddingHorizontal:18
  },
  h_20:{
    paddingHorizontal:20
  },
  t_40:{
    paddingTop: 40,
  },
  t_35:{
    paddingTop: 35,
  },
  t_36:{
    paddingTop: 36,
  },
  t_37:{
    paddingTop: 37,
  },
  t_18:{
    paddingTop: 18,
  },
  t_19:{
    paddingTop: 19,
  },
  b_17:{
    paddingBottom:17
  },
  b_10:{
    paddingBottom:10
  },
  b_8:{
    paddingBottom:8
  },
  b_2:{
    paddingBottom:2
  },
  b_0:{
    paddingBottom:0
  },
  b_30:{
    paddingBottom:30
  },
  t_5:{
    paddingTop:10
  },
  t_10:{
    paddingTop:10
  },
  p_11:{
    padding:11
  },
  p_16:{
    padding:16
  },
  p_10:{
    padding:10
  },
  p_6:{
    padding:6
  },
  p_5:{
    padding:5
  },
  p_7:{
    padding:7
  },
  p_1:{
    padding:1
  },
  p_3:{
    padding:3
  },
  p_2:{
    padding:2
  },
  l_10:{
paddingLeft:10
  },
  t_12:{
    paddingTop:12
  },
  l_12:{
    paddingLeft:12
  },
  h_24:{
    paddingHorizontal:24
  },
  v_12:{
    paddingVertical:12
  },
  v_7:{
    paddingVertical:7
  },
  t_32:{
    paddingTop:32
  },
  h_42:{
    paddingHorizontal:42
  },
  v_11:{
    paddingVertical:11
  },
  t_16:{
    padingTop:16
  }
};

 const backgroundColor = {
  backgroung_exchange_chip_color: {
    backgroundColor: root.backgroung_exchange_chip_color,
  },
  chip_background_positive_cotrast: {
    backgroundColor: root.chip_background_positive_cotrast,
  },
  color_negative: {
    backgroundColor: root.color_negative,
  },
  color_active:{
    backgroundColor:root.color_active
  },
  client_background:{
    backgroundColor:root.client_background
  },
  color_positive:{
    backgroundColor:root.color_positive
  },
};

 export const textAlign = StyleSheet.create({
  center: {
    textAlign: 'center',
    textAlignVertical: 'center',
  },
});

 export const margin = {
  m_l_5: {
    marginLeft: 5,
  },
  m_l_6: {
    marginLeft: 6,
  },
  m_l_4: {
    marginLeft: 4,
  },
  m_l_3: {
    marginLeft: 3,
  },
  m_l_10: {
    marginLeft: 10,
  },
  m_l_9: {
    marginLeft: 9,
  },
  m_l_8: {
    marginLeft: 8,
  },
  m_l_15: {
    marginLeft: 15,
  },
  m_l_13: {
    marginLeft: 13,
  },
  m_l_16: {
    marginLeft: 16,
  },
  m_l_17: {
    marginLeft: 17,
  },
  m_l_32: {
    marginLeft: 32,
  },
  m_l_70: {
    marginLeft: 70,
  },
  m_12:{
    margin:12
  },
  t_26:{
    marginTop:26
  },
  t_25:{
    marginTop:25
  },
  t_18:{
    marginTop:18
  },
  t_20:{
    marginTop:20
  },
  t_21:{
    marginTop:21
  },
  t_17:{
    marginTop:17
  },
  t_23:{
    marginTop:23
  },
  t_22:{
    marginTop:22
  },
  t_28:{
    marginTop:28
  },
  t_10:{
    marginTop:10
  },
  t_11:{
    marginTop:11
  },
  t_58:{
    marginTop:58
  },
  t_14:{
    marginTop:14
  },
  t_15:{
    marginTop:15
  },
  t_12:{
    marginTop:12
  },
  t_13:{
    marginTop:13
  },
  t_30:{
    marginTop:30
  },
  t_31:{
    marginTop:30
  },
  t_34:{
    marginTop:30
  },
  t_35:{
    marginTop:35
  },
  t_36:{
    marginTop:36
  },
  t_42:{
    marginTop:42
  },
  t_40:{
    marginTop:40
  },
  t_41:{
    marginTop:41
  },
  t_45:{
    marginTop:45
  },
  t_8:{
    marginTop:8
  },
  t_48:{
    marginTop:48
  },
  t_50:{
    marginTop:50
  },
  t_100:{
    marginTop:50
  },
  t_16:{
    marginTop:16
  },
  t_6:{
    marginTop:6
  },
  t_7:{
    marginTop:7
  },
  t_5:{
    marginTop:5
  },
  t_4:{
    marginTop:4
  },
  t_2:{
    marginTop:2
  },
  t_3:{
    marginTop:3
  },
  b_8:{
    marginBottom:8
  },
  b_7:{
    marginBottom:7
  },
  b_12:{
    marginBottom:12
  },
  b_16:{
    marginBottom:16
  },
  b_18:{
    marginBottom:18
  },
  b_20:{
    marginBottom:20
  },
  b_23:{
    marginBottom:23
  },
  b_28:{
    marginBottom:28
  },
  b_30:{
    marginBottom:30
  },
  b_5:{
    marginBottom:5
  },
  b_32:{
    marginBottom:32
  },
  b_35:{
    marginBottom:35
  },
  b_60:{
    marginBottom:60
  },
  b_50:{
    marginBottom:50
  },
  b_100:{
    marginBottom:100
  },
  b_15:{
    marginBottom:15
  },
  b_14:{
    marginBottom:14
  },
  b_6:{
    marginBottom:6
  },
  b_9:{
    marginBottom:9
  },
  b_10:{
    marginBottom:10
  },
  b_0:{
    marginBottom:0
  },
  h_13:{
    marginHorizontal: 13,
  },
  h_16:{
    marginHorizontal:16,
  },
  h_35:{
    marginHorizontal: 35,
  },
  r_12:{
    marginRight: 12,
  },
  r_13:{
    marginRight: 13,
  },
  r_15:{
    marginRight: 12,
  },
  r_25:{
    marginRight: 25,
  },
  r_20:{
    marginRight: 20,
  },
  r_30:{
    marginRight: 30,
  },
  r_10:{
    marginRight: 10,
  },
  r_5:{
    marginRight: 5,
  },
  r_0:{
    marginRight: 0,
  },
  v_20:{
    marginVertical: 20,
  },
  v_10:{
    marginVertical: 10,
  },
  v_6:{
    marginVertical: 6,
  },
  v_8:{
    marginVertical: 8,
  },
  v_1:{
    marginVertical: 1,
  },
  
  v_16:{
    marginVertical:16
  },
  v_18:{
    marginVertical:18
  }
};

 const borderRadius = {
  5: {
    borderRadius: 5,
  },
  10: {
    borderRadius: 10,
  },
  15: {
    borderRadius: 15,
  },
  20: {
    borderRadius: 20,
  },
};

 const font_size_family = {
  rm_5: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 5,
  },
  rm_6: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 6,
  },
  rm_7: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 7,
  },
  rm_8: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 8,
  },
  rm_9: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 9,
  },
  rm_10: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 10,
  },
  rm_11: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 11,
  },
  rm_12: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  rm_13: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
  },
  rm_14: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
  },
  rm_15: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 15,
  },
  rm_16: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
  },
  rm_17: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 17,
  },

  rm_18: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
  },
  rm_20: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 20,
  },
  rm_21: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 21,
  },
  rm_22: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 22,
  },
  rm_23: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 23,
  },
  rm_24: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 24,
  },
  rm_25: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 25,
  },
  rm_30: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 30,
  },
  rm_26: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 26,
  },
  rm_27: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 27,
  },
  rm_28: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 28,
  },
  rr_9: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 9,
  },
  rr_10: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 10,
  },
  rr_11: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 11,
  },
  rr_12: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
  },
  rr_13: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 13,
  },
  rr_14: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 14,
  },
  rr_15: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 15,
  },
  rr_16: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 16,
  },
  rr_17: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 17,
  },
  rr_18: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
  },
  rr_20: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 20,
  },
  rr_24:{
    fontFamily: Cfont.rubik_regular,
    fontSize: 24,
  },
  rr_30: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 30,
  },

  rl_9: {
    fontFamily: Cfont.rubik_light,
    fontSize: 9,
  },
  rl_10: {
    fontFamily: Cfont.rubik_light,
    fontSize: 10,
  },
  rl_11: {
    fontFamily: Cfont.rubik_light,
    fontSize: 11,
  },
  rl_12: {
    fontFamily: Cfont.rubik_light,
    fontSize: 12,
  },
  rl_13: {
    fontFamily: Cfont.rubik_light,
    fontSize: 13,
  },
  rl_14: {
    fontFamily: Cfont.rubik_light,
    fontSize: 14,
  },
  rl_16: {
    fontFamily: Cfont.rubik_light,
    fontSize: 16,
  },
  rl_18: {
    fontFamily: Cfont.rubik_light,
    fontSize: 18,
  },
  rl_20: {
    fontFamily: Cfont.rubik_light,
    fontSize: 20,
  },
  rl_30: {
    fontFamily: Cfont.rubik_light,
    fontSize: 30,
  },
};


export default {fontFamily,color,backgroundColor,font_size_family,padding,margin}

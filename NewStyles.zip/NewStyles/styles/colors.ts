// import { initialState } from "../redux/Reducer/Reducer";
// import Reducer from "../redux/Reducer/Reducer";
// import  useColorMode  from "./useColorMode";
// import { useState } from "react";
import { ColorValue } from "react-native";
import { useSelector } from "react-redux";
import { store } from "../redux/Store";

// // const newRdx = {
// //   Reducer: {
// //     ...initialState, 
// //   },
// // };
// const [colorMode, setColorMode] = useColorMode();
// console.log('color code =>',colorMode)

// export const ColorTheme = ()=>{
//      const colorMode = useSelector(state => state?.Reducer?.colorMode);


//  const root = {
//   color_primary: '#fffffff',
//   color_active: '#FFFFFF',
//   client_background: '#25335c',
//   ipo_btn_backgrougd: '#f6f6f6',
//   color_text:'#303030',
//   color_subtext: '#979797',
//   color_active_text: '#ffffff',
//   color_signup_rap_background: '#1f1f1f',
//   signup_wrap_subtitle: '#999999',
//   color_textual: '#25335C',
//   ion_rb_2: '#000000',
//   color_border: '#ebebeb',
//   backgroung_exchange_chip_color: '#9797971A',
//   color_disable: '#ffffff',
//   choose_indices_background: '#1E1E1E',
//   dropdown_background: 'rgba(151,151,151,0.1)',
//   chip_primary:'#9AB3FF33',
//   color_positive_step_100:'#3DB943',
//   color_positive_step_50:'#408E41',
//   color_chipFilter:'#F5F7FA',
//   color_orderPreference_bg:'#FAFAFA',
//   color_border_bg:'#ebebeb',

//   // Market Screen colors
//   indices_red: '#FE0000',
//   calendar_bg: '#F5F7FA',

//   // watchList
//   color_positive: '#4caf50',
//   color_positive_rgb: 'rgba(76,175,80,0.15)',
//   color_negative: '#d32f2f',
//   color_negative_rgb: 'rgba(211,47,47,0.15)',
//   chip_background_positive_cotrast:'#4CAF5026',
// };

//  const Font = {
//   font_title: 30,
//   font_sub_title: 28,
//   font_normal_one: 12,
//   font_normal_two: 14,
//   font_normal_three: 16,
//   font_normal_four: 18,
//   font_normal_five: 13,
//   font_normal_six: 10,
//   font_normal_seven: 11,
//   font_normal_eight: 9,
//   font_normal_ten: 17,
//   font_normal_fifteen: 15,
//   font_normal_twenty_six: 26,
//   font_normal_twenty_four: 24,
//   font_normal_twenty_two: 22,
//   font_normal_twenty_one: 21,
// };
//  const Cfont = {
//   rubik_medium: 'Rubik-Medium',
//   rubik_regular: 'Rubik-Regular',
//   rubik_light: 'Rubik-Light',
//   rubik_bold: 'Rubik-Bold',
//   rubik_black: 'Rubik-Black',
//   rubik_extrabold: 'Rubik-ExtraBold',
//   rubik_semibold: 'Rubik-SemiBold',
// };
// return({
//   root,
//   Cfont,
//   Font
// })
// }

type ColorTheme = {
  primary: string;
  secondary: string;
  textSecondary: string;
  textPrimary: string;
  background: string;
  cardColor: string;
};

const sharedColors = {
  black: '#000000',
  white: '#FFFFFF',
};

type SharedColors = typeof sharedColors;

export type TColors = ColorTheme & SharedColors;

type ColorPalettes = {
  red: any | ColorValue | undefined;
  bright_green: any | ColorValue | undefined;
  black: ColorValue | undefined;
  white: ColorValue | undefined;
  light: TColors;
  dark: TColors;
};

const Colors: ColorPalettes = {
  dark: {
    primary: '#3F51B5',
    secondary: '#161629',
    textPrimary: sharedColors.white,
    textSecondary: '#67686E',
    background: '#1f1f1f',
    cardColor: '#37474F',
    ...sharedColors,
  },
  light: {
    primary: '#3F51B5',
    secondary: '#E4E4E4',
    textPrimary: '#161629',
    textSecondary: '#9D5DB0',
    background: '#f2f2f2',
    cardColor: '#FFFFFF',
    ...sharedColors,
  },
  red: undefined,
  bright_green: undefined,
  black: undefined,
  white: undefined
};

export default Colors;
// var newState
// export const rootFunction =()=> {
//   newState =store.getState();
// console.log('state changed->',newState.Reducer.colorMode);
//   return{
//   color_primary: '#fffffff',
//   color_active: newState.Reducer.colorMode==='light'?'#FFFFFF':'#303030',
//   client_background: '#25335c',
//   ipo_btn_backgrougd: '#f6f6f6',
//   color_text: newState.Reducer.colorMode==='light'?'#303030':'#FFFFFF',
//   color_subtext: '#979797',
//   color_active_text: '#ffffff',
//   color_signup_rap_background: '#1f1f1f',
//   signup_wrap_subtitle: '#999999',
//   color_textual: '#25335C',
//   ion_rb_2: '#000000',
//   color_border: '#ebebeb',
//   backgroung_exchange_chip_color: '#9797971A',
//   color_disable: '#ffffff',
//   choose_indices_background: '#1E1E1E',
//   dropdown_background: 'rgba(151,151,151,0.1)',
//   chip_primary:'#9AB3FF33',
//   color_positive_step_100:'#3DB943',
//   color_positive_step_50:'#408E41',
//   color_chipFilter:'#F5F7FA',
//   color_orderPreference_bg:'#FAFAFA',
//   color_border_bg:'#ebebeb',
//   // Market Screen colors
//   indices_red: '#FE0000',
//   calendar_bg: '#F5F7FA',
//   // watchList
//   color_positive: '#4caf50',
//   color_positive_rgb: 'rgba(76,175,80,0.15)',
//   color_negative: '#d32f2f',
//   color_negative_rgb: 'rgba(211,47,47,0.15)',
//   chip_background_positive_cotrast:'#4CAF5026',
// }
// };
// store.subscribe(rootFunction)

// var root = rootFunction();

// export { root };

const generateRootObject = (darkMode) => {
  console.log('mode',darkMode)
  return{
  color_primary: '#fffffff',
  color_active: '#FFFFFF',
  color_active_botton:'#FFFFFF',
  client_background: '#25335c',
  ipo_btn_backgrougd: '#f6f6f6',
  color_text: '#303030',
  color_subtext: '#979797',
  color_active_text: '#ffffff',
  color_signup_rap_background: '#1f1f1f',
  signup_wrap_subtitle: '#999999',
  color_textual: '#25335C',
  ion_rb_2: '#000000',
  color_border: '#ebebeb',
  backgroung_exchange_chip_color: '#9797971A',
  color_disable: '#ffffff',
  choose_indices_background: '#1E1E1E',
  dropdown_background: 'rgba(151,151,151,0.1)',
  chip_primary:'#9AB3FF33',
  color_positive_step_100:'#3DB943',
  color_positive_step_50:'#408E41',
  color_chipFilter:'#F5F7FA',
  color_orderPreference_bg:'#FAFAFA',
  color_border_bg:'#ebebeb',
  // Market Screen colors
  indices_red: '#FE0000',
  calendar_bg: '#F5F7FA',
  // watchList
  color_positive: '#4caf50',
  color_positive_rgb: 'rgba(76,175,80,0.15)',
  color_negative: '#d32f2f',
  color_negative_rgb: 'rgba(211,47,47,0.15)',
  chip_background_positive_cotrast:'#4CAF5026',
}
};
// Get initial dark mode state from Redux store
let currentDarkMode = store.getState().Reducer?.colorMode;
let root = generateRootObject(currentDarkMode);

// Subscribe to Redux store changes and update the root object accordingly
store.subscribe(() => {
    const newDarkMode = store.getState().Reducer.colorMode;
    if (currentDarkMode !== newDarkMode) {
      currentDarkMode = newDarkMode;
      root = generateRootObject(currentDarkMode);
    }
});

export { root };

 export const Font = {
  font_title: 30,
  font_sub_title: 28,
  font_normal_one: 12,
  font_normal_two: 14,
  font_normal_three: 16,
  font_normal_four: 18,
  font_normal_five: 13,
  font_normal_six: 10,
  font_normal_seven: 11,
  font_normal_eight: 9,
  font_normal_ten: 17,
  font_normal_fifteen: 15,
  font_normal_twenty_six: 26,
  font_normal_twenty_four: 24,
  font_normal_twenty_two: 22,
  font_normal_twenty_one: 21,
};
 export const Cfont = {
  rubik_medium: 'Rubik-Medium',
  rubik_regular: 'Rubik-Regular',
  rubik_light: 'Rubik-Light',
  rubik_bold: 'Rubik-Bold',
  rubik_black: 'Rubik-Black',
  rubik_extrabold: 'Rubik-ExtraBold',
  rubik_semibold: 'Rubik-SemiBold',
};

// New Style

export const font = {
  size_5: 5,
  size_6: 6,
  size_7: 7,
  size_8: 8,
  size_9: 9,
  size_10: 10,
  size_11: 11,
  size_12: 12,
  size_13: 13,
  size_14: 14,
  size_15: 15,
  size_16: 16,
  size_17: 17,
  size_18: 18,
  size_19: 19,
  size_20: 20,
  size_21: 21,
  size_22: 22,
  size_23: 23,
  size_24: 24,
  size_25: 25,
  size_26: 26,
  size_27: 27,
  size_28: 28,
  size_29: 29,
  size_30: 30,
};


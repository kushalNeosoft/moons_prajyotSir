import React from 'react';
const FontSize = (size: any) => {
  const font = {
    size_5: 5 + size,
    size_6: 6 + size,
    size_7: 7 + size,
    size_8: 8 + size,
    size_9: 9 + size,
    size_10: 10 + size,
    size_11: 11 + size,
    size_12: 12 + size,
    size_13: 13 + size,
    size_14: 14 + size,
    size_15: 15 + size,
    size_16: 16 + size,
    size_17: 17 + size,
    size_18: 18 + size,
    size_19: 19 + size,
    size_20: 20 + size,
    size_21: 21 + size,
    size_22: 22 + size,
    size_23: 23 + size,
    size_24: 24 + size,
    size_25: 25 + size,
    size_26: 26 + size,
    size_27: 27 + size,
    size_28: 28 + size,
    size_29: 29 + size,
    size_30: 30 + size,
  };
  return {font};
};

export default FontSize;

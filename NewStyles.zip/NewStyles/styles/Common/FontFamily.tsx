export const font_Family = {
  medium: 'Rubik-Medium',
  regular: 'Rubik-Regular',
  light: 'Rubik-Light',
  bold: 'Rubik-Bold',
  black: 'Rubik-Black',
  extrabold: 'Rubik-ExtraBold',
  semibold: 'Rubik-SemiBold',
};

import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function WatchlistHeaderStyle() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const watchlistheader = StyleSheet.create({
    container: {
      flexDirection: 'row',
      height: Dimensions.get('window').width * 0.146,
      paddingTop: 8,
      //  justifyContent:'flex-end',
      backgroundColor: root.color_active,
      // backgroundColor:'yellow'
    },
    image: {
      height: 20,
      width: 20,
    },
    titleconstainer: {flexDirection: 'row', paddingHorizontal: 40},
    titleText: {
      top: -2.5,
      fontFamily: font_Family.medium,
      fontSize: font.size_14,
      color: root.color_text,

      // paddingHorizontal: 40,
    },
    titleText_12: {
      // top: -2.5,
      fontFamily: font_Family.regular,
      fontSize: font.size_12,
      color: root.color_text,
    },
    changePercentage: {
      // color: colors.bright_green,
      top: -2.5,
      marginRight: 4,
      fontFamily: font_Family.regular,
      fontSize: font.size_11,
      color: root.color_positive,
      alignSelf: 'center',
      // backgroundColor:root.color_positive_rgb
    },
    changePercentageminus: {
      // color: colors.bright_green,
      top: -2.5,
      marginRight: 4,
      fontFamily: font_Family.regular,
      fontSize: font.size_11,
      color: root.color_negative,
      alignSelf: 'center',
      // backgroundColor:root.color_negative_rgb
    },
    headerLeft: {
      flex: 0.65,
      height: Dimensions.get('window').width * 0.121,
      backgroundColor: root.color_active,
      justifyContent: 'center',
      alignItems: 'center',
    },
    headerMiddle: {
      flex: 4,
      height: Dimensions.get('window').width * 0.121,
      backgroundColor: root.color_active,
      alignItems: 'center',
    },
    headerRight: {
      flex: 1,
      height: Dimensions.get('window').width * 0.121,
      backgroundColor: root.color_active,
      justifyContent: 'space-around',
      alignItems: 'center',
    },
    midtxt: {
      alignItems: 'center',
      borderRightWidth: 1,
      borderRightColor: '#E0E0E0',
      padding: 0,
      top: -4,
    },
    headercon: {
      alignItems: 'center',
      // borderRightWidth: 1,
      borderRightColor: '#E0E0E0',
      height: Dimensions.get('window').width * 0.121,
    },
    rupeicon: {
      height: 16,
      width: 16,
      color: 'red',
    },
  });

  return {watchlistheader};
}

import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function FooterStyle() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const FooterStyles = StyleSheet.create({
    footerContainer: {
      padding: 16,
      flexDirection: 'row',
      justifyContent: 'space-between',
      backgroundColor: root.color_active,
    },
    itemContainer: {
      paddingHorizontal: 12,
      paddingVertical: 4,
    },
    text: {
      fontSize: font.size_10,
      color: root.color_textual,
      fontFamily: font_Family.medium,
    },
    cliper: {
      borderRadius: 16,
    },
  });

  return {FooterStyles};
}

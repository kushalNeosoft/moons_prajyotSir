import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function ProfileStyles() {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme(colorMode);
  const {font} = FontSize(fontSize);
  const Profile = StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
    },
    headerContainer: {
      backgroundColor: root.color_active,
      shadowColor: 'black',
      shadowOffset: {
        width: 0,
        height: 4,
      },
      shadowOpacity: 0.3,
      shadowRadius: 4.65,

      elevation: 8,
    },
    userContainer: {
      flexDirection: 'row',
      padding: 26,
    },
    userProfilePic: {
      width: 64,
      height: 64,
      backgroundColor: 'gray',
      borderRadius: 32,
    },
    userInfoContainer: {
      // flex: 1,
      marginLeft: 16,
    },
    userName: {
      fontSize: 16,
      color: root.color_text,
      fontFamily: font_Family.medium,
      marginTop: 9,
    },
    userId: {
      fontSize: font.size_14,
      color: root.color_text,
      fontFamily: font_Family.medium,
    },
    userIdName: {
      fontSize: font.size_14,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    switchAccountContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    switchAccount: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
    },
    dropDownIcon: {
      height: 24,
      width: 24,
      color: root.color_text,
    },
    tabContainer: {
      flexDirection: 'row',
    },
    tabItem: {
      flex: 1,
      alignItems: 'center',
    },
    itemText: {
      paddingVertical: 10,
      paddingHorizontal: 16,
      //fontWeight: 'bold',
      fontFamily: font_Family.medium,
      fontSize: 12,
    },
    itemUnderlineContainer: {
      paddingHorizontal: 16,
      height: 2,
      width: '100%',
    },
    itemUnderline: {
      height: 2,
      flex: 1,
      width: '100%',
    },
    bodyContainer: {
      padding: 16,
      flex: 1,
      backgroundColor: root.color_active,
    },
  });

  return {Profile};
}

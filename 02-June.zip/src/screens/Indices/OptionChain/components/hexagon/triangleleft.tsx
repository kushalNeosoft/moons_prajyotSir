import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import { root } from '../../../../../styles/colors';

const TriangleLeft = (props:any) => {
  return <View style={[styles.triangle, props.style]} />;
};

const styles = StyleSheet.create({
  triangle: {
    width: 0,
    height: 0,
    left:4,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 15,
    borderRightWidth: 15,
    borderBottomWidth: 22,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: root.color_text,
    transform:[{rotate:'-90deg'}],
  },
});

export default TriangleLeft;

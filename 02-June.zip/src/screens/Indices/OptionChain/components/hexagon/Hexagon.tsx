import React from 'react';
import {View, StyleSheet, Text} from 'react-native';
import TriangleLeft from './triangleleft';
import TriangleRight from './triangleRight';
import { root } from '../../../../../styles/colors';

const Hexagon = (props: any) => {
  return (
    <View style={styles.hexagon}>
      <View style={styles.dashedLine} />
      <TriangleLeft />
      <View style={styles.hexagonInner}>
        <Text style={{alignSelf: 'center', color: root.color_active_text}}>
          1.5
        </Text>
      </View>
      <TriangleRight />
    </View>
  );
};

const styles = StyleSheet.create({
  hexagon: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems:"center"
  },
  hexagonInner: {
    width: 80,
    height: 30,
    backgroundColor: root.color_text,
    justifyContent:'center',
  },
  hexagonAfter: {
    position: 'absolute',
    bottom: -25,
    left: 0,
    width: 0,
    height: 0,
    borderStyle: 'solid',
    borderLeftWidth: 50,
    borderLeftColor: 'transparent',
    borderRightWidth: 50,
    borderRightColor: 'transparent',
    borderTopWidth: 25,
    borderTopColor: 'red',
  },
  dashedLine: {
    width: '100%',
    position: 'absolute',
    top: 14,
    borderWidth: 0.5,
    borderStyle: 'dashed',
    borderColor:root.color_text,
  },
});

export default Hexagon;

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {positionModalButton} from '../../../../theme/light';

const PositionModalBtn = props => {
  return (
    <TouchableOpacity
      style={{...positionModalButton.conatiner, ...props.style}}
      onPress={props.onPress}>
      <Text style={positionModalButton.btnText}>{props.title}</Text>
    </TouchableOpacity>
  );
};
export default PositionModalBtn;

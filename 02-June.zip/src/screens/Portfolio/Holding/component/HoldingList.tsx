import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {holdingListComp} from '../../../../theme/light';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import {holdingBottomModal} from '../../../../theme/light';
import BuySellButton from './BuySellButton';
import AntDesign from 'react-native-vector-icons/AntDesign';

const HoldingList = props => {
  const [visibleModal, setVisibleModal] = useState(false);
  const [additionalDetails, setAdditionalDetails] = useState(false);
  return (
    // <View style={{}}>
    <>
      <TouchableOpacity
        style={holdingListComp.container}
        onPress={() => {
          // openModal();
          setVisibleModal(true);
        }}>
        <View>
          <Text style={holdingListComp.listTitle}>{props.stockName}</Text>
          <Text style={holdingListComp.listSubTitle}>{props.stockTtile}</Text>
        </View>
        <View style={holdingListComp.listPlLtpView}>
          <View style={{flexDirection: 'row'}}>
            <Text style={holdingListComp.listLtpText}>LTP : </Text>
            <Text style={holdingListComp.listLtpValue}>{props.LTP}</Text>
          </View>
          <View style={{flexDirection: 'row'}}>
            <Text style={holdingListComp.listPlText}>P/L : </Text>
            <Text style={holdingListComp.listPlValue}>{props.PL}</Text>
          </View>
        </View>
      </TouchableOpacity>

      <CommonModal
        visible={visibleModal}
        onClose={() => {
          setVisibleModal(false);
          setAdditionalDetails(false);
        }}>
        <View style={holdingBottomModal.modalView}>
          <Text style={holdingBottomModal.stockName}>{props.stockName}</Text>
          <View style={holdingBottomModal.stockDetailsView}>
            <View>
              <Text style={holdingBottomModal.stockTitle}>
                {props.stockTtile}
              </Text>
              <View style={{flexDirection: 'row'}}>
                <Text style={holdingBottomModal.stockDetailsText}>
                  Today's P/L :{' '}
                </Text>
                <Text style={holdingBottomModal.stockDetailsValue}>
                  {props.PL}
                </Text>
              </View>
              <View style={{flexDirection: 'row'}}>
                <Text style={holdingBottomModal.stockDetailsText}>
                  Invested :{' '}
                </Text>
                <Text style={holdingBottomModal.stockTitle}>
                  {props.invested}
                </Text>
              </View>
            </View>
            <View>
              <View style={{flexDirection: 'row'}}>
                <Text style={holdingBottomModal.stockDetailsText}>LTP : </Text>
                <Text style={holdingBottomModal.stockDetailsValue}>
                  {props.LTP}{' '}
                </Text>
              </View>
              <View style={{flexDirection: 'row'}}>
                <Text style={holdingBottomModal.stockDetailsText}>P/L : </Text>
                <Text style={holdingBottomModal.stockDetailsValue}>
                  {props.PL}
                </Text>
              </View>
              <View style={{flexDirection: 'row'}}>
                <Text style={holdingBottomModal.stockDetailsText}>CMV : </Text>
                <Text style={holdingBottomModal.stockTitle}>{props.cmv}</Text>
              </View>
            </View>
          </View>
          <View>
            <TouchableOpacity
              onPress={() => {
                setAdditionalDetails(!additionalDetails);
              }}>
              <View style={holdingBottomModal.additionalTextIconView}>
                <Text style={holdingBottomModal.additionalDetailsText}>
                  Additional Details
                </Text>
                {additionalDetails === false ? (
                  <AntDesign
                    name="caretdown"
                    size={10}
                    color="#303030"
                    style={holdingBottomModal.upDownIcon}
                  />
                ) : (
                  <AntDesign
                    name="caretup"
                    size={10}
                    color="#303030"
                    style={holdingBottomModal.upDownIcon}
                  />
                )}
              </View>
            </TouchableOpacity>
            {additionalDetails ? (
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: 28,
                  marginTop: 22,
                }}>
                <View>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Stocks
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Today's
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Receivable
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Pool
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    DP
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Available
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Pledged
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Blocked
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Free
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
              </View>
            ) : (
              <View style={{height: 33}}></View>
            )}
          </View>
          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <BuySellButton title={'Buy'} style={{flex: 0.48}} />
            <BuySellButton title={'Sell'} style={{flex: 0.48}} />
          </View>
        </View>
      </CommonModal>
    </>
    // </View>
  );
};
export default HoldingList;

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';

import { dateEventComp } from '../../../theme/light';

const DateEventComponent = props => {
  return (
    <TouchableOpacity style={dateEventComp.container}>
      <View>
        <Text style={dateEventComp.title}>{props.title}</Text>
        <Text style={dateEventComp.subTitle}>{props.subTitle}</Text>
      </View>
      <SimpleLineIcons
        name="arrow-right-circle"
        size={21}
        color={'black'}
        style={{paddingRight: 15}}
      />
    </TouchableOpacity>
  );
};
export default DateEventComponent;

import React from "react";
import { View,Text } from "react-native";

const TestScreen=()=>{
    return(
       <View>
        <Text style={{fontSize:50,backgroundColor:"yellow"}}>
            New Screen Log
        </Text>
       </View>
    )
}
export default TestScreen;
import React from "react";
import { View,Text } from "react-native";
import CommonModal from "../../../../components/CommonModal/CommonModal";

export const DateModal=(props: any)=>{
    console.log(props,"MAMAMAMAm----->");
    
    return(
        <CommonModal visible={props.visible} onClose={props.onClose}>
            <View style={{width:"100%",backgroundColor:'red'}}>
                <Text>Iam date Modal{props.day}</Text>
            </View>

        </CommonModal>
    )
}
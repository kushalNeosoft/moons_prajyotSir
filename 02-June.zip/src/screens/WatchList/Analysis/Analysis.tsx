import React, { useState } from "react";
import { ScrollView, Text, View } from "react-native";
import { Analysisstyle } from "../../../theme/light";

const Analysis: React.FC =({route}: any)=>{
    const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);
    return(
        <ScrollView
      style={Analysisstyle.maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
        <View style={Analysisstyle.innercon} />

      </ScrollView>
    )
}

export default Analysis;
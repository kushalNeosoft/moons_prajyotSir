import React, {useState} from 'react';
import {
  View,
  Modal,
  StyleSheet,
  TouchableOpacity,
  Text,
  FlatList,
} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../../../../styles/colors';
import {RadioButton} from 'react-native-paper';

const FundsModal = (props: any) => {
  const [account, setAccount] = useState<string>(props.account);

  const setAccountAndClose = (value: string) => {
    props.setCurrentAccount(value)
    setAccount(value);
    props.onClose();
  };

  const renderAccounts = ({item}: any) => {
    return (
      <TouchableOpacity
        style={styles.accountsContainer}
        onPress={() => setAccountAndClose(item.name)}>
        <View style={styles.selectAccount}>
          <RadioButton
            color={root.color_text}
            value={item.name}
            onPress={() => setAccount(item.name)}
            status={account == item.name ? 'checked' : 'unchecked'}
          />
          <Text style={styles.name}>{item.name}</Text>
        </View>
      </TouchableOpacity>
    );
  };
  return (
    <Modal
      visible={props.visible}
      transparent={true}
      onRequestClose={() => props.onClose()}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={styles.modalView}>
        <View style={styles.headerView}>
          <Text style={styles.accountsTxt}>Accounts</Text>
          <AntDesign name="close" size={24} color={'black'} />
        </View>
        <FlatList
          data={props.data}
          renderItem={renderAccounts}
          style={styles.accountList}
          showsVerticalScrollIndicator={false}
          scrollEnabled={false}
        />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: '38.5%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  headerView: {
    ...alignment.row_SpaceB,
  },
  accountsTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  accountsContainer: {
    ...alignment.row_SpaceB,
    height: 48,
    alignItems: 'center',
  },
  selectAccount: {
    ...alignment.row,
    alignItems: 'center',
  },
  name: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_text,
  },
  accountList: {
    marginTop: 24,
  },
});

export default FundsModal;

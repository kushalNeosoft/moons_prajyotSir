export const multiLegOpenOrders=[];
export const multiLegCloseOrders=[];
export const multiLegAllOrders=[
    {
        name:'BAJAJFINSV',
        date:"25 MAY'23 FUT",
        time:'11:58:07 AM',
        leg:2
    }
];
import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { equitySipCard } from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { styles } from '../../../navigators/Curverbottom';

const EquityCard = (props: any) => {
  return (
    <View style={equitySipCard.container}>
      <View style={equitySipCard.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={equitySipCard.companyNameTxt}>{props.name}</Text>
            <Text style={equitySipCard.nseTxt}>NSE</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center'}}>
            <Text style={equitySipCard.buyTxt}>Buy : </Text>
            <Text style={equitySipCard.buyQty}>{props.buy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center'}}>
            <Text style={equitySipCard.frequenctTxt}>{props.frequency}</Text>
            <Text style={equitySipCard.eqSIP}>EQ SIP</Text>
          </View>
        </View>
        <View style={{justifyContent: 'space-around',alignItems:'flex-end'}}>
          <View style={{...alignment.row,alignItems:"center"}}>
          <Text style={equitySipCard.activeTxt}>Active</Text>
          <Ionicons name="md-at-circle-outline" size={15} style={{paddingLeft:5}}/>
          </View>
          <Text style={equitySipCard.installMent}>{props.installments}</Text>
          <Text style={equitySipCard.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};

export default EquityCard;

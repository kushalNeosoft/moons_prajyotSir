import React from 'react';
import {TouchableOpacity} from 'react-native-gesture-handler';
import SingleScriptCard from '../Card/SingleScriptCard';
import EquityCard from '../Card/EquitySip';
import SpreadOrdersCard from '../Card/SpreadOrders';
import MultiLegCard from '../Card/MultiLeg';
import GoodTillDateCard from '../Card/GoodTillDate';
import {View} from 'react-native';

const RenderCardView = (props: any) => {
  const renderCardView = (item: any, scriptName: any) => {
    switch (scriptName) {
      case 'Single Script Orders':
        return (
          <TouchableOpacity onPress={() => props.openSheet(item)}>
            <SingleScriptCard
              name={item.name}
              buy={item.buy}
              quantity={item.quantity}
              time={item.time}
              ltp={item.ltp}
              bought={item.bought}
            />
          </TouchableOpacity>
        );
      case 'Equity SIP':
        return (
          <TouchableOpacity onPress={() => props.openSheet(item)}>
            <EquityCard
              name={item.name}
              buy={item.buy}
              frequency={item.frequency}
              installments={item.installments}
              ltp={item.ltp}
            />
          </TouchableOpacity>
        );
      case 'Spread Orders':
        return (
          <TouchableOpacity onPress={() => props.openSheet(item)}>
            <SpreadOrdersCard
              name={item.name}
              timePeriod={item.timePeriod}
              sellBuy={item.sellBuy}
              quantity={item.qty}
              ltp={item.ltp}
              time={item.time}
            />
          </TouchableOpacity>
        );
      case 'Multileg Orders':
        return (
          <TouchableOpacity onPress={() => props.openSheet(item)}>
            <MultiLegCard
              name={item.name}
              time={item.time}
              date={item.date}
              leg={item.leg}
            />
          </TouchableOpacity>
        );
      case 'Good Till Date':
        return (
          <TouchableOpacity onPress={() => props.openSheet(item)}>
            <GoodTillDateCard
              name={item.name}
              buy={item.buy}
              quantity={item.qty}
              ltp={item.ltp}
              validity={item.validity}
            />
          </TouchableOpacity>
        );
      default:
        return null;
    }
  };
  return <View>{renderCardView(props.item, props.scriptName)}</View>;
};

export default RenderCardView;

export enum LoginAction {
  UPDATE_EMAIL = 'update_email',
  UPDATE_PASSWORD = 'update_password',
  UPDATE_ERROR = 'update_error',
 
}
interface LoginModel {
  email?: string;
  password?: string;
  error?: {
    email?: string;
    password?: string;
  };
}
interface LoginActionModel {
  payload: {
    email?: string;
    password?: string;
    
    error?: {
      email: string;
      password: string;
    };
  };
  type?: LoginAction;
}
export const loginReducer = (login: any, action: LoginActionModel) => {
  switch (action.type) {
    case LoginAction.UPDATE_EMAIL:
      return {
        ...login,
        email: action.payload.email,
        error: {
          ...login.error,
          email: null,
        },
      };
    case LoginAction.UPDATE_PASSWORD:
      return {
        ...login,
        password: action.payload.password,
        error: {
          ...login.error,
          password: null,
        },
      };

    case LoginAction.UPDATE_ERROR:
      return {
        ...login,
        error: action.payload.error,
      };

      
  }
};

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {Cfont, Font, root} from '../../../../styles/colors';

const CancelList = (props: any) => {
  const clicked =
    props.selectedItems.findIndex(
      (itm: {id: any}) => itm.id == props.item.id,
    ) != -1;
  return (
    <>
      <TouchableOpacity
        style={[
          cancelList.container,
          {
            backgroundColor: clicked
              ? 'rgba(211, 47, 47, 0.15)'
              : root.color_active,
          },
        ]}
        onPress={() => {
          props.onPress(props.item);
        }}>
        <View style={{alignItems: 'flex-start'}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
            }}>
            <Text style={cancelList.listTitle}>{props.stockName}</Text>
            <View style={cancelList.titleChip}>
              <Text style={cancelList.titleChipText}>{props.titleChip}</Text>
            </View>
          </View>
          <Text style={cancelList.expiry}>{props.expiry}</Text>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingTop: 5,
            }}>
            <Text style={cancelList.buyText}>{props.status} </Text>
            <Text style={cancelList.buyQty}>{`${props.buy} (Open : 3000 Qty)`}</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              paddingTop: 5,
            }}>
            <Text style={cancelList.timeDate}>{`${props.time}, ${props.date}`}</Text>
            <View style={cancelList.bottomChip}>
              <Text style={cancelList.bottomChipText}>{props.bottomChip}</Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingLeft:5
              }}>
              <Text style={cancelList.ltpTxt}>LTP : </Text>
              <Text style={cancelList.ltpValue}>{props.LTP}</Text>
            </View>
          </View>
        </View>
        <View style={cancelList.listPlLtpView}>
          {clicked === true ? (
            <AntDesign name="checksquare" style={cancelList.selectAllIcon} />
          ) : (
            <MaterialIcons
              name="check-box-outline-blank"
              style={cancelList.selectAllIcon}
            />
          )}
        </View>
      </TouchableOpacity>
    </>
  );
};

const cancelList = StyleSheet.create({
  container: {
    padding: 3,
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 120,
    width: '100%',
    alignSelf: 'center',
    paddingTop: 15,
    paddingHorizontal: 16,
  },
  listTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_fifteen,
    marginTop: 4,
  },
  titleChip: {
    marginLeft: 5,
    backgroundColor: 'rgba(151,151,151,0.1)',
    borderRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  titleChipText: {
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
    color: '#979797',
  },
  buyText: {
    color: root.color_positive,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
  },
  listSubTitle: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  bottomChip: {
    backgroundColor: '#25335C33',
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 2,
    paddingHorizontal: 4,
    marginLeft:5
  },
  bottomChipText: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
  },
  listPlLtpView: {
    alignItems: 'flex-end',
  },
  listPlText: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 4,
  },
  listPlValue: {
    fontSize: Font.font_normal_six,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    marginTop: 4,
  },
  listLtpText: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 4,
  },
  listLtpValue: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 4,
  },
  selectAllIcon: {
    color: root.color_text,
    fontSize: 24,
  },
  expiry: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
    paddingTop: 5,
  },
  timeDate:{
    fontFamily:Cfont.rubik_light,
    fontSize:10,
    color:root.color_text
  },
  ltpTxt:{
    fontFamily:Cfont.rubik_medium,
    color:root.color_text,
    fontSize:12
  },
  ltpValue:{
    fontFamily:Cfont.rubik_regular,
    fontSize:12,
    color:root.color_text
  },
  buyQty:{
    fontFamily:Cfont.rubik_regular,
    fontSize:12,
    color:root.color_text
  }
});
export default CancelList;

import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {Pressable} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {root} from '../../styles/colors';

const Backarrowbutton = (props: any) => {
    
    
  const navigation = useNavigation();

  return (
    <Pressable
      onPress={
        props.onClose == undefined ? () => navigation.goBack() : props.onClose
      }>
      <Ionicons
        name="arrow-back"
        size={props.size}
        color={root.color_text}
        {...props}
      />
    </Pressable>
  );
};

export default Backarrowbutton;

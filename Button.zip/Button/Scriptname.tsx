import {useRoute} from '@react-navigation/native';
import React from 'react';
import {Text, View} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  Allstyle,
  constituentsListComponent,
  watchlistdata,
} from '../../theme/light';
import alignment from '../utils/alignment';

const Scriptname = (props: any) => {  
  const route = useRoute();
  return (
    <>
      {route.name == 'All' ||
      route.name == 'Equity' ||
      route.name == 'Commodity' ||
      route.name == 'Currency'||
      route.name == 'Options' ? (
        <>
          <View key={props.data?.id}>
            <Text style={Allstyle.tittxtstyle}>{props.data?.companyName} EQ</Text>
            <View style={Allstyle.innercontainer}>
              <Text style={Allstyle.nsetxt}>{props.data?.nindex}</Text>
              <Text style={Allstyle.banktxt}>STATE BANK OF INDIA</Text>
            </View>
          </View>
        </>
      ) : (
        <>
          <View
            style={{
              flex: 2,
              height: 36,
              // flexDirection: 'row',
              // backgroundColor:'red'
            }}>
            <View style={{flexDirection: 'row'}}>
              <Text style={constituentsListComponent.stockName}>
                {props.data?.stockName}
              </Text>
              <Text style={constituentsListComponent.nseTxt}>
                {props.data?.nindex}
              </Text>
              {props.data?.screenName === 'WatchList' ? (
                <Text style={watchlistdata.Atxt}>A</Text>
              ) : null}
            </View>
            {props.data?.future === true ? (
              <>
                {props.data?.date.value === '' ? (
                  <>
                    <View style={{...alignment.row}}>
                      <Text style={constituentsListComponent.future}>
                        {props.data?.date.day}
                      </Text>
                      <Text style={constituentsListComponent.future}>
                        {props.data?.date.strickprice}{' '}
                        {props.data?.date.optiontype}
                      </Text>
                    </View>
                  </>
                ) : (
                  <>
                    <View style={{...alignment.row}}>
                      <Text style={constituentsListComponent.future}>
                        {props.data?.date.day}
                      </Text>
                      <Text style={constituentsListComponent.future}>
                        {props.data?.date.value}
                      </Text>
                    </View>
                  </>
                )}
              </>
            ) : (
              <View style={{...alignment.row}}>
                {props.data?.showIcon === true ? (
                  <MaterialCommunityIcons
                    name="crown-circle"
                    size={16}
                    color="#ffd700"
                  />
                ) : null}
                {props.data?.showIcon === true ? (
                  <Text
                    style={
                      props.data?.title === 'Vol.Gainer'
                        ? constituentsListComponent.volGainerTxt
                        : props.data?.title === 'Pr.Loser'
                        ? constituentsListComponent.prLoserTxt
                        : constituentsListComponent.defaultTxt
                    }>
                    {props.data?.title}
                  </Text>
                ) : null}
              </View>
            )}
          </View>
        </>
      )}
    </>
  );
};

export default Scriptname;

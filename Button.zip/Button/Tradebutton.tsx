import {useNavigation} from '@react-navigation/native';
import React from 'react';

import {Text, TouchableOpacity, StyleSheet, Pressable} from 'react-native';
import alignment from '../utils/alignment';
import {root} from '../../styles/colors';

function Tradebutton(props: any) {
  const navigation = useNavigation();
  return (
    <Pressable
      style={styles.bottonView}
      onPress={() => {
        navigation.navigate('BuySell', {
          item: props,
        });
      }}>
      <Text style={{fontWeight: 'bold', color: root.color_text}}>T</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  bottonView: {
    borderColor: root.color_text,
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
});

export default Tradebutton;

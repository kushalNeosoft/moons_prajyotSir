import {useNavigation} from '@react-navigation/native';
import React from 'react';
import {View, TouchableOpacity,Pressable} from 'react-native';
import {MenuIcon} from '../Svg/Svg';

const Menubutton = () => {
  const navigation = useNavigation<any>();

  return (
    <Pressable onPress={() => navigation.toggleDrawer()}>
      <MenuIcon />
    </Pressable>
  );
};

export default Menubutton;

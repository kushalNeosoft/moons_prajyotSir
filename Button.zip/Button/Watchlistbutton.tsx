import React from 'react';

import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../styles/colors';

const Watchlistbutton = (props: any) => {
  return (
    <TouchableOpacity
      style={{marginTop: 5, marginLeft: 5}}
      onPress={() => props?.data.addToScripts(props.index, props.stockName, true)}>
      <AntDesign
        name="pluscircleo"
        size={26}
        color={root.color_text}
        {...props}
      />
    </TouchableOpacity>
  );
};

export default Watchlistbutton;

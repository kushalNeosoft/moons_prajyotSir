import { useNavigation } from '@react-navigation/native';
import React from 'react';
import {Pressable} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {root} from '../../styles/colors';

const Crossbutton = (props: any) => {
  const navigation = useNavigation();
  return (
    <Pressable onPress={props.onClose == undefined ? () => navigation.goBack() : props.onClose}>
      <Entypo
        name="cross"
        size={props.size}
        color={root.color_text}
        {...props}
      />
    </Pressable>
  );
};

export default Crossbutton;

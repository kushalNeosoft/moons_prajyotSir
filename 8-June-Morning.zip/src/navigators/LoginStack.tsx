import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../screens/Login/LoginScreen';
import {FC, useEffect} from 'react';
import React from 'react';
import {useColorScheme} from 'react-native';
import Colors from '../styles/colors';
import useColors from '../styles/useColors';
import SignupScreen from '../screens/Signup/SignupScreen';
import ProfileScreen from '../screens/Profile/ProfileScreen';
import ForgotPasswordScreen from '../screens/ForgotPassword/ForgotPasswordScreen';
import PhoneVerificationScreen from '../screens/PhoneVerification/PhoneVerificationScreen';
import {useSelector} from 'react-redux';
import ForgotMpin from '../screens/ForgotPassword/ForgotMpin';

const LogStack = createStackNavigator();

const LoginStack: FC = () => {
  const {colors, applyColors} = useColors();
  const colorScheme = useColorScheme();
  const newLog = useSelector(state => state.Login.firsttime);

  useEffect(() => {
    applyColors(colorScheme === 'dark' ? Colors.dark : Colors.light);
  }, [applyColors, colorScheme]);

  return (
    <LogStack.Navigator screenOptions={{headerShown: false}}>
      {newLog ? (
        <>
          <LogStack.Screen name="LoginScreen" component={LoginScreen} />
        </>
      ) : (
        <>
          <LogStack.Screen name="LoginScreen" component={LoginScreen} />
        </>
      )}

      <LogStack.Screen
        name="ForgotPasswordScreen"
        component={ForgotPasswordScreen}
      />

      {/* <LogStack.Screen name="ProfileScreen" component={ProfileScreen} /> */}
      <LogStack.Screen name="SignupScreen" component={SignupScreen} />
      <LogStack.Screen
        name="PhoneVerificationScreen"
        component={PhoneVerificationScreen}
      />
      <LogStack.Screen name="ForgotMpin" component={ForgotMpin} />
    </LogStack.Navigator>
  );
};

export default LoginStack;

import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Holdings from '../../screens/Portfolio/Holding/Holdings';
import Positions from '../../screens/Portfolio/Position/Positions';
import {portFolioScreen} from '../../theme/light';

const Tab = createMaterialTopTabNavigator();

function AnimatedTopBar({bottomSheetRef}) {
  return (
    <Tab.Navigator
      //   scrollEnabled={true}
      screenOptions={{
        // tabBarScrollEnabled: true,
        lazy: true,
        tabBarLabelStyle: portFolioScreen.tabBarLabelStyle,
        tabBarStyle: portFolioScreen.tabBarStyle,
        tabBarIndicatorStyle: portFolioScreen.tabBarIndicatorStyle,
      }}>
      <Tab.Screen
        name="Holdings"
        // component={Holdings}
        children={props => (
          <Holdings {...props} bottomSheetRef={bottomSheetRef} />
        )}
        options={{tabBarLabel: 'Holdings'}}
      />
      <Tab.Screen
        name="Positions"
        component={Positions}
        options={{tabBarLabel: 'Positions'}}
      />
    </Tab.Navigator>
  );
}
export default AnimatedTopBar;

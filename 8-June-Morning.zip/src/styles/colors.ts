export type ColorTheme = {
  primary: string;
  secondary: string;
  textSecondary: string;
  textPrimary: string;
  background: string;
  cardColor: string;
};

const sharedColors = {
  black: '#000000',
  white: '#FFFFFF',
};

type SharedColors = typeof sharedColors;

export type TColors = ColorTheme & SharedColors;

type ColorPalettes = {
  red: any | ColorValue | undefined;
  bright_green: any | ColorValue | undefined;
  black: ColorValue | undefined;
  white: ColorValue | undefined;
  light: TColors;
  dark: TColors;
};

const Colors: ColorPalettes = {
  dark: {
    primary: '#3F51B5',
    secondary: '#161629',
    textPrimary: sharedColors.white,
    textSecondary: '#67686E',
    background: '#1f1f1f',
    cardColor: '#37474F',
    ...sharedColors,
  },
  light: {
    primary: '#3F51B5',
    secondary: '#E4E4E4',
    textPrimary: '#161629',
    textSecondary: '#9D5DB0',
    background: '#f2f2f2',
    cardColor: '#FFFFFF',
    ...sharedColors,
  },
};

export default Colors;

export const root = {
  color_primary: '#fffffff',
  color_active: '#FFFFFF',
  client_background: '#25335c',
  ipo_btn_backgrougd: '#f6f6f6',
  color_text: '#303030',
  color_subtext: '#979797',
  color_active_text: '#ffffff',
  color_signup_rap_background: '#1f1f1f',
  signup_wrap_subtitle: '#999999',
  color_textual: '#25335C',
  ion_rb_2: '#000000',
  color_border: '#ebebeb',
  backgroung_exchange_chip_color: '#9797971A',
  color_disable: '#ffffff',
  choose_indices_background: '#1E1E1E',
  dropdown_background: 'rgba(151,151,151,0.1)',
  chip_primary:'#9AB3FF33',
  color_positive_step_100:'#3DB943',
  color_positive_step_50:'#408E41',

  // Market Screen colors
  indices_red: '#FE0000',
  calendar_bg: '#F5F7FA',

  // watchList
  color_positive: '#4caf50',
  color_positive_rgb: 'rgba(76,175,80,0.15)',
  color_negative: '#d32f2f',
  color_negative_rgb: 'rgba(211,47,47,0.15)',
};

export const Font = {
  font_title: 30,
  font_sub_title: 28,
  font_normal_one: 12,
  font_normal_two: 14,
  font_normal_three: 16,
  font_normal_four: 18,
  font_normal_five: 13,
  font_normal_six: 10,
  font_normal_seven: 11,
  font_normal_eight: 9,
  font_normal_ten: 17,
  font_normal_fifteen: 15,
  font_normal_twenty_six: 26,
  font_normal_twenty_four: 24,
  font_normal_twenty_two: 22,
  font_normal_twenty_one: 21,
};
export const Cfont = {
  rubik_medium: 'Rubik-Medium',
  rubik_regular: 'Rubik-Regular',
  rubik_light: 'Rubik-Light',
  rubik_bold: 'Rubik-Bold',
  rubik_black: 'Rubik-Black',
  rubik_extrabold: 'Rubik-ExtraBold',
  rubik_semibold: 'Rubik-SemiBold',
};

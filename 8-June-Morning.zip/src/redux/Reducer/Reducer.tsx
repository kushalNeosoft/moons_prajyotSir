import {
  REGISTER_DATA,
  REGISTER_RANDOM_DATA,
  UPDATE_DATA,
  CHECK_INTERNET,
  SET_APP_STATE,
  REORDER_LIST,
  LOGIN_STATE,
  LOGIN_FAIL,
  LOGIN_SUCESS,
  BOTTOM_TAB_SHOW_HIDE,
  BOTTOMSHEET_SHOW_HIDE,
  GET_SHEET_DATA,
  GET_SCRIPT_NAME,
  ADD_REMOVE_STOCK,
} from '../actionTypes';

const initialState = {
  usersData: [],
  randomData: [],
  isConnected: false,
  priviousAppState: null,
  currentAppState: null,
  isLoggedIn: false,
  logging: false,
  currentUser: undefined,
  error: '',
  username: '',
  reorderList: [],
  isBottmtabShow: true,
  isBottomSheetShow: false,
  bottomSheetData: null,
  scriptName: '',
  favouritesStock: [],
};

const Reducer = (
  state = initialState,
  action: {
    type: any;
    payload: {
      username: any;
      email: any;
    };
    data: any;
  },
) => {
  switch (action.type) {
    case LOGIN_STATE:
      return {
        ...state,
        username: action.data,
        isLoggedIn: true,
      };
    case REGISTER_DATA:
      return {
        ...state,
        usersData: [...state.usersData, {...action.data}],
      };
    case REGISTER_RANDOM_DATA:
      return {
        ...state,
        randomData: action.data,
      };
    case UPDATE_DATA: {
      let updatedUserDetails = state.randomData.map(user => {
        // if (user.id === action.userId) {
        //   // console.log('userIdMatch', action.userId, 'count', action.payload);
        //   return {
        //     ...user,
        //     count: action.payload,
        //   };
        // } else {
        //   // console.log('userIdMisMatch', user.id, 'count', user.count);
        //   return user;
        // }
        return {
          ...user,
          count: user.count + 1,
        };
      });

      return {
        ...state,
        randomData: updatedUserDetails,
      };
    }
    case CHECK_INTERNET:
      return {
        ...state,
        isConnected: action.data,
      };
    case SET_APP_STATE:
      return {
        ...state,
        priviousAppState: state.currentAppState,
        currentAppState: action.data,
      };
    case REORDER_LIST:
      return {
        ...state,
        reorderList: action.data,
      };
    case BOTTOM_TAB_SHOW_HIDE:
      console.log('Data in switch', action);
      return {
        ...state,
        isBottmtabShow: action.payload,
      };
    case BOTTOMSHEET_SHOW_HIDE:
      return {
        ...state,
        isBottomSheetShow: action.payload,
      };
    case GET_SHEET_DATA:
      return {
        ...state,
        bottomSheetData: action.payload,
      };
    case GET_SCRIPT_NAME:
      return {
        ...state,
        scriptName: action.payload,
      };
    case ADD_REMOVE_STOCK: {
      let arr = [...state.favouritesStock];

      console.log('MY ARR', arr, action.payload);

      let idx = arr.findIndex(
        (itm, idx) => action.payload.indexId == itm.indexId,
      );

      if (idx == -1) {
        arr.push(action.payload);
      } else {
        arr = arr.filter((itm, idx) => action.payload.indexId != itm.indexId);
      }

      return {
        ...state,
        favouritesStock: [...arr],
      };
    }

    default:
      return state;
  }
};

export default Reducer;

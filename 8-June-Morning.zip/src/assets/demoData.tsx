import {duration} from 'moment';
import React from 'react';
import {Text, View} from 'react-native';

export const demoData = [
  {
    price: 827.67,
    changes: '+3.65(+0.44%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 5000,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'WIPRO',
    price: 977.7,
    changes: '+2.65(+0.54%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'HDFCBANK',
    price: 767.7,
    changes: '+5.67(+0.50%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'TCS',
    price: 890.5,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 1200,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'SBIN',
    price: 890.89,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 1800,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'BSE',
    price: 890.79,
    changes: '+2.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 300,
    plus: '[+77.06%]',
    minus: '',
  },
  {
    stockName: 'SBIN',
    price: 1098.59,
    changes: '+4.69(+0.75%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 400,
    plus: '',
    minus: '[-12.90%]',
  },
  {
    stockName: 'NTPC',
    price: 655.52,
    changes: '+1.69(+0.35%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'INFY',
    price: 789.5,
    changes: '+1.69(+0.35%)',
    portfolio: false,
    title: 'Vol.Gainer',
    stockfrom: 'NSE',
  },
  {
    stockName: 'RELIANCE',
    price: 890.5,
    changes: '+5.69(+0.45%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'BAJAJ',
    price: 870.5,
    changes: '+4.69(+0.55%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 500,
    plus: '',
    minus: '[-10.90%]',
  },
  {
    stockName: 'TATA',
    price: 560.5,
    changes: '+7.69(+0.90%)',
    portfolio: true,
    stockfrom: 'NSE',
    value: 800,
    plus: '',
    minus: '[-14.70%]',
  },

  {
    stockName: 'INDUSLAND',
    price: 878.5,
    changes: '+1.69(+0.20%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'ICICIBANK',
    price: 678.5,
    changes: '+4.69(+0.50%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'SBI',
    price: 678.5,
    changes: '+4.89(+0.5%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'AXIS',
    price: 767.5,
    changes: '+2.60(+0.30%)',
    portfolio: false,
    title: 'Pr.Loser',
    stockfrom: 'NSE',
  },
  {
    stockName: 'TCS',
    stockfrom: 'NSE',
    date: '25 MAY',
    tag: 'FUT',
    price: '3229.35',
    changes: '0.00(0.00)',
  },
  {
    stockName: 'TCS',
    stockfrom: 'NSE',
    date: '25 MAY',
    future: '3200.00CE',
    tag: 'FUT',
    price: '61.70',
    changes: '0.00(0.00)',
  },
];

export const courselDemodata = [
  {
    title: 'Open',
    value: '1213.45',
  },
  {
    title: 'Close',
    value: '1207.35',
  },
  {
    title: 'Daily Price Range',
    value: '1101.60-',
    valuetwo: '1346.40',
  },
];

export const progressData = [
  {
    title: 'Today (Low-High)',
    price: '1383.30',
    pricetwo: '1411.05',
  },
  {
    title: '52 Week (Low-High)',
    price: '1185.30',
    pricetwo: '1672.60',
  },
];

export const endDemodata = [
  {
    title: 'Avg Trading Price',
    value: '1394.82',
  },
  {
    title: 'Value',
    value: '120797392.35',
  },
  {
    title: 'Volume',
    value: '9844356',
  },
  {
    title: 'Last Traded Time',
    value: '15:29:59',
  },
  {
    title: 'Last Updated Time',
    value: '15:11:17',
  },
];

export const newDemodata = [
  {
    title: 'Avg Trading Price',
    value: '1394.82',
  },
  {
    title: 'Value',
    value: '120797392.35',
  },
  {
    title: 'Volume',
    value: '9844356',
  },
];

export const newsecondDemodata = [
  {
    title: 'Last Traded Qty',
    value: '23',
  },
  {
    title: 'Last Traded Time',
    value: '15:29:59',
  },
  {
    title: 'Last Updated Time',
    value: '15:11:17',
  },
];

export const marketdata = [
  {
    title: 'Market Cap',
    value: '30',
  },
];

export const eventdata = [
  {
    title: 'Board Meeting',
    data: {
      date: [
        {
          day: '09 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '10 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '11 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '12 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '13 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'Book Closure',
    data: {
      date: [
        {
          day: '09 Nov',
          year: "'21",
          duration: "15 Jun '23-26 Jun '23",
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '06 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'AGM',
    data: {
      date: [
        {
          day: '09 Nov',
          year: "'21",
          duration: "15 Jun '23-26 Jun '23",
          Gm: 'GM Date',
          Gmvalue: "26 Jun '23",
          percentage: '1800%',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'EGM',
    data: {
      date: [
        {
          day: '09 Nov',
          year: "'21",
          duration: '',
          Gm: 'GM Date',
          Gmvalue: "26 Jun '23",
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '18 Nov',
          year: "'21",
          duration: '',
          Gm: 'GM Date',
          Gmvalue: "26 Jun '23",
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '12 Nov',
          year: "'21",
          duration: '',
          Gm: 'GM Date',
          Gmvalue: "26 Jun '23",
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'Split',
    data: {
      date: [
        {
          day: '09 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'Dividend',
    data: {
      date: [
        {
          day: '18 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '1800%',
          Final: 'Final',
          Fdate: "26 Jun '23",
          Dividend_Type: 'Dividend_Type',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
        {
          day: '13 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '200%',
          Final: 'Final',
          Fdate: "6 Jun '22",
          Dividend_Type: 'Dividend_Type',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'Buy Back',
    data: {
      date: [
        {
          day: '19 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',
          Tender_Offer: 'Tender Offer',

          Recorded_Date: 'Recorded Date',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
  {
    title: 'Rights',
    data: {
      date: [
        {
          day: '20 Nov',
          year: "'21",
          duration: '',
          Gm: '',
          Gmvalue: '',
          percentage: '',
          Final: '',
          Fdate: '',
          Dividend_Type: '',

          Recorded_Date: '',

          Recorded_Date_value: "05 Aug '22",

          Announcement: 'Announcement Date',
          Announcement_date: "29 Apr '22",

          Ex_Date: 'Ex Date ',
          Ex_Datevalue: "03 Aug '22",

          Amount: 'Amount',
          Avalue: '60',
        },
      ],
    },
  },
];

export interface Itemtrade {
  title: string;
  date: string;
  value: string;
  change: string;
  cevalue: string;
  Broken: string;
  ptive: string;
  id: string;
}
export const tradeData: Itemtrade[] = [
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id: '1',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id: '2',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '23.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id: '3',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '27.36%',
    cevalue: '1610.00 CE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id: '4',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '9.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'true',
    id: '5',
  },
  {
    title: 'TRADE',
    date: '25MAY2023',
    value: '1612.36',
    change: '-0.36%',
    cevalue: '1610.00 PE',
    Broken: 'S1 Broken',
    ptive: 'false',
    id: '6',
  },
];

export const CompanyData = [
  {
    title: 'Code',
    Value: '11536',
  },
  {
    title: 'Instrument',
    Value: 'EQUITY',
  },
  {
    title: 'ISIN',
    Value: 'INSAKASI91029',
  },
];

export const SecurityDetail = [
  {
    title: 'Market Lot',
    Value: '1',
  },
  {
    title: 'Price Tick (Rs.)',
    Value: '0.05',
  },
  {
    title: 'Issued Capital',
    Value: '3,65,90,51,373.00',
  },
  {
    title: 'Face Value',
    Value: '1.00',
  },
  {
    title: 'Qty Freeze',
    Value: '0.08%',
  },
  {
    title: 'Margin %',
    Value: '12.50%',
  },
  {
    title: 'Ex. Multiplier',
    Value: '1',
  },
  {
    title: 'Pre Open',
    Value: 'yes',
  },
  {
    title: 'Special Pre Open',
    Value: 'No',
  },
  {
    title: 'Call Auction',
    Value: 'No',
  },
  {
    title: 'GSM Category',
    Value: 'No',
  },
];

export const Bookclosure = [
  {
    title: 'Date',
    Value: '17JUN2022 23JUN2022',
  },
  {
    title: 'Ex.Date',
    Value: '15JUN2022',
  },
  {
    title: 'Purpose',
    Value: 'AGM Dividend AGM/DIV - RS 125 PER SH',
  },
];

export const Management = [
  {
    title: 'Rajiv Chandan',

    value: 'Company Seo.& Compli. Officer',
  },

  {
    title: 'R Mukundan',

    value: 'Managing Director & CEO',
  },

  {
    title: 'Vibha Paul Rishi',

    value: 'Independent Director',
  },
  {
    title: 'S Padmanabhan',

    value: 'Director',
  },

  {
    title: 'Ratan N Tatan',

    value: 'Chairman Emeritus',
  },

  {
    title: 'Padmini Khare Kaicker',

    value: 'Independent Director',
  },
];

export const Contactdata = [
  {
    title: 'Register Address',
    data: [
      {
        addvalue: 'Nirmal Building.9th Floor Nariman Point,Mumbai,400021',
        telephone: '',
        fax: '',
        email: 'csg-unit@tsrdarshaw.com',
        RegName: '',
        author: '',
        website: 'www.tsdarhaw.com',
      },
    ],
  },
  {
    title: 'Head Office',
    data: [
      {
        addvalue: 'Invest Building.9th Floor Nariman Point,Mumbai,400021',
        telephone: '91-22-67893283',
        fax: '91-22-67893283',
        email: 'csg-unit@tsrdarshaw.com',
        RegName: '',
        author: '',
        website: 'www.tsdarhaw.com',
      },
    ],
  },
  {
    title: 'Registrar',
    data: [
      {
        RegName: 'Life Intime India Pvt Ltd',
        addvalue: 'Zone Building.9th Floor Nariman Point,Mumbai,400021',
        telephone: '91-22-67893283',
        fax: '91-22-67893283',
        email: 'csg-unit@tsrdarshaw.com',
        website: 'www.tsdarhaw.com',
        author: 'S R Batliboi & Associcates LLp',
      },
    ],
  },
];

export const Newsdata = [
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
  {
    headLine:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    bottomline:
      'Lorem ipsum dolor sit amet consectetur adipisicing elit. ',
    newsdate: '26 May',
    time: '09.44 Am',
  },
];

export const Listingdata = [
  {
    title:'NSE Symbol',
    value:'TATACHEM',
  },
  {
    title:'BSE Symbol',
    value:'500770',
  },
  {
    title:'BSE Group',
    value:'A',
  },
  {
    title:'ISIN',
    value:'INE092A01019',
  },
  {
    title:'ISIN',
    value:'INE092A01019',
  },
  {
    title:'Listed On',
    value:'BSE MSEINSE',
  },
  {
    title:'Sector',
    value:'Chemicals',
  },

]



export const PartofIndices=[
  {
    title:'BSE600'
  },
  {
    title:'CNX600'
  },
  {
    title:'BSESMALLCA'
  },
  {
    title:'CNXMIDCAP'
  },
  {
    title:'CNX200'
  },
  {
    title:'CNXCOMMODI'
  },
  {
    title:'BSEALLCAP'
  },
  {
    title:'BSEMETERIA'
  },
  {
    title:'MID 160'
  },
  {
    title:'LM1250'
  },
  {
    title:'MSL400'
  },
  {
    title:'NFTYLM250'
  },
  {
    title:'NFTYMC150'
  },
  {
    title:'NF500M5025'
  },
  
  
]

// }-->

// BSE600

// CNX600

// BSESMALLCA

// CNXMIDCAP

// <!--bindings={

// "ng-reflect-n

// "false"

// CNX200

// CNXCOMMODI

// BSEALLCAP

// BSEMETERIA

// J-->

// BSESMALLSE

// MID 160

// LM1250

// MSL400

// <!--bindings={

// nn-raflart-n

// NFTYLM250

// NFTYMC150

// NFTYMSC400

// NF500M5025'

export const companymodaldata=[
  {
    title: 'Year',

    value: '2023',
  },
  {
    title:'Qualification',
    value:'MCom LLB FCS PG on IPR'
  },
  {
    title:'Remuneration',
    value:'MCom LLB FCS PG'
  },

]
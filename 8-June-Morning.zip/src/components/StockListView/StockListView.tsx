import React from 'react';
import {View, Text, TouchableOpacity, Dimensions} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import alignment from '../utils/alignment';
import {constituentsListComponent, watchlistdata} from '../../theme/light';
import PlusIcon from '../Icons-remove/PlusIcon';
import {root} from '../../styles/colors';
import {useNavigation} from '@react-navigation/native';

const StockListView = (props: any) => {

  const navigation = useNavigation();
  return (
    <View
      style={{
        height: 60,
        paddingTop: 5,
        paddingBottom: 8,
        borderBottomWidth: 1,
        borderBottomColor: root.color_border,
      }}>
      <View style={{flex: 1, paddingHorizontal: 16, flexDirection: 'row'}}>
        <View
          style={{
            flex: 2,
            height: 36,
            // flexDirection: 'row',
            // backgroundColor:'red'
          }}>
          <View style={{flexDirection: 'row'}}>
            <Text style={constituentsListComponent.stockName}>
              {props.stockName}
            </Text>
            <Text style={constituentsListComponent.nseTxt}>NSE</Text>
            {props.screenName === 'WatchList' ? (
              <Text style={watchlistdata.Atxt}>A</Text>
            ) : null}
          </View>
          {props.future === true ? (
            <>
            {props.date.value===''?
            <>
            <View style={{...alignment.row}}>
            <Text style={constituentsListComponent.future}>{props.date.day}</Text>
            <Text style={constituentsListComponent.future}>{props.date.strickprice} {props.date.optiontype}</Text>
          </View>
            </>
            :
            <>
            <View style={{...alignment.row}}>
            <Text style={constituentsListComponent.future}>{props.date.day}</Text>
            <Text style={constituentsListComponent.future}>{props.date.value}</Text>
          </View>
            </>
            
          }
              
            </>
          ) : (
            <View style={{...alignment.row}}>
              {props.showIcon === true ? (
                <MaterialCommunityIcons
                  name="crown-circle"
                  size={16}
                  color="#ffd700"
                />
              ) : null}
              {props.showIcon === true ? (
                <Text
                  style={
                    props.title === 'Vol.Gainer'
                      ? constituentsListComponent.volGainerTxt
                      : props.title === 'Pr.Loser'
                      ? constituentsListComponent.prLoserTxt
                      : constituentsListComponent.defaultTxt
                  }>
                  {props.title}
                </Text>
              ) : null}
            </View>
          )}
        </View>
        {/* <View style={{...alignment.row}}>
            {props.showIcon === true && (
              <MaterialCommunityIcons
                name="crown-circle"
                size={16}
                color="#ffd700"
              />
            )}
            {props.showIcon === true ? (
              <Text
                style={
                  props.title === 'Vol.Gainer'
                    ? constituentsListComponent.volGainerTxt
                    : props.title === 'Pr.Loser'
                    ? constituentsListComponent.prLoserTxt
                    : constituentsListComponent.defaultTxt
                }>
                {props.title}
              </Text>
            ) : null}
          </View> */}

        <View
          style={{
            flex: 1.5,
            height: 36,
            ...alignment.row_alignC,
            justifyContent: 'flex-end',
          }}>
          <View
            style={
              props.price > 200 && props.price < 300
                ? constituentsListComponent.rightValuesView_200_300
                : props.price > 300 && props.price < 500
                ? constituentsListComponent.rightValuesView_300_500
                : constituentsListComponent.rightValuesDefault
            }>
            <Text style={constituentsListComponent.currentPriceTxt}>
              {props.price}
            </Text>
            <Text style={constituentsListComponent.changes}>
              {props.changes}
            </Text>
          </View>
        </View>
        <View
          style={{
            flex: 0.35,
            height: 36,
            justifyContent: 'center',
            marginLeft: 5,
          }}>
          <TouchableOpacity
            style={constituentsListComponent.bottonView}
            onPress={() => {
              navigation.navigate('BuySell', {
                item: props,
              });
            }}>
            <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
          </TouchableOpacity>
        </View>
        {props.screenName === 'WatchList' ? null : (
          <TouchableOpacity
            style={{marginTop: 5, marginLeft: 5}}
            onPress={() =>
              props.addToScripts(props.index, props.stockName, true)
            }>
            <PlusIcon size={26} />
          </TouchableOpacity>
        )}
      </View>
      {/* <View style={constituentsListComponent.container}>
        <View >
          <View style={{...alignment.row, justifyContent: 'flex-start',height:36}}>
            <Text style={constituentsListComponent.stockName}>
              {props.stockName}
            </Text>
            <Text style={constituentsListComponent.nseTxt}>NSE</Text>
            {props.screenName === 'WatchList' ? (
              <Text style={watchlistdata.Atxt}>A</Text>
            ) : null}
          </View>
          <View style={{...alignment.row}}>
            {props.showIcon === true && (
              <MaterialCommunityIcons
                name="crown-circle"
                size={16}
                color="#ffd700"
              />
            )}
            {props.showIcon === true ? (
              <Text
                style={
                  props.title === 'Vol.Gainer'
                    ? constituentsListComponent.volGainerTxt
                    : props.title === 'Pr.Loser'
                    ? constituentsListComponent.prLoserTxt
                    : constituentsListComponent.defaultTxt
                }>
                {props.title}
              </Text>
            ) : null}
          </View>
        </View>

        <View style={{...alignment.row_alignC}}>
          <View
            style={
              props.price > 200 && props.price < 300
                ? constituentsListComponent.rightValuesView_200_300
                : props.price > 300 && props.price < 500
                ? constituentsListComponent.rightValuesView_300_500
                : constituentsListComponent.rightValuesDefault
            }>
            <Text style={constituentsListComponent.currentPriceTxt}>
              {props.price}
            </Text>
            <Text style={constituentsListComponent.changes}>
              {props.changes}
            </Text>
          </View>
          <TouchableOpacity style={constituentsListComponent.bottonView}>
            <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
          </TouchableOpacity>
          {props.screenName === 'WatchList' ? null : (
            <TouchableOpacity
              onPress={() =>
                props.addToScripts(props.index, props.stockName, true)
              }>
              <PlusIcon size={26} style={{marginHorizontal: 5}} />
            </TouchableOpacity>
          )}
        </View>
      </View> */}
    </View>
  );
};

export default StockListView;

import React, {useCallback, useRef, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';
import alignment from '../../../components/utils/alignment';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Entypo from 'react-native-vector-icons/Entypo';
import {Cfont, Font, root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import {useFocusEffect, useNavigation} from '@react-navigation/native';
import BottomSheet, {
  BottomSheetRefProps,
} from './components/TransactionSheet/transactionSheet';
import PeriodicityModal from './components/Modal/PeriodicityModal';

function AvailableFunds() {
  const [card, setCard] = useState('TEST123');
  const ref = useRef<BottomSheetRefProps>(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [periodicityModal, setPeriodicityModal] = useState(false);
  const data = ['TEST123', 'BSE EQUITIES', 'NSE DERIVATIVE', 'NSE EQUITIES'];

  const navigation = useNavigation<any>();

  const onClose = () => {
    setPeriodicityModal(prevState => !prevState);
  };

  useFocusEffect(() => {
    ref?.current?.scrollTo(-150);
  });

  const periodiCityData = [
    {
      indicator: 'Deposit',
      value: '10,000.00',
    },
    {
      indicator: 'Limit Utilization',
      value: '-2,09,530.20',
    },
    {
      indicator: 'Funds Transferred Today',
      value: '0.00',
    },
    {
      indicator: 'Funds withdrawl/Allocation',
      value: '0.00',
    },
    {
      indicator: 'Collateral',
      value: '100000000000000.00',
    },
    {
      indicator: 'MTM Profit/Loss',
      value: '0.00',
    },
    {
      indicator: 'Credit For Sale',
      value: '0.00',
    },
    {
      indicator: 'Booked Profit/Loss',
      value: '0.00',
    },
    {
      indicator: 'Option CFS',
      value: '0.00',
    },
  ];

  const tradingData = [
    {
      title: 'Total Trading',
      value: '10,000.00 Cr',
    },
    {
      title: 'Total Utilization',
      value: '0.00',
    },
    {
      title: 'Multiplier',
      value: '1',
    },
    {
      title: 'Net Availbale',
      value: '10,000.00 Cr',
    },
  ];

  const renderCard = ({item}: any) => {
    return (
      <TouchableOpacity
        style={card === item ? styles.cardActive : styles.cardInactive}
        activeOpacity={1}
        onPress={() => setCard(item)}>
        <View style={styles.cardContainer}>
          <Text
            style={
              card === item ? styles.headingActive : styles.headingInactive
            }>
            {item}
          </Text>
          <View style={styles.add_withDraw_Funds}>
            <Text
              style={
                card === item
                  ? styles.add_withdraw_ActiveTxt
                  : styles.add_withdraw_InactiveTxt
              }>
              Add Funds
            </Text>
            <TouchableOpacity
              onPress={() => {
                console.log(item);
              }}>
              <Feather
                name="plus-circle"
                size={24}
                color={card === item ? root.color_active : root.color_text}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.add_withDraw_Funds}>
            <Text
              style={
                card === item
                  ? styles.add_withdraw_ActiveTxt
                  : styles.add_withdraw_InactiveTxt
              }>
              Withdraw Funds
            </Text>
            <TouchableOpacity onPress={() => {}}>
              <Feather
                name="minus-circle"
                size={24}
                color={card === item ? root.color_active : root.color_text}
              />
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const navigateViaMenu = (value: string) => {
    navigation.replace(value, {fundName: card});
    setMenuVisible(prevState => !prevState);
  };

  return (
    <GestureHandlerRootView>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => setMenuVisible(prevState => !prevState)}>
            <Entypo name="dots-three-vertical" size={24} color={'black'} />
          </TouchableOpacity>
        </View>
        {menuVisible && (
          <View style={styles.menuNav}>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => navigateViaMenu('AddFunds')}>
              <Text style={styles.menuTxt}>Add Funds</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => navigateViaMenu('WithDrawFunds')}>
              <Text style={styles.menuTxt}>Withdraw Funds</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.menuItem}
              onPress={() => navigateViaMenu('RecentTransactions')}>
              <Text style={styles.menuTxt}>Recent Transactions</Text>
            </TouchableOpacity>
          </View>
        )}
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={styles.availableFundsTxt}>Available Funds</Text>
          <TouchableOpacity
            style={styles.periodictyView}
            onPress={() => setPeriodicityModal(prevState => !prevState)}
            activeOpacity={1}>
            <Text
              style={
                styles.periodicityValue
              }>{`All Exchange Combined ₹ 10,000.00 Cr`}</Text>
            <AntDesign name="caretdown" size={10} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.valueContainer}
            onPress={() => {}}
            activeOpacity={1}>
            <View style={styles.utilisedContainer}>
              <View style={styles.utilised_available_Container}>
                <Text style={styles.utlised_available_Txt}>Utlised</Text>
                <Text
                  style={
                    styles.utilised_available_Value
                  }>{`₹ -2,09,530.20`}</Text>
              </View>
            </View>
            <View style={styles.availableContainer}>
              <View style={styles.utilised_available_Container}>
                <Text style={styles.utlised_available_Txt}>Available</Text>
                <Text
                  style={
                    styles.utilised_available_Value
                  }>{`₹ 9,999,98 Cr.`}</Text>
              </View>
            </View>
          </TouchableOpacity>
          <FlatList
            style={styles.cardView}
            data={data}
            renderItem={renderCard}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
          />
          <TouchableOpacity onPress={() => navigation.navigate('FundDetails')}>
            <FlatList
              style={styles.periodicityContainer}
              data={periodiCityData}
              numColumns={2}
              renderItem={({item}) => (
                <View style={styles.perodiCtyContainer}>
                  <View style={{width: '40%'}}>
                    <Text numberOfLines={1} style={styles.indicatorTxt}>
                      {item.indicator}
                    </Text>
                  </View>
                  <View style={styles.value}>
                    <Text style={styles.valueTxt} numberOfLines={1}>
                      {item.value}
                    </Text>
                    <Ionicons
                      name="chevron-forward"
                      size={15}
                      color={root.client_background}
                    />
                  </View>
                </View>
              )}
            />
          </TouchableOpacity>
          <FlatList
            style={styles.periodicityContainer}
            data={tradingData}
            numColumns={2}
            renderItem={({item}) => (
              <View style={styles.perodiCtyContainer}>
                <View style={{width: '40%'}}>
                  <Text numberOfLines={1} style={styles.indicatorTxt}>
                    {item.title}
                  </Text>
                </View>
                <View style={styles.value}>
                  <Text style={styles.valueTxt} numberOfLines={1}>
                    {item.value}
                  </Text>
                  <Ionicons
                    name="chevron-forward"
                    size={15}
                    color={root.client_background}
                  />
                </View>
              </View>
            )}
          />
        </ScrollView>
      </View>
      <BottomSheet ref={ref} />
      <PeriodicityModal onClose={onClose} visible={periodicityModal} />
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 16,
    paddingVertical: 16,
  },
  header: {
    ...alignment.row_SpaceB,
  },
  availableFundsTxt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 16,
  },
  periodictyView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 16,
  },
  periodicityValue: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
  valueContainer: {
    ...alignment.row,
    height: 49,
    marginTop: 28,
  },
  utilisedContainer: {
    width: '50%',
    backgroundColor: root.color_positive_step_50,
  },
  availableContainer: {
    width: '50%',
    backgroundColor: root.color_positive_step_100,
  },
  utlised_available_Txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_active,
    fontSize: Font.font_normal_six,
  },
  utilised_available_Value: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_two,
    color: root.color_active,
    paddingTop: 3,
  },
  utilised_available_Container: {
    paddingVertical: 8,
    paddingLeft: 16,
  },
  cardActive: {
    height: 140,
    width: 140,
    marginRight: 16,
    borderRadius: 10,
    backgroundColor: root.client_background,
  },
  cardInactive: {
    height: 140,
    width: 140,
    marginRight: 16,
    borderRadius: 10,
    backgroundColor: root.color_active,
  },
  cardContainer: {
    padding: 12,
    justifyContent: 'space-between',
    height: '100%',
  },
  headingActive: {
    fontSize: Font.font_normal_two,
    color: root.color_active,
    fontFamily: Cfont.rubik_regular,
  },
  headingInactive: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  add_withDraw_Funds: {
    ...alignment.row,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  add_withdraw_ActiveTxt: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_six,
    paddingRight: 5,
  },
  add_withdraw_InactiveTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_six,
    paddingRight: 5,
  },
  perodiCtyContainer: {
    height: 34,
    width: '50%',
    ...alignment.row_SpaceB,
    alignItems: 'center',
  },
  innerPeriodicity: {
    ...alignment.row,
  },
  indicatorTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  valueTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    alignment: 'flex-end',
  },
  cardView: {
    paddingTop: 20,
  },
  periodicityContainer: {
    paddingTop: 24,
  },
  menuNav: {
    width: 156,
    backgroundColor: root.color_active,
    position: 'absolute',
    right: 25,
    top: 40,
    zIndex: 1,
  },
  menuItem: {
    height: 40,
    justifyContent: 'center',
    paddingLeft: 12,
  },
  menuTxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  value: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'flex-end',
    width: '40%',
  },
});

export default AvailableFunds;

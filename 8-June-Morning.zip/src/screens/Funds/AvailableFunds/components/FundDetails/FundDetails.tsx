import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import List from '../List/List';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {data} from '../../../data';

const FundDetails = () => {
  const [visible, setVisible] = useState<any>({
    deposit: false,
    collateral: false,
    optionCFS: false,
    creditForSale: false,
    limitUtilization: false,
    mtmProfitLoss: false,
    bookedProfitLoss: false,
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <AntDesign name="arrowleft" size={24} color={'black'} style={styles.backIcon}/>
        <Text style={styles.headerTxt}>Fund Details</Text>
      </View>

      <ScrollView>
        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() => setVisible({deposit: !visible.deposit})}>
          <Text style={styles.titleTxt}>Deposit</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.deposit ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.deposit ? <List data={data} keyword="Deposit" /> : null}

        <List data={data} keyword="Funds Transferred Today" />

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() => setVisible({collateral: !visible.collateral})}>
          <Text style={styles.titleTxt}>Collateral</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.collateral ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.collateral ? <List data={data} keyword="Collateral" /> : null}

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() => setVisible({creditForSale: !visible.creditForSale})}>
          <Text style={styles.titleTxt}>Credit For Sale</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.creditForSale ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.creditForSale ? (
          <List data={data} keyword="Credit For Sale" />
        ) : null}

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() => setVisible({optionCFS: !visible.optionCFS})}>
          <Text style={styles.titleTxt}>Option CFS</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.optionCFS ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.optionCFS ? <List data={data} keyword="Option CFS" /> : null}

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() =>
            setVisible({limitUtilization: !visible.limitUtilization})
          }>
          <Text style={styles.titleTxt}>Limit Utilization</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.limitUtilization ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.limitUtilization ? (
          <List data={data} keyword="Limit Utilization" />
        ) : null}

        <List data={data} keyword="Funds Withdrawal/Allocation" />

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() => setVisible({mtmProfitLoss: !visible.mtmProfitLoss})}>
          <Text style={styles.titleTxt}>MTM Profit/Loss</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.mtmProfitLoss ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.mtmProfitLoss ? (
          <List data={data} keyword="MTM Profit/Loss" />
        ) : null}

        <TouchableOpacity
          style={styles.titleContainer}
          onPress={() =>
            setVisible({bookedProfitLoss: !visible.bookedProfitLoss})
          }>
          <Text style={styles.titleTxt}>Booked Profit/Loss</Text>
          <View style={styles.titleValueContainer}>
            <Text style={styles.titleValue}>0.00</Text>
            <AntDesign
              name={visible.bookedProfitLoss ? 'up' : 'right'}
              size={17}
              color={'black'}
            />
          </View>
        </TouchableOpacity>
        {visible.bookedProfitLoss ? (
          <List data={data} keyword="Booked Profit/Loss" />
        ) : null}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 16,
    flex: 1,
    // overflow:'hidden'
  },
  titleContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
  },
  titleTxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  titleValueContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  titleValue: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    paddingRight:10
  },
  header: {
    ...alignment.row,
    height:44,
    alignItems:'center',
  },
  backIcon:{
    paddingRight:25
  },
  headerTxt:{
    fontSize:Font.font_normal_four,
    fontFamily:Cfont.rubik_medium,
    color:root.color_text
  }
});

export default FundDetails;

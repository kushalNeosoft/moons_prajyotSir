import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';

const List = (props: any) => {
  const renderItem = item => {
    let Texts = [];
    if (item.indicator === props.keyword) {
      if (
        props.keyword === 'Funds Transferred Today' ||
        props.keyword === 'Funds Withdrawal/Allocation'
      ) {
        return (
          <View style={styles.detailsContainer}>
            <Text style={styles.singleIndicatorTxt}>{item.indicator}</Text>
            <Text style={styles.singleIndicatorValue}>{item.value}</Text>
          </View>
        );
      } else {
        Texts.push(
          <View style={styles.detailsContainer}>
            <Text style={styles.titleTxt}>{item.title}</Text>
            <Text style={styles.valueTxt}>{item.value}</Text>
          </View>,
        );
      }
    }
    return Texts;
  };

  return (
    <>
      {props.data.map((item: any) => (
        <>{renderItem(item)}</>
      ))}
    </>
  );
};

const styles = StyleSheet.create({
  detailsContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 10,
    alignItems:'center'
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valueTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  singleIndicatorTxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    width:'50%'
  },
  singleIndicatorValue:{
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    paddingRight:27
  }
});

export default List;

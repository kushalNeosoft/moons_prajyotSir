import React, {useState} from 'react';
import {View, Text, FlatList, Animated} from 'react-native';
import Date from './components/Date/Date';
import {dateData, optionData} from './constData';
import CallModal from './components/CallModal/CallModal';
import PutModal from './components/PutModal/PutModal';
import CallPutList from './components/CallPullList/CallPullList';
import Hexagon from './components/hexagon/Hexagon';
import {useNavigation} from '@react-navigation/native';
import {optionChainScreen} from '../../../theme/light';
import AddToWatchListModal from '../../../components/AddToWatchlistModal/AddToWatchlistModal';

function OptionChain() {
  const [date, setDate] = useState('04');
  const [callModalVisible, setCallModalVisible] = useState(false);
  const [putModalVisible, setPutModalVisible] = useState(false);
  const [addToWatchlistModalVisible,setAddToWatchlistModalVisible]=useState(false)
  const value = useState(new Animated.ValueXY({x: 0, y: 0}))[0];
  const navigation = useNavigation();

  const moveDown = () => {
    Animated.timing(value, {
      toValue: {x: 0, y: 400},
      duration: 1000,
      useNativeDriver: false,
    }).start();
  };

  const moveUp = () => {
    Animated.timing(value, {
      toValue: {x: 0, y: 0},
      duration: 1000,
      useNativeDriver: false,
    }).start();
  };

  const onPress = (value: string) => {
    setDate(value);
  };

  const callModal = () => {
    setCallModalVisible(prevState => !prevState);
  };

  const putModalView = () => {
    setPutModalVisible(prevState => !prevState);
  };

  const addToWatchlistModalView=()=>{
    setAddToWatchlistModalVisible(prevState=>!prevState)
  }

  const showAddToWatchlistModal=()=>{
    setAddToWatchlistModalVisible(prevState=>!prevState)
  }

  const renderList = ({item, index}: any) => {
    return (
      <View style={optionChainScreen.callsPutContainer}>
        <View style={optionChainScreen.callsPutInner}>
          <CallPutList
            ltpTxt={item.calls.ltp}
            ltpValue={item.calls.value}
            ivTxt={item.calls.IV}
            ivValue={item.calls.ivValue}
            oiTxt={item.calls.OI}
            oiValue={item.calls.oiValue}
            leftView={true}
            modalView={callModal}
            showAddToWatchlistModal={showAddToWatchlistModal}
          />
          <View style={optionChainScreen.dayValueTxtContainer}>
            <Text style={optionChainScreen.dayValue}>{`${item.value}.00`}</Text>
          </View>
          <CallPutList
            ltpTxt={item.calls.ltp}
            ltpValue={item.calls.value}
            ivTxt={item.calls.IV}
            ivValue={item.calls.ivValue}
            oiTxt={item.calls.OI}
            oiValue={item.calls.oiValue}
            leftView={false}
            modalView={putModalView}
            showAddToWatchlistModal={showAddToWatchlistModal}
          />
        </View>
      </View>
    );
  };

  return (
    <View style={optionChainScreen.container}>
      <View>
        <FlatList
          data={dateData}
          horizontal={true}
          renderItem={({item}) => (
            <Date
              date={item.date}
              month={item.month}
              year={item.year}
              onPress={onPress}
              selectedDate={date}
            />
          )}
        />
      </View>
      <Text style={optionChainScreen.expiryTxt}>
        *18 Expires available till dec'27
      </Text>
      <View style={optionChainScreen.callsPutTxtContainer}>
        <Text style={optionChainScreen.callsTxt}>Calls</Text>
        <Text style={optionChainScreen.callsTxt}>Puts</Text>
      </View>
      {/* Main View */}
      <View style={{flex: 1}}>
        <Animated.View style={[value.getLayout(), {zIndex: 1}]}>
          <Hexagon />
        </Animated.View>
        <FlatList
          data={optionData}
          renderItem={renderList}
          onEndReached={moveUp}
          onMomentumScrollBegin={moveDown}
          contentContainerStyle={{marginTop: 12}}
        />
      </View>
      <CallModal
        visible={callModalVisible}
        onClose={() => setCallModalVisible(false)}
      />
      <PutModal
        visible={putModalVisible}
        onClose={() => setPutModalVisible(false)}
      />
      <AddToWatchListModal visible={addToWatchlistModalVisible} onClose={addToWatchlistModalView}/>
    </View>
  );
}

export default OptionChain;

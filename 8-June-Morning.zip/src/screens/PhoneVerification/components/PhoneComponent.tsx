import React, {useState} from 'react';
import {Text, TextInput, TouchableNativeFeedback, View} from 'react-native';

import useStyles from '../../../styles/useStyles';

import {useTranslation} from 'react-i18next';

// import BackIcon from '../../../assets/BackIcon';
// import Logo from '../../../assets/Logo';
import {createPhoneComponentStyles} from '../styles/phoneComponent.styles';
// import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import { Cfont, Font, root } from '../../../styles/colors';
import { useNavigation } from '@react-navigation/native';
import { PhoneComponentStyles } from '../../../theme/light';

const PhoneComponent = ({moveForward}: any) => {
  const [phoneNumber, setPhoneNumber] = useState<string>();
  const {colors, styles} = useStyles(createPhoneComponentStyles);
  const {t} = useTranslation();
  const navigation=useNavigation();
  return (
    <View style={{marginTop: 32}}>
      {/* <Logo /> */}
      <Text style={[PhoneComponentStyles.heading, {marginTop: 18}]}>
        The next gen  mobile trading app
      </Text>
      
      <Text style={{color: root.color_text,fontSize:Font.font_normal_two , marginTop: 14, fontFamily:Cfont.rubik_medium}}>Try It Now</Text>
      <View style={[PhoneComponentStyles.inputContainer, {marginTop: 14}]}>
        <TextInput
          style={PhoneComponentStyles.input}
          placeholderTextColor={'grey'}
          placeholder={'Enter Mobile Number'}
          keyboardType="phone-pad"
          
          onChangeText={text => {
            setPhoneNumber(text);
          }}
        />
      </View>
      <View style={{flexDirection: 'row'}}>
        <View
          style={{
            marginTop: 32,
            borderRadius: 8,
          }}>
          <TouchableNativeFeedback
          disabled={!phoneNumber}
            // background={TouchableNativeFeedback.Ripple('blue', true)}
            onPress={() => {
              moveForward('OTP');
            }}>
            <View
              style={[
                PhoneComponentStyles.buttonContainer,
                // {
                //   backgroundColor: phoneNumber ? root.client_background :root.client_background ,
                // },
              ]}>
              <Text style={[PhoneComponentStyles.buttonText,{
                color:phoneNumber?root.color_disable:root.color_active,
                opacity: phoneNumber
                        ? 1
                        : 0.3,
              }]}>Verify</Text>
              {/* <ArrowForwardIcon style={[PhoneComponentStyles.buttonImage,{
                color:phoneNumber?root.color_active:root.color_disable,
                opacity: phoneNumber
                        ? 1
                        : 0.3,
              }]} /> */}
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 32}}>
        <Text style={{fontSize: Font.font_normal_one,color:root.color_text,fontFamily:Cfont.rubik_light}}>Already registered? Click here to </Text>

        <View
          style={{
            borderRadius: 16,
          }}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              navigation.navigate('LoginScreen');
            }}>
            <View style={{paddingHorizontal: 12, paddingVertical: 8}}>
              <Text style={{color: root.client_background, fontFamily:Cfont.rubik_medium, fontSize: Font.font_normal_one}}>
                Login
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <View style={{flexDirection: 'row', alignItems: 'center', marginTop: 8}}>
        <Text style={{fontSize: Font.font_normal_one,color:root.color_text,fontFamily:Cfont.rubik_light}}>havent registered yet?</Text>

        <View
          style={{
            borderRadius: 16,
          }}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              navigation.navigate("SignupScreen");
            }}>
            <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
              <Text style={{color: root.client_background, fontWeight: 'bold', fontSize: Font.font_normal_one,fontFamily:Cfont.rubik_medium}}>
                Click Here
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
    </View>
  );
};

export default PhoneComponent;

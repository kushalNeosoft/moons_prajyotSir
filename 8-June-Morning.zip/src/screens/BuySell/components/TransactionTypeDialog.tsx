import React from 'react';
import {useState} from 'react';
import {View, Text, TouchableNativeFeedback, TouchableOpacity} from 'react-native';
// import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import CommonModaltwo from '../../../components/CommonModal/CommonModaltwo';
import { Cfont, Font, root } from '../../../styles/colors';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModalThree from '../../../components/CommonModal/CommonModalThree';

const  TransactionTypeDialog = (props: any) => {
  const [selected, setSelected] = useState(' Quantity');
  return (
    <CommonModalThree visible={props.visible} onClose={props.onClose} >
    
    <View style={{width: '100%' }}>
        <Text
          style={{
            fontSize: Font.font_title,
            fontFamily: Cfont.rubik_medium,
            color: root.color_text
            
          }}>
          Select
        </Text>
        
        
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected(' Quantity');
        }}>

          
          
        <View style={{flexDirection: 'row', marginTop: 18, padding:14 }}>
          <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === ' Quantity' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 12 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
         Quantity
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('Amount');
        }}>
       <View style={{flexDirection: 'row', marginTop: 1, padding: 16}}>
          <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'Amount' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 12 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
          Amount
          </Text>
        </View>
      </TouchableNativeFeedback>
     
    </View>
    </CommonModalThree>
  );
};
export default TransactionTypeDialog;

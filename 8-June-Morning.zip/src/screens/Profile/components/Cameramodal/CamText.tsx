
export interface IUser {
  name: string;
  index: string;
  drawerType: string;
  navigateTo: string;

}

export const CamText = [
  {
    name: 'Gallery',
    index: ' 1',
    drawerType: 'Open',
    navigateTo: 'P',
    
  },
  {
    name: 'Camera',
    index: ' 2',
    drawerType: 'Capture',
    navigateTo: 'P',
    
  },
  {
    name: 'Remove Profile',
    index: '3',
    drawerType: 'Remove',
    navigateTo: 'P',
  },
  {
    name: 'Close',
    index: '4',
    drawerType: 'Close',
    navigateTo: 'P',
  },
];

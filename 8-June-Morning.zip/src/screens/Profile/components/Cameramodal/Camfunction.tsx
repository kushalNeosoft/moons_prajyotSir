import React, { useState } from "react";
import ImagePicker from 'react-native-image-crop-picker';
import { useDispatch } from "react-redux";
import { imgcon } from "../../Redux/Action";




export const cameraOpen = () => {
    const dispatch = useDispatch();
    const [imagest, setImagest] = useState(
        'https://api.adorable.io/avatars/80/abott@adorable.png',
      );
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      console.log(image, 'PPPPPP--->');
      setImagest(image.path);
      console.log(imagest, 'KAKAKAK2222->');

      dispatch(imgcon({imgstore: image.path}));
    });
  };

export const galleryOpen = () => {
    const dispatch = useDispatch();
    const [imagest, setImagest] = useState(
        'https://api.adorable.io/avatars/80/abott@adorable.png',
      );
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      console.log(image);
      setImagest(image.path);
      dispatch(imgcon({imgstore: image.path}));
    });
  };
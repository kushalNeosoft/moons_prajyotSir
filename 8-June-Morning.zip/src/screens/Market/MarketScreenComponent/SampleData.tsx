export const whatsNewData = [
  {
    title: 'IPO is incoming!!',
    subTitle: 'Starting from: 4th Feb 22',
  },
  {
    title: 'IIFL',
    subTitle: 'Starting from: 22th March 22',
  },
];
export const newProductData = [
  {
    title: 'IPO',
    link: 'navigation',
  },
  {
    title: 'WEB',
    link: 'navigation',
  },
];
export const indicesData = [
  {
    title: 'Nifty 50',
    price: '17600.75',
    changes: '-58.40(-0.34)',
    date: '19 APR 23 01:2421',
  },
  {
    title: 'SENSEX',
    price: '16500.75',
    changes: '-42.40(-0.14)',
    date: '19 APR 23 01:2421',
  },
];
export const screenersData = [
  {
    title: 'Top Gainers/Losers',
    url: '/1',
  },
  {
    title: 'Upper/Lower Circuit',
    url: '/1',
  },
  {
    title: '3D Positive/ Negitive Runners',
    url: '/1',
  },
  {
    title: '52 Week High/Low',
    url: '/1',
  },
  {
    title: '5% Open Gap Up/Down',
    url: '/1',
  },
  {
    title: 'PreMuim / Discount',
    url: '/1',
  },
  {
    title: '5% Open Gap Up/Down',
    url: '/1',
  },
];
export const newsData = [
  {
    title: 'MRF Ltd spurts 0.07%, gains for fifth starith session',
    subTitle: 'MRF Ltd up for a latest fifth ...',
  },
  {
    title: 'ABB India Ltd Spurts 0.69%',
    subTitle: 'ABB India Ltd rose 0.69% to ...',
  },
  {
    title: 'MRF Ltd spurts 0.07%, gains for fifth starith session',
    subTitle: 'MRF Ltd up for a fifth ...',
  },
  {
    title: 'ABB India Ltd Spurts 0.69%',
    subTitle: 'ABB India Ltd rose 0.69% to ...',
  },
  {
    title: 'MRF Ltd spurts 0.07%, gains for fifth starith session',
    subTitle: 'MRF Ltd up for a fifth ...',
  },
  {
    title: 'MRF Ltd spurts 0.07%, gains for fifth starith session',
    subTitle: 'MRF Ltd up for a fifth ...',
  },
];
export const newsListData = [
  {
    title:
      'PNC Infra gets provionsnal completion certificate for Bihar-based project',
    time: '16 minutes ago',
    stockName: 'PNCINFRA',
    price: '284.90',
    change: '070.(-0.25%)',
  },
  {
    title: 'Ion Exchange gains after board Oks 1:10 stock split',
    time: '16 minutes ago',
    stockName: 'IONEXCHANGE',
    price: '683.50',
    change: '040.(-0.45%)',
  },
  {
    title: 'Hosiery stocks in demand on encouraging outlook',
    time: '16 minutes ago',
    stockName: 'LUXIND',
    price: '1235.50',
    change: '-2.05(-0.17%)',
  },
  {
    title:
      'PNC Infra gets provionsnal completion certificate for Bihar-based project',
    time: '16 minutes ago',
    stockName: 'PNCINFRA',
    price: '284.90',
    change: '070.(-0.25%)',
  },
  {
    title:
      'PNC Infra gets provionsnal completion certificate for Bihar-based project',
    time: '16 minutes ago',
    stockName: 'PNCINFRA',
    price: '284.90',
    change: '070.(-0.25%)',
  },
  {
    title: 'Hosiery stocks in demand on encouraging outlook',
    time: '16 minutes ago',
    stockName: 'LUXIND',
    price: '1235.50',
    change: '-2.05(-0.17%)',
  },
];
export const markedDates = [
  {
    '2023-04-14': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-15': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-16': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-17': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
  },
];
export const events = [
  {id: 1, title: 'NETFLIX', subTitle: 'bonus', date: '2023-04-14'},
  {id: 2, title: 'AMAZONE', subTitle: 'AGM', date: '2023-04-15'},
  {id: 3, title: 'AXISNEO', subTitle: 'EGM', date: '2023-04-16'},
  {id: 4, title: 'SBIFUNDS', subTitle: 'BONUS', date: '2023-04-17'},
];
export const ipoData = [
  {
    title: 'Life Insurance Of India',
    range: '₹902 - ₹949',
    date: '01 OCT 22 - 01 OCT 25',
    minQty: '15(1 Lots)',
    minAmount: '₹13,530',
  },
];

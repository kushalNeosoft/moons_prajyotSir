import React, {useEffect, useRef, useState} from 'react';
import {Text, StyleSheet, } from 'react-native';
import BottomSheet from '@gorhom/bottom-sheet';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import OrdersModal from './OrdersModal/OrdersModal';
import OrdersNavigation from './OrdersNavigation/OrdersNavigation';

function Orders() {
  const [scriptName, setScriptName] = useState('Equity SIP');
  const [orderModalVisible, setOrderModalVisible] = useState(false);
  const visible = -1;
  const bottomSheetRef = useRef<BottomSheet>(null);

  const onPress = () => {
    bottomSheetRef.current?.snapToIndex(0);
  };

  const closeSheet=()=>{
    bottomSheetRef.current?.forceClose();
  }

  const changeScriptName = (value: string) => {
    setScriptName(value);
  };

  const closeModal = () => {
    setOrderModalVisible(prevState => !prevState);
  };

  const orderModalToggle = () => {
    setOrderModalVisible(prevState => !prevState);
  };

  return (
    <GestureHandlerRootView style={orders.container}>
      <OrdersNavigation
        ref={bottomSheetRef}
        index={visible}
        orderModalToggle={orderModalToggle}
        scriptName={scriptName}
        onPress={onPress}
        closeSheet={closeSheet}
      />
      <OrdersModal
        changeScriptName={changeScriptName}
        visible={orderModalVisible}
        onClose={closeModal}
        scriptName={scriptName}
      />
    </GestureHandlerRootView>
  );
}

const orders = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default Orders;

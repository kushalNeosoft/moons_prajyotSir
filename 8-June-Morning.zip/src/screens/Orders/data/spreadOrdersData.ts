export const spreadOpenOrders=[];
export const spreadCloseOrders=[];
export const spreadAllOrders=[
    {
        name:'AXISBANK-1',
        timePeriod:"MAY - JUN 25 MAY'23 FUT",
        sellBuy:'1200 Qty @ 5.80',
        qty:'1200/1200 Qty',
        time:'11:59:21 AM',
        ltp:5.85,
        timeAndDate:"11:59:21 AM 25 May '23",
        sell:"25 MAY'23 FUT",
        buy:"29 JUN'23 FUT",
        pL:'6420(96.55%)',
        tradesBuyQty:1200,
        tradesSellQty:1200,
        tradesBuyTradeNo:19,
        tradesSellTradeNo:18,
        tradesBuyTime:'11:59:21 AM',
        tradesSellTime:'11:59:21 AM',
        tradesBuyPrice:918.90,
        tradesSellPrice:913.30,
        tradesAvgPrics:916.10,
        orderDetailsSell:"25 MAY'23 FUT",
        orderDetailsBuy:"29 JUN'23 FUT",
        orderDetailsQty:"1200 Qty",
        orderDetailsPrice:5.80,
        orderDetailsValidity:'DAY',
        additionalDetailsExgOrderNo:133051,
        additionalDetailsOrderType:'RL',
        additionalDetailsClientOrderNo:0,
        additionalDetailsInitiatedFrom:'-',
        additionalDetailsModifiedFrom:'-',
        additionalDetailsPreOrder:'-'
    }
];

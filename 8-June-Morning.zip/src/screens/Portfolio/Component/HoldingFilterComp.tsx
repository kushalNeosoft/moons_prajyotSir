import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {root} from '../../../styles/colors';
import {holdingFilter} from '../../../theme/light';
import MinMaxInput from './MinMaxInput';
import {ScrollView} from 'react-native-gesture-handler';

const HoldingFilterComp = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [cmvValue, setcmvValue] = useState('');
  const [daysPlValue, setDaysPlValue] = useState('');
  const [overallPlValue, setOverallPlValue] = useState('');
  const [daysPlPercentage, setDaysPlPercentage] = useState('');
  const [overallPlPercentage, setOverallPlPercenatge] = useState('');
  const [textInputLine, setTextInputLine] = useState(false);

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['Low to High', 'High to Low'];
  const [daysPlRange, setDaysPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [daysPlPercentageRange, setDaysPlPercentageRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [overallPlRange, setOverallPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [overallPlPercentageRange, setOverallPlPercentageRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  return (
    <View>
      <View style={holdingFilter().Maincon}>
        <View style={holdingFilter().space}>
          <View style={holdingFilter().spaceinner}>
            <Text style={holdingFilter().titleText}>Alphabetically</Text>
          </View>

          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabetValue(item)}
                style={
                  holdingFilter({selected: alphabetValue === item})
                    .commonHtZSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={holdingFilter().spacetwo}>
          <View style={holdingFilter().spacetwoinner}>
            <Text style={holdingFilter().titleText}>
              Current Mraket Value(CMV)
            </Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setcmvValue(item)}
                style={
                  holdingFilter({selected: cmvValue === item}).commonHtLSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={holdingFilter().spacetwo}>
          <View style={holdingFilter().spacetwoinner}>
            <Text style={holdingFilter().titleText}>Day's P/L</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlValue(item)}
                style={
                  holdingFilter({selected: daysPlValue === item})
                    .commonHtLSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlRange}
                item={item}
                rangeArr={daysPlRange}
              />
            )}
          />
        </View>

        <View style={holdingFilter().space}>
          <View style={holdingFilter().spaceinner}>
            <Text style={holdingFilter().titleText}>Overall P/L</Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOverallPlValue(item)}
                style={
                  holdingFilter({selected: overallPlValue === item})
                    .commonHtLSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={overallPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setOverallPlRange}
                item={item}
                rangeArr={overallPlRange}
              />
            )}
          />
        </View>
        <View style={holdingFilter().space}>
          <View style={holdingFilter().spaceinner}>
            <Text style={holdingFilter().titleText}>Day's P/L Percentage</Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlPercentage(item)}
                style={
                  holdingFilter({selected: daysPlPercentage === item})
                    .commonHtLSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlPercentageRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlPercentageRange}
                item={item}
                rangeArr={daysPlPercentageRange}
              />
            )}
          />
        </View>
        <View style={holdingFilter().space}>
          <View style={holdingFilter().spaceinner}>
            <Text style={holdingFilter().titleText}>
              Overall P/L Percentage
            </Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOverallPlPercenatge(item)}
                style={
                  holdingFilter({selected: overallPlPercentage === item})
                    .commonHtLSelected
                }>
                <Text style={holdingFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={overallPlPercentageRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setOverallPlPercentageRange}
                item={item}
                rangeArr={overallPlPercentageRange}
              />
            )}
          />
        </View>
      </View>
    </View>
  );
};
export default HoldingFilterComp;

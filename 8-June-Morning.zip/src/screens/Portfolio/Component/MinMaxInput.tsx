import {useFocusEffect} from '@react-navigation/native';
import React, {useRef, useState} from 'react';
import {Text, TouchableOpacity, TextInput} from 'react-native';
import {holdingFilter} from '../../../theme/light';

const MinMaxInput = (props: any) => {
  const onChange = text => {
    let arr = [...props.rangeArr];
    arr[props.index].value = text;
    props.setValue([...arr]);
  };

  const [clickedItem, setClickedItem] = useState(false);
  const inputRef = useRef();

  useFocusEffect(
    React.useCallback(() => {
      setClickedItem(false);
    }, []),
  );

  return (
    <TouchableOpacity
      onPress={() => {
        setClickedItem(true);
        inputRef?.current?.focus?.();
      }}
      style={
        holdingFilter({
          showBoxBorder:
            props.item?.value.toString?.()?.length > 0 &&
            props.item?.value.toString?.() != 0,
        }).commonMinMaxSelected
      }>
      <Text style={holdingFilter().minMaxText}>{props.item?.type}</Text>
      <TextInput
        ref={inputRef}
        style={holdingFilter({showBorder: clickedItem}).minMaxTextInput}
        placeholder={'0'}
        value={props.item?.value.toString()}
        editable={clickedItem}
        placeholderTextColor={'#303030'}
        keyboardType="numeric"
        onChangeText={text => onChange(text)}
        onFocus={() => {
          setClickedItem(true);
        }}
      />
    </TouchableOpacity>
  );
};
export default MinMaxInput;

import {TextInput, View} from 'react-native';
import CloseIcon from '../../assets/CloseIcon';
import {TouchableOpacity} from 'react-native-gesture-handler';
import {useNavigation} from '@react-navigation/native';
import React, { useState } from 'react';
import { SearchScreen } from '../../theme/light';

const SearchMarketNewsScreen = () => {
  const [query, setQuery] = useState('');
  const navigation = useNavigation();
  return (
    <View>
      <View
        style={SearchScreen.main}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <View style={SearchScreen.padding}>
            <CloseIcon style={SearchScreen.close} />
          </View>
        </TouchableOpacity>
        <TextInput
          textAlign={'left'}
          placeholder="Search Market News"
          onChangeText={value => {
            setQuery(value);
          }}
          style={SearchScreen.flex}
        />
      </View>
    </View>
  );
};

export default SearchMarketNewsScreen;

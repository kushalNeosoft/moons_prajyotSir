import {useEffect, useState} from 'react';
import {
  ActivityIndicator,
  FlatList,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import SelectSectorDialog from './SelectSectorDialog';
import React from 'react';
import { Cfont, root } from '../../../styles/colors';
import ExpandIcon from '../../../assets/ExpandIcon';

import NewsDialog from './NewsDialog';
import moment from 'moment';
import { NewsComp } from '../../../theme/light';

const timeSince = (date: any) => {
  const now = new Date();

  var seconds = Math.floor((now.getTime() - date) / 1000);

  var interval = seconds / 31536000;
  if (interval > 1) {
    return Math.floor(interval) + ' years ago';
  }
  interval = seconds / 2592000;
  if (interval > 1) {
    return Math.floor(interval) + ' months ago';
  }
  interval = seconds / 604800;
  if (interval > 1) {
    return Math.floor(interval) + ' weeks ago';
  }
  interval = seconds / 86400;
  if (interval > 1) {
    return Math.floor(interval) + ' days ago';
  }
  interval = seconds / 3600;
  if (interval > 1) {
    return Math.floor(interval) + ' hours ago';
  }
  interval = seconds / 60;
  if (interval > 1) {
    return Math.floor(interval) + ' minutes ago';
  }
  return 'now';
};

const NewsComponent = () => {
  const [sectors, setSectors] = useState([]);
  const [selectedSector, setSelectedSector] = useState<any>();
  const [sectorDialog, setSectorDialog] = useState(false);

  const [newsDialog, setNewsDialog] = useState(false);
  const [news, setNews] = useState([]);
  const [loadingNews, setLoadingNews] = useState(true);
  const [selectedNews, setSelectedNews] = useState<any>();

  useEffect(() => {
    console.log('1');

    const loadSectors = () => {
      const headers = new Headers();
      headers.append('jTenantToken', '1');
      headers.append('jTenantid', '1404');
      fetch('https://pre-prod.odinwave.com/cds/1404/V1/-/-/GetSectorList', {
        method: 'GET',
        headers: headers,
      })
        .then(response => {
          return response.json();
        })
        .then((data): any => {
          if (data.ResponseObject.type === 'success') {
            setSectors(data.ResponseObject.resultset);
            if (selectedSector === undefined) {
              setSelectedSector(data.ResponseObject.resultset[0]);
            }
          }
        })
        .catch(error => console.log('error', error));
    };
    loadSectors();
  }, []);

  useEffect(() => {
    const loadNews = async () => {
      setLoadingNews(true);
      if (selectedSector) {
        const headers = new Headers();
        headers.append('jTenantToken', '1');
        headers.append('jTenantid', '1404');
        fetch(
          'https://pre-prod.odinwave.com/cds/1404/V1/' +
            selectedSector.SectorCode +
            '/1/10/GetSectorWiseNewsData',
          {
            method: 'GET',
            headers: headers,
          },
        )
          .then(response => {
            setLoadingNews(false);
            return response.json();
          })
          .then((data): any => {
            if (data.ResponseObject.type === 'success') {
              console.log(data.ResponseObject.resultset);
              setNews(data.ResponseObject.resultset);
              // setSectors(data.ResponseObject.resultset);
              // if (selectedSector === undefined) {
              //   setSelectedSector(data.ResponseObject.resultset[0]);
              // }
            }
          })
          .catch(error => console.log('error', error));
      }
    };
    loadNews();
  }, [selectedSector]);

  return (
    <View style={NewsComp.flex}>
      {/* Sector */}
      <View
        style={NewsComp.SectorMain}>
        <Text style={NewsComp.Sector}>Sector :</Text>
        <TouchableOpacity
          onPress={() => {
            setSectorDialog(true);
          }}>
          <View
            style={NewsComp.SelectMain}>
            <Text style={NewsComp.Select}>{selectedSector?.SectorName}</Text>
            <ExpandIcon
              style={NewsComp.Expand}
            />
          </View>
        </TouchableOpacity>
      </View>
      {loadingNews ? (
        <ActivityIndicator />
      ) : (
        <FlatList
          style={NewsComp.flatMain}
          data={news}
          renderItem={({item}: any) => {
            return (
              <TouchableOpacity
                key={item.SNo}
                onPress={() => {
                  setSelectedNews(item);
                  setNewsDialog(true);
                }}>
                <View
                  style={NewsComp.FlatHeadingMain}
                  key={item.SNo}>
                  <Text
                    style={NewsComp.FlatHeading}>
                    {item.Heading}
                  </Text>
                  <Text style={NewsComp.FlatTime}>
                    {timeSince(
                      moment(item.Date + ' ' + item.Time, 'DD-MMM-yyyy hh:mm'),
                    )}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          }}
          keyExtractor={(_, index) => `item-${index}`}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      )}
      <SelectSectorDialog
        visible={sectorDialog}
        onClose={() => {
          console.log('Here');
          setSectorDialog(false);
        }}
        sectors={sectors}
        onSectorSelected={(sector: any) => {
          setSelectedSector(sector);
          setSectorDialog(false);
        }}
        selectedSector={selectedSector}
      />
       <NewsDialog
        visible={newsDialog}
        onClose={() => {
          setNewsDialog(false);
        }}
        sNo={selectedNews?.SNo}
      />
    </View>
  );
};

export default NewsComponent;

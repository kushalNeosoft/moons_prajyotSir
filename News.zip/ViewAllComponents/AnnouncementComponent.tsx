import {useEffect, useState} from 'react';
import {
  ActivityIndicator,
  FlatList,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import ExpandIcon from '../../../assets/ExpandIcon';
import DropDownIcon from '../../../assets/DropDownIcon';
import React from 'react';
import { Cfont, root } from '../../../styles/colors';
import { Announce } from '../../../theme/light';

const exchanges = ['NSE', 'BSE', 'NSECDS'];
const AnnouncementItem = ({announcement}: any) => {
  const [expanded, setExpanded] = useState(false);
  const [showSelectExchange, setShowSelectExchange] = useState(false);
  const [selectedExchange, setSelectedExchange] = useState('NSE');


  return (
    <TouchableOpacity
      key={announcement.Symbol}
      onPress={() => {
        setExpanded(prev => !prev);
        // setSelectedNews(item);
        // setNewsDialog(true);
      }}>
      <View
        style={ Announce.CardBack}
        key={announcement.SNo}>
        <Text style={Announce.Cap}>
          {announcement.Caption}
        </Text>
        {expanded && <Text style={Announce.Memo}>{announcement.Memo}</Text>}

        <Text style={Announce.date}>{announcement.Date}</Text>
        <View
          style={{
            position: 'absolute',
            top: 8,
            right: 8,
            transform: [{rotateZ: expanded ? '180deg' : '0deg'}],
          }}>
          <DropDownIcon style={Announce.DropDown} />
        </View>
      </View>
    </TouchableOpacity>
  );
};
const AnnouncementComponent = () => {
  const [loading, setLoading] = useState(false);
  const [announcements, setAnnouncements] = useState([]);
  const [showSelectExchange, setShowSelectExchange] = useState(false);
  const [selectedExchange, setSelectedExchange] = useState('NSE');
  useEffect(() => {
    const loadNews = async () => {
      if (selectedExchange) {
        setLoading(true);
        const headers = new Headers();
        headers.append('jTenantToken', '1');
        headers.append('jTenantid', '1404');
        fetch(
          'https://pre-prod1.odinwave.com/cds/1404/v1/' +
            selectedExchange +
            '/1/10/GetAnnoucementsData',
          {
            method: 'GET',
            headers: headers,
          },
        )
          .then(response => {
            setLoading(false);
            return response.json();
          })
          .then((data): any => {
            if (data.ResponseObject.type === 'success') {
              console.log(data.ResponseObject.resultset);
              setAnnouncements(data.ResponseObject.resultset);
            }
          })
          .catch(error => console.log('error', error));
      }
    };
    loadNews();
  }, [selectedExchange]);
  return (
    <View style={{flex: 1}}>
      <View
        style={Announce.SectorMain}>
        <Text  style={Announce.Exc}>Exchange :</Text>
        <View style={Announce.DropDown1}>
          <TouchableOpacity
            onPress={() => {
              setShowSelectExchange(prev => !prev);
              // setSectorDialog(true);
            }}>
           
           <View
              style={Announce.ExcSec}>
              <Text style={Announce.ExcSelect}>{selectedExchange}</Text>
              <ExpandIcon
                style={Announce.ExcExpand}
              />
            </View>
          </TouchableOpacity>
          {showSelectExchange && (
            <View
              style={Announce.ShowMain}>
              {exchanges.map(exchange => {
                return (
                  <TouchableOpacity
                    key={exchange}
                    onPress={() => {
                      setSelectedExchange(exchange);
                      setShowSelectExchange(false);
                    }}>
                    <View
                      key={exchange}
                      style={Announce.ShowMain1}>
                      <Text style={Announce.ShowExc}>{exchange}</Text>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          )}
        </View>
      </View>
      <View style={{zIndex: -1}}>
        {loading ? (
          <ActivityIndicator />
        ) : (
          <FlatList
            style={{marginHorizontal: 16}}
            data={announcements}
            renderItem={({item}: any) => {
              return (
                <AnnouncementItem announcement={item} key={item.CompanyCode} />
              );
            }}
            keyExtractor={(_, index) => `item-${index}`}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
          />
        )}
      </View>
     
    </View>
  );
};

export default AnnouncementComponent;

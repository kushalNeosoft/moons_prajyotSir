import React, { useEffect, useState } from 'react';
//import {View, Text} from 'react-native';
import { Cfont, Font, root } from '../../../styles/colors';
import {
  View,
  Text,
  Modal,
  TouchableNativeFeedback,
  ScrollView,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import CloseIcon from '../../../assets/CloseIcon';
import { TouchableHighlight } from '@gorhom/bottom-sheet';
import { TextInput } from 'react-native-gesture-handler';
import SearchIcon from '../../../assets/SearchIcon';
import WebView from 'react-native-webview';
import HTMLView from 'react-native-htmlview';
import { NewsDialog1 } from '../../../theme/light';
const NewsDialog = ({ visible, onClose, sNo }: any) => {
  const [news, setNews] = useState<any>();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadNews = async () => {
      setLoading(true);
      const headers = new Headers();
      headers.append('jTenantToken', '1');
      headers.append('jTenantid', '1404');
      fetch(
        'https://pre-prod.odinwave.com/cds/1404/v1/' +
        sNo +
        '/GetSectorWiseNewsDetails',
        {
          method: 'GET',
          headers: headers,
        },
      )
        .then(response => {
          setLoading(false);
          return response.json();
        })
        .then((data): any => {
          if (data.ResponseObject.type === 'success') {
            console.log(data.ResponseObject.resultset);
            if (data.ResponseObject.recordcount === 1) {
              setNews(data.ResponseObject.resultset[0]);
            }
          }
        })
        .catch(error => console.log('error', error));
    };
    loadNews();
  }, [sNo]);
  return (
    <Modal
      visible={visible}
      onRequestClose={() => onClose()}
      transparent={true}>
      <View
        style={NewsDialog1.Main}>
        <TouchableOpacity onPress={() => onClose()}>
          <View
            style={NewsDialog1.close}
          />
        </TouchableOpacity>
      </View>

      <View
        style={NewsDialog1.MainView}>
        {loading && <ActivityIndicator />}
        {news && (
          <View style={NewsDialog1.Main1}>
            <View style={NewsDialog1.main2}>
              <Text
                style={NewsDialog1.Time}>
                {news.Date + ' ' + news.Time}
              </Text>
            </View>
            <View style={NewsDialog1.HaedingView}>
              <Text
                style={NewsDialog1.Heading}>
                {news.Heading}
              </Text>
              {/* <Text style={{fontSize: 14, marginTop: 16}}>{news.Caption}</Text> */}
              <ScrollView>
              <HTMLView
                value={news.ArtText}
                style={NewsDialog1.Html}
              />
              </ScrollView>
              
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
};
export default NewsDialog;

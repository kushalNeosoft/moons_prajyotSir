import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {ordersFilter} from '../../../../theme/light';

const AlertFilter = (props: any) => {
  const [category, setCategory] = useState('');
  const [alert, setAlert] = useState('');
  const categories = ['Equity', 'F&O'];
  const alerts = ['Price', '52WH', '52WL'];

  useEffect(() => {
    setCategory(props.category);
    setAlert(props.alerts);
  }, [props.order, props.filterTags]);

  const setFilter = () => {
    if (category !== '') {
      props.setCategoryFilter(category);
    }
    if (alert !== '') {
      props.setAlertFilter(alert);
    }
    props.closeSheet();
  };

  return (
    <View style={ordersFilter.Maincon}>
      <View style={ordersFilter.contentView}>
        <View>
          <Text style={ordersFilter.titleTxt}>Order</Text>
          <FlatList
            data={categories}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setCategory(item)}
                style={
                  item === category
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text style={ordersFilter.item}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View>
          <Text style={ordersFilter.titleTxt}>Broker Tags</Text>
          <FlatList
            data={alerts}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlert(item)}
                style={
                  item === alert
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text style={ordersFilter.item}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
      <TouchableOpacity style={ordersFilter.applyBtn} onPress={setFilter}>
        <Text style={ordersFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};

export default AlertFilter;

import React, {useRef, useState} from 'react';
import {
  View,
  Text,
  TouchableHighlight,
  Modal,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import alignment from '../../components/utils/alignment';
import Entypo from 'react-native-vector-icons/Entypo';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../styles/colors';
import {recommendationsAlerts, shiftButton} from '../../theme/light';
import Recommendations from './Recommendations/Recommendations';
import Alerts from './Alerts/Alerts';
import SortFilterBottomSheet from '../../components/BottomSheet/SortFilterBottomSheet';
import Filter from './components/Filter/Filter';
import BottomSheet from '@gorhom/bottom-sheet';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {useNavigation} from '@react-navigation/native';

function RecommendationsAlerts() {
  const [selectedBtn, setSelectedBtn] = useState<any>(0);
  const [searchKey, setSearchKey] = useState('');
  const [searchModalVisible, setSearchModalVisible] = useState(false);
  const [settingsView, setSettingsView] = useState(false);
  const buttons = ['Recommendations', 'Alerts'];
  const bottomSheetRef = useRef<BottomSheet>(null);

  const navigation = useNavigation();

  const renderButtons = () => {
    return (
      <View style={shiftButton.tabBarContainer}>
        {buttons &&
          buttons.map((btn: any, key: any) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? shiftButton.selectedTabBtns
                    : shiftButton.unSelectedTabBtns
                }
                onPress={() => setSelectedBtn(key)}>
                <Text
                  style={
                    selectedBtn === key
                      ? shiftButton.selectedBtnText
                      : shiftButton.tabBtnsText
                  }>
                  {btn}
                </Text>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };

  const searchModalToggle = () => {
    setSearchModalVisible(prevState => !prevState);
  };

  const openSortFilterSheet = () => {
    bottomSheetRef.current?.snapToIndex(0);
  };

  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return (
          <Recommendations
            openSortFilterSheet={openSortFilterSheet}
            searchModalToggle={searchModalToggle}
          />
        );
      case buttons[1]:
        return <Alerts />;
    }
  };

  return (
    <View style={recommendationsAlerts.container}>
      <View style={recommendationsAlerts.header}>
        <View style={recommendationsAlerts.rightHeaderView}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <AntDesign name="arrowleft" size={24} color={'black'} />
          </TouchableOpacity>
          <Text style={recommendationsAlerts.title}>
            Recommendations & Alerts
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => setSettingsView(prevState => !prevState)}>
          <Entypo name="dots-three-vertical" size={20} color={'black'} />
        </TouchableOpacity>
      </View>
      {renderButtons()}
      {renderView(buttons[selectedBtn])}
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        closesheet={closeSheet}
        index={-1}>
        <Filter />
      </SortFilterBottomSheet>
      <Modal
        visible={searchModalVisible}
        transparent={false}
        onRequestClose={searchModalToggle}>
        <View style={recommendationsAlerts.searchModal}>
          <View style={recommendationsAlerts.modalHeader}>
            <View style={recommendationsAlerts.rightHeaderView}>
              <TouchableOpacity onPress={searchModalToggle}>
                <Ionicons name="close" size={25} color="black" />
              </TouchableOpacity>
              <TextInput
                placeholder="Search eg: Axis,Reliance"
                value={searchKey}
                onChangeText={key => setSearchKey(key)}
                placeholderTextColor={root.color_textual}
                style={recommendationsAlerts.txtIp}
              />
            </View>
            <MaterialCommunityIcons
              name="microphone"
              size={24}
              color={root.color_text}
            />
          </View>
        </View>
      </Modal>
      {settingsView ? (
        <TouchableOpacity
          onPress={() => navigation.navigate('Settings')}
          style={recommendationsAlerts.settingsView}>
          <Text
            style={recommendationsAlerts.settingsTxt}>
            Settings
          </Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}

export default RecommendationsAlerts;

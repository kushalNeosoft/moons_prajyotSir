import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import CommonModaltwo from '../../../../components/CommonModal/CommonModaltwo';
import { followUpModal } from '../../../../theme/light';
import { root } from '../../../../styles/colors';

const FollowUpModal = (props: any) => {
  console.log(props.data)
  return (
    <CommonModaltwo visible={props.visible} onClose={props.onClose}>
      <Text style={followUpModal.titleTxt}>Follow-up Recommendations</Text>
      <View style={followUpModal.gainerContainer}>
        <Text style={followUpModal.volGainer}>Vol Gainer</Text>
      </View>
      <View
        style={followUpModal.detailsContainer}>
        <Text style={followUpModal.typeTxt}>
          Exit Buy: Sell NSE EQUITIES ABB EQ @ 2500.00
        </Text>
        <Text style={[followUpModal.transaction,{backgroundColor:root.color_negative}]}>Sell</Text>
        <Text style={followUpModal.date}>12 Aug 22 5:36PM</Text>
      </View>
      <View
        style={followUpModal.detailsContainer}>
        <Text style={followUpModal.typeTxt}>
          Exit Buy: Sell NSE EQUITIES ABB EQ @ 2500.00
        </Text>
        <Text style={followUpModal.transaction}>Buy</Text>
        <Text style={followUpModal.date}>12 Aug 22 5:36PM</Text>
      </View>
    </CommonModaltwo>
  );
};

export default FollowUpModal;

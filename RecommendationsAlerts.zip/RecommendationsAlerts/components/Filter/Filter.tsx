import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  TextInput,
} from 'react-native';
import { Cfont, Font, root } from '../../../../styles/colors';
import { ordersFilter } from '../../../../theme/light';

const OrdersFilter = props => {
  const [order, setOrder] = useState<number>();
  const [broker,setBroker]=useState('');
  const orders = [1, 2];
  const brokerTags=['All1','Bracket']

  return (
    <View style={ordersFilter.Maincon}>
      <View style={ordersFilter.contentView}>
        <View>
          <Text style={ordersFilter.titleTxt}>Alphabetically</Text>
          <FlatList
            data={orders}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOrder(item)}
                style={
                  item === order
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={ordersFilter.item}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View>
          <Text style={ordersFilter.titleTxt}>Order</Text>
          <FlatList
            data={brokerTags}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setBroker(item)}
                style={
                  item === broker
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={ordersFilter.item}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
      <TouchableOpacity style={ordersFilter.applyBtn}>
        <Text style={ordersFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};

export default OrdersFilter;

import React, {useRef, useState} from 'react';
import {FlatList, Modal, StyleSheet, Text, TouchableOpacity, TouchableWithoutFeedback, View} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import FollowUpModal from '../components/FollowUpModal/FollowUpModal';
import Fontisto from 'react-native-vector-icons/Fontisto';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import {recommendations} from '../../../theme/light';
import { useNavigation } from '@react-navigation/native';

function Recommendations(props: any) {
  const [modalVisible, setModalVisible] = useState(false);
  const [itemData, setItemData] = useState<any>();

  const modalToggle = () => {
    setModalVisible(prevState => !prevState);
  };

  const showModalData = (data: any) => {
    setItemData(data);
    setModalVisible(prevState => !prevState);
  };

  const data = [
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Buy',
      buyType: 'Buy @ 560.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 1,
      gainer: 'Vol Gainer',
    },
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Sell',
      buyType: 'Buy @ 560.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 2,
      gainer: 'Raco',
    },
    {
      name: 'WIPRO',
      sExchange: 'NSE',
      sSeries: 'EQ',
      transaction: 'Sell',
      buyType: 'Buy @ 560.00 Target @ 600',
      recommendationOn: "11:23AM 19 Jun'23",
      valid: "19 Jun'23",
      followUp: 2,
      gainer: 'Raco',
    },
  ];

  const progressBarView = () => {
    return (
      <View style={recommendations.innerProgress}>
        <View style={recommendations.outerProgress} />
      </View>
    );
  };

  const horizontalLine = () => {
    return <View style={recommendations.horzontalLine} />;
  };

  const renderCards = ({item}: any) => {
    return (
      <View style={recommendations.card}>
        <View style={{padding: 12}}>
          <View style={recommendations.topView}>
            <View>
              <View style={recommendations.nameContainer}>
                <Text style={recommendations.stockName}>{item.name}</Text>
                <Text style={recommendations.nseText}>{item.sExchange}</Text>
                <Text style={recommendations.eQ}>{item.sSeries}</Text>
              </View>
              <View style={recommendations.gainerContainer}>
                <Text style={recommendations.volGainer}>{item.gainer}</Text>
              </View>
            </View>
            <TouchableOpacity>
              <Text
                style={
                  item.transaction === 'Buy'
                    ? recommendations.buyTxt
                    : [
                        recommendations.buyTxt,
                        {backgroundColor: root.color_negative},
                      ]
                }>
                {item.transaction}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={{...alignment.row, paddingVertical: 16}}>
            <Text style={recommendations.buyTarget}>{item.buyType}</Text>
          </View>
          {progressBarView()}
          {horizontalLine()}
          <View style={recommendations.recommendationValidity}>
            <View>
              <Text style={recommendations.detailTxt}>Recommendation on</Text>
              <Text style={recommendations.detailTxt}>
                {item.recommendationOn}
              </Text>
            </View>
            <View>
              <Text style={recommendations.detailTxt}>Valid Till</Text>
              <Text style={recommendations.detailTxt}>{item.valid}</Text>
            </View>
          </View>
          {item.followUp > 1 ? (
            <TouchableOpacity
              onPress={() => showModalData(item)}
              style={recommendations.followUpSection}>
              <Text style={recommendations.noOfFollupRecommendation}>
                {item.followUp}
              </Text>
              <Text style={recommendations.followUp}>
                Follow-up Recommendations
              </Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
    );
  };
  return (
    <View style={recommendations.container}>
      <View style={recommendations.header}>
        <Text style={recommendations.noOfRecommendations}>
          6 Recommendations
        </Text>
        <View style={recommendations.filterSearchContainer}>
          <TouchableOpacity onPress={() => props.searchModalToggle()}>
            <Fontisto
              name="search"
              size={20}
              color={'black'}
              style={{paddingRight: 25}}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => props.openSortFilterSheet()}>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
          </TouchableOpacity>
        </View>
      </View>
      <FlatList data={data} renderItem={renderCards} />
      <FollowUpModal
        onClose={modalToggle}
        visible={modalVisible}
        data={itemData}
      />
    </View>
  );
}

export default Recommendations;

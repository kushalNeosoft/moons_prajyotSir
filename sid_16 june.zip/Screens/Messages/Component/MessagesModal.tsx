import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import ModalItems from './ModalItems';
import {messagesModal} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';

const modalData = [
  {
    title: 'NSE CASH',
  },
  {
    title: 'NSE DERIVATIVES',
  },
  {
    title: 'BSE CASH',
  },
  {
    title: 'BSE DERIVATIVES',
  },
  {
    title: 'MCX FUTURES',
  },
  {
    title: 'NCDEX FUTURES',
  },
  {
    title: 'BSE COMM',
  },
  {
    title: 'NSECDS',
  },
  {
    title: 'BSECDS',
  },
  {
    title: 'ICEX FUTURES',
  },
  {
    title: 'UCX FUTURES',
  },
];

const MessagesModal = props => {
  const modalRenderItem = ({item}: any) => {
    return (
      <ModalItems
        title={item?.title}
        setModalChip={props.setModalChip}
        setVisibleModal={props.setVisibleModal}
        modalChip={props.modalChip}
      />
    );
  };

  return (
    <CommonModal visible={props.visibleModal} onClose={() => {}}>
      <View style={messagesModal.modalMainView}>
        <View style={messagesModal.headerAndIconView}>
          <Text style={messagesModal.modalTitle}>Exchange</Text>
          <TouchableOpacity
            onPress={() => {
              props.setVisibleModal(false);
            }}>
            <AntDesign name="close" style={messagesModal.modalCloseIcon} />
          </TouchableOpacity>
        </View>
        <FlatList
          data={modalData}
          renderItem={modalRenderItem}
          contentContainerStyle={messagesModal.modalFlatelistConatiner}
          style={messagesModal.modalDataFlatelist}
        />
      </View>
    </CommonModal>
  );
};
export default MessagesModal;

import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {messagesModal} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const ModalItems = props => {
  return (
    <TouchableOpacity
      style={messagesModal.itemMainView}
      activeOpacity={0.3}
      onPress={() => {
        // setSelected(!selected);
        props.setModalChip(props.title);
        // props.setVisibleModal(false);
      }}>
      <Text style={messagesModal.modalItemTitle}>{props?.title}</Text>
      <MaterialCommunityIcons
        name={
          props.modalChip === props?.title
            ? 'radiobox-marked'
            : 'radiobox-blank'
        }
        style={messagesModal.radioBtn}
      />
    </TouchableOpacity>
  );
};
export default ModalItems;

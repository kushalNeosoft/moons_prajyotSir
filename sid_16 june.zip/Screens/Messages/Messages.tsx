import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import {sideDrawerMessages, messagesModal} from '../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
import MessagesModal from './Component/MessagesModal';
import MessageOrder from './Component/MessageOrder';
import SearchModal from './Component/SearchModal';
const modalData = [
  {
    title: 'NSE CASH',
  },
];

let ordersData = [];
let brokersData = [];
let DropDownData = [];

const Messages = () => {
  const [index, setIndex] = useState(0);
  const [visibleModal, setVisibleModal] = useState(false);
  const [modalChip, setModalChip] = useState(modalData[0].title);
  const [modalVisible, setModalVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const navigation = useNavigation();

  const fetchData = () => {
    // Replace this with your actual data fetching logic
    setTimeout(() => {
      ordersData = [
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '15 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '16 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '17 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '18 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '19 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '20 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '21 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '22 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '23 Jun 23 17:50PM',
        },
        {
          title:
            'NWSYM00003663732023 : Traded Trade no: 38 BOUGHT AGAINST Order no. 66560 1 NSE EQUITY INFY Amount: 1246.75 Order-Type: Reguler Lot Limit at 1246.75 at 15-062023 5:50:48 PM Product Type: MARGIN For PRAGATI',
          date: '24 Jun 23 17:50PM',
        },
      ];
      brokersData = [
        {
          title: 'EOD Trade Message : 14Jun 2023 : NSEBUYITC EQ @10.00',
          date: '14 Jun 23 17:50PM',
        },
        {
          title: 'BUY nifty @ 19000',
          date: '17 Jun 23 17:50PM',
        },
        {
          title: 'Real Time Trade messages : 6/14/2023 YKRAF',
          date: '18 Jun 23 17:50PM',
        },
        {
          title:
            'Real Time Trade Messages : 6/14/2023 11:40:01 AM NSE BUY ITC EQ @10.00 Order #21600 Trade #15607 init By Wave_Mobile Mod By ',
          date: '19 Jun 23 17:50PM',
        },
        {
          title:
            'Orders Details : 6/14/2023 11:40:01 AM NSE BUY ITC EQ VAlidity up To That @10.00 Order #21600 Trade #15607 init By Wave_Mobile Mod By ',
          date: '20 Jun 23 17:50PM',
        },
      ];
      DropDownData = [
        {
          title: 'Attn. Members:',
          date: '14 Jun 23 17:50PM',
        },
        {
          title: 'Upper price range of WIPRO is Being relaxed',
          date: '17 Jun 23 17:50PM',
        },
        {
          title: 'From 10% to 15%',
          date: '18 Jun 23 17:50PM',
        },
        {
          title:
            'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
          date: '19 Jun 23 17:50PM',
        },
        {
          title: 'Attn. Members:',
          date: '20 Jun 23 17:50PM',
        },
        {
          title: 'Lower Price range Of Wipro is Being Realxed',
          date: '20 Jun 23 17:50PM',
        },
        {
          title:
            'as Notified vide cicular NO : NSE/CMTR/38833 dated May 09, 2014',
          date: '19 Jun 23 17:50PM',
        },
        {
          title: 'EOD Trade Message : 14Jun 2023 : NSEBUYITC EQ @10.00',
          date: '14 Jun 23 17:50PM',
        },
        {
          title: 'BUY nifty @ 19000',
          date: '17 Jun 23 17:50PM',
        },
        {
          title: 'Real Time Trade messages : 6/14/2023 YKRAF',
          date: '18 Jun 23 17:50PM',
        },
      ];
      setIsLoading(false);
    }, 2000);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const renderItem = ({item}: any) => {
    return <MessageOrder title={item?.title} date={item?.date} />;
  };

  const topBar = () => {
    return (
      <View style={sideDrawerMessages().scrollBarView}>
        <TouchableOpacity
          style={sideDrawerMessages({Index: index}).brokerTopBarTextBg}
          onPress={() => {
            setIndex(0);
          }}>
          <Text style={sideDrawerMessages({Index: index}).brokerTopBarText}>
            Broker
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={sideDrawerMessages({Index: index}).ordersTopBarTextBg}
          onPress={() => {
            setIndex(1);
          }}>
          <Text style={sideDrawerMessages({Index: index}).ordersTopBarText}>
            Order
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={sideDrawerMessages({Index: index}).nseTopBarTextBg}
          onPress={() => {
            setIndex(2);
            setVisibleModal(true);
          }}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <Text style={sideDrawerMessages({Index: index}).nseTopBarText}>
              {modalChip}
            </Text>
            <MaterialIcons
              name="keyboard-arrow-down"
              style={sideDrawerMessages({Index: index}).dropDownIcon}
            />
          </View>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <View style={sideDrawerMessages().mainView}>
      {/* Header */}
      <View style={sideDrawerMessages().headerView}>
        <View style={sideDrawerMessages().backIconHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <Ionicons
              name="arrow-back"
              style={sideDrawerMessages().headerBackIcon}
            />
          </TouchableOpacity>
          <Text style={sideDrawerMessages().headerText}>Messages</Text>
        </View>
        <TouchableOpacity
          onPress={() => {
            setModalVisible(true);
          }}>
          <Ionicons
            name="search-sharp"
            style={sideDrawerMessages().headerSearchIcon}
          />
        </TouchableOpacity>
      </View>

      {/* TabBar */}

      <View style={sideDrawerMessages().topBarBackgroundView}>{topBar()}</View>
      {isLoading ? (
        <ActivityIndicator
          style={sideDrawerMessages().activityIndicatore}
          color={'#25335C'}
          size={25}
        />
      ) : (
        <FlatList
          data={
            index === 0 ? brokersData : index === 1 ? ordersData : DropDownData
          }
          renderItem={renderItem}
          style={{marginTop: 15, marginBottom: 5}}
        />
        // <Text style={sideDrawerMessages().noDataText}>No data Found</Text>
      )}

      <MessagesModal
        visibleModal={visibleModal}
        setVisibleModal={setVisibleModal}
        modalChip={modalChip}
        setModalChip={setModalChip}
      />
      <SearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
    </View>
  );
};
export default Messages;

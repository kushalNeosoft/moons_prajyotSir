// Messages Screen Style
export const sideDrawerMessages = (props = {}) =>
  StyleSheet.create({
    mainView: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    headerView: {
      flexDirection: "row",
      justifyContent: "space-between",
      alignItems: "center",
      height: 56,
      paddingHorizontal: 18,
    },
    backIconHeaderView: {
      flexDirection: "row",
      alignItems: "center",
    },
    headerText: {
      fontSize: Font.font_normal_ten,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      paddingLeft: 20,
    },
    headerBackIcon: {
      fontSize: Font.font_normal_twenty_four,
      color: root.color_text,
    },
    headerSearchIcon: {
      fontSize: Font.font_normal_twenty_two,
      color: root.color_text,
    },
    dropDownIcon: {
      fontSize: Font.font_normal_three,
      color: props.Index == 2 ? root.color_active : root.color_text,
      paddingRight: 11,
    },
    scrollBarView: {
      flexDirection: "row",
      borderRadius: 25,
      // alignItems:"center",
      // justifyContent:"center",
      height: 32,
      paddingHorizontal: 18,
    },
    brokerTopBarTextBg: {
      marginRight: 5,
      height: 32,
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 25,
      backgroundColor: props.Index == 0 ? root.color_textual : "transparent",
      borderColor: root.color_text,
      borderWidth: props.Index != 0 ? 0.9 : 0,
      width: 78,
    },
    brokerTopBarText: {
      fontSize: Font.font_normal_seven,
      paddingHorizontal: 9,
      fontFamily: Cfont.rubik_medium,
      color: props.Index == 0 ? root.color_active : root.color_text,
    },
    ordersTopBarTextBg: {
      // paddingHorizontal: 10,
      marginRight: 5,
      height: 32,
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 25,
      backgroundColor: props.Index == 1 ? root.color_textual : "transparent",
      borderWidth: props.Index != 1 ? 0.9 : 0,
      width: 78,
    },
    ordersTopBarText: {
      fontSize: Font.font_normal_seven,
      paddingHorizontal: 9,
      fontFamily: Cfont.rubik_medium,
      color: props.Index == 1 ? root.color_active : root.color_text,
    },
    nseTopBarTextBg: {
      // paddingHorizontal: 10,
      marginRight: 5,
      height: 32,
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 25,
      backgroundColor: props.Index == 2 ? root.color_textual : "transparent",
      borderWidth: props.Index != 2 ? 0.9 : 0,
    },
    nseTopBarText: {
      fontSize: Font.font_normal_seven,
      paddingLeft: 20,
      paddingRight: 6,
      fontFamily: Cfont.rubik_medium,
      color: props.Index == 2 ? root.color_active : root.color_subtext,
    },
    topBarBackgroundView: {
      width: "100%",
      flexDirection: "row",
      // alignSelf: 'center',
      paddingTop: 7,
    },
    activityIndicatore: {
      marginTop: 15,
      marginBottom: 5,
      color: "red",
    },
    noDataText: {
      marginTop: 40,
      fontSize: 13,
      color: root.color_subtext,
      fontFamily: Cfont.rubik_regular,
      alignSelf: "center",
    },
  });

//side Drawer Message Modal

export const messagesModal = StyleSheet.create({
  modalMainView: {
    backgroundColor: root.color_active,
    paddingHorizontal: 10,
  },
  modalTitle: {
    color: root.color_text,
    fontSize: Font.font_sub_title,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    paddingTop: 3,
  },
  headerAndIconView: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  itemMainView: {
    width: "100%",
    height: 51,
    backgroundColor: root.color_active,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  modalItemTitle: {
    color: root.ion_rb_2,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
  },
  radioBtn: {
    color: root.ion_rb_2,
    fontSize: Font.font_normal_twenty_six,
  },
  modalDataFlatelist: {
    height: 350,
    marginTop: 10,
  },
  modalFlatelistConatiner: {
    marginTop: 6,
  },
});

export const messageOrder = StyleSheet.create({
  mainView: {
    width: "100%",
    backgroundColor: root.color_chipFilter,
    flexDirection: "row",
    marginBottom: 5,
  },
  messageOrderImg: {
    borderRadius: 25,
    height: 35,
    width: 35,
    backgroundColor: root.color_active,
    marginTop: 10,
    marginLeft: 17,
  },
  messageOrderText: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 9,
    paddingLeft: 25,
    paddingRight: 30,
    color: root.color_text,
    marginRight: 30,
  },
  messageOrderDate: {
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_light,
    paddingLeft: 25,
    color: root.color_text,
    paddingTop: 3,
    paddingBottom: 10,
  },
});

// Messages Search Modal

export const messageSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: 300,
    justifyContent: "center",
    alignItems: "center",
    //   backgroundColor : "#00BCD4",
    //   height: 300 ,
    //   width: '80%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: root.color_active,
    //  width: 300,
    //  height: 60,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    marginHorizontal: 13,
  },
  textInput: {
    flex: 1,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  cleanBtn: {
    fontFamily: Cfont.rubik_medium,
    marginHorizontal: 15,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
});

//Indices View All styling

export const indicesViewAll = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 18,
    height: 52,
    alignItems: "center",
  },
  headerShadowHideView: {
    width: "100%",
    height: 8,
    backgroundColor: root.color_active,
    // zIndex: 10,
  },
  headerTextIconView: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_ten,
    marginLeft: 34,
  },
  backIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_two,
  },
  filterIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_two,
  },

  // cutom Tab Bar style

  tabBarContainer: {
    flexDirection: "row",
    paddingHorizontal: 16,
    height: 46,
    backgroundColor: root.color_active,
    // shadowColor: '#000',
    // shadowOffset: {
    //   width: 20,
    //   height: 20,
    // },
    // shadowOpacity: 0.25,
    // shadowRadius: 3.84,
    elevation: 8,
  },
  selectedTabBtns: {
    justifyContent: "space-around",
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: root.color_textual,
  },
  unSelectedTabBtns: {
    justifyContent: "space-around",
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  selectedBtnText: {
    textAlign: "center",
    color: root.color_textual,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
  },
  tabBtnsText: {
    textAlign: "center",
    color: root.color_subtext,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
  },

  // tab bar style not cutom
  tabBarLabelStyle: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    textTransform: "none",
    marginBottom: 20,
  },
  tabBarStyle: {
    height: 40,
  },
  tabBarIndicatorStyle: {
    backgroundColor: root.color_textual,
    width: 120,
    marginLeft: 14,
    paddingRight: 17,
    height: 1.8,
  },
});

//Box component Indices View All

export const boxComponentIndices = (props = {}) =>
  StyleSheet.create({
    container: {
      backgroundColor:
        props.price > 13000
          ? root.color_positive
          : props.price == 0
          ? "#B1B1B1"
          : root.indices_red,
      height: 132,
      // flex: 0.5,
      width: "48%",
      marginBottom: 14,
      borderRadius: 8,
      marginRight: 11,
      shadowColor: "#000",
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,

      elevation: 3,
      overflow: "hidden",
    },
    title: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_medium,
      marginLeft: 12,
      marginTop: 11,
      paddingBottom: 25,
      fontSize: 12,
    },
    price: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 12,
      paddingBottom: 2,
      fontSize: 16,
    },
    changes: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 12,
      fontSize: Font.font_normal_seven,
    },
    date: {
      color: root.color_active_text,
      fontFamily: Cfont.rubik_light,
      marginLeft: 12,
      marginTop: 12,
      fontSize: Font.font_normal_six,
    },
    heartIcon: {
      fontSize: Font.font_normal_twenty_one,
      color: root.color_active,
      marginRight: 15,
      marginTop: 11,
    },
    titleHeartView: {
      flexDirection: "row",
      justifyContent: "space-between",
    },
  });

//indexFilter style

export const indexFilter = (props = {}) =>
  StyleSheet.create({
    Maincon: {
      // flex: 1,
      // backgroundColor: 'red',
      marginBottom: 100,
      marginTop: 20,
    },
    space: {
      // height: 82,
      backgroundColor: "white",
      marginBottom: 8,
    },
    spacetwo: {
      // height: 82,
      backgroundColor: "white",
      marginBottom: 8,
    },
    spaceinner: {
      backgroundColor: "white",
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    spacetwoinner: {
      backgroundColor: "white",
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    titleText: {
      color: root.color_text,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
    },
    commonHtLSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 126,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: props?.selected == true ? "#F5F7FA" : "white",
      margin: 12,
      marginRight: 0,
      marginBottom: 10,
      marginTop: 15,
      // marginHorizontal:20
    },

    commonHtZSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 81,
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: props?.selected == true ? "#F5F7FA" : "white",
      margin: 12,
      marginRight: 0,
      marginBottom: 5,
      marginTop: 15,
      // marginHorizontal:20
    },
    text: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
    },
  });

//MyFavourites screen style

export const myFavouritesScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    paddingHorizontal: 12,
  },
});

// Local screen style
export const localScreen = (props = {}) =>
  StyleSheet.create({
    mainView: {
      flex: 1,
      paddingHorizontal: 12,
    },
    dropDown: {
      height: 16,
      width: 70,
      backgroundColor: root.dropdown_background,
      alignItems: "center",
      // paddingLeft: 2,
      marginLeft: 4,
      flexDirection: "row",
      justifyContent: "space-between",
      marginTop: 18,
      borderWidth: 0.4,
      borderColor: root.dropdown_background,
    },
    dropDownText: {
      fontSize: Font.font_normal_six,
      color: root.color_subtext,
      fontFamily: Cfont.rubik_medium,
      paddingLeft: 3,
    },
    dropDownListView: {
      height: 123,
      width: 80,
      backgroundColor: root.color_active,
      zIndex: 10,
      position: "absolute",
      top: 35,
      elevation: 2,
      borderRadius: 6,
      marginLeft: 4,
    },
    dropDownItems: {
      fontSize: Font.font_normal_five,
      color: root.color_text,
      fontFamily:
        props.dropDownChip == props.Item
          ? Cfont.rubik_medium
          : Cfont.rubik_regular,
      marginTop: 10,
      marginBottom: 15,
      marginLeft: 7,
    },
    arrowIcon: {
      color: root.color_subtext,
      fontSize: Font.font_normal_fifteen,
      paddingRight: 2,
      paddingLeft: 8,
    },
  });

//global screen style
export const globalScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    paddingHorizontal: 12,
  },
  countryText: {
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 17,
  },
  innerFlatlist: {
    marginBottom: 15,
  },
  outerFlatlist: {
    marginTop: 29,
    paddingBottom: 30,
  },
});

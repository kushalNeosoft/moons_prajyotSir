

// Action Type 
export const ADD_REMOVE_STOCK = 'ADD_STOCK';

// Action.tsx
export const addRemoveStock = (stock: {}) => ({
  type: ADD_REMOVE_STOCK,
  payload: stock,
});

// Reducer.tsx
case ADD_REMOVE_STOCK: {
  let arr = [...state.favouritesStock];

  console.log('MY ARR', arr, action.payload);

  let idx = arr.findIndex(
    (itm, idx) => action.payload.indexId == itm.indexId,
  );

  if (idx == -1) {
    arr.push(action.payload);
  } else {
    arr = arr.filter((itm, idx) => action.payload.indexId != itm.indexId);
  }

  return {
    ...state,
    favouritesStock: [...arr],
  };
}
import React, {useEffect, useRef, useCallback, useState} from 'react';

import {View} from 'react-native';
import {portFolioScreen} from '../../theme/light';
import Header from '../../components/IndicesHeader/IndicesHeader';
import HoldingFilterComp from './Component/HoldingFilterComp';
import PositionFilter from './Component/PositionFilter';
import SortFilterBottomSheet from '../../components/BottomSheet/SortFilterBottomSheet';
import TopTabBar from './Component/TopTabBar';
const Portfolio = () => {
  const [filter, setFilter] = useState([]);
  const [pFilter, setpFilter] = useState([]);
  const bottomSheetRef = useRef<BottomSheet>(null);
  const buttons = ['Holdings', 'Positions'];
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [tabFilter, setTabFilter] = useState('');
  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  return (
    <View style={portFolioScreen.portFolioContainer}>
      <Header />
      <TopTabBar
        bottomSheetRef={bottomSheetRef}
        setTabFilter={setTabFilter}
        filter={filter}
        setFilter={setFilter}
        pfilter={filter}
        setpFilter={setFilter}
      />
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        index={-1}
        closesheet={closeSheet}>
        {tabFilter == 'Holding' ? (
          <HoldingFilterComp
            filter={filter}
            setFilter={setFilter}
            bottomSheetRef={bottomSheetRef}
          />
        ) : (
          <PositionFilter
            bottomSheetRef={bottomSheetRef}
            pFilter={pFilter}
            setpFilter={setpFilter}
          />
        )}
      </SortFilterBottomSheet>
    </View>
  );
};

export default Portfolio;

import React, {useCallback} from 'react';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {useNavigation} from '@react-navigation/native';
import {Cfont, root} from '../../../styles/colors';
import Holdings from '../Holding/Holdings';
import Positions from '../Position/Positions';
const TopTab = createMaterialTopTabNavigator();

export default function TopTabBar({
  setTabFilter,
  bottomSheetRef,
  filter,
  setFilter,
  pfilter,
  setpFilter,
}: any) {
  const Holding = useCallback(() => {
    return (
      <Holdings
        setTabFilter={setTabFilter}
        bottomSheetRef={bottomSheetRef}
        filter={filter}
        setFilter={setFilter}
      />
    );
  }, [filter, setFilter]);

  const Position = useCallback(() => {
    return (
      <Positions
        setTabFilter={setTabFilter}
        bottomSheetRef={bottomSheetRef}
        pfilter={pfilter}
        setpFilter={setpFilter}
      />
    );
  }, [pfilter, setpFilter]);
  const navigation = useNavigation();
  return (
    <>
      <TopTab.Navigator
        screenOptions={{
          tabBarScrollEnabled: false,
          lazy: true,
          //   tabBarStyle: {
          //     marginHorizontal: 0,
          //     height: 40,
          //     elevation: 10,
          //     paddingLeft: 50,
          //   },
          tabBarLabelStyle: {
            fontSize: 12,
            textTransform: 'none',
            fontFamily: Cfont.rubik_medium,
          },
          tabBarIndicatorStyle: {
            width: '45%',
            marginLeft: 9,
            backgroundColor: root.client_background,
          },
          tabBarActiveTintColor: root.client_background,
          tabBarInactiveTintColor: root.color_subtext,
          swipeEnabled: false,
        }}>
        <TopTab.Screen name="Holdings" component={Holding} />
        <TopTab.Screen name="Positions" component={Position} />
      </TopTab.Navigator>
    </>
  );
}

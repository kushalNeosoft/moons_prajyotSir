import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const BackIcon = (props: any) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    // width={48}
    // height={48}
    viewBox="0 96 960 960"
    fill={'currentColor'}
    {...props}>
    <Path d="M447 875 169 597q-5-5-7-10t-2-11q0-6 2-11t7-10l279-279q8-8 20-8t21 9q9 9 9 21t-9 21L262 546h496q13 0 21.5 8.5T788 576q0 13-8.5 21.5T758 606H262l228 228q8 8 8 20t-9 21q-9 9-21 9t-21-9Z" />
  </Svg>
);
export default BackIcon;

import React from 'react';
import {View, StyleSheet,Text} from 'react-native';
import TriangleLeft from './triangleleft';
import TriangleRight from './triangleRight';
import { root } from '../../styles/colors';

const Hexagon = (props:any) => {
  return (
    <View style={styles.hexagon}>
      <TriangleLeft />
      <View style={styles.hexagonInner}>
        <Text style={{alignSelf:'center',color:root.color_active_text}}>lorem epsum</Text>
        </View>
      <TriangleRight />
    </View>
  );
};

const styles = StyleSheet.create({
  hexagon: {
    flexDirection: 'row',
  },
  hexagonInner: {
    width: 80,
    height: 20,
    backgroundColor: root.client_background,
  },
  hexagonAfter: {
    position: 'absolute',
    bottom: -25,
    left: 0,
    width: 0,
    height: 0,
    borderStyle: 'solid',
    borderLeftWidth: 50,
    borderLeftColor: 'transparent',
    borderRightWidth: 50,
    borderRightColor: 'transparent',
    borderTopWidth: 25,
    borderTopColor: 'red',
  },
  hexagonBefore: {
    position: 'absolute',
    top: -25,
    left: 0,
    width: 0,
    height: 0,
    borderStyle: 'solid',
    borderLeftWidth: 50,
    borderLeftColor: 'transparent',
    borderRightWidth: 50,
    borderRightColor: 'transparent',
    borderBottomWidth: 25,
    borderBottomColor: 'red',
  },
});

export default Hexagon;

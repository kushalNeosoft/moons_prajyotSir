import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import { root } from '../../styles/colors';

const TriangleRight = (props:any) => {
  return <View style={[styles.triangle, props.style]} />;
};

const styles = StyleSheet.create({
  triangle: {
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 10,
    borderRightWidth: 10,
    borderBottomWidth: 20,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderBottomColor: root.client_background,
    transform:[{rotate:'+90deg'}]
  },
});

export default TriangleRight;

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import alignment from '../../utils/alignment';
import {styles} from './ConstituentsList.style';

const ConstituentsList = (props: any) => {
  return (
    <View style={styles.container}>
      <View>
        <View style={{...alignment.row}}>
          <Text style={styles.stockName}>{props.stockName}</Text>
          <Text style={styles.nseTxt}>NSE</Text>
        </View>
        <View style={{...alignment.row}}>
          {props.showIcon === true && (
            <MaterialCommunityIcons
              name="crown-circle"
              size={16}
              color="#ffd700"
            />
          )}
          {props.showIcon === true ? (
            <Text
              style={
                props.title === 'Vol.Gainer'
                  ? styles.volGainerTxt
                  : props.title === 'Pr.Loser'
                  ? styles.prLoserTxt
                  : styles.defaultTxt
              }>
              {props.title}
            </Text>
          ) : null}
        </View>
      </View>

      <View style={{...alignment.row_alignC}}>
        <View
          style={
            props.price > 200 && props.price < 300
              ? styles.rightValuesView_200_300
              : props.price > 300 && props.price < 500
              ? styles.rightValuesView_300_500
              : styles.rightValuesDefault
          }>
          <Text style={styles.currentPriceTxt}>{props.price}</Text>
          <Text style={styles.changes}>{props.changes}</Text>
        </View>
        <TouchableOpacity style={styles.bottonView}>
          <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
        </TouchableOpacity>
        <AntDesign
          name="pluscircleo"
          size={26}
          color="black"
          style={{marginHorizontal: 5}}
        />
      </View>
    </View>
  );
};

export default ConstituentsList;

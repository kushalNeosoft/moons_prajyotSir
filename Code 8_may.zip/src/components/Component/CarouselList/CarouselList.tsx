import React from 'react';
import {
  View,
  Text,
  FlatList,
  Dimensions,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Button,
  Modal,
} from 'react-native';
import Carousel from 'react-native-reanimated-carousel';
// import {colors} from '../../constants/colors';
import alignment from '../../utils/alignment';
import {CarouselProps} from './type';
import {buyData, sellData} from './constData';
import {useNavigation} from '@react-navigation/native';
import colors, {Cfont, Font, root} from '../../../styles/colors';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Entypo from 'react-native-vector-icons/Entypo';
import {
  courselDemodata,
  endDemodata,
  progressData,
} from '../../assets/demoData';
import Feather from 'react-native-vector-icons/Feather';
import {
  interpolate,
  interpolateColor,
  useAnimatedStyle,
} from 'react-native-reanimated';
// import { Modal } from 'react-native-paper';
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

function CarouselList(props: CarouselProps) {
  const navigation = useNavigation();
  const buyView = () => {
    return (
      <View style={styles.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={styles.ordersHeaderText}>Qty</Text>
          <Text style={styles.ordersHeaderText}>Orders</Text>
          <Text style={styles.ordersHeaderText}>Bid</Text>
        </View>
        <FlatList
          data={buyData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={styles.buyText}>{item.qty}</Text>
              <Text style={styles.buyText}>{item.orders}</Text>
              <Text style={styles.buyText}>{item.bid}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  const sellView = () => {
    return (
      <View style={styles.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={styles.ordersHeaderText}>Ask</Text>
          <Text style={styles.ordersHeaderText}>Orders</Text>
          <Text style={styles.ordersHeaderText}>Qty</Text>
        </View>
        <FlatList
          data={sellData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={styles.sellText}>{item.ask}</Text>
              <Text style={styles.sellText}>{item.orders}</Text>
              <Text style={styles.sellText}>{item.qty}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  const renderItemList = ({item, index}: any) => {
    return (
      <>
        <View style={styles.subContainer}>
          <TouchableOpacity
            style={{
              height: '31%',
              width: '100%',
              backgroundColor: 'transperent',
            }}
            onPress={() => props.onCloseCarousel()}
            activeOpacity={1}
          />
          <View style={styles.subContainertwo}>
            <View style={styles.headerView}>
              <TouchableOpacity
                activeOpacity={1}
                onPress={() =>
                  navigation.navigate('Detail', {
                    detail: {item},
                  })
                }>
                <Text style={styles.companyName_Value_Text}>
                  {item.stockName}
                </Text>
                <View style={styles.bsesty}>
                  <Text style={styles.txtsty}>BSE</Text>
                  <Entypo
                    name="chevron-small-down"
                    size={10}
                    color={root.color_text}
                    style={{marginTop: 3}}
                  />
                </View>
              </TouchableOpacity>

              <View>
                <Text
                  style={[styles.companyName_Value_Text, {textAlign: 'right'}]}>
                  {item.price}
                </Text>
                <Text style={styles.chaval}>{item.changes}</Text>
                <View style={styles.iconall}>
                  <MaterialCommunityIcons
                    name="bell-outline"
                    color={'black'}
                    size={23}
                  />
                  <TouchableOpacity
                    style={{borderWidth: 1.5, borderRadius: 25}}>
                    <Feather name="bar-chart-2" size={20} color="black" />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <ScrollView
              overScrollMode="always"
              showsVerticalScrollIndicator={false}
              style={{paddingLeft: 16, paddingRight: 16}}>
              {/* Header View */}

              {/* Button View */}

              <View style={styles.buttonContainer}>
                <TouchableOpacity style={styles.buysty}>
                  <Text style={styles.buy_sell_Text}>Buy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.sellsty}>
                  <Text style={styles.buy_sell_Text}>Sell</Text>
                </TouchableOpacity>
              </View>
              {/* Button View Ends */}
              {/* Orders List View */}
              <View style={styles.ordersView}>
                {buyView()}
                {sellView()}
              </View>
              {/* Orders List View Ends */}
              {/* Total Bids View */}
              <View style={{...alignment.row_SpaceB, marginTop: '5%'}}>
                <Text style={styles.Bidtxt}>Total Bids</Text>
                <Text style={styles.Bidtxt}>Total Asks</Text>
              </View>

              <View style={styles.progressMain}>
                <View style={styles.progressOuter}>
                  <Text style={styles.perplus}>10</Text>
                </View>
                <Text style={styles.negtxt}>30</Text>
              </View>
              <View style={styles.oneflex}>
                {courselDemodata.map(item => {
                  return (
                    <View>
                      <Text style={styles.txttitle}>{item.title}</Text>
                      <Text style={styles.txtval}>{item.value}</Text>
                      <Text style={styles.txtval}>{item.valuetwo}</Text>
                    </View>
                  );
                })}
              </View>
              <View style={styles.twoflex}>
                {progressData.map(item => {
                  return (
                    <View style={styles.over}>
                      <Text style={styles.prtitle}>{item.title}</Text>
                      <View style={styles.prline} />
                      <View style={styles.txtallign}>
                        <Text style={styles.prval}>{item.price}</Text>
                        <Text style={styles.prval}>{item.pricetwo}</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
              <View style={styles.threeflex}>
                {endDemodata.map(item => {
                  return (
                    <View style={styles.endstyle}>
                      <Text style={styles.txttitle}>{item.title}</Text>
                      <Text style={styles.txtval}>{item.value}</Text>
                    </View>
                  );
                })}
              </View>

              {/* End total Bids View */}
              {/* <Button title="Close" onPress={() => props.onCloseCarousel()} /> */}
            </ScrollView>
          </View>
        </View>
      </>
    );
  };

  return (
    <Carousel
      style={styles.container}
      width={screenWidth}
      defaultIndex={props.index}
      data={props.listData}
      renderItem={renderItemList}
      panGestureHandlerProps={{
        activeOffsetX: [-50, 50],
      }}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignSelf: 'center',
    height: '100%',
    zIndex: 100,
    // backgroundColor: 'rgba(52, 52, 52, 0.8)',
  },
  subContainer: {
    // borderTopLeftRadius: 20,
    // borderTopRightRadius: 20,
    // width: screenWidth - 50,
    // height: screenHeight / 1.5,
    height: '100%',
    width: '100%',
    // top: screenHeight / 4.4,
    bottom: 0,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    alignSelf: 'center',
    position: 'relative',

    // padding: 16,
  },
  subContainertwo: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    width: screenWidth - 50,
    height: screenHeight / 1.5,
    // height:"100%",
    // width:'100%',
    // top: screenHeight / 4.4,
    bottom: 0,
    backgroundColor: 'white',
    alignSelf: 'center',
    position: 'absolute',

    // padding: 16,
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
    height: 106,
  },
  companyName_Value_Text: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    padding: 2,
    fontSize: Font.font_normal_five,
  },
  buy_sell_Text: {
    paddingHorizontal: 50,
    fontSize: Font.font_normal_three,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    paddingVertical: 7,
  },
  buttonContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 10,
  },
  ordersView: {
    ...alignment.row_SpaceB,
    marginTop: '4%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  buySellViewContainer: {
    height: 160,
    width: '49%',
  },
  buyText: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  sellText: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  ordersHeaderText: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  progressMain: {
    backgroundColor: root.color_negative_rgb,
    height: 20,
    width: '100%',
    marginTop: '5%',
    alignSelf: 'center',

    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressOuter: {
    width: '50%',
    backgroundColor: root.color_positive_rgb,
    justifyContent: 'center',
    height: 20,
  },
  corhedval: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chaval: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  iconall: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 2,
  },
  bsesty: {
    marginTop: '3%',
    backgroundColor: '#F0F0F0',
    flexDirection: 'row',
    width: '35%',

    justifyContent: 'space-around',
  },
  txtsty: {
    color: root.color_text,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
  buysty: {
    backgroundColor: root.color_positive,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    width: '47%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  sellsty: {
    backgroundColor: root.color_negative,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 6,
    shadowColor: '#000',
    height: 40,
    width: '47%',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  Bidtxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  perplus: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  negtxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  oneflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  twoflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txtallign: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  prtitle: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  prval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  prline: {
    height: '5%',
    backgroundColor: 'yellow',
  },
  over: {
    width: '40%',
    height: 60,
    justifyContent: 'space-between',
  },
  threeflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
  },
  endstyle: {
    margin: '1%',
  },
});

export default CarouselList;

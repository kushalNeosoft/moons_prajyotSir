import { StyleSheet,Dimensions } from "react-native";
import colors, { Cfont, Font, root } from "../../../styles/colors";
import alignment from "../../utils/alignment";


const screenHeight=Dimensions.get('window').height

export const styles = StyleSheet.create({
    bottomSheetContainer: {
      height: screenHeight,
      width: '100%',
      backgroundColor: 'white',
      position: 'absolute',
      top: screenHeight,
      borderRadius: 25,
      padding:20,
      zIndex:1
    },
    line: {
      width: 75,
      height: 4,
      marginTop:0,
      backgroundColor: 'grey',
      alignSelf: 'center',
      marginVertical: 15,
      borderRadius: 2,
    },
    commonTimingView: {
      height: 300,
      width: 120,
      alignItems: 'flex-start',
    },
    commonHtLSelected: {
      borderWidth: 1,
      borderRadius:10,
      borderColor:root.client_background,
      height: 40,
      width: 126.86,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:'#F5F7FA',
      margin:12,
      marginRight:0,
      marginBottom:0
      // marginHorizontal:20
    },
    commonHtLUnSelected: {
      borderWidth: 1,
      borderColor:root.color_border,
      borderRadius:10,
      height: 40,
      width: 126.86,
      alignItems: 'center',
      justifyContent: 'center',
      margin:12,
      marginRight:0,
      marginBottom:0
      // marginHorizontal:20
    },
    commonHtZSelected: {
      borderWidth: 1,
      borderRadius:10,
      borderColor:root.client_background,
      height: 40,
      width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor:'#F5F7FA',
      margin:12,
      marginRight:0,
      marginBottom:0
      // marginHorizontal:20
    },
    commonHtZUnSelected: {
      borderWidth: 1,
      borderColor:root.color_border,
      borderRadius:10,
       height: 40,
      // width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      paddingRight:24,
      paddingLeft:24,
      margin:12,
      marginRight:0,
      marginBottom:0
      // marginHorizontal:20
    },
    aplhaType: {
      width: 200,
      ...alignment.row_SpaceB,
    },
    pricePercentage: {
      width: 250,
      ...alignment.row_SpaceB,
    },
    submitBtn: {
      width: 300,
      backgroundColor: 'black',
      height: 50,
      alignSelf: 'center',
      marginTop: '30%',
      ...alignment.alignC_justifyC,
    },
    submitBtntwo:{
      position:'absolute',
      bottom:0,
      width:'100%',
      height:40,
      justifyContent:'center',
      alignItems:'center',
      backgroundColor: root.client_background,
    },
    titleText:{
      color:root.color_text,
      fontSize:Font.font_normal_one,
      fontFamily:Cfont.rubik_medium,
      
      
    },
    text:{
      color:root.color_text,
      fontSize:Font.font_normal_two,
      fontFamily:Cfont.rubik_regular,

    },
    header:{
      fontSize:Font.font_title,
      color:root.color_text,
      fontFamily:Cfont.rubik_medium,

    },
    space:{
      height:82,
      backgroundColor:'white',
      marginBottom:8,
    },
    spacetwo:{
      height:82,
      backgroundColor:'white',
      marginBottom:8,
    },
    spaceinner:{
      backgroundColor:"white",
      height:30,
      padding:16,
      paddingBottom:0
    },
    spacetwoinner:{
      backgroundColor:"white",
      height:30,
      padding:16,
      paddingBottom:0
    }
  });
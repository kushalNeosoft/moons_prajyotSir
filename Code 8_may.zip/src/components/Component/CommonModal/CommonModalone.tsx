import React, {useEffect} from 'react';
import {View, Text, Modal, StyleSheet, BackHandler, Alert, TouchableOpacity, TouchableWithoutFeedback} from 'react-native';

function CommonModalone(props: any) {
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}
      >
      <TouchableOpacity style={styles.centeredView} onPress={() => props.onClose()} activeOpacity={1}>
        
      </TouchableOpacity>
      <View style={styles.modalView}>{props.children}</View>
      
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    // top: 320,
    bottom: 0,
    left: 0,
    right: 0,
    height:'58%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    paddingVertical: 30,
    borderTopLeftRadius:10,
    borderTopRightRadius:10,
    // borderRadius: 10,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position:'relative'
  },
});

export default CommonModalone;

import React from "react";


const Lazycomponent = React.lazy(()=> import('../../Screens/Extra/comp/Mapview'))
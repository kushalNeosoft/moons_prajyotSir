import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';

const MyScreenersComponent = props => {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <View style={{marginTop: 10}}>
        <Text style={styles.title}>{props.title}</Text>
      </View>
    </TouchableOpacity>
  );
};
export default MyScreenersComponent;
const styles = StyleSheet.create({
  container: {
    backgroundColor: root.color_active,
    height: 116,
    width: 118,
    marginVertical: 10,
    marginRight: 13,
    marginLeft: 3,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    paddingTop: 12,
    paddingRight: 18,
    paddingBottom: 18,
    fontSize: 13,
  },
});

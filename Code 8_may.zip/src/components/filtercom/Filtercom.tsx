import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {Cfont, Font, root} from '../../styles/colors';
import {styles} from '../Component/BottomSheet/BottomSheetStyle';
import CustomHeader from '../Component/Header/CustomHeader';

const Filtercom = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [percentageValue, setPercentageValue] = useState('');
  const [typeValue, setTypeValue] = useState('');
  const [priceValue, setPriceValue] = useState('');
  const [exValue, setExValue] = useState('');

  //   const dispatch = useDispatch();
  //   const navigation=useNavigation();
  const navigation = useNavigation();
  const navtoback = () => {
    navigation.goBack();
  };

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['High to Low', 'Low to High'];
  const type = ['Equity', 'Equity F&O'];
  const percentage = ['High to Low', 'Low to High'];
  const Exchnages = ['BSE', 'NSE'];
  return (
    <View style={{flex: 1}}>
      <View style={styles.space}>
        <View style={styles.spaceinner}>
          <Text style={styles.titleText}>Alphabetically</Text>
        </View>

        <FlatList
          horizontal={true}
          data={alphabet}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setAlphabetValue(item)}
              style={
                alphabetValue === item
                  ? styles.commonHtZSelected
                  : styles.commonHtZUnSelected
              }>
              <Text style={styles.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={styles.spacetwo}>
        <View style={styles.spacetwoinner}>
          <Text style={styles.titleText}>Price</Text>
        </View>

        <FlatList
          horizontal={true}
          data={price}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setPriceValue(item)}
              style={
                priceValue === item
                  ? styles.commonHtLSelected
                  : styles.commonHtLUnSelected
              }>
              <Text style={styles.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={styles.spacetwo}>
        <View style={styles.spacetwoinner}>
          <Text style={styles.titleText}>Percentage</Text>
        </View>

        <FlatList
          horizontal={true}
          data={percentage}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setPercentageValue(item)}
              style={
                percentageValue === item
                  ? styles.commonHtLSelected
                  : styles.commonHtLUnSelected
              }>
              <Text style={styles.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={styles.space}>
        <View style={styles.spaceinner}>
          <Text style={styles.titleText}>Type</Text>
        </View>

        <FlatList
          data={type}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setTypeValue(item)}
              style={
                typeValue === item
                  ? styles.commonHtZSelected
                  : styles.commonHtZUnSelected
              }>
              <Text style={styles.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={styles.space}>
        <View style={styles.spaceinner}>
          <Text style={styles.titleText}>Exchnages</Text>
        </View>

        <FlatList
          data={Exchnages}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setExValue(item)}
              style={
                exValue === item
                  ? styles.commonHtZSelected
                  : styles.commonHtZUnSelected
              }>
              <Text style={styles.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
};
export default Filtercom;

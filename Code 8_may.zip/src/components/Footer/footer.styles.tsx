import {Dimensions, StatusBar, StyleSheet, useColorScheme} from 'react-native';
import {Font, root, TColors} from '../../styles/colors';

// console.log(height);

export const createFooterStyles = (colors: TColors) => {
  return StyleSheet.create({
    footerContainer: {
      padding: 16,
     
      flexDirection: 'row',
      justifyContent: 'space-between',
      backgroundColor:'white',
    },
    itemContainer: {
      paddingHorizontal: 12,
      paddingVertical: 4,
    },
    text: {
      fontSize: Font.font_normal_one,
      color:root.client_background
    },
    cliper: {
      borderRadius: 16,
    },
  });
};

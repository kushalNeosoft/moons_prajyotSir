import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const HoldingList = props => {
  return (
    <View style={styles.container}>
      <View>
        <Text style={styles.stockName}>{props.stockName}</Text>
        <View>
          <Text style={{fontSize: 12, color: 'green', paddingTop: 3}}>
            {props.stockTtile}
          </Text>
        </View>
      </View>
      <View>
        <Text></Text>
      </View>
    </View>
  );
};
export default HoldingList;
const styles = StyleSheet.create({
  container: {
    padding: 3,
    paddingLeft: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 50,
  },
  stockName: {
    color: 'black',
    fontWeight: '700',
    fontSize: 16,
  },
  bottonView: {
    borderColor: 'black',
    borderRadius: 15,
    borderWidth: 2,
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 6,
    marginRight: 7,
    marginTop: 4,
  },
});

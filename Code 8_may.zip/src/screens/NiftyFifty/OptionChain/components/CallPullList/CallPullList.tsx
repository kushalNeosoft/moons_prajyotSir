import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Font} from '../../../../../styles/colors';
import {root} from '../../../../../styles/colors';
import {Cfont} from '../../../../../styles/colors';

function CallPutList(props: any) {
  return (
    <TouchableOpacity
      activeOpacity={1}
      style={{
        height: '100%',
        width: 115,
        backgroundColor: props.leftView === true ? '#FFFED6' : '#FFFFFF',
      }}
      onPress={() => props.modalView()}>
      <View
        style={{
          paddingVertical: 5,
          alignItems: props.leftView === true ? 'flex-end' : 'flex-start',
        }}>
        <View style={{...alignment.row}}>
          <Text style={styles.ltpTxt}>{`${props.ltpTxt}:`}</Text>
          <Text style={styles.ltpValue}>{props.ltpValue}</Text>
        </View>
        <View style={{...alignment.row}}>
          <Text style={styles.ivTxt}>{`${props.ivTxt}:`}</Text>
          <Text style={styles.ivValue}>{props.ivValue}</Text>
        </View>
        <View style={{...alignment.row}}>
          <Text style={styles.oiTxt}>{`${props.oiTxt}:`}</Text>
          <Text style={styles.oiValue}>{props.oiValue}</Text>
        </View>
        <View
          style={{
            ...alignment.row,
            width: '60%',
            alignSelf: 'center',
            justifyContent: 'space-between',
            marginTop: 34,
          }}>
          {props.leftView === true ? (
            <>
              <AntDesign name="pluscircleo" size={22} color="black" />
              <TouchableOpacity style={styles.bottonView}>
                <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity style={styles.bottonView}>
                <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
              </TouchableOpacity>
              <AntDesign name="pluscircleo" size={22} color="black" />
            </>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 22,
    height: 22,
    borderRadius: 22 / 2,
    ...alignment.alignC_justifyC,
  },
  ltpTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

export default CallPutList;

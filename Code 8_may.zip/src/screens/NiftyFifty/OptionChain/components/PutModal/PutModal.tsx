import React from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Font} from '../../../../../styles/colors';
import {Cfont} from '../../../../../styles/colors';
import {root} from '../../../../../styles/colors';
import Common from '../CallPutCommonModal/Common';

function PutModal(props: any) {
  const leftData = [
    {
      name: 'LTP',
      value: '0.0',
    },
    {
      name: 'LTP (%)',
      value: '0.0',
    },
    {
      name: 'OI',
      value: '0.0',
    },
    {
      name: 'OI (%)',
      value: '0.0',
    },
    {
      name: 'IV',
      value: 0,
    },
  ];

  const rightData = [
    {
      name: 'Delta',
      value: 0,
    },
    {
      name: 'Gamma',
      value: '-',
    },
    {
      name: 'Theta',
      value: 0,
    },
    {
      name: 'Vega',
      value: 0,
    },
    {
      name: 'Rho',
      value: 0,
    },
  ];

  const renderLeftData = ({item}: any) => {
    return (
      <View style={{...alignment.row_SpaceB, paddingVertical: 5}}>
        <Text style={styles.txt}>{item.name}</Text>
        <Text style={styles.txt}>{item.value}</Text>
      </View>
    );
  };

  const renderRightData = ({item}: any) => {
    return (
      <View style={{...alignment.row_SpaceB, paddingVertical: 5}}>
        <Text style={styles.txt}>{item.name}</Text>
        <Text style={styles.txt}>{item.value}</Text>
      </View>
    );
  };
  return (
    <Common onClose={props.onClose} visible={props.visible}>
      <View style={{...alignment.row_SpaceB, padding: 16}}>
        <Text style={styles.callValue}>Nifty 13590</Text>
        <Text style={styles.callTxt}>Put</Text>
      </View>
      <View style={styles.horizontalLine} />
      <View style={{...alignment.row_SpaceB, padding: 16}}>
        <View style={{width: '45%'}}>
          <FlatList data={leftData} renderItem={renderLeftData} />
        </View>
        <View style={{width: '45%'}}>
          <FlatList data={rightData} renderItem={renderRightData} />
        </View>
      </View>
      <View style={styles.btnContainer}>
        <View style={styles.buyBtn}>
          <Text style={styles.btnTxt}>Buy</Text>
        </View>
        <TouchableOpacity style={styles.sellBtn}>
          <Text style={styles.btnTxt}>Sell</Text>
        </TouchableOpacity>
      </View>
    </Common>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  horizontalLine: {
    borderWidth: 0.5,
    marginHorizontal: 16,
    borderColor:"#979797"
  },
  callValue: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  callTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  buyBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_positive,
    borderRadius: 10,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
    paddingHorizontal: 16,
  },
});

export default PutModal;

import React from 'react';
import {View, Modal, Text, TouchableOpacity, StyleSheet} from 'react-native';

function Common(props: any) {
  return (
    <Modal
      onRequestClose={() => props.onClose()}
      transparent={true}
      visible={props.visible}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={styles.container}>{props.children}</View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
});

export default Common;

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {styles} from './DateStyle';
import alignment from '../../../../../components/utils/alignment';

function Date(props: any) {
  return (
    <View style={{paddingLeft: 10, paddingTop: 16}}>
      <TouchableOpacity
        onPress={() => props.onPress(props.date)}
        style={
          props.date === props.selectedDate
            ? styles.dateContainerSelected
            : styles.dateContainerUnselected
        }>
        <Text
          style={
            props.date === props.selectedDate
              ? styles.dateTxtSelected
              : styles.dateTxtUnselected
          }>
          {props.date}
        </Text>
        <View style={{...alignment.row}}>
          <Text
            style={
              props.date === props.selectedDate
                ? styles.monthTxtSelected
                : styles.monthTxtUnselected
            }>
            {props.month}
          </Text>
          <Text
            style={
              props.date === props.selectedDate
                ? styles.yearTxtSelected
                : styles.yearTxtUnselected
            }>
            {props.year}
          </Text>
        </View>
      </TouchableOpacity>
     </View>
  );
}

export default Date;

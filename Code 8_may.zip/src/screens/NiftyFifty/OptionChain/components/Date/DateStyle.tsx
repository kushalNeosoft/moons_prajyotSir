import {StyleSheet} from 'react-native';
import {Cfont, Font, root} from '../../../../../styles/colors';

export const styles = StyleSheet.create({
  dateContainerUnselected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
  },
  dateContainerSelected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
    backgroundColor: root.client_background,
  },
  dateTxtUnselected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  dateTxtSelected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  monthTxtUnselected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  monthTxtSelected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
  },
  yearTxtUnselected: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  yearTxtSelected: {
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
  },
  expiryTxt: {
    fontSize: Font.font_normal_seven,
    color: 'grey',
    fontFamily: Cfont.rubik_regular,
    paddingTop: 25,
    paddingLeft: 15,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

import React, {useCallback, useRef, useState} from 'react';
import {View, Text, StyleSheet, FlatList, Animated} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import Date from './components/Date/Date';
import {dateData, optionData} from './constData';
import CallModal from './components/CallModal/CallModal';
import PutModal from './components/PutModal/PutModal';
import CallPutList from './components/CallPullList/CallPullList';
import Hexagon from '../../../components/hexagon/Hexagon';
import Triangle from '../../../components/hexagon/triangleleft';

function OptionChain() {
  const [date, setDate] = useState('04');
  const [callModalVisible, setCallModalVisible] = useState(false);
  const [putModalVisible, setPutModalVisible] = useState(false);

  const onPress = (value: string) => {
    setDate(value);
  };

  const callModal = () => {
    setCallModalVisible(prevState => !prevState);
  };

  const putModalView = () => {
    setPutModalVisible(prevState => !prevState);
  };

  const component = () => {
    return (
      <View
        style={{
          height: 50,
          backgroundColor: 'yellow',
          zIndex: 1,
          width: '100%',
          position: 'absolute',
          top: 10,
        }}>
        <Text>Hello</Text>
      </View>
    );
  };

  const renderList = ({item, index}: any) => {
    return (
      <View style={styles.callsPutContainer}>
        <View style={{...alignment.row_SpaceB, height: '100%'}}>
          <CallPutList
            ltpTxt={item.calls.ltp}
            ltpValue={item.calls.value}
            ivTxt={item.calls.IV}
            ivValue={item.calls.ivValue}
            oiTxt={item.calls.OI}
            oiValue={item.calls.oiValue}
            leftView={true}
            modalView={callModal}
          />
          <View style={{justifyContent: 'center'}}>
            <Text style={styles.dayValue}>{`${item.value}.00`}</Text>
          </View>
          <CallPutList
            ltpTxt={item.calls.ltp}
            ltpValue={item.calls.value}
            ivTxt={item.calls.IV}
            ivValue={item.calls.ivValue}
            oiTxt={item.calls.OI}
            oiValue={item.calls.oiValue}
            leftView={false}
            modalView={putModalView}
          />
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View>
        <FlatList
          data={dateData}
          horizontal={true}
          renderItem={({item}) => (
            <Date
              date={item.date}
              month={item.month}
              year={item.year}
              onPress={onPress}
              selectedDate={date}
            />
          )}
        />
      </View>
      <Text style={styles.expiryTxt}>*18 Expires available till dec'27</Text>
      <View
        style={{
          ...alignment.row_SpaceB,
          paddingHorizontal: 12,
          marginTop: 34,
        }}>
        <Text style={styles.callsTxt}>Calls</Text>
        <Text style={styles.callsTxt}>Puts</Text>
      </View>
      {/* Main View */}
      <View style={{flex: 1}}>
        <Animated.View
          style={{
            position: 'absolute',
            zIndex: 1,
            width: '100%',
          }}>
          <View
            style={{
              width: '100%',
              zIndex: 1,
              position: 'absolute',
              top: 10,
              borderWidth: 0.5,
              borderStyle: 'dashed',
            }}
          />
          <View
            style={{
              position: 'absolute',
              height: 20,
              zIndex: 1,
              width: '100%',
              left: 120,
            }}>
            <Hexagon />
          </View>
        </Animated.View>
        <View style={{marginTop:32}}>
        <FlatList
          data={optionData}
          renderItem={renderList}
        />
        </View>
      </View>
      <CallModal
        visible={callModalVisible}
        onClose={() => setCallModalVisible(false)}
      />
      <PutModal
        visible={putModalVisible}
        onClose={() => setPutModalVisible(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  expiryTxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 32,
    paddingLeft: 15,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
  callsPutContainer: {
    height: 135,
  },
  value: {
    fontSize: Font.font_normal_two,
  },
  dayValue: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

export default OptionChain;

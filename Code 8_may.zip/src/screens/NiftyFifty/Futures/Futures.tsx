import React from 'react';
import {View, Text, StyleSheet, FlatList} from 'react-native';
import ListItem from './components/ListItem';

function Futures() {
  const data = [
    {
      date: "25 MAY '23",
      price: '17879.00',
      change: '35.35(-0.20%)',
      discount: '-103.65',
    },
    {
      date: "29 JUN '23",
      price: '17931.70',
      change: '24.65(-0.14%)',
      discount: '-149.76',
    },
    {
      date: "27 JUL '23",
      price: '18339.45',
      change: '00.00(-0.00)',
      discount: '-661.65',
    },
  ];

  const renderItem = ({item}: any) => {
    return (
      <ListItem
        date={item.date}
        price={item.price}
        change={item.change}
        discount={item.discount}
      />
    );
  };

  return (
    <View style={styles.container}>
      <FlatList data={data} renderItem={renderItem} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'rgba(0,0,0,0)',
  },
});

export default Futures;

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import {Cfont, Font} from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';

const ListItem = (props: any) => {
  return (
    <View style={styles.card}>
      <View style={{padding: 12}}>
        <View style={{...alignment.row_alingC_SpaceB}}>
          <View>
            <Text style={styles.date}>{props.date}</Text>
            <View style={{...alignment.row}}>
              <Text style={styles.price}>{props.price}</Text>
              <Text style={styles.change}>{props.change}</Text>
            </View>
          </View>

          <View style={{...alignment.row}}>
            <TouchableOpacity style={styles.bottonView}>
              <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
            </TouchableOpacity>
            <AntDesign
              name="pluscircleo"
              size={26}
              color="black"
              style={{marginHorizontal: 5}}
            />
          </View>
        </View>

        <View style={{...alignment.row, paddingTop: 20}}>
          <Text style={styles.discountTxt}>Premium Discount</Text>
          <Text style={styles.discount}>{props.discount}</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    marginTop: 12,
    marginHorizontal: 16,
    backgroundColor: '#FFFFFF',
    height: 110,
  },
  date: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily:Cfont.rubik_medium
  },
  price: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily:Cfont.rubik_regular
  },
  change: {
    fontSize: Font.font_normal_one,
    paddingTop: 4,
    paddingLeft: 3,
    color: root.color_negative,
    fontFamily:Cfont.rubik_regular
  },
  discountTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily:Cfont.rubik_light
  },
  discount: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingLeft: 3,
    fontFamily:Cfont.rubik_medium
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
});

export default ListItem;

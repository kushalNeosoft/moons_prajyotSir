import React from 'react';
import {View, Text, TouchableOpacity, FlatList, ScrollView} from 'react-native';
import {styles} from '../styles/styles';
import {screenersData} from './SampleData';
import MyScreenersComponent from '../../../components/MarketScreen/MyScreenersComponent';
const MyScreeners = () => {
  const renderScreenersItem = ({item}) => {
    return <MyScreenersComponent title={item.title} />;
  };
  return (
    <View style={{}}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingRight: 15,
        }}>
        <Text style={[styles.scrollHead, {marginTop: 9, marginBottom: 3}]}>
          {' '}
          My Screeners
        </Text>
        <TouchableOpacity>
          <Text style={[styles.viewAllButton, {marginTop: 10}]}>View All</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        directionalLockEnabled={true}
        alwaysBounceVertical={false}
        style={{marginLeft: 13}}>
        <FlatList
          contentContainerStyle={{alignSelf: 'flex-start'}}
          numColumns={Math.ceil(screenersData.length / 2)}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          data={screenersData}
          renderItem={renderScreenersItem}
        />
      </ScrollView>
    </View>
  );
};
export default MyScreeners;

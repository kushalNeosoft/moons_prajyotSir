import React, {useState, useRef, useEffect, useCallback} from 'react';
import {Text, View, TouchableOpacity, ScrollView} from 'react-native';
import {styles} from './styles/styles';
import WhatsNew from './MarketScreenParts/WhatsNew';
import NewProducts from './MarketScreenParts/NewProducts';
import Indices from './MarketScreenParts/Indices';
import MyScreeners from './MarketScreenParts/MyScreeners';
import NewsAndAnnouncement from './MarketScreenParts/NewsAndAnnouncement';
import Events from './MarketScreenParts/Events';
import IPO from './MarketScreenParts/IPO';
import {root, Font} from '../../styles/colors';
import {useNavigation} from '@react-navigation/native';
const MarketScreen = () => {
  const scrollViewRef = useRef();
  const [index, setIndex] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const scrollRef = useRef();
  const [clickedOnTopHeader, setClickOnTopHeader] = useState(false);

  // Scrollable Top bar code
  const topHeader = useCallback(() => {
    return (
      <ScrollView
        horizontal={true}
        ref={scrollRef}
        contentContainerStyle={styles.topBar}
        showsHorizontalScrollIndicator={false}
        style={{
          borderRadius: 25,
          overflow: 'hidden',
          backgroundColor: 'rgba(0,0,0,0.10)',
          marginVertical: 0,
          marginLeft: 0,
          height: 32,
        }}>
        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 0 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(0);
            indexScroll = 0;
            scrollViewRef.current.scrollTo({y: 0});
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 0 ? root.color_active : root.color_subtext},
            ]}>
            New
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 1 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(1);
            indexScroll = 1;
            scrollViewRef.current.scrollTo({y: 400});
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 1 ? root.color_active : root.color_subtext},
            ]}>
            Indices
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 2 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);

            setIndex(2);
            indexScroll = 2;
            scrollViewRef.current.scrollTo({y: 600});

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 2 ? root.color_active : root.color_subtext},
            ]}
            numberOfLines={1}>
            Screeners
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 3 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(3);
            indexScroll = 3;
            scrollViewRef.current.scrollTo({y: 880});

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 3 ? root.color_active : root.color_subtext},
            ]}>
            News
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 4 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);

            setIndex(4);
            indexScroll = 4;
            scrollViewRef.current.scrollTo({y: 1300});
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 4 ? root.color_active : root.color_subtext},
            ]}>
            Events
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.topBarOpacity,
            {backgroundColor: index == 5 ? root.color_textual : 'transparent'},
          ]}
          onPress={() => {
            setClickOnTopHeader(true);
            setIndex(5);
            indexScroll = 5;
            scrollViewRef.current.scrollTo({y: 2500});
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });

            setTimeout(() => {
              setClickOnTopHeader(false);
            }, 500);
          }}>
          <Text
            style={[
              styles.topBarText,
              {color: index == 5 ? root.color_active : root.color_subtext},
            ]}>
            IPO
          </Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }, [index]);

  // MarketScreen View Start
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      {/* Market Header Code */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
          <View
            style={{
              width: 15,
              backgroundColor: '#303030',
              height: 1.8,
              marginVertical: 1.5,
            }}></View>
          <View
            style={{
              width: 12,
              backgroundColor: '#303030',
              height: 1.8,

              marginVertical: 1.5,
            }}></View>
          <View
            style={{
              width: 8,
              backgroundColor: '#303030',
              height: 1.8,
              marginVertical: 1.5,
            }}></View>
        </TouchableOpacity>
        <Text style={styles.headerText}>Market</Text>
      </View>
      {/* market header code ends */}
      <View
        style={{
          width: '100%',
          paddingHorizontal: 13,
          flexDirection: 'row',
          // alignSelf: 'center',
        }}>
        {topHeader()}
      </View>

      <ScrollView
        ref={scrollViewRef}
        onScroll={event => {
          if (clickedOnTopHeader) {
            return;
          }

          setScrollY(event.nativeEvent.contentOffset.y);
          // update index based on scroll position
          if (
            event.nativeEvent.contentOffset.y >= 0 &&
            event.nativeEvent.contentOffset.y < 400
          ) {
            setIndex(0);
            indexScroll = 0;
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 400 &&
            event.nativeEvent.contentOffset.y < 600
          ) {
            setIndex(1);
            indexScroll = 1;
            scrollRef?.current?.scrollTo({
              x: 0,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 600 &&
            event.nativeEvent.contentOffset.y < 880
          ) {
            setIndex(2);
            indexScroll = 2;
          } else if (
            event.nativeEvent.contentOffset.y >= 880 &&
            event.nativeEvent.contentOffset.y < 1300
          ) {
            setIndex(3);
            indexScroll = 3;
          } else if (
            event.nativeEvent.contentOffset.y >= 1300 &&
            event.nativeEvent.contentOffset.y < 1500
          ) {
            setIndex(4);
            indexScroll = 4;
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });
          } else if (
            event.nativeEvent.contentOffset.y >= 1500 &&
            event.nativeEvent.contentOffset.y < 1800
          ) {
            setIndex(5);
            indexScroll = 5;
            scrollRef?.current?.scrollToEnd?.({
              x: 5,
              animated: true,
            });
          }
        }}>
        <WhatsNew />
        <NewProducts />
        <Indices />
        <MyScreeners />
        <NewsAndAnnouncement />
        <Events />
        <IPO />
      </ScrollView>
    </View>
  );
};
export default MarketScreen;

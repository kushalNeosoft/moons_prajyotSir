import {StyleSheet} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
export const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    flex: 1,
    borderBottomColor: root.color_primary,
  },
  header: {
    width: '100%',
    height: 58,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_primary,
    paddingLeft: 17,
    paddingRight: 16,
  },
  headerText: {
    color: root.color_text,
    fontSize: 17,
    marginLeft: 20,
    fontFamily: Cfont.rubik_medium,
  },
  headerIcon: {
    marginLeft: 16,
  },
  topBar: {
    flexDirection: 'row',
    borderRadius: 25,
    // alignItems:"center",
    // justifyContent:"center",
    height: 32,
  },
  topBarText: {
    fontSize: 11,
    marginHorizontal: 9,
    fontFamily: Cfont.rubik_medium,
  },
  topBarOpacity: {
    paddingHorizontal: 10,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
  },
  scrollHead: {
    color: root.color_text,
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  viewAllButton: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  newsSearchButton: {
    color: root.color_text,
    paddingTop: 9,
  },
  allNewsText: {
    color: root.color_textual,
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 35,
  },
  eventDateView: {
    backgroundColor: root.calendar_bg,
    height: 60,
    width: '100%',
    marginTop: 11,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  currentDate: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 16,
    fontSize: 15,
  },
  emptyEventText: {
    color: root.color_subtext,
    fontSize: 14,
    marginBottom: 50,
    marginTop: 15,
    fontFamily: Cfont.rubik_regular,
  },
});

import {StyleSheet} from 'react-native';
import {Font, root, TColors} from '../../../styles/colors';

export const createPasswordStyles = (colors: TColors) => {
  return StyleSheet.create({
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: Font.font_normal_three,
      alignSelf: 'center',
    },

    inputContainer: {
      flexDirection: 'row',
      borderColor: 'lightgrey',
      borderWidth: 2,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      color:root.color_text,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: 'grey',
      margin: 12,
    },
  });
};

import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../../styles/colors';

export const createProfileStyles = (colors: TColors) => {
  return StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
    },
    headerContainer: {
      backgroundColor: 'white',
      shadowColor: 'black',
      shadowOffset: {
        width: 0,
        height: 4,
      },
      shadowOpacity: 0.3,
      shadowRadius: 4.65,

      elevation: 8,
    },
    userContainer: {
      flexDirection: 'row',
      padding: 26,
    },
    userProfilePic: {
      width: 64,
      height: 64,
      backgroundColor: 'gray',
      borderRadius: 32,
    },
    userInfoContainer: {
      // flex: 1,
      marginLeft: 16,
    },
    userName: {
      fontSize: 16,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
    },
    userId: {
      fontSize: Font.font_normal_two,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
    },
    switchAccountContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    switchAccount: {
      fontSize: 14,
      color: 'black',
      fontWeight: 'bold',
    },
    dropDownIcon: {
      height: 24,
      width: 24,
      color: 'black',
    },
    tabContainer: {
      flexDirection: 'row',
    },
    tabItem: {
      flex: 1,
      alignItems: 'center',
      
      
    },
    itemText: {
      paddingVertical: 10,
      paddingHorizontal: 16,
      //fontWeight: 'bold',
      fontFamily: Cfont.rubik_medium,
      fontSize : 12, 
      
    },
    itemUnderlineContainer: {
      paddingHorizontal: 16,
      height: 2,
      width: '100%',
    },
    itemUnderline: {
      height: 2,
      flex: 1,
      width: '100%',
    },
    bodyContainer: {
      padding: 16,
      flex: 1,
      backgroundColor: 'white',
    },
  });
};

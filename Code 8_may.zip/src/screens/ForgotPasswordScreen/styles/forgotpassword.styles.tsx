import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../../styles/colors';

export const createForgotPasswordStyles = (colors: TColors) => {
  return StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
      padding: 16,
    },
    heading: {
      fontSize: Font.font_title,
      fontFamily:Cfont.rubik_medium,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: 'grey',
    },
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 11,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: Font.font_normal_three,
      fontFamily:Cfont.rubik_medium,
      alignSelf: 'center',
    },
  });
};

import React from "react";
import { View,Text } from "react-native";

const Screen1=()=>{
    return(
       <View>
        <Text style={{fontSize:50,backgroundColor:"yellow"}}>
            Work in Progress
        </Text>
       </View>
    )
}
export default Screen1;
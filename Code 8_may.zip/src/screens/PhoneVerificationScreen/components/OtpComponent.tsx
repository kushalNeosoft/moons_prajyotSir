import React, {useState} from 'react';
import {Text, TextInput, TouchableNativeFeedback, View} from 'react-native';

import useStyles from '../../../styles/useStyles';

import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import {createOtpComponentStyles} from '../styles/otpComponent.styles';
import { root } from '../../../styles/colors';

const OtpComponent = ({navigation}: any) => {
  const [otp, setOtp] = useState<string>();
  const {colors, styles} = useStyles(createOtpComponentStyles);
  return (
    <View style={{marginTop: 32}}>
      <Text style={[styles.heading, {marginTop: 10}]}>Verify OTP</Text>
      <Text style={{color: root.color_text, marginTop: 11}}>OTP sent to 99xxxxxx98</Text>
      <View style={[styles.inputContainer, {marginTop: 32}]}>
        <TextInput
          style={styles.input}
          placeholder={'Enter OTP'}
          placeholderTextColor={'grey'}
          keyboardType="phone-pad"
          onChangeText={text => {
            setOtp(text);
          }}
        />
      </View>
      <Text style={{marginTop: 16}}>Resend OTP in 44 sec</Text>
      <View style={{flexDirection: 'row'}}>
        <View
          style={{
            marginTop: 32,
            borderRadius: 8,
          }}>
          <TouchableNativeFeedback
            disabled={!otp}
            // background={TouchableNativeFeedback.Ripple('blue', true)}
            onPress={() => {
              navigation.navigate('TestScreen')
              // navigation.navigate('SignupScreen');
            }}>
            <View
              style={[
                styles.buttonContainer,
                // {
                //   backgroundColor: otp ? 'darkblue' : 'lightblue',
                // },
              ]}>
              <Text style={[styles.buttonText,{
                color:otp?root.color_active:root.color_disable,
                opacity:otp?1:0.3,

              }]}>Verify</Text>
              <ArrowForwardIcon style={[styles.buttonImage,,{
                color:otp?root.color_active:root.color_disable,
                opacity:otp?1:0.3,

              }]} />
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
    </View>
  );
};

export default OtpComponent;

import {NavigationContainer} from '@react-navigation/native';

import {
  CardStyleInterpolators,
  createStackNavigator,
} from '@react-navigation/stack';
import LoginScreen from '../screens/LoginScreen/LoginScreen';

import {FC, useEffect} from 'react';
import React from 'react';
import {useColorScheme} from 'react-native';

import Colors from '../styles/colors';
import useColors from '../styles/useColors';
import BottomTab from './BottomStack';
import TestScreen from '../screens/EmptyScreen/TestScreen';
import LoginStack from './LoginStack';
import CurvedBar from './Curverbottom';
import Detail from '../screens/StockDetailScreen/Detail';
import SignupScreen from '../screens/SignupScreen/SignupScreen';
import ProfileScreen from '../screens/ProfileScreen/ProfileScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen/ForgotPasswordScreen';
import PhoneVerificationScreen from '../screens/PhoneVerificationScreen/PhoneVerificationScreen';
import TopMaterialTab from './TopNavigator';
import Btos from '../screens/EmptyScreen/btos';

const DashboardStack = createStackNavigator();

const DashNavigator: FC = () => {
  const {colors, applyColors} = useColors();
  const colorScheme = useColorScheme();

  const config = {
    animation: 'spring',
    config: {
      stiffness: 500,
      damping: 1000,
      mass: 3,
      overshootClamping: false,
      restDisplacementThreshold: 0.019,
      restSpeedThreshold: 0.020,
    },
  };

  const MULTIPLIER = 1.2;
const POP_MULTIPLIER = 1.0;
const LONG_DURATION = 540 * MULTIPLIER;
const SHORT_DURATION = 210 * MULTIPLIER;

const SPRING_CONFIG = { mass: 2, damping: 500, stiffness: 200 };

  useEffect(() => {
    applyColors(colorScheme === 'dark' ? Colors.dark : Colors.light);
  }, [applyColors, colorScheme]);

  return (
    <DashboardStack.Navigator screenOptions={{headerShown: false}}>
      {/* <DashboardStack.Screen name="Bottom" component={BottomTab} /> */}
      <DashboardStack.Screen name="Login" component={LoginStack} />
      <DashboardStack.Screen name="TestScreen" component={BottomTab} />
      <DashboardStack.Screen name="Btos" component={Btos} />

      {/* <DashboardStack.Screen name="TestScreen" component={CurvedBar} /> */}

      <DashboardStack.Screen
        name="Detail"
        component={Detail}
        
        options={{
          cardStyleInterpolator:
            CardStyleInterpolators.forFadeFromBottomAndroid,
            

        }}
        
       
      />

      <DashboardStack.Screen name="Constituents" component={TopMaterialTab}  />
      {/* <DashboardStack.Screen name="TestScreen" component={TestScreen} /> */}
    </DashboardStack.Navigator>
  );
};

export default DashNavigator;

export const colors={
    black:'#000000',
    white:'#ffffff',
    bright_green:'#097969',
    grey:'#B2BEB5'
}
import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';

const list = ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 300', 'NIFTY 400'];
const ExchangeDialog = (props: any) => {
  const {item, visible, onClose} = props;

  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          paddingVertical: 24,
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View
            style={{
              paddingHorizontal: 16,
              position: 'relative',
            }}>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                width: '75%',
              }}>
              Choose
            </Text>
            <Text
              style={{
                fontSize: Font.font_title,
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                width: '75%',
              }}>
              Exchange
            </Text>
            <TouchableNativeFeedback
              onPress={() => {
                props.onClose();
              }}
              background={TouchableNativeFeedback.Ripple('gray', true)}>
              <View style={{position: 'absolute', right: 16}}>
                <CloseIcon style={{height: 24, width: 24, color: 'black'}} />
              </View>
            </TouchableNativeFeedback>
          </View>

          <FlatList
            style={{marginTop: 16}}
            data={list}
            showsHorizontalScrollIndicator={false}
            renderItem={(i: any) => {
              return (
                <TouchableNativeFeedback
                  key={i.item}
                  // disabled={!filled}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    // setConfirmOrderVisible(true);
                  }}>
                  <View
                    style={{
                      paddingVertical: 12,
                      paddingHorizontal: 16,
                      flexDirection: 'row',
                    }}>
                    <View
                      style={{
                        width: 20,
                        height: 20,
                        borderWidth: 2,
                        borderColor: 'black',
                        borderRadius: 12,
                        padding: 2,
                      }}>
                      <View
                        style={{
                          height: 12,
                          width: 12,
                          backgroundColor: 'black',
                          borderRadius: 8,
                        }}
                      />
                    </View>
                    <Text style={{marginLeft: 16}}>{i.item}</Text>
                  </View>
                </TouchableNativeFeedback>
              );
            }}
          />
        </View>
      </View>
    </Modal>
  );
};
export default ExchangeDialog;

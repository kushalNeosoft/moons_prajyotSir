import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
  Modal,
  TextInput,
  FlatList,
} from 'react-native';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import SearchIcon from '../../../assets/SearchIcon';
import {useNavigation} from '@react-navigation/native';

const list = ['NIFTY 50', 'NIFTY 100', 'NIFTY 200', 'NIFTY 300', 'NIFTY 400'];

const FilterDialog = (props: any) => {

  const navigation = useNavigation();
  const {item, visible, onClose} = props;

  const [selectedFilter, setSelectedFilter] = useState('');
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={{
          flex: 1,
          backgroundColor: 'rgba(52, 52, 52, 0.8)',
          position: 'relative',
        }}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View
        style={{
          position: 'absolute',
          // top: 320,
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: 'white',
          paddingVertical: 24,
          borderTopLeftRadius: 10,
          borderTopRightRadius: 10,
        }}>
        {selectedFilter == '' && (
          <View style={{width: '100%', height: '100%'}}>
            <View style={{paddingHorizontal: 16, position: 'relative'}}>
              <Text
                style={{
                  fontSize: Font.font_title,
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                }}>
                Filter And Sort
              </Text>
              <TouchableNativeFeedback
                onPress={() => {
                  navigation.goBack();
                }}
                background={TouchableNativeFeedback.Ripple('gray', true)}>
                <View style={{position: 'absolute', right: 16}}>
                  <CloseIcon style={{height: 24, width: 24, color: 'black'}} />
                </View>
              </TouchableNativeFeedback>
            </View>
            <TouchableNativeFeedback
              onPress={() => {
                // setSelectedTab(2);
                setSelectedFilter('SEGMENT');
              }}
              background={TouchableNativeFeedback.Ripple('gray', false)}>
              <View
                style={{
                  marginTop: 32,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: 'black',
                    flex: 1,
                  }}>
                  Segment
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>Equity</Text>
                  <DropDownIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableNativeFeedback>
            <TouchableNativeFeedback
              onPress={() => {
                // setSelectedTab(2);
              }}
              background={TouchableNativeFeedback.Ripple('gray', false)}>
              <View
                style={{
                  marginTop: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                }}>
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: 'bold',
                    color: 'black',
                    flex: 1,
                  }}>
                  Exchange
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>NSE</Text>
                  <DropDownIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableNativeFeedback>
            <TouchableNativeFeedback
              onPress={() => {
                // setSelectedTab(2);
              }}
              background={TouchableNativeFeedback.Ripple('gray', false)}>
              <View
                style={{
                  marginTop: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  paddingVertical: 12,
                  paddingHorizontal: 16,
                }}>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: 'bold',
                      color: 'black',
                    }}>
                    Index
                  </Text>
                  <Text style={{}}>Optional</Text>
                </View>

                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text>NIFTY 200</Text>
                  <DropDownIcon
                    style={{height: 24, width: 24, color: 'black'}}
                  />
                </View>
              </View>
            </TouchableNativeFeedback>
            <TouchableNativeFeedback
              // disabled={!filled}
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                // setConfirmOrderVisible(true);
              }}>
              <View
                style={{
                  backgroundColor: root.client_background,
                  marginTop: 32,
                  marginHorizontal: 16,
                  borderRadius: 4,
                  paddingHorizontal: 16,
                  paddingVertical: 10,
                }}>
                <Text
                  style={{
                    fontSize: 16,
                    color: 'white',
                    textAlign: 'center',
                    fontFamily: Cfont.rubik_semibold,
                    opacity: 1,
                  }}>
                  Apply
                </Text>
              </View>
            </TouchableNativeFeedback>
          </View>
        )}
        {selectedFilter === 'SEGMENT' && (
          <View style={{width: '100%', height: '100%'}}>
            <View
              style={{
                paddingHorizontal: 16,
                position: 'relative',
              }}>
              <Text
                style={{
                  fontSize: Font.font_title,
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                  width: '75%',
                }}>
                Choose Indices / Sectors
              </Text>
              <TouchableNativeFeedback
                onPress={() => {
                  props.onClose();
                }}
                background={TouchableNativeFeedback.Ripple('gray', true)}>
                <View style={{position: 'absolute', right: 16}}>
                  <CloseIcon style={{height: 24, width: 24, color: 'black'}} />
                </View>
              </TouchableNativeFeedback>
            </View>
            <View
              style={{
                marginTop: 16,
                marginHorizontal: 16,
                borderWidth: 2,
                borderRadius: 8,
                borderColor: 'lightgrey',
                paddingVertical: 4,
                paddingHorizontal: 8,
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <SearchIcon style={{width: 16, height: 16, fill: 'lightgrey'}} />
              <TextInput
                style={{
                  marginLeft: 8,
                  flex: 1,
                  paddingVertical: 0,
                  fontSize: 14,
                }}
                keyboardType="default"
                placeholder="Search"
              />
            </View>

            <FlatList
              style={{marginTop: 16}}
              data={list}
              showsHorizontalScrollIndicator={false}
              renderItem={(i: any) => {
                return (
                  <TouchableNativeFeedback
                    key={i.item}
                    // disabled={!filled}
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setSelectedFilter('');
                      // setConfirmOrderVisible(true);
                    }}>
                    <View
                      style={{
                        paddingVertical: 12,
                        paddingHorizontal: 16,
                        flexDirection: 'row',
                      }}>
                      <View
                        style={{
                          width: 20,
                          height: 20,
                          borderWidth: 2,
                          borderColor: 'black',
                          borderRadius: 12,
                          padding: 2,
                        }}>
                        <View
                          style={{
                            height: 12,
                            width: 12,
                            backgroundColor: 'black',
                            borderRadius: 8,
                          }}
                        />
                      </View>
                      <Text style={{marginLeft: 16}}>{i.item}</Text>
                    </View>
                  </TouchableNativeFeedback>
                );
              }}
            />
          </View>
        )}
      </View>
    </Modal>
  );
};
export default FilterDialog;

import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  ImageBackground,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import Logo from '../../assets/Logo';
import AddIcon from '../../assets/AddIcon';
import AddFunds from '../Funds/AddFunds/AddFunds';
import {calculator} from '../../theme/light';
import {FlatList} from 'react-native';

const MyFavourites = () => {
  const navigation = useNavigation();

  const [list, setList] = useState([]);
  const [categories, setCategories] = useState<any>([]);
  const [selectedCategory, setSelectedCategory] = useState('');

  const loadData = async () => {
    fetch(
      'https://devwaveapi.odinwave.com/nontransactional/1404/v1/getAppWaveScannerDetails',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        if (data.status) {
          setList(data.result);
          const unique = [
            ...new Set(data.result.map((item: any) => item.Category)),
          ];
          setCategories(unique);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View style={calculator.main}>
      <View style={calculator.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={calculator.backIcon} />
        </TouchableOpacity>
      </View>
      <Text
        style={{fontSize: 24, fontWeight: 'bold', color: 'black', padding: 16}}>
        My Favorites
      </Text>
      <Text
        style={{
          fontSize: 16,
          fontWeight: 'bold',
          color: 'black',
          paddingHorizontal: 16,
        }}>
        Total {list.length}
      </Text>
      <FlatList
        style={{marginHorizontal: 12, marginTop: 16, height: 43}}
        horizontal={true}
        data={categories}
        showsHorizontalScrollIndicator={false}
        renderItem={(item: any) => {
          return (
            <TouchableOpacity
              key={item}
              onPress={() => {
                setSelectedCategory(item.item);
              }}>
              <View
                style={{
                  borderRadius: 16,
                  paddingHorizontal: 16,
                  paddingVertical: 6,
                  borderWidth: 1,
                  marginLeft: 4,
                  borderColor: 'lightgrey',
                  backgroundColor:
                    selectedCategory == item.item ? 'darkblue' : 'transparent',
                }}>
                <Text
                  style={{
                    color: selectedCategory == item.item ? 'white' : 'black',
                  }}>
                  {item.item}
                </Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
      <ScrollView
        showsHorizontalScrollIndicator={false}
        directionalLockEnabled={true}
        alwaysBounceVertical={false}
        style={{
          marginTop: 12,
          // marginLeft: 13,
        }}>
        <FlatList
          // contentContainerStyle={{alignSelf: 'flex-start'}}
          // numColumns={Math.ceil(screenersData.length / 2)}
          // showsVerticalScrollIndicator={false}
          // showsHorizontalScrollIndicator={false}
          data={list}
          renderItem={(item: any) => {
            return (
              <TouchableNativeFeedback
                key={item.GroupId}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  navigation.navigate('Favourite', {data: item.item});
                }}>
                <View
                  key={item.GroupId}
                  style={{
                    backgroundColor: 'white',
                    padding: 16,
                    marginHorizontal: 16,
                    marginVertical: 8,
                    shadowColor: '#000',
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.23,
                    shadowRadius: 2.62,
                    elevation: 4,
                    borderRadius: 4,
                  }}>
                  <Text
                    style={{color: 'black', fontWeight: 'bold', fontSize: 16}}>
                    {item.item.GroupName}
                  </Text>
                  <Text style={{color: 'black'}}>{item.item.Description}</Text>
                </View>
              </TouchableNativeFeedback>
            );
          }}
        />
      </ScrollView>
    </View>
  );
};
export default MyFavourites;

import {useEffect, useState} from 'react';
import React from 'react';
import {FlatList, Text, TouchableNativeFeedback, View} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import AddIcon from '../../assets/AddIcon';
import {useNavigation} from '@react-navigation/native';
import HeartIcon from '../../assets/HeartIcon';
import FilterIcon from '../../assets/FilterIcon';
import FilterDialog from './components/FilterDialog';
import {TouchableOpacity} from 'react-native-gesture-handler';
import DropDownIcon from '../../assets/DropDownIcon';
import ExpandIcon from '../../assets/ExpandIcon';
import ExchangeDialog from './components/ExchangeDialog';

const Favourite = ({route}: any) => {
  const fav = route.params.data;
  const [filterDialogVisibility, setFilterDialogVisibility] = useState(false);
  const [exchangeDialogVisibility, setExchageDialogVisibility] =
    useState(false);
  const [selectedTab, setSelectedTab] = useState(1);

  const [list1, setList1] = useState([]);
  const [list2, setList2] = useState([]);
  const navigation = useNavigation();

  useEffect(() => {
    const loadData = async () => {
      //load List1
      fetch(
        'https://pre-prod1.odinwave.com/nontransactional/1404/1/getAnalyticsData/WaveScreener/1/Nifty%2050/' +
          fav.RedisKeyPrefix_1 +
          '/-/-',
        {
          method: 'GET',
        },
      )
        .then(response => response.json())
        .then((data): any => {
          if (data.status) {
            setList1(data.result);
          }
        })
        .catch(error => console.log('error', error));
      fetch(
        'https://pre-prod1.odinwave.com/nontransactional/1404/1/getAnalyticsData/WaveScreener/1/Nifty%2050/' +
          fav.RedisKeyPrefix_2 +
          '/-/-',
        {
          method: 'GET',
        },
      )
        .then(response => response.json())
        .then((data): any => {
          if (data.status) {
            setList2(data.result);
          }
        })
        .catch(error => console.log('error', error));
    };
    loadData();
  }, [fav]);

  const Item = ({item}: any) => {
    return (
      <View
        key={item.GroupId}
        style={{
          backgroundColor: 'white',
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
          <View
            style={{
              flexDirection: 'row',
              // justifyContent: 'center',
              alignItems: 'center',
              flex: 1,
            }}>
            <Text
              style={{
                fontWeight: 'bold',
                color: 'black',
                marginRight: 4,
                fontSize: 16,
              }}>
              {item.sSymbol}
            </Text>
            <View style={{alignSelf: 'center'}}>
              <Text
                style={{
                  fontSize: 8,
                  backgroundColor: 'lightgrey',
                  paddingHorizontal: 6,
                  paddingVertical: 2,
                }}>
                {item.sSeries}
              </Text>
            </View>
          </View>
          <View style={{flexDirection: 'row'}}>
            <View>
              <Text style={{textAlign: 'right', fontSize: 14}}>
                {item.nClose}
              </Text>
              <Text
                style={{
                  fontSize: 12,
                  color: item.nPercChange.includes('-') ? 'red' : 'green',
                  textAlign: 'right',
                }}>
                {(item.nOpen - item.nClose).toFixed(2) +
                  '(' +
                  item.nPercChange +
                  ' %)'}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate('BuySell', {
                  item,
                });
              }}>
              <View
                style={{
                  borderWidth: 1,
                  borderColor: 'black',
                  height: 24,
                  width: 24,
                  borderRadius: 20,
                  marginLeft: 8,
                }}>
                <Text
                  style={{
                    textAlign: 'center',
                    fontWeight: 'bold',
                    fontSize: 16,
                  }}>
                  T
                </Text>
              </View>
            </TouchableOpacity>

            <View
              style={{
                borderWidth: 1,
                borderColor: 'black',
                height: 24,
                width: 24,
                borderRadius: 20,
                marginLeft: 8,
              }}>
              <AddIcon
                style={{
                  height: 22,
                  width: 22,
                  color: 'black',
                }}
              />
            </View>
          </View>
        </View>
        <View style={{height: 1, backgroundColor: 'lightgrey'}} />
      </View>
    );
  };

  return (
    <View>
      <View
        style={{
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 2,
          },
          shadowOpacity: 0.23,
          shadowRadius: 2.62,

          elevation: 4,
          backgroundColor: 'white',
          zIndex: 10,
        }}>
        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 16,
            paddingVertical: 8,
            marginVertical: 8,
            alignItems: 'center',
          }}>
          <TouchableNativeFeedback
            onPress={() => {
              navigation.goBack();
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <BackIcon style={{width: 24, height: 24, color: 'black'}} />
            </View>
          </TouchableNativeFeedback>
          <Text
            style={{
              flex: 1,
              fontSize: 18,
              fontWeight: 'bold',
              marginHorizontal: 12,
              color: 'black',
            }}>
            {fav.GroupName}
          </Text>
          <TouchableNativeFeedback
            onPress={() => {}}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <HeartIcon style={{width: 24, height: 24, color: 'black'}} />
            </View>
          </TouchableNativeFeedback>
          <View style={{width: 16}} />
          <TouchableNativeFeedback
            onPress={() => {
              setFilterDialogVisibility(true);
            }}
            background={TouchableNativeFeedback.Ripple('gray', true)}>
            <View>
              <FilterIcon style={{width: 24, height: 24, color: 'black'}} />
            </View>
          </TouchableNativeFeedback>
        </View>
        <View
          style={{
            paddingHorizontal: 16,
            paddingVertical: 8,
            flexDirection: 'row',
            alignItems: 'center',
          }}>
          <Text>Filter</Text>
          <TouchableOpacity
            onPress={() => {
              setExchageDialogVisibility(true);
            }}>
            <View
              style={{
                marginLeft: 16,
                backgroundColor: 'lightgrey',
                flexDirection: 'row',
                paddingHorizontal: 6,
                borderRadius: 4,
                alignItems: 'center',
              }}>
              <Text style={{paddingVertical: 2}}>Equity</Text>
              <ExpandIcon style={{height: 16, width: 16, color: 'grey'}} />
            </View>
          </TouchableOpacity>

          <View
            style={{
              marginLeft: 16,
              backgroundColor: 'lightgrey',
              flexDirection: 'row',
              paddingHorizontal: 6,
              borderRadius: 4,
              alignItems: 'center',
            }}>
            <Text style={{paddingVertical: 2}}>NSE Indices</Text>
            <ExpandIcon style={{height: 16, width: 16, color: 'grey'}} />
          </View>
          <View
            style={{
              marginLeft: 16,
              backgroundColor: 'lightgrey',
              flexDirection: 'row',
              paddingHorizontal: 6,
              borderRadius: 4,
              alignItems: 'center',
            }}>
            <Text style={{paddingVertical: 2}}>NIFTY 100</Text>
            <ExpandIcon style={{height: 16, width: 16, color: 'grey'}} />
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
          }}>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(1);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{flex: 1}}>
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 14,
                  paddingVertical: 12,
                  color: selectedTab == 1 ? 'darkblue' : 'gray',
                  fontWeight: 'bold',
                }}>
                {fav.ScannerName_1}
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 1 ? 'darkblue' : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            onPress={() => {
              setSelectedTab(2);
            }}
            background={TouchableNativeFeedback.Ripple('gray', false)}>
            <View style={{flex: 1}}>
              <Text
                style={{
                  textAlign: 'center',
                  fontSize: 14,
                  paddingVertical: 12,
                  color: selectedTab == 2 ? 'darkblue' : 'gray',
                  fontWeight: 'bold',
                }}>
                {fav.ScannerName_2}
              </Text>
              <View
                style={{
                  height: 2,
                  backgroundColor:
                    selectedTab == 2 ? 'darkblue' : 'transparent',
                }}
              />
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      {selectedTab == 1 ? (
        <FlatList
          data={list1}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return <Item item={item.item} />;
          }}
        />
      ) : (
        <FlatList
          data={list2}
          showsHorizontalScrollIndicator={false}
          renderItem={(item: any) => {
            return <Item item={item.item} />;
          }}
        />
      )}
      <FilterDialog
        visible={filterDialogVisibility}
        onClose={() => {
          setFilterDialogVisibility(false);
        }}
        onChange={(t: string) => {
          console.log(t);
          setFilterDialogVisibility(false);
        }}
      />
      <ExchangeDialog
        visible={exchangeDialogVisibility}
        onClose={() => {
          setExchageDialogVisibility(false);
        }}
        onChange={(t: string) => {
          console.log(t);
          setExchageDialogVisibility(false);
        }}
      />
    </View>
  );
};
export default Favourite;

import React, {useState} from 'react';
import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';

import useStyles from '../../styles/useStyles';

import {useTranslation} from 'react-i18next';

import {createForgotPasswordStyles} from './styles/forgotpassword.styles';
import BackIcon from '../../assets/BackIcon';
import { Cfont, Font, root } from '../../styles/colors';
import { ForgotPasswordStyles } from '../../theme/light';

const ForgotPasswordScreen = ({navigation}: any) => {
  const {colors, styles} = useStyles(createForgotPasswordStyles);
  const {t} = useTranslation();
  return (
    <View style={ForgotPasswordStyles.container}>
      <View style={{flex: 1}}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            console.log('Here');
            navigation.goBack();
          }}>
          <View style={{width: 32, height: 32}}>
            <BackIcon style={ForgotPasswordStyles.backIcon} />
          </View>
        </TouchableNativeFeedback>
        <Text style={[ForgotPasswordStyles.heading, {marginTop: 32}]}>
          Reset Your Password
        </Text>
      
        <Text style={[ForgotPasswordStyles.Sendotp]}>
          We will send OTP to your registered Mobile Number and Email
        </Text>
        <Text
          style={[ForgotPasswordStyles.user]}>
          User Information
        </Text>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View>
            <Text
              style={[ForgotPasswordStyles.userId]}>
              User ID
            </Text>
            <Text
              style={[ForgotPasswordStyles.email]}>
              Email
            </Text>
            <Text
              style={[ForgotPasswordStyles.mobile]}>
              Mobile No.
            </Text>
          </View>
          <View style={{flex: 1, marginLeft: 38}}>
            <Text
              style={ForgotPasswordStyles.om}>
              OM
            </Text>
            <Text
              style={[ForgotPasswordStyles.moons]}>
              ****h.dashore@63moons.com
            </Text>
            <Text
              style={[ForgotPasswordStyles[99]]}>
              99XXXXXX58
            </Text>
          </View>
        </View>
      </View>
      <View
        style={{
          borderRadius: 8,
        }}>
        <TouchableNativeFeedback
          //  background={TouchableNativeFeedback.Ripple( root.,true)}
          onPress={() => {
            // onLogin();
            // i18next.changeLanguage('hin');
          }}>
          <View style={ForgotPasswordStyles.buttonContainer}>
            <Text style={ForgotPasswordStyles.buttonText}>Reset Password</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
    </View>
  );
};

export default ForgotPasswordScreen;

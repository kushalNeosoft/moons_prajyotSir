import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {newProductData} from './SampleData';
import NewProductComponent from '../Component/NewProductComponent';
import {marketScreen} from '../../../theme/light';

const NewProducts = () => {
  const renderNewProductItem = ({item}) => {
    return <NewProductComponent title={item.title} />;
  };
  return (
    <View>
      <Text style={marketScreen.newProductHeadText}>New products</Text>
      <View>
        <FlatList
          data={newProductData}
          renderItem={renderNewProductItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          style={marketScreen.newProductFlatList}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
    </View>
  );
};
export default NewProducts;

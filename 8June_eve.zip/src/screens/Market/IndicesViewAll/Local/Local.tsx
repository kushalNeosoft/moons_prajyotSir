import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, ScrollView} from 'react-native';
import BoxIndicesComponent from '../Component/BoxComponent';
import {localScreen} from '../../../../theme/light';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useSelector} from 'react-redux';

const Local = () => {
  const chipData = ['NSE', 'BSE', 'NSECDS'];
  const [dropDownChip, setDropDownChip] = useState<string>(chipData[0]);
  const [dropDown, setDropDown] = useState<boolean>(false);
  const favArr = useSelector(state => state?.Reducer?.favouritesStock);

  const indicesData = [
    {
      title: 'Nifty 50',
      price: '17600.75',
      changes: '-58.40(-0.34)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 1,
    },
    {
      title: 'SENSEX',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 2,
    },
    {
      title: 'NIFTY MNC',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 3,
    },
    {
      title: 'NIFTY NEXT 50',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 4,
    },
    {
      title: 'NIFTY PHARMA',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 5,
    },
    {
      title: 'NIFTY BANK',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 6,
    },
    {
      title: 'NIFTY MIDCAP',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 7,
    },
    {
      title: 'NIFTY IT',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 8,
    },
    {
      title: 'NIFTY INFRA',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 9,
    },
    {
      title: 'NIFTY PSE',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 10,
    },
    {
      title: 'NIFTY SECTORE',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nse',
      indexId: 11,
    },
    {
      title: 'LCTMCI',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 12,
    },
    {
      title: 'BSEPBI',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 13,
    },
    {
      title: 'ALLCAP',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 14,
    },
    {
      title: 'ENERGY',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 15,
    },

    {
      title: 'FINSER',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 16,
    },
    {
      title: 'INDSTR',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 17,
    },
    {
      title: 'MIDSEL',
      price: '16500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'bse',
      indexId: 18,
    },
    {
      title: 'MSX7N10YIR',
      price: '12500.75',
      changes: '-42.40(-0.14)',
      date: '19 APR 23 01:2421',
      chip: 'nsecds',
      indexId: 19,
    },
  ];

  // const onItemPress = pressedItem => {
  //   let arr = [...favArr];

  //   let idx = arr.findIndex((itm, index) => itm.id == pressedItem.id);

  //   if (idx == -1) {
  //     arr.push(pressedItem);
  //   } else {
  //     arr.splice(idx, 1);
  //   }

  //   // setSelectedItems([...arr]);
  // };

  const renderItem = ({item}: any) => {
    if (item.chip == dropDownChip.toLocaleLowerCase()) {
      return (
        <BoxIndicesComponent
          // onPress={onItemPress}
          // item={item}
          title={item.title}
          price={item.price}
          changes={item.changes}
          date={item.date}
          indexId={item?.indexId}
        />
      );
    } else {
      return null;
    }
  };

  const chipRenderItem = ({item}: any) => {
    return (
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => {
          setDropDownChip(item);
          setDropDown(false);
        }}>
        <Text
          style={
            localScreen({dropDownChip: dropDownChip, Item: item}).dropDownItems
          }>
          {item}
        </Text>
      </TouchableOpacity>
    );
  };
  return (
    <ScrollView style={localScreen().mainView}>
      <View style={{zIndex: 100}}>
        <TouchableOpacity
          activeOpacity={0.6}
          onPress={() => {
            setDropDown(!dropDown);
          }}
          style={localScreen().dropDown}>
          <Text style={localScreen().dropDownText}>{dropDownChip}</Text>
          <MaterialIcons
            name="keyboard-arrow-down"
            style={localScreen().arrowIcon}
          />
        </TouchableOpacity>
        {dropDown ? (
          <View style={localScreen().dropDownListView}>
            <FlatList
              data={chipData}
              renderItem={chipRenderItem}
              contentContainerStyle={{marginBottom: 2, paddingTop: 2}}
              keyExtractor={(_, index) => `item-${index}`}
            />
          </View>
        ) : (
          <></>
        )}
      </View>
      <FlatList
        data={indicesData}
        numColumns={2}
        renderItem={renderItem}
        contentContainerStyle={{
          marginTop: 24,
          paddingBottom: 30,
        }}
        keyExtractor={(_, index) => `item-${index}`}
        style={{paddingHorizontal: 13}}
      />
    </ScrollView>
  );
};
export default Local;

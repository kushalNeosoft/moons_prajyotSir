import React from 'react';
import {View, FlatList} from 'react-native';
import {myFavouritesScreen} from '../../../../theme/light';
import BoxIndicesComponent from '../Component/BoxComponent';
import {useSelector, useDispatch} from 'react-redux';

const MyFavourites = () => {
  const data = useSelector(state => state?.Reducer?.favouritesStock);

  const renderItem = ({item}: any) => {
    return (
      <BoxIndicesComponent
        title={item?.title}
        price={item?.price}
        changes={item?.changes}
        date={item?.date}
        indexId={item.indexId}
      />
    );
  };
  return (
    <View style={myFavouritesScreen.mainView}>
      <FlatList
        data={data}
        numColumns={2}
        renderItem={renderItem}
        contentContainerStyle={{
          marginTop: 42,
          paddingBottom: 30,
        }}
        keyExtractor={(_, index) => `item-${index}`}
        style={{paddingHorizontal: 13}}
      />
    </View>
  );
};
export default MyFavourites;

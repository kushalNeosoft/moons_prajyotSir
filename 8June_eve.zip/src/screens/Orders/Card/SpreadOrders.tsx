import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { spreadOrders } from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign'

const SpreadOrdersCard = (props: any) => {
  return (
    <View
      style={spreadOrders.container}>
      <View style={spreadOrders.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={spreadOrders.companyNameTxt}>{props.name}</Text>
            <Text style={spreadOrders.nseTxt}>NSE</Text>
          </View>
          <Text style={{color:'black'}}>{props.timePeriod}</Text>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={spreadOrders.sellTxt}>Sell - </Text>
            <Text style={spreadOrders.buyTxt}>Buy : </Text>
            <Text style={spreadOrders.buyQty}>{props.sellBuy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={spreadOrders.frequenctTxt}>{props.time}</Text>
            <Text style={spreadOrders.delivery}>Carryforward</Text>
          </View>
        </View>
        <View style={{alignItems:'flex-end'}}>
          <View style={{...alignment.row,alignItems:'center',paddingBottom:15}}>
          <Text style={spreadOrders.completedTxt}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
          <Text style={spreadOrders.installMent}>{props.quantity}</Text>
          <Text style={spreadOrders.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};


export default SpreadOrdersCard;

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { multiLeg } from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign'

const MultiLegCard = (props: any) => {
    console.log(props,'->')
  return (
    <View
      style={multiLeg.container}>
      <View style={multiLeg.companyNameContainer}>
        <View>
          <View style={{...alignment.row}}>
            <Text style={multiLeg.companyNameTxt}>{props.name}</Text>
            <Text style={multiLeg.nseTxt}>NSE</Text>
          </View>
            <Text style={multiLeg.date}>{props.date}</Text>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={multiLeg.frequenctTxt}>{props.time}</Text>
            <Text style={multiLeg.delivery}>{`${props.leg} leg`}</Text>
            <Text style={multiLeg.delivery}>Multileg</Text>
          </View>
        </View>
        <View style={{alignItems:"flex-end"}}>
          <View style={{...alignment.row,alignItems:'center'}}>
          <Text style={multiLeg.completed}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
        </View>
      </View>
    </View>
  );
};


export default MultiLegCard;

import {useState} from 'react';
import React from 'react';
import {
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import Limit from './components/Limit';
import SLLimit from './components/SLLimit';
import SLMarket from './components/SLMarket';
import CloseIcon from '../../assets/CloseIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import MarginPrice from './components/MarginPrice';
import Margin from './components/Margin';
import SipOrder from './components/SipOrder';
import {Cfont, root} from '../../styles/colors';
import TransactionTypeDialog from './components/TransactionTypeDialog';
import MultilegOrder from './components/MultilegOrder';
import { OrderEntry } from '../../theme/light';

interface BuySellProps {
  navigation: any;
  route: any;
}

const tabs = [
  {
    id: 'MARGIN',
    title: 'MARGIN',
    description: 'Buy & Sell Today',
  },
  {
    id: 'INTRADAY',
    title: 'INTRADAY',
    description: 'Buy & Sell Today',
  },
  {
    id: 'CARRYFORWARD',
    title: 'CARRYFORWARD',
    description: 'Buy & Sell Today',
  },
  {
    id: 'MULTILEG_ORDER',
    title: 'Multileg Order',
    description: 'Buy & Sell Today',
  },
  {
    id: 'DELIVERY',
    title: 'DELIVERY',
    description: 'Hold Long Term',
  },
  {
    id: 'MTF',
    title: 'MTF',
    description: 'Margin Trading Funding',
  },
  {
    id: 'PTST',
    title: 'PTST',
    description: 'Buy Today & Sell Tomorrow ',
  },
  {
    id: 'SIP_ORDER',
    title: 'SIP Order',
    description: 'Invest Regularly',
  },
];
const future = [
  {
    id: 'INTRADAY',
    title: 'INTRADAY',
    description: 'Buy & Sell Today',
  },
  {
    id: 'CARRYFORWARD',
    title: 'CARRYFORWARD',
    description: 'Buy & Sell Today',
  },
  {
    id: 'MULTILEG_ORDER',
    title: 'Multileg Order',
    description: 'Buy & Sell Today',
  },
];
const notFuture = [
  {
    id: 'MARGIN',
    title: 'MARGIN',
    description: 'Buy & Sell Today',
  },
  {
    id: 'DELIVERY',
    title: 'DELIVERY',
    description: 'Hold Long Term',
  },
  {
    id: 'MTF',
    title: 'MTF',
    description: 'Margin Trading Funding',
  },
  {
    id: 'PTST',
    title: 'PTST',
    description: 'Buy Today & Sell Tomorrow ',
  },
  {
    id: 'SIP_ORDER',
    title: 'SIP Order',
    description: 'Invest Regularly',
  },
];

const BuySell = ({navigation, route}: BuySellProps) => {
  const {item} = route.params;
  const [operation, setOperation] = useState<string>('BUY');
  const [selectedTab, setSelectedTab] = useState<string>('MARGIN');
  const [transactionTypeVisible, setTransactionTypeVisible] = useState(false);
  const [transactionType, setTransactionType] = useState('Quantity');

  const [type, setType] = useState('QUANTITY');
  console.log(item);

  return (
    <View style={{flexDirection: 'column', flex: 1, backgroundColor: 'white'}}>
      <View
        style={OrderEntry.Top}>
        <View style={{flexDirection: 'row', padding: 16}}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', true)}
            onPress={() => {
              navigation.goBack();
            }}>
            <View style={{width: 32, height: 32}}>
              <CloseIcon
                style={OrderEntry.closeIcon}
              />
            </View>
          </TouchableNativeFeedback>

          <View style={{marginLeft: 16, flex: 1}}>
            <View style={{flexDirection: 'row'}}>
              <Text
                style={OrderEntry.stockName}>
                {item?.stockName}
              </Text>
              <View
                style={OrderEntry.nseView}>
                <Text
                  style={OrderEntry.Nse}>
                  NSE
                </Text>
                <View>
                  <Text
                    style={OrderEntry.A}>
                    A
                  </Text>
                </View>
              </View>
              <Text
                style={OrderEntry.Asub}></Text>
            </View>

            <Text>
              <Text
                style={OrderEntry.price}>
                {item?.price}
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  color: item?.LTPTrend == 'color-positive' ? 'green' : 'red',
                  fontFamily: Cfont.rubik_medium,
                  paddingLeft: 20,
                }}>
                {item?.changes}
              </Text>
            </Text>
          </View>
          {selectedTab !== 'MULTILEG_ORDER' && (
            <View>
              <View
                style={{
                  flexDirection: 'row',
                  borderWidth: 1,
                  borderColor: 'lightgrey',
                  borderRadius: 16,
                  opacity: selectedTab == 'SIP_ORDER' ? 0.5 : 1,
                }}>
                <View style={{borderRadius: 15, overflow: 'hidden'}}>
                  <TouchableNativeFeedback
                    disabled={selectedTab == 'SIP_ORDER'}
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      // navigation.goBack();
                      setOperation('BUY');
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 12,
                          backgroundColor:
                            operation == 'BUY'
                              ? root.color_positive
                              : 'transparent',
                          borderRadius: 16,
                          color: operation == 'BUY' ? 'white' : root.color_text,
                        }}>
                        BUY
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>

                <View
                  style={{
                    borderRadius: 15,
                    overflow: 'hidden',
                  }}>
                  <TouchableNativeFeedback
                    disabled={selectedTab == 'SIP_ORDER'}
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setOperation('SELL');
                      // navigation.goBack();
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 8,
                          borderRadius: 16,
                          backgroundColor:
                            operation == 'SELL'
                              ? root.color_negative
                              : 'transparent',
                          color:
                            operation == 'SELL' ? 'white' : root.color_text,
                        }}>
                        SELL
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>
              </View>
            </View>
          )}
        </View>

        <View style={{flexDirection: 'row'}}>
          <View
            style={OrderEntry.BseView}>
            <View style={{minWidth: 91}}>
              <Text style={OrderEntry.BsePrice}>
                {item.price}
              </Text>
              <Text style={OrderEntry.qty}>Qty -</Text>
            </View>
            <Text
              style={OrderEntry.Bse}>
              BSE
            </Text>
          </View>
          <View
            style={OrderEntry.Bsebox}>
            <View style={{minWidth: 91}}>
              <Text style={OrderEntry.BseBoxPrice}>
                {item.price}
              </Text>
              <Text style={OrderEntry.qty}>Qty -</Text>
            </View>
            <Text
              style={OrderEntry.NSE}>
              NSE
            </Text>
          </View>
        </View>

        <View style={{flexDirection: 'row', marginTop: 7}}>
          <ScrollView
            horizontal={true}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}>
            {(item.future === true ? future : notFuture).map(tab => {
              return (
                <View key={tab.id}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setSelectedTab(tab.id);
                    }}>
                    <View
                      style={{
                        paddingHorizontal: 20,
                        paddingVertical: 6,
                        // backgroundColor: 'lightgrey',
                      }}>
                      <Text
                        style={{
                          color:
                            selectedTab == tab.id
                              ? root.client_background
                              : 'grey',
                          fontFamily: Cfont.rubik_medium,
                          fontSize: 13,
                        }}>
                        {tab.title}
                      </Text>
                      <Text
                        style={{
                          color:
                            selectedTab == tab.id ? root.color_text : 'grey',
                          fontFamily: Cfont.rubik_regular,
                          fontSize: 10,
                        }}>
                        {tab.description}
                      </Text>
                    </View>
                  </TouchableNativeFeedback>

                  <View
                    style={{
                      height: 2,
                      backgroundColor:
                        selectedTab == tab.id
                          ? root.client_background
                          : 'transparent',
                      borderRadius: 2,
                    }}
                  />
                </View>
              );
            })}
          </ScrollView>
        </View>
      </View>

      {selectedTab === 'SIP_ORDER' ? (
        <SipOrder operation={operation} />
      ) : selectedTab === 'MULTILEG_ORDER' ? (
        <MultilegOrder operation={operation} item={item} />
      ) : (
        <Margin
          operation={operation}
          item={item}
          transactionType={transactionType}
          setTransactionTypeVisible={setTransactionTypeVisible}
        />
      )}
      <TransactionTypeDialog
        visible={transactionTypeVisible}
        onClose={() => {
          setTransactionTypeVisible(false);
        }}
        onChange={(t: string) => {
          console.log(t);
          setTransactionType(t);
          setTransactionTypeVisible(false);
        }}
      />
    </View>
  );
};
export default BuySell;

import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
//import {View, Text, TouchableOpacity, ScrollView} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalFour from '../../../components/CommonModal/CommonModalFour';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import AddIcon from '../../../assets/AddIcon';
import CommonModalBig from '../../../components/CommonModal/CommonModalBig';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TouchableNativeFeedback,
} from 'react-native';

const MarginConfirmPlaceOrderDialog = (props: any) => {
  const {item, visible, onClose} = props;
  return (
    <CommonModalBig visible={visible} onClose={onClose}>
      <View style={{width: '100%', height: '100%'}}>
        <View>
          <Text
            style={{
              fontSize: Font.font_title,
              fontFamily: Cfont.rubik_medium,
              color: root.color_text,
            }}>
            Confirm Your
          </Text>
          <Text
            style={{
              fontSize: Font.font_title,
              fontFamily: Cfont.rubik_medium,
              color: root.color_text,
            }}>
            <Text style={{color: root.color_positive}}>Buy</Text> Order
          </Text>
        </View>
        <View style={{flex: 1}}>
          <View style={{flex: 1}}>
            <View style={{marginTop: 16}}>
              <View style={{flexDirection: 'row'}}>
                <Text
                  style={{
                    fontWeight: 'bold',
                    fontSize: 16,
                    color: root.color_text,
                  }}>
                  {item?.stockName}
                </Text>
                <View
                  style={{
                    marginLeft: 8,
                    alignSelf: 'center',
                    flexDirection: 'row',
                  }}>
                  <Text
                    style={{
                      color: 'grey',
                      fontSize: 8,
                      backgroundColor: '#EFF2F2',
                      borderRadius: 2,
                      paddingVertical: 1,
                      paddingHorizontal: 4,
                      alignSelf: 'center',
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    NSE
                  </Text>
                  <View>
                    <Text
                      style={{
                        color: root.color_text,
                        fontSize: 10,
                        // backgroundColor: '#EEE7E7',
                        //  borderRadius: 2,
                        // paddingVertical: 1,
                        paddingHorizontal: 4,
                        fontFamily: Cfont.rubik_regular,
                      }}>
                      A
                    </Text>
                  </View>
                </View>
                <Text
                  style={{
                    fontSize: 12,
                    alignSelf: 'center',
                    marginLeft: 8,
                  }}></Text>
              </View>
              <Text>
                {item.price}{' '}
                <Text style={{fontSize: 12, color: 'green'}}>
                  {item.changes}
                </Text>
              </Text>
            </View>
            <View
              style={{
                marginTop: 16,
                height: 1,
                backgroundColor: 'lightgrey',
              }}></View>
            <View style={{marginTop: 16}}>
              <View style={{flexDirection: 'row'}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Product Type
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>MARGIN</Text>
                  <Text style={{}}>(Buy & Sell Today)</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Quantity
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>1</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Price
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>{item.price}</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Order Value
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>₹{item.price}</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Validity
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>DAY</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <View
                  style={{flex: 1, flexDirection: 'row', alignItems: 'center'}}>
                  <Text style={{fontWeight: 'bold', color: 'black'}}>
                    Approximate Margin
                  </Text>
                  <AddIcon style={{width: 16, height: 16, color: 'black'}} />
                </View>

                <View style={{flex: 1}}>
                  <Text style={{}}>₹123</Text>
                </View>
              </View>
              <View style={{flexDirection: 'row', marginTop: 8}}>
                <Text style={{flex: 1, fontWeight: 'bold', color: 'black'}}>
                  Available Margin
                </Text>
                <View style={{flex: 1}}>
                  <Text style={{}}>₹123</Text>
                </View>
              </View>
            </View>
          </View>
        </View>
        
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => {
            props.onConfirm();
          }}>
           <Text
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor: root.client_background,
              fontSize: 16,
              color: 'white',
              borderRadius: 8,
              textAlign: 'center',
              marginTop: 16,
              fontFamily: Cfont.rubik_semibold,
            }}>
            Confirm Order
          </Text>
        </TouchableNativeFeedback>
      </View>
    </CommonModalBig>
  );
};
export default MarginConfirmPlaceOrderDialog;

import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableNativeFeedback,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
const MarketDepthDialog = (props: any) => {
  return (
    <CommonModalone visible={props.visible} onClose={props.onClose}>
      <View style={{width: '100%'}}>
        <Text
          style={{
            fontSize: Font.font_title,
            fontFamily: Cfont.rubik_medium,
            color: root.color_text,
          }}>
          Market Depth
        </Text>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View style={{paddingHorizontal: 4, backgroundColor: 'lightgray'}}>
            <Text style={{fontWeight: 'bold'}}>BSE</Text>
          </View>
          <Text style={{marginLeft: 12}}>
            <Text style={{color: 'black', fontWeight: 'bold'}}>1212.0</Text>
            <Text style={{color: 'grey'}}> 00(0.0)</Text>
          </Text>
        </View>
        <View>
          <View style={{flexDirection: 'row', marginTop: 16}}>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Qty</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Orders</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Bid</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Ask</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Orders</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>Qty</Text>
            </View>
          </View>
          <View style={{flexDirection: 'row', marginTop: 8}}>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
          </View>
          <View style={{flexDirection: 'row', marginTop: 8}}>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
          </View>
          <View style={{flexDirection: 'row', marginTop: 8}}>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
          </View>
          <View style={{flexDirection: 'row', marginTop: 8}}>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{textAlign: 'center'}}>-</Text>
            </View>
          </View>
        </View>

        <View
          style={{height: 2, backgroundColor: 'lightgrey', marginVertical: 8}}
        />
        <View>
          <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
            <Text style={{fontWeight: 'bold', color: 'black'}}>Total Bids</Text>
            <Text style={{fontWeight: 'bold', color: 'black'}}>Total Ask</Text>
          </View>
          <View style={{flexDirection: 'row', marginTop: 16}}>
            <View
              style={{
                backgroundColor: 'lightblue',
                flex: 1,
                paddingHorizontal: 8,
                paddingVertical: 2,
              }}>
              <Text style={{color: 'blue'}}>- (50%)</Text>
            </View>
            <View
              style={{
                backgroundColor: 'lightpink',
                flex: 1,
                paddingHorizontal: 8,
                paddingVertical: 2,
              }}>
              <Text style={{textAlign: 'right', color: 'red'}}>-50</Text>
            </View>
          </View>
          <Text style={{marginTop: 16}}>
            Select Your Limit Price By Clicking The Bid/Ask Amount
          </Text>
        </View>
      </View>
    </CommonModalone>
  );
};
export default MarketDepthDialog;

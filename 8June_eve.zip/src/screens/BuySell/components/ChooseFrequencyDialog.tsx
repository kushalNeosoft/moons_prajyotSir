import React from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {View, Text, TouchableOpacity} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalFour from '../../../components/CommonModal/CommonModalFour';
const ChooseFrequencyDialog = (props: any) => {
  const frequencies = [
    {
      name: 'Monthly',
    },
    {
      name: 'Forthnightly',
    },
    {
      name: 'Weekly',
    },
    {
      name: 'Daily',
    },
  ];
  return (
    <CommonModalFour visible={props.visible} onClose={props.onClose}>
      <View style={{width: '100%'}}>
        <Text
          style={{
            fontSize: Font.font_title,
            fontFamily: Cfont.rubik_medium,
            color: root.color_text,
          }}>
          Choose
        </Text>
        <Text
          style={{
            fontSize: Font.font_title,
            fontFamily: Cfont.rubik_medium,
            color: root.color_text,
            
          }}>
           Frequency
        </Text>
        <View style={{marginTop: 16}}>
          {frequencies.map((frequency, index) => {
            return (
              <View
                key={index}
                style={{
                  padding: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}>
                <View
                  style={{
                    height: 16,
                    width: 16,
                    borderWidth: 1,
                    borderRadius: 16,
                  }}
                />
                <Text
                  style={{fontWeight: 'bold', color: 'black', marginLeft: 16}}>
                  {frequency.name}
                </Text>
              </View>
            );
          })}
        </View>
      </View>
    </CommonModalFour>
  );
};
export default ChooseFrequencyDialog;

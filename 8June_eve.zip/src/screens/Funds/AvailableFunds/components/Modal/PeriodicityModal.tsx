import React from 'react';
import {View, Text, Modal, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';
import Entypo from 'react-native-vector-icons/Entypo';
import {RadioButton} from 'react-native-paper';

const PeriodicityModal = (props: any) => {
  return (
    <Modal
      transparent={true}
      onRequestClose={() => props.onClose()}
      visible={props.visible}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={styles.modalContainer}>
        <View style={styles.header}>
          <Text style={styles.titleTxt}>Periodicities</Text>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
        <View style={styles.item}>
          <RadioButton color={root.color_text} status={'checked'} value={''} />
          <Text style={styles.itemTxt}>All Exchnage Combined</Text>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '20%',
    backgroundColor: 'white',
    padding: 16,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  header: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
  },
  titleTxt: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  item: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '10%',
  },
  itemTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export default PeriodicityModal;

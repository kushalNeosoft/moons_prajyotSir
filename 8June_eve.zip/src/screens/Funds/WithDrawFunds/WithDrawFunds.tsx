import React, {useState} from 'react';
import {
  View,
  Text,
  TouchableWithoutFeedback,
  Keyboard,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import FundsModal from '../AddFunds/components/Modal/Modal';

const WithDrawFunds = (props: any) => {
  const [amount, setAmount] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [account, setAccount] = useState<string>(
    props?.route.params?.fundName ? props.route.params.fundName : 'TEST123',
  );

  const closeModal = () => {
    setShowModal(prevState => !prevState);
  };

  const setCurrentAccount = (value: string) => {
    setAccount(value);
  };

  const data = [
    {
      name: 'TEST123',
      available: '10000',
    },
    {
      name: 'BSE EQUITIES',
      available: '10000',
    },
    {
      name: 'NSE DERIVATIVE',
      available: '10000',
    },
    {
      name: 'NSE EQUITIES',
      available: '10000',
    },
  ];
  const navigation = useNavigation();
  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={withDrawFunds.container}>
        <View style={withDrawFunds.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={withDrawFunds.name}
            onPress={() => setShowModal(prevState => !prevState)}>
            <Text style={withDrawFunds.title}>{account}</Text>
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={withDrawFunds.caretDown}
            />
          </TouchableOpacity>
        </View>
        <View style={withDrawFunds.amountContainer}>
          <View style={withDrawFunds.addFundsTxtContainer}>
            <Text style={withDrawFunds.addFundsTxt}>Withdraw</Text>
            <Text style={withDrawFunds.addFundsTxt}>Funds</Text>
          </View>
          <View style={withDrawFunds.enterAmountContainer}>
            <View style={withDrawFunds.txtIpContainer}>
              <FontAwesome name="rupee" size={30} color={'black'} />
              <TextInput
                keyboardType="numeric"
                placeholder="0"
                style={withDrawFunds.txtIp}
                value={amount}
                onChangeText={amount => setAmount(amount)}
              />
            </View>
          </View>
        </View>
        <Text style={withDrawFunds.availableFund}>{`Available funds for withdrawal: ₹ 9999999999.99`}</Text>
        <TouchableOpacity
          style={withDrawFunds.addFundsBtn}
          activeOpacity={1}
          disabled={amount === '' || amount === undefined}>
          <Text
            style={
              amount === '' || amount === undefined
                ? withDrawFunds.addFundsBtnTxtDisabled
                : withDrawFunds.addFundsBtnTxt
            }>
            Request for Withdrawal
          </Text>
        </TouchableOpacity>
        <FundsModal
          onClose={closeModal}
          visible={showModal}
          data={data}
          setCurrentAccount={setCurrentAccount}
          account={account}
        />
      </View>
    </TouchableWithoutFeedback>
  );
};

const withDrawFunds = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    paddingVertical: '4%',
  },
  name: {
    ...alignment.row,
    alignItems: 'center',
    paddingLeft: 15,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  caretDown: {
    paddingLeft: 10,
  },
  amountContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'flex-end',
    paddingTop: '7%',
  },
  addFundsTxtContainer: {
    width: '47%',
    alignItems: 'flex-start',
  },
  addFundsTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  enterAmountContainer: {
    width: '50%',
  },
  txtIpContainer: {
    borderBottomWidth: 1,
    ...alignment.row,
    alignItems: 'center',
  },
  txtIp: {
    flexGrow: 1,
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
  },
  addFundsBtn: {
    height: 40,
    backgroundColor: root.client_background,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addFundsBtnTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  addFundsBtnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  availableFund:{
    fontSize:Font.font_normal_six,
    color:root.color_textual,
    fontFamily:Cfont.rubik_medium,
    paddingHorizontal:8,
    backgroundColor:root.chip_primary,
    alignSelf:'flex-end',
    borderRadius:10,
    marginTop:8
  }
});

export default WithDrawFunds;

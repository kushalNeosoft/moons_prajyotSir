import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {useNavigation} from '@react-navigation/native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {Cfont, Font, root} from '../../../styles/colors';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

const RecentTransactions = () => {
  const navigation = useNavigation();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.titleContainer}>
          <Ionicons name="arrow-back" size={24} color={'black'} />
          <Text style={styles.titleTxt}>Transactions</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => {}}>
          <FontAwesome5 name="sliders-h" color={'black'} size={20} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal:16
  },
  header: {
    ...alignment.row_SpaceB,
    height: 45,
    alignItems: 'center',
  },
  titleContainer: {
    ...alignment.row,
    alignItems: 'center',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    paddingLeft: 20,
  },
});

export default RecentTransactions;

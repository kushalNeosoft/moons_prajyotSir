import React from 'react';
import {useNavigation} from '@react-navigation/native';
import {Cfont, Font, root} from '../styles/colors';
import Analysis from '../screens/WatchList/Analysis/Analysis';
import Overview from '../screens/WatchList/Overview/Overview';
import Recommendations from '../screens/WatchList/Recommendations/Recommendations';
import Events from '../screens/WatchList/Events/Events';
import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Companyinformation from '../screens/WatchList/Companyinformation/Companyinformation';
import Futures from '../screens/Indices/Futures/Futures';
import OptionChain from '../screens/Indices/OptionChain/OptionChain';

const Scripttab = createMaterialTopTabNavigator();

const Scriptviewtab: React.FC = ({data, setScrollValue}: any) => {

  return (
    <Scripttab.Navigator
      screenOptions={{
        tabBarScrollEnabled: true,
        tabBarStyle: {
          marginHorizontal: 0,
          height: 40,
          elevation: 10,
          paddingLeft: 10,
        },
        tabBarLabelStyle: {
          fontSize: Font.font_normal_one,
          // fontWeight: 'bold',
          textTransform: 'none',
          fontFamily: Cfont.rubik_medium,
        },
        tabBarItemStyle: {
          width: 'auto',
        },
        tabBarIndicatorStyle: {
          marginLeft: 10,
          backgroundColor: root.client_background,
        },
        tabBarActiveTintColor: root.client_background,
        tabBarInactiveTintColor: '#979797',
      }}>
      <Scripttab.Screen
        name="Overview"
        component={Overview}
        initialParams={{
          // item:data

          setScrollValue: setScrollValue,
        }}
      />
      <Scripttab.Screen
        name="Events"
        component={Events}
        initialParams={{setScrollValue: setScrollValue}}
      />
      <Scripttab.Screen
        name="Recommendations"
        component={Recommendations}
        initialParams={{setScrollValue: setScrollValue}}
      />
      <Scripttab.Screen
        name="Analysis"
        component={Analysis}
        initialParams={{setScrollValue: setScrollValue}}
      />
      {data?.item?.future == true ? (
        <>
          <Scripttab.Screen
            name="Futures"
            component={Futures}
            initialParams={{setScrollValue: setScrollValue}}
          />
          <Scripttab.Screen
            name="Option chain"
            component={OptionChain}
            initialParams={{setScrollValue: setScrollValue}}
          />
        </>
      ) : null}

      <Scripttab.Screen
        name="Company Information"
        component={Companyinformation}
        initialParams={{setScrollValue: setScrollValue}}
      />
    </Scripttab.Navigator>
  );
};

export default Scriptviewtab;

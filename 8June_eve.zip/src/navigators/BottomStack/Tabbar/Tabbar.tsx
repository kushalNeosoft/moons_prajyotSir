import React from 'react';

import {View, Pressable, Dimensions, StyleSheet, Text} from 'react-native';
import Fontisto from 'react-native-vector-icons/Fontisto';
// import { assets } from '../../assets';
import {Cfont, Font, root} from '../../../styles/colors';
//* Hello
import Tabnew from '../../../assets/tab-background-latest.svg';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Entypo from 'react-native-vector-icons/Entypo';
import {useSelector} from 'react-redux';

const CustomButton = () => (
  <View
    style={{
      alignItems: 'center',
      top: -10,
      //    backgroundColor:'rgba(48, 48, 48, 0.8)',
    }}>
    <View style={styles.customtab}>
      <Fontisto
        name="search"
        size={25}
        style={{transform: [{rotate: '-45deg'}]}}
        color={'white'}
      />
    </View>
  </View>
);

const TabBar = ({state, descriptors, navigation}: any) => {
  const isShow = useSelector((s: any) => s.Reducer.isBottmtabShow);
  console.log('Ststus---=====$$$$', isShow);

  return (
    <>
      {isShow === true ? (
        <>
          <View style={styles.mainContainer}>
            <Tabnew
              width={'100%'}
              height={128}
              style={{
                position: 'absolute',
                alignSelf: 'center',
                backgroundColor: '#0000000',
                bottom: -31,
                shadowColor: '#000',
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowOpacity: 0.23,
                shadowRadius: 2.62,

                elevation: 24,
              }}
            />
            {state.routes.map((route: any, index: number) => {
              const {options} = descriptors[route.key];
              const label =
                options.tabBarLabel !== undefined
                  ? options.tabBarLabel
                  : options.title !== undefined
                  ? options.title
                  : route.name;

              const isFocused = state.index === index;

              const onPress = () => {
                setTimeout(() => {
                  const event = navigation.emit({
                    type: 'tabPress',
                    target: route.key,
                  });

                  if (!isFocused && !event.defaultPrevented) {
                    navigation.navigate(route.name);
                  }
                }, 10);
              };

              return (
                <View key={index} style={[styles.mainItemContainer]}>
                  <Pressable
                    onPress={onPress}

                    // style={{  height: Dimensions.get('window').height * 0.1, width: 30 }}
                  >
                    {route.name == 'tab1' ? (
                      <>
                        <View style={styles.taballign}>
                          {/* <Addsvg height={24} width={24} /> */}
                          <FontAwesome5
                            name="list-alt"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? styles.tabtxt : styles.tabtxt2}>
                            Watchlist
                          </Text>
                        </View>
                      </>
                    ) : route.name == 'tab2' ? (
                      <>
                        <View style={styles.taballign}>
                          {/* <Addsvg height={24} width={24} /> */}
                          <Entypo
                            name="bar-graph"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? styles.tabtxt : styles.tabtxt2}>
                            Market
                          </Text>
                        </View>
                      </>
                    ) : route.name == 'tab3' ? (
                      <>
                        <CustomButton />
                      </>
                    ) : route.name == 'tab4' ? (
                      <>
                        <View style={styles.taballign}>
                          {/* <Addsvg height={24} width={24} /> */}
                          <FontAwesome5
                            name="book"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? styles.tabtxt : styles.tabtxt2}>
                            Order
                          </Text>
                        </View>
                      </>
                    ) : (
                      <>
                        <View style={styles.taballign}>
                          {/* <Addsvg height={24} width={24} /> */}
                          <FontAwesome5
                            name="chart-pie"
                            size={24}
                            color={!isFocused ? 'grey' : root.client_background}
                          />
                          <Text
                            style={!isFocused ? styles.tabtxt : styles.tabtxt2}>
                            Portfolio
                          </Text>
                        </View>
                      </>
                    )}
                  </Pressable>
                </View>
              );
            })}
          </View>
        </>
      ) : null}
    </>
  );
};

const styles = StyleSheet.create({
  mainContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    position: 'absolute',
    backgroundColor: 'rgba(52, 52, 52, 0.1)',
    bottom: 0,
    height: 60,
    width: '100%',
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 24,
  },
  mainItemContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: 60,
    //  marginVertical: 10,
    // borderRadius: 1,
    // borderColor: "#333B42",
  },
  customtab: {
    height: Dimensions.get('window').width * 0.147,
    width: Dimensions.get('window').width * 0.147,
    backgroundColor: root.client_background,
    borderRadius: 24,
    top: -25,
    transform: [{rotate: '45deg'}],
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.17,
    shadowRadius: 2.54,
    elevation: 4,
  },
  tabtxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 5,
  },
  tabtxt2: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    marginTop: 5,
  },
  taballign: {
    height: 60,
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
  },
});

export default TabBar;

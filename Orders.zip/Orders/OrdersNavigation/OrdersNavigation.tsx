import React, {memo, useEffect, useRef, useState} from 'react';
import {View, Text, FlatList, TouchableOpacity, Modal} from 'react-native';
import Bottomsheet from '../../../components/BottomSheet/BottomSheet';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import EquitySipSheet from '../Component/EquitySipSheet';
import {ordersNavigation} from '../../../theme/light';
import {
  selectOpenOrders,
  selectCompletedOrders,
  selectAllOrders,
  selectReqOrder,
  getPositionResp,
} from '../helpers/SelectOrder';
import SingleScriptComp from '../Component/SingleScript';
import NetPosition from '../Component/NetPosition';
import SpreadOrdersComp from '../Component/SpreadOrders';
import GoodTillDateComp from '../Component/GoodTillDate';
import MultiLegComp from '../Component/MultiLegComp';
import RenderButtons from '../ShiftButton/ShiftButton';
import RenderCardView from '../helpers/RenderCardView';
import HeaderComp from '../HeaderComp/HeaderComp';
import {useDispatch, useSelector} from 'react-redux';

import {
  changeScriptName,
  filterOrders,
  showInBottomSheetData,
} from '../../../redux/Action';
import SortFilterBottomSheet from '../../../components/BottomSheet/SortFilterBottomSheet';
import BottomSheet from '@gorhom/bottom-sheet/lib/typescript/components/bottomSheet/BottomSheet';
import SearchModal from '../SearchModal/SearchModal';
import OrdersFilter from '../Component/OrdersFilter';

const OrdersNavigation = React.forwardRef((props: any, ref) => {
  const buttons = ['Open', 'Completed', 'All Orders'];
  const [searchModal, setSearchModal] = useState(false);
  const [reachedTop, setReachedTop] = useState(false);
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [allData, setAllData] = useState({});
  const [openNetPosition, setOpenNetPosition] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalData, setModalData] = useState<object>({});
  const [netPositionData,setNetPositionData]=useState<any>();
  const [originalData, setOriginalData] = useState<any>(
    selectOpenOrders(props.scriptName)?.data,
  );
  const [filteredData, setFilteredData] = useState<any>(
    selectOpenOrders(props.scriptName)?.data,
  );
  const filter = useSelector(state => state?.Reducer?.filter);
  const dispatch = useDispatch();
  const bottomSheetRef = useRef<BottomSheet>(null);

  useEffect(() => {
    const getReqOrders = async () => {
      const response = await selectReqOrder(props.scriptName, selectedBtn);
      console.log(response, 'response');
    };

    switch (selectedBtn) {
      case 0:
        setOriginalData(selectOpenOrders(props.scriptName)?.data);
        setFilteredData(selectOpenOrders(props.scriptName)?.data);
        break;
      case 1:
        setOriginalData(selectCompletedOrders(props.scriptName)?.data);
        setFilteredData(selectCompletedOrders(props.scriptName)?.data);
        break;
      case 2:
        setOriginalData(selectAllOrders(props.scriptName)?.data);
        setFilteredData(selectAllOrders(props.scriptName)?.data);
        break;
    }

    getReqOrders();
  }, [props.scriptName, selectedBtn]);

  useEffect(()=>{
    const netPositionResp= getPositionResp().then((res)=>{
      setNetPositionData(res)
      console.log(res)
    });
  },[])

  useEffect(() => {
    if (Object.values(filter).length !== 0) {
      let result = originalData;
      if (filter.alphabet !== '') {
        result = aplhabet(result);
      }
      if (filter.order !== '') {
        result = orderFilter(result);
      }
      if (filter.orderStats !== '') {
        result = orderStats(result);
      }
      setFilteredData(result);
    }
  }, [filter]);

  const aplhabet = (data: any) => {
    return [...data].sort((a, b) => a.name.localeCompare(b.name));
  };

  const orderFilter = (data: any) => {
    return [...data].filter(item =>
      item.transactionType.includes(filter?.order),
    );
  };

  const orderStats = (data: any) => {
    return [...data].filter(item => item.status.includes(filter?.orderStats));
  };

  const minAmount = (data: any) => {
    return [...data].filter(item => item.minAmount > filter?.minAmount);
  };

  const maxAmount = (data: any) => {
    return [...data].filter(item => item.maxAmount < filter?.maxAmount);
  };

  useEffect(() => {
    dispatch(changeScriptName(props.scriptName));
  }, []);

  const closeSheet = () => {
    bottomSheetRef.current?.forceClose();
  };

  const openFilterSheet = () => {
    bottomSheetRef?.current?.snapToIndex?.(0);
  };

  const searchModalToggle = () => {
    setSearchModal(prevState => !prevState);
  };

  const open = () => {
    return (
      <FlatList
        style={{flex: 1}}
        data={filteredData}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const completed = () => {
    return (
      <FlatList
        data={filteredData}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const allOrders = () => {
    return (
      <FlatList
        data={filteredData}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return open();
      case buttons[1]:
        return completed();
      case buttons[2]:
        return allOrders();
    }
  };

  const closeModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const renderComponent = () => {
    if (openNetPosition) {
      dispatch(changeScriptName('Net Position'));
      return (
        <NetPosition
          openModal={openModal}
          reachedTop={reachedTop}
          closeModal={closeModal}
          closeSheet={() => props.closeSheet()}
          data={netPositionData}
        />
      );
    } else {
      switch (props.scriptName) {
        case 'Single Script Orders':
          return <SingleScriptComp allData={allData} reachedTop={reachedTop} />;
        case 'Equity SIP':
          return <EquitySipSheet allData={allData} reachedTop={reachedTop} />;
        case 'Spread Orders':
          return <SpreadOrdersComp allData={allData} reachedTop={reachedTop} />;
        case 'Good Till Date':
          return <GoodTillDateComp allData={allData} reachedTop={reachedTop} />;
        case 'Multileg Orders':
          return <MultiLegComp allData={allData} reachedTop={reachedTop} />;
      }
    }
  };

  const getHeightValue = (value: boolean) => {
    setReachedTop(value);
  };

  const openSheet = async (item?: object) => {
    setOpenNetPosition(false);
    setAllData(item);
    dispatch(showInBottomSheetData(item));
    dispatch(changeScriptName(props.scriptName));
    await props.onPress();
  };

  const netPositionSheetView = async () => {
    setOpenNetPosition(true);
    await props.onPress();
  };

  const openModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const setSelectedButton = (value: any) => {
    setSelectedBtn(value);
    dispatch(filterOrders({}));
  };

  return (
    <View style={{flex: 1}}>
      <HeaderComp
        orderModalToggle={props.orderModalToggle}
        scriptName={props.scriptName}
        openFilterSheet={openFilterSheet}
        searchModalToggle={searchModalToggle}
      />
      <View style={ordersNavigation.netPositionValueContainer}>
        <TouchableOpacity
          style={{...alignment.row_alingC_SpaceB}}
          onPress={netPositionSheetView}>
          <Text style={ordersNavigation.netPositionTxt}>Net Position</Text>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
        <Text style={ordersNavigation.pLvalueTxt}>Today's P/L: 0</Text>
      </View>
      <RenderButtons
        data={selectOpenOrders(props.scriptName)}
        buttons={buttons}
        selectedBtn={selectedBtn}
        setButton={setSelectedButton}
      />
      {renderView(buttons[selectedBtn])}
      <Bottomsheet
        ref={ref}
        index={props.index}
        getHeightValue={getHeightValue}
        closeSheet={() => props.closeSheet()}
        scriptName={props.scriptName}
        allData={allData}>
        {renderComponent()}
      </Bottomsheet>
      <SortFilterBottomSheet
        ref={bottomSheetRef}
        index={-1}
        closesheet={closeSheet}>
        <OrdersFilter bottomSheetRef={bottomSheetRef} />
      </SortFilterBottomSheet>
      <Modal visible={modalVisible} transparent={true}>
      </Modal>
      <SearchModal
        visible={searchModal}
        onClose={searchModalToggle}
        data={originalData}
        scriptName={props.scriptName}
        button={selectedBtn}
      />
    </View>
  );
});

export default memo(OrdersNavigation);

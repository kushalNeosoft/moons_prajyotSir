import React, {memo} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import Fontisto from 'react-native-vector-icons/Fontisto';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {MenuIcon} from '../../../components/Svg/Svg';
import { useSelector } from 'react-redux';
import { headerComp } from '../../../theme/light';
import { useNavigation } from '@react-navigation/native';

const HeaderComp = (props: any) => {
  const navigation=useNavigation<any>()
  const getScriptName=useSelector(state=>state.Reducer.scriptName);
  return (
    <View style={headerComp.headerView}>
      <View style={headerComp.headerLeftContainer}>
        <TouchableOpacity onPress={()=>navigation.toggleDrawer()}>
        <MenuIcon />
        </TouchableOpacity>
        <TouchableOpacity
          style={headerComp.chooseOrderContainer}
          onPress={() => props.orderModalToggle()}>
          <View>
            <Text style={headerComp.orderTxt}>Orders</Text>
            <Text style={headerComp.chosenOrderTxt}>{props.scriptName}</Text>
          </View>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
      </View>
      <View style={{...alignment.row}}>
        <TouchableOpacity onPress={()=>props.searchModalToggle()}>
        <Fontisto
          name="search"
          size={20}
          color={'black'}
          style={{paddingRight: '5%'}}
        />
        </TouchableOpacity>
        <TouchableOpacity onPress={()=>props.openFilterSheet()}>
        <FontAwesome5 name="sliders-h" color={'black'} size={20} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default memo(HeaderComp);

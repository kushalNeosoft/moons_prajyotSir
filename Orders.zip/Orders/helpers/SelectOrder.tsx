import {
  allEquityOrders,
  closeEquityOrders,
  openEquityOrders,
} from '../data/equityOrdersData';
import {
  goodTillDateAllOrders,
  goodTillDateCloseOrders,
  goodTillDateOpenOrders,
} from '../data/goodTillDateData';
import {
  multiLegAllOrders,
  multiLegCloseOrders,
  multiLegOpenOrders,
} from '../data/multiLegOrdersData';
import {
  singleScriptAllOrders,
  singleScriptCloseOrders,
  singleSriptOpenOrders,
} from '../data/singleScriptOrdersData';
import {
  spreadAllOrders,
  spreadCloseOrders,
  spreadOpenOrders,
} from '../data/spreadOrdersData';

export const selectOpenOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleSriptOpenOrders;
    case 'Spread Orders':
      return spreadOpenOrders;
    case 'Multileg Orders':
      return multiLegOpenOrders;
    case 'Good Till Date':
      return goodTillDateOpenOrders;
    case 'Equity SIP':
      return openEquityOrders;
  }
};

export const selectCompletedOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleScriptCloseOrders;
    case 'Spread Orders':
      return spreadCloseOrders;
    case 'Multileg Orders':
      return multiLegCloseOrders;
    case 'Good Till Date':
      return goodTillDateCloseOrders;
    case 'Equity SIP':
      return closeEquityOrders;
  }
};

export const selectAllOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleScriptAllOrders;
    case 'Spread Orders':
      return spreadAllOrders;
    case 'Multileg Orders':
      return multiLegAllOrders;
    case 'Good Till Date':
      return goodTillDateAllOrders;
    case 'Equity SIP':
      return allEquityOrders;
  }
};

const baseUrl = `https://pre-prod1.odinwave.com/transactional/v1/`;

const eqSipOrder = `${baseUrl}eqsipOrders?offset=1&limit=20&orderStatus=`;
const spreadOrder = `${baseUrl}multilegOrders?offset=1&limit=20&orderType=spread&orderStatus=`;
const singleScriptOrder = `${baseUrl}orders?offset=1&limit=20&orderStatus=`;
const multilegOrder = `${baseUrl}multilegOrders?offset=1&limit=20&orderType=multileg&orderStatus=`;
const gtdOrder = `${baseUrl}gtdOrders?offset=1&limit=20&orderStatus=`;

const getOrders = async (url: string) => {
  return await fetch(url, {
    method: 'GET',
    headers: {
      authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtZW1iZXJJZCI6NzA3MDcwLCJ1c2VyaWQiOjcwNzA3MCwidGVuYW50aWQiOjcwNzA3MCwibWVtYmVySW5mbyI6eyJ0ZW5hbnRJZCI6IjE0MDQiLCJncm91cElkIjoiSE8iLCJ1c2VySWQiOiJQUkFHQVRJIiwidGVtcGxhdGVJZCI6IlNUQVRJQzEiLCJ1ZElkIjoiIiwib2NUb2tlbiI6IjB4MDEzRUNFNzFBOUFDQkY5MjI3Q0M2QUIxNDRCODA5IiwidXNlckNvZGUiOiJOV1NZTSIsImdyb3VwQ29kZSI6IkFBQUFBIiwiYXBpa2V5RGF0YSI6eyJDdXN0b21lcklkIjoiMTQwNCIsImV4cCI6MTY4OTA0NDg4MCwiaWF0IjoxNjU3NTA4OTIxfSwic291cmNlIjoiV0FWRUFQSSJ9LCJleHAiOjE2ODgxNDk3OTksImlhdCI6MTY4ODA5ODI4OX0.nUAmc_QzgxQJBnQ70a7-r8xrm8MLv0AIKjW3lv6qnEk`,
    },
  })
    .then(response => response.json())
    .then(response => {
      return response;
    })
    .catch(err => {
      return err;
    });
};

export const getPositionResp = async () => {
  return await fetch('https://pre-prod.odinwave.com/transactional/vl/portfolio/positions/all?intropStatus=1', {
    method: 'GET',
    headers: {
      authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtZW1iZXJJZCI6NzA3MDcwLCJ1c2VyaWQiOjcwNzA3MCwidGVuYW50aWQiOjcwNzA3MCwibWVtYmVySW5mbyI6eyJ0ZW5hbnRJZCI6IjE0MDQiLCJncm91cElkIjoiSE8iLCJ1c2VySWQiOiJQUkFHQVRJIiwidGVtcGxhdGVJZCI6IlNUQVRJQzEiLCJ1ZElkIjoiIiwib2NUb2tlbiI6IjB4MDEzRUNFNzFBOUFDQkY5MjI3Q0M2QUIxNDRCODA5IiwidXNlckNvZGUiOiJOV1NZTSIsImdyb3VwQ29kZSI6IkFBQUFBIiwiYXBpa2V5RGF0YSI6eyJDdXN0b21lcklkIjoiMTQwNCIsImV4cCI6MTY4OTA0NDg4MCwiaWF0IjoxNjU3NTA4OTIxfSwic291cmNlIjoiV0FWRUFQSSJ9LCJleHAiOjE2ODgxNDk3OTksImlhdCI6MTY4ODA5ODI4OX0.nUAmc_QzgxQJBnQ70a7-r8xrm8MLv0AIKjW3lv6qnEk`,
    },
  })
    .then(response => response.json())
    .then(response => {
      return response;
    })
    .catch(err => {
      return err;
    });
};

const orderStatus=['1','2','-1']

export const selectReqOrder = (scriptName: string, btn: number) => {
  switch (true) {
    case scriptName === 'Equity SIP':
      return getOrders(`${eqSipOrder}${orderStatus[btn].toString()}`);
    case scriptName === 'Single Script Orders':
      return getOrders(`${singleScriptOrder}${orderStatus.toString()}`);
    case scriptName === 'Spread Orders':
      return getOrders(`${spreadOrder}${orderStatus.toString()}`);
    case scriptName === 'Multileg Orders':
      return getOrders(`${multilegOrder}${orderStatus.toString()}`);
    case scriptName === 'Good Till Date':
      return getOrders(`${gtdOrder}${orderStatus.toString()}`);
  }
};

import {memo} from 'react';
import React from 'react';
import {Text, TouchableHighlight, View, StyleSheet} from 'react-native';
import { shiftButton } from '../../../theme/light';
import alignment from '../../../components/utils/alignment';

const RenderButtons=(props:any)=>{

  const number=(value:any)=>{
    switch(value){
      case 'Open':return props.data.metaData.open
      case 'Completed':return props.data.metaData.completed
      case 'All Orders':return props.data.metaData.all
    }
  }

  return(
    <View style={shiftButton.tabBarContainer}>
    {props.buttons &&
      props.buttons.map((btn:any, key:any) => {
        return (
          <TouchableHighlight
            underlayColor={'#F0F2F5'}
            key={key}
            style={
              props.selectedBtn === key
                ? shiftButton.selectedTabBtns
                : shiftButton.unSelectedTabBtns
            }
            onPress={() => props.setButton(key)}>
            <Text
              style={
                props.selectedBtn === key
                  ? shiftButton.selectedBtnText
                  : shiftButton.tabBtnsText
              }>
              {`${btn} (${number(btn)})`}
            </Text>
          </TouchableHighlight>
        );
      })}
  </View>
  )
}


export default memo(RenderButtons);

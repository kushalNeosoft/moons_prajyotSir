import React, {useEffect, useState} from 'react';
import {View, Modal, TouchableOpacity, TextInput, FlatList, Text} from 'react-native';
import {ordersNavigation} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {root} from '../../../styles/colors';
import EquityCard from '../Card/EquitySip';
import SingleScriptCard from '../Card/SingleScriptCard';
import SpreadOrdersCard from '../Card/SpreadOrders';
import MultiLegCard from '../Card/MultiLeg';
import GoodTillDateCard from '../Card/GoodTillDate';

const SearchModal = (props: any) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = props.data;
      const filterTempList = mainList.filter(item =>
        item.name.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };

  const renderSearchItems = () => {
    switch (props.scriptName) {
      case 'Equity SIP':
        return (
          <FlatList
            data={filterData}
            renderItem={({item}) => (
              <EquityCard
                name={item.name}
                buy={item.buy}
                frequency={item.frequency}
                installments={item.installments}
                ltp={item.ltp}
              />
            )}
          />
        );
      case 'Single Script Orders':
        return (
          <FlatList
            data={filterData}
            renderItem={({item}) => (
              <SingleScriptCard
                name={item.name}
                buy={item.buy}
                quantity={item.quantity}
                time={item.time}
                ltp={item.ltp}
                bought={item.bought}
              />
            )}
          />
        );
      case 'Spread Orders':
        return (
          <FlatList
            data={filterData}
            renderItem={({item}) => (
              <SpreadOrdersCard
                name={item.name}
                timePeriod={item.timePeriod}
                sellBuy={item.sellBuy}
                quantity={item.qty}
                ltp={item.ltp}
                time={item.time}
              />
            )}
          />
        );
      case 'Multileg Orders':
        return (
          <FlatList
            data={filterData}
            renderItem={({item}) => (
              <MultiLegCard
                name={item.name}
                time={item.time}
                date={item.date}
                leg={item.leg}
              />
            )}
          />
        );
      case 'Good Till Date':
        return (
          <FlatList
            data={filterData}
            renderItem={({item}) => (
              <GoodTillDateCard
                name={item.name}
                buy={item.buy}
                quantity={item.qty}
                ltp={item.ltp}
                validity={item.validity}
              />
            )}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Modal transparent={false} visible={props.visible}>
      <View style={ordersNavigation.searchModal}>
        <View style={ordersNavigation.searchModalHeader}>
          <View style={ordersNavigation.searchModalTxt}>
            <TouchableOpacity onPress={() => props.onClose()}>
              <Ionicons name="close" size={25} color="black" />
            </TouchableOpacity>
            <TextInput
              placeholder="Search eg: Axis,Reliance"
              placeholderTextColor={root.color_textual}
              style={ordersNavigation.searchModalTxtip}
              onChangeText={text => searchFilterOnList(text)}
            />
          </View>
         <Text style={ordersNavigation.clearTxt}>Clear</Text>
        </View>
        {renderSearchItems()}
      </View>
    </Modal>
  );
};

export default SearchModal;

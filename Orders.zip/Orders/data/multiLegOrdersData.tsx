export const multiLegOpenOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'BAJAJFINSV',
      date: "25 MAY'23 FUT",
      time: '11:58:07 AM',
      leg: 2,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};
export const multiLegCloseOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'BAJAJFINSV',
      date: "25 MAY'23 FUT",
      time: '11:58:07 AM',
      leg: 2,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};
export const multiLegAllOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'BAJAJFINSV',
      date: "25 MAY'23 FUT",
      time: '11:58:07 AM',
      leg: 2,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};

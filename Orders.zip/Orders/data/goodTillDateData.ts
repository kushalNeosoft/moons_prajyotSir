export const goodTillDateOpenOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'INNOVANA',
      buy: '400 Qty @ 300.00',
      qty: '0/400 Qty',
      validity: "29 May'23",
      ltp: 305.0,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};
export const goodTillDateCloseOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'INNOVANA',
      buy: '400 Qty @ 300.00',
      qty: '0/400 Qty',
      validity: "29 May'23",
      ltp: 305.0,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};
export const goodTillDateAllOrders = {
  metaData: {open: 0, completed: 0, all: 1},
  data: [
    {
      name: 'INNOVANA',
      buy: '400 Qty @ 300.00',
      qty: '0/400 Qty',
      validity: "29 May'23",
      ltp: 305.0,
      transactionType: 'BUY',
      status: 'Open',
    },
  ],
};

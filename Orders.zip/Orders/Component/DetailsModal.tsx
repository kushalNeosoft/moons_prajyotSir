import React, {useState} from 'react';
import {View, Modal, Text, TouchableOpacity} from 'react-native';
import {netPositionSheet, ordersNavigation} from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  Table,
  Row,
  Rows,
  Col,
  TableWrapper,
} from 'react-native-table-component';
import moment from 'moment';

const DetailsModal = (props: any) => {
  const [modalData, setModalData] = useState(props?.data);
  const [additionalDetailsVisible, setAdditionalDetailsVisible] =
    useState(false);

  const tableHead = ['', 'Qty', 'Avg Price', 'Total Value'];
  const tableData = [
    [modalData?.buy_quantity, modalData?.avg_buy_price, modalData?.buy_value],
    [modalData?.market_lot, '0.00', modalData?.cf_sell_value],
    [modalData?.net_quantity, modalData?.net_price, modalData?.net_value],
  ];
  const tableTitle = ['Buy', 'Sell', 'Net'];

  const addtionalDetailsComp = () => {
    return (
      <View style={ordersNavigation.container}>
        <Table>
          <Row
            data={tableHead}
            style={ordersNavigation.head}
            textStyle={ordersNavigation.headText}
          />
          <TableWrapper style={ordersNavigation.wrapper}>
            <Col
              data={tableTitle}
              heightArr={[48, 48]}
              textStyle={ordersNavigation.headText}
            />
            <Rows
              data={tableData}
              flexArr={[1, 1, 1]}
              style={ordersNavigation.row}
              textStyle={ordersNavigation.dataText}
            />
          </TableWrapper>
        </Table>
      </View>
    );
  };

  return (
    <Modal
      visible={props.visible}
      transparent={true}
      onRequestClose={() => props.onClose()}>
      <View style={ordersNavigation.centeredView} />
      <View
        style={
          additionalDetailsVisible
            ? ordersNavigation.modalFullView
            : ordersNavigation.modalView
        }>
        <TouchableOpacity onPress={() => props.onClose()}>
          <AntDesign
            name="close"
            size={24}
            color={'black'}
            style={{alignSelf: 'flex-end'}}
          />
        </TouchableOpacity>
        <View style={ordersNavigation.modalCompanyTitleView}>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.name}>{modalData?.symbol}</Text>
            <Text style={ordersNavigation.eqCombined}>
              {modalData?.exchange}
            </Text>
          </View>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.todaysPlTxt}>Today's P/L : </Text>
            <Text style={ordersNavigation.todaysPlValue}>0.05(0.71%)</Text>
          </View>
        </View>
        <Text style={netPositionSheet.expiryTxt}>{`${moment(
          modalData?.expiry_date,
        ).format("DD MMM'YY")} FUT`}</Text>
        <View style={ordersNavigation.modalCompanyTitleView}>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.buyTxt}>Sell : </Text>
            <Text
              style={
                netPositionSheet.marketLotNetPrice
              }>{`${modalData?.market_lot} Qty@ ₹${modalData?.net_price}`}</Text>
          </View>
          <View style={ordersNavigation.modalCompanyName}>
            <Text style={ordersNavigation.ltpTxt}>LTP : </Text>
            <Text style={ordersNavigation.ltpValue}>7.05(0.71%)</Text>
          </View>
        </View>
        <Text style={ordersNavigation.delivery}>Carryforward</Text>
        <TouchableOpacity
          style={ordersNavigation.additionalDetailsTxt}
          onPress={() => setAdditionalDetailsVisible(prevState => !prevState)}>
          <Text style={ordersNavigation.additionalDetailsText}>
            Additional Details
          </Text>
          {!additionalDetailsVisible ? (
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={{paddingLeft: '4%'}}
            />
          ) : (
            <AntDesign
              name="caretup"
              size={10}
              color={'black'}
              style={{paddingLeft: '4%'}}
            />
          )}
        </TouchableOpacity>
        {additionalDetailsVisible ? <>{addtionalDetailsComp()}</> : null}
        <View style={ordersNavigation.btnContainer}>
          <View style={ordersNavigation.btns}>
            <Text style={ordersNavigation.btnTxt}>Convert Position</Text>
          </View>
          <View style={ordersNavigation.btns}>
            <Text style={ordersNavigation.btnTxt}>Add More</Text>
          </View>
        </View>
        <TouchableOpacity style={ordersNavigation.squareOffBtn}>
          <Text style={ordersNavigation.btnTxt}>Square Off</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

export default DetailsModal;

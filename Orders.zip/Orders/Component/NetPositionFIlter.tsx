import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  TextInput,
  Button,
  ScrollView,
} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import {filterModal} from '../../../theme/light';
import {useDispatch} from 'react-redux';
import {filterOrders} from '../../../redux/Action';
import AntDesign from 'react-native-vector-icons/AntDesign';

const NetPositionFilter = props => {
  const [alphabet, setAlphabet] = useState('');
  const [modalHeight, setModalHeight] = useState(false);
  const [minFocus, setMinFocus] = useState(false);
  const [maxFocus, setMaxFocus] = useState(false);
  const [orderStats, setOrderStats] = useState('');
  const [minAmount, setMinAmount] = useState('');
  const [maxAmount, setMaxAmount] = useState('');
  const [daysPl, setDaysPl] = useState('');
  const [quantity, setQuantity] = useState('');
  const [position, setPosition] = useState('');
  const [segment, setSegment] = useState('');
  const [cmv, setCmv] = useState('');
  const alphabetically = ['A-Z', 'Z-A'];
  const quantities = ['Low to High', 'High to Low'];
  const dispatch = useDispatch();
  const positions = ['Open', 'Close'];
  const segments = ['All', 'All Combined'];

  const clearAll = () => {
    setAlphabet('');
    setOrderStats('');
    setMinAmount('');
    setMaxAmount('');
  };

  const goBack = () => {
    setModalHeight(false);
    props.onClose();
  };

  const setDisableScroll = () => {
    setModalHeight(true);
  };

  return (
    <View style={modalHeight ? ordersFilter.MainconTwo : ordersFilter.Maincon}>
      {modalHeight ? (
        <View style={filterModal.top}>
          <View style={{...alignment.row_alignC}}>
          <TouchableOpacity onPress={() => goBack()}>
            <AntDesign name="arrowleft" size={24} color={root.color_text} />
          </TouchableOpacity>
          <Text style={filterModal.titleTxt}>Sort & Filter</Text>
          </View>
          <Text>Clear</Text>
        </View>
      ) : null}
      {!modalHeight ? (
        <View style={filterModal.header}>
          <Text style={filterModal.filter}>Sort & Filter</Text>
        </View>
      ) : null}
      <ScrollView
        style={ordersFilter.contentView}
        onScrollBeginDrag={() => setDisableScroll()}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="always">
        <View>
          <Text style={ordersFilter.titleTxt}>Alphabetically</Text>
          <FlatList
            data={alphabetically}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabet(item)}
                style={
                  item === alphabet
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_regular,
                    fontSize: Font.font_normal_two,
                    color: root.color_text,
                  }}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
        {/* <Button title="clear" onPress={clearAll} /> */}
        <View>
          <Text style={ordersFilter.titleTxt}>Quantity</Text>
          <FlatList
            data={quantities}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setQuantity(item)}
                style={
                  item === quantity
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_regular,
                    fontSize: Font.font_normal_two,
                    color: root.color_text,
                  }}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>

        <View>
          <Text style={ordersFilter.titleTxt}>Current MARKET Value (CMV)</Text>
          <FlatList
            data={quantities}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setCmv(item)}
                style={
                  item === cmv
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_regular,
                    fontSize: Font.font_normal_two,
                    color: root.color_text,
                  }}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>

        <View>
          <Text style={ordersFilter.titleTxt}>Day's P/L</Text>
          <FlatList
            data={quantities}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPl(item)}
                style={
                  item === daysPl
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_regular,
                    fontSize: Font.font_normal_two,
                    color: root.color_text,
                  }}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={{...alignment.row, paddingLeft: 16, marginTop: 16}}>
          <View style={filterModal.inputView}>
            <View style={filterModal.inputContainer}>
              <Text style={filterModal.itemTxt}>Min</Text>
              <View
                style={
                  minFocus
                    ? filterModal.txtInputStyleFocused
                    : filterModal.txtInputStyleUnFocused
                }>
                <TextInput
                  style={filterModal.input}
                  keyboardType="numeric"
                  onFocus={() => setMinFocus(prevState => !prevState)}
                  onBlur={() => setMinFocus(prevState => !prevState)}
                  onChangeText={value => setMinAmount(value)}
                  textAlign="right">
                  <Text>0</Text>
                </TextInput>
              </View>
            </View>
          </View>

          <View style={[filterModal.inputView, {}]}>
            <View style={filterModal.inputContainer}>
              <Text style={filterModal.itemTxt}>Max</Text>
              <View
                style={
                  maxFocus
                    ? filterModal.txtInputStyleFocused
                    : filterModal.txtInputStyleUnFocused
                }>
                <TextInput
                  style={filterModal.input}
                  keyboardType="numeric"
                  onFocus={() => setMaxFocus(prevState => !prevState)}
                  onBlur={() => setMaxFocus(prevState => !prevState)}
                  onChangeText={value => setMaxAmount(value)}
                  textAlign="right">
                  <Text>0</Text>
                </TextInput>
              </View>
            </View>
          </View>
        </View>

        <Text style={ordersFilter.titleTxt}>Position</Text>
        <FlatList
          data={positions}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setPosition(item)}
              style={
                item === position
                  ? [ordersFilter.blockSelected]
                  : [ordersFilter.blockUnSelected]
              }>
              <Text
                style={{
                  fontFamily: Cfont.rubik_regular,
                  fontSize: Font.font_normal_two,
                  color: root.color_text,
                }}>
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />

        <Text style={ordersFilter.titleTxt}>Segment</Text>
        <FlatList
          data={segments}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setSegment(item)}
              style={
                item === segment
                  ? [ordersFilter.blockSelected]
                  : [ordersFilter.blockUnSelected]
              }>
              <Text
                style={{
                  fontFamily: Cfont.rubik_regular,
                  fontSize: Font.font_normal_two,
                  color: root.color_text,
                }}>
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </ScrollView>
      <TouchableOpacity style={ordersFilter.applyBtn} onPress={() => {}}>
        <Text style={ordersFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};

const ordersFilter = StyleSheet.create({
  Maincon: {
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '50%',
    borderTopLeftRadius:20,
    borderTopRightRadius:20
  },
  MainconTwo: {
    backgroundColor: 'white',
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: '100%',
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingLeft: 12,
    marginVertical: 16,
  },
  typeTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_two,
    color: root.color_text,
  },
  blockUnSelected: {
    paddingHorizontal: 24,
    borderWidth: 1,
    borderColor: root.color_border,
    paddingVertical: 12,
    backgroundColor: root.color_active,
    marginLeft: 15,
    borderRadius: 10,
  },
  blockSelected: {
    paddingHorizontal: 24,
    borderWidth: 1,
    borderColor: root.client_background,
    paddingVertical: 12,
    backgroundColor: '#F5F7FA',
    marginLeft: 15,
    borderRadius: 10,
  },
  applyBtn: {
    width: '100%',
    backgroundColor: root.color_textual,
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
  },
  applyBottonText: {
    fontSize: Font.font_normal_three,
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
  },
  contentView: {
    height: Dimensions.get('window').height - 98,
  },
});
export default NetPositionFilter;

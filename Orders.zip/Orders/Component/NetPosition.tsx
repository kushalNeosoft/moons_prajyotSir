import React, {useRef, useState} from 'react';
import {
  FlatList,
  Modal,
  TouchableHighlight,
  TouchableOpacity,
} from 'react-native';
import {View, Text, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {
  filterModal,
  netPositionSheet,
  ordersNavigation,
} from '../../../theme/light';
import moment from 'moment';
import {Cfont, root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import DetailsModal from './DetailsModal';
import NetPositionFilter from './NetPositionFIlter';

const NetPosition = (props: any) => {
  const buttons = ['Todays', 'Overall'];
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [detailsModalVisible, setDetailsModalVisible] = useState(false);
  const [filterVisible, setFilterVisible] = useState(false);
  const [modalData, setModalData] = useState();
  const navigation = useNavigation();

  const showModal = (item: any) => {
    setDetailsModalVisible(prevState => !prevState);
    setModalData(item);
  };
  const navigateToSquareOff = (data: any) => {
    navigation.navigate('SquareOffOrders');
  };

  const closeFilter = () => {
    setFilterVisible(prevState => !prevState);
  };

  const todays = () => {
    return (
      <View style={{flex: 1, paddingHorizontal: 16}}>
        <View style={netPositionSheet.plContainer}>
          <View>
            <View style={netPositionSheet.plView}>
              <Text style={netPositionSheet.topPl}>Today's P/L : </Text>
              <Text style={netPositionSheet.plValue}>₹-160.00</Text>
            </View>
          </View>
          <TouchableOpacity
            onPress={() => navigateToSquareOff(props.data.data)}>
            <Text style={netPositionSheet.squareOffTxt}>Square-Off</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          style={{paddingTop: 16}}
          data={props?.data?.data}
          renderItem={renderTodays}
        />
      </View>
    );
  };

  const renderTodays = ({item}: any) => {
    if (item.daily_or_expiry === 'DAILY') {
      return (
        <TouchableOpacity
          style={netPositionSheet.overAllCard}
          onPress={() => showModal(item)}>
          <View style={netPositionSheet.overAllCardInnerContainer}>
            <View
              style={{
                ...alignment.row_SpaceB,
              }}>
              <View>
                <View style={netPositionSheet.companyNameView}>
                  <Text style={netPositionSheet.companyNameTxt}>
                    {item.symbol}
                  </Text>
                  <Text style={netPositionSheet.eqCombined}>
                    {item.exchange}
                  </Text>
                </View>
                <Text style={netPositionSheet.expiryTxt}>{`${moment(
                  item.expiry_date,
                ).format("DD MMM'YY")} FUT`}</Text>
                {item.market_lot > 0 ? (
                  <View style={{...alignment.row_alignC, paddingTop: 5}}>
                    <Text style={netPositionSheet.sellTxt}>Sell : </Text>
                    <Text
                      style={
                        netPositionSheet.marketLotNetPrice
                      }>{`${item.market_lot} Qty@ ₹${item.net_price}`}</Text>
                  </View>
                ) : (
                  <>
                    <Text>0 Qty</Text>
                  </>
                )}
              </View>

              <View style={{justifyContent: 'space-between'}}>
                <View style={netPositionSheet.topView}>
                  <Text style={netPositionSheet.ltp}>LTP : </Text>
                  <Text style={netPositionSheet.ltp}>{item.ltp}</Text>
                </View>
                <View></View>
              </View>
            </View>

            <View style={{...alignment.row_alingC_SpaceB, paddingTop: 5}}>
              <Text style={netPositionSheet.deliveryTxt}>Delivery</Text>
              <View style={{...alignment.row_alignC}}>
                <Text style={netPositionSheet.todaysPl}>Today's P/L</Text>
                <Text>{}</Text>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      );
    }
  };

  const renderOverallView = ({item}: any) => {
    if (item.daily_or_expiry === 'EXPIRY') {
      return (
        <TouchableOpacity
          style={netPositionSheet.overAllCard}
          onPress={() => showModal(item)}>
          <View style={netPositionSheet.overAllCardInnerContainer}>
            <View
              style={{
                ...alignment.row_SpaceB,
              }}>
              <View>
                <View style={netPositionSheet.companyNameView}>
                  <Text style={netPositionSheet.companyNameTxt}>
                    {item.symbol}
                  </Text>
                  <Text style={netPositionSheet.eqCombined}>
                    {item.exchange}
                  </Text>
                </View>
                <Text style={netPositionSheet.expiryTxt}>{`${moment(
                  item.expiry_date,
                ).format("DD MMM'YY")} FUT`}</Text>
                {item.market_lot > 0 ? (
                  <View style={{...alignment.row_alignC, paddingTop: 5}}>
                    <Text style={netPositionSheet.sellTxt}>Sell : </Text>
                    <Text
                      style={
                        netPositionSheet.marketLotNetPrice
                      }>{`${item.market_lot} Qty@ ₹${item.net_price}`}</Text>
                  </View>
                ) : (
                  <>
                    <Text>0 Qty</Text>
                  </>
                )}
              </View>

              <View>
                <View style={netPositionSheet.topView}>
                  <Text style={netPositionSheet.ltp}>LTP : </Text>
                  <Text style={netPositionSheet.ltp}>{item.ltp}</Text>
                </View>
                <View style={{marginTop: 30}}>
                  <Text style={netPositionSheet.todaysPl}>Today's P/L</Text>
                  <Text></Text>
                </View>
              </View>
            </View>

            <View style={{...alignment.row_SpaceB, paddingTop: 10}}>
              <View>
                <Text style={netPositionSheet.actualPrice}>Actual Price</Text>
                <Text style={netPositionSheet.netPrice}>{item.net_price}</Text>
              </View>

              <View>
                <Text style={netPositionSheet.actualPl}>Actual P/L</Text>
              </View>
            </View>

            <Text style={netPositionSheet.deliveryTxt}>Delivery</Text>
          </View>
        </TouchableOpacity>
      );
    }
  };

  const overall = () => {
    return (
      <View style={{flex: 1, paddingHorizontal: 16}}>
        <View style={netPositionSheet.plContainer}>
          <View>
            <View style={netPositionSheet.plView}>
              <Text style={netPositionSheet.topPl}>Today's P/L : </Text>
              <Text style={netPositionSheet.plValue}>₹-160.00</Text>
            </View>
            <Text style={netPositionSheet.topPl}>{`Actual P/L : ₹${0.0}`}</Text>
          </View>
          <TouchableOpacity>
            <Text style={netPositionSheet.squareOffTxt}>Square-Off</Text>
          </TouchableOpacity>
        </View>
        <FlatList
          style={{paddingTop: 16}}
          data={props?.data?.data}
          renderItem={renderOverallView}
        />
      </View>
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return todays();
      case buttons[1]:
        return overall();
    }
  };

  const renderBtn = () => {
    return (
      <View style={netPositionSheet.tabBarContainer}>
        {buttons &&
          buttons.map((btn, key) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? netPositionSheet.selectedTabBtns
                    : netPositionSheet.unSelectedTabBtns
                }
                onPress={() => setSelectedBtn(key)}>
                <View style={{...alignment.row, justifyContent: 'center'}}>
                  <Text
                    style={
                      selectedBtn === key
                        ? netPositionSheet.selectedBtnText
                        : netPositionSheet.tabBtnsText
                    }>
                    {btn}
                  </Text>
                </View>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };

  return (
    <View style={netPositionSheet.container}>
      {!props.reachedTop ? (
        <View style={{paddingHorizontal: 10}}>
          <Text style={netPositionSheet.netPositionTxt}>Net Position</Text>
          <Text style={netPositionSheet.pL}>{`P/L : ₹ 0`}</Text>
        </View>
      ) : (
        <View style={{...alignment.row_alingC_SpaceB}}>
          <View style={{...alignment.row_alignC}}>
            <TouchableOpacity onPress={()=>props.closeSheet()}>
            <AntDesign name="arrowleft" size={24} color={root.color_text} />
            </TouchableOpacity>
            <Text>Sort & Filter</Text>
          </View>
          <TouchableOpacity
            onPress={() => setFilterVisible(prevState => !prevState)}>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
          </TouchableOpacity>
        </View>
      )}
      {renderBtn()}
      {renderView(buttons[selectedBtn])}
      <DetailsModal visible={detailsModalVisible} data={modalData} />
      <Modal
        visible={filterVisible}
        transparent={true}
        onRequestClose={() => {}}>
        <TouchableOpacity
          style={filterModal.centeredView}
          onPress={() => setFilterVisible(prevState => !prevState)}
          activeOpacity={1}></TouchableOpacity>
        <NetPositionFilter onClose={closeFilter} />
      </Modal>
    </View>
  );
};

export default NetPosition;

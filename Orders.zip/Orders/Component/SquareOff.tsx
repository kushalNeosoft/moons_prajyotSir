import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, root} from '../../../styles/colors';
import globalStyleClass from '../../../theme/globalStyleClass';

const SquareOffOrders = (props: any) => {
  return (
    <View style={squareOffOrders.container}>
      <View style={squareOffOrders.header}>
        <AntDesign name="arrowleft" size={24} color={root.color_text} />
        <Text style={squareOffOrders.title}>Square Off</Text>
      </View>
      <View style={squareOffOrders.bottomView}>
        <View style={{...alignment.row_alingC_SpaceB, padding: 16}}>
          <View>
            <Text
              style={{
                color: root.color_active,
                fontFamily: Cfont.rubik_medium,
                fontSize: 12,
              }}>
              Square-off
            </Text>
            <View style={{...alignment.row_alignC}}>
              <Text
                style={{
                  color: root.color_active,
                  fontFamily: Cfont.rubik_medium,
                  fontSize: 16,
                }}>
                All Orders
              </Text>
              <Text
                style={{
                  color: root.color_active,
                  paddingHorizontal: 10,
                  backgroundColor: 'red',
                  marginLeft: 10,
                  borderRadius: 20,
                }}>
                1
              </Text>
            </View>
          </View>

          <TouchableOpacity
            style={{
              borderWidth: 1,
              backgroundColor: root.color_active,
              borderRadius: 10,
            }}>
            <Text
              style={{
                color: root.client_background,
                fontSize: 18,
                fontFamily: Cfont.rubik_medium,
                paddingHorizontal: 15,
                paddingVertical: 5,
              }}>
              Done
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const squareOffOrders = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    ...alignment.row_alignC,
    height: 50,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 18,
    paddingLeft: 16,
  },
  bottomView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '10%',
    backgroundColor: root.client_background,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
});

export default SquareOffOrders;

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { goodTillDateCard } from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign'

const GoodTillDateCard = (props: any) => {
  return (
    <View
      style={goodTillDateCard.container}>
      <View style={goodTillDateCard.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={goodTillDateCard.companyNameTxt}>{props.name}</Text>
            <Text style={goodTillDateCard.nseTxt}>NSE</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={goodTillDateCard.buyTxt}>Buy : </Text>
            <Text style={goodTillDateCard.buyQty}>{props.buy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:9}}>
            <Text style={goodTillDateCard.frequenctTxt}>{`Valid till ${props.validity}`}</Text>
            <Text style={goodTillDateCard.delivery}>GTD</Text>
            <Text style={goodTillDateCard.delivery}>Delivery</Text>
          </View>
        </View>
        <View style={{alignItems:"flex-end"}}>
          <View style={{...alignment.row,paddingTop:8}}>
          <Text style={goodTillDateCard.completed}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
          <Text style={goodTillDateCard.installMent}>{props.quantity}</Text>
          <Text style={goodTillDateCard.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};


export default GoodTillDateCard;

import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TouchableNativeFeedback,
  Modal,
  FlatList,
} from 'react-native';
import alignment from '../../../components/utils/alignment';
import {Cfont, root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import MarginPrice from './components/MarginPrice/MarginPrice';
import Limit from './components/Limit/Limit';
import SLMarket from './components/SLMarket/SLMarket';
import SLLimit from './components/SLLimit/SLLimit';
import SuccessModal from './components/SuccessModal/SuccessModal';
import ConfirmModal from './components/ConfirmModal/ConfirmModal';
import {RadioButton} from 'react-native-paper';
import { squareOffOrders } from '../../../theme/light';

const SquareOffOrders = (props: any) => {
  const [active, setActive] = useState(false);
  const [selectedDeliveryType, setSelectedDeliveryType] =
    useState('MARGIN_PRICE');
  const [successModal, setSuccessModal] = useState(false);
  const [confirmModal, setConfirmModal] = useState(false);
  const [validityModalVisible, setValidityModalVisible] = useState(false);
  const [validityType, setValidityType] = useState('');
  const navigation = useNavigation<any>();

  const toggelSuccessModal = () => {
    setSuccessModal(prev => !prev);
  };

  const validityModalToggle = () => {
    setValidityModalVisible(prev => !prev);
  };

  const onValiditySelection = (item: string) => {
    setValidityType(item);
    validityModalToggle();
  };

  const toggleConfirmModal = () => {
    setConfirmModal(prev => !prev);
  };

  const validity = ['Day', 'Some'];

  const deliveryTypes = [
    {
      id: 'MARGIN_PRICE',
      title: 'Margin Price',
    },
    {
      id: 'LIMIT',
      title: 'Limit',
    },
    {
      id: 'SL_MARKET',
      title: 'SL Market',
    },
    {
      id: 'SL_LIMIT',
      title: 'SL Limit',
    },
  ];

  const close = () => {
    setActive(prev => !prev);
    setSelectedDeliveryType('MARGIN_PRICE');
  };

  const onSubmit = () => {
    toggelSuccessModal();
    toggleConfirmModal();
  };

  const closeAndNavigate = () => {
    toggelSuccessModal();
    navigation.goBack();
  };
  return (
    <View style={squareOffOrders.container}>
      <View style={squareOffOrders.header}>
        <View>
          <Text style={squareOffOrders.titleTxt}>ACC</Text>
          <View style={squareOffOrders.priceAndPercent}>
            <Text style={squareOffOrders.price}>1894.95</Text>
            <Text style={squareOffOrders.change}>{`0.00 (0.00)`}</Text>
          </View>
        </View>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign name="close" size={20} color={'black'} />
        </TouchableOpacity>
      </View>
      <View style={squareOffOrders.card}>
        <View style={squareOffOrders.topView}>
          <View style={squareOffOrders.breakDownView}>
            <AntDesign name="checksquare" size={20} color={root.color_text} />
            <View style={squareOffOrders.detailsContainer}>
              <Text style={squareOffOrders.titleTxt}>{props.route.params.data.symbol}</Text>
              <View style={squareOffOrders.qtyContainer}>
                <Text style={squareOffOrders.sellTxt}>Sell : </Text>
                <Text style={squareOffOrders.qtyTxt}>{`5 Qty @ MARKET`}</Text>
                <Text style={squareOffOrders.typeTxt}>Intraday</Text>
              </View>
              <View style={squareOffOrders.qtyContainer}>
                <Text style={squareOffOrders.validityTxt}>Validity</Text>
                <Text style={squareOffOrders.validityValue}> DAY </Text>
              </View>
            </View>
          </View>
          <TouchableOpacity
          onPress={() => setActive(prev => !prev)}
          >
            <MaterialCommunityIcons
              name="pencil"
              size={15}
              color={root.color_text}
            />
          </TouchableOpacity>
        </View>
        {active ? (
          <View>
            <TouchableOpacity
              onPress={() => navigation.navigate('BuySell')}
              >
              <Text style={squareOffOrders.sellBtn}>Sell</Text>
            </TouchableOpacity>
            <View
              style={squareOffOrders.navigationContainer}>
              {deliveryTypes.map(type => {
                return (
                  <View
                    >
                    <TouchableNativeFeedback
                      background={TouchableNativeFeedback.Ripple(
                        '#90CAF9',
                        false,
                      )}
                      onPress={() => {
                        setSelectedDeliveryType(type.id);
                      }}>
                      <Text
                        key={type.id}
                        style={[
                          squareOffOrders.typeTitle,
                          {
                            backgroundColor:
                              selectedDeliveryType == type.id
                                ? root.client_background
                                : 'transparent',
                            color:
                              selectedDeliveryType == type.id
                                ? root.color_active
                                : root.client_background,
                          },
                        ]}>
                        {type.title}
                      </Text>
                    </TouchableNativeFeedback>
                  </View>
                );
              })}
            </View>
            <View style={{marginTop: 16}}>
              {selectedDeliveryType === 'MARGIN_PRICE' && (
                <MarginPrice
                  close={close}
                  validityModalToggle={validityModalToggle}
                  validityType={validityType}
                />
              )}
              {selectedDeliveryType === 'LIMIT' && (
                <Limit
                  close={close}
                  validityModalToggle={validityModalToggle}
                  validityType={validityType}
                />
              )}
              {selectedDeliveryType === 'SL_MARKET' && (
                <SLMarket
                  close={close}
                  validityModalToggle={validityModalToggle}
                  validityType={validityType}
                />
              )}
              {selectedDeliveryType === 'SL_LIMIT' && (
                <SLLimit
                  close={close}
                  validityModalToggle={validityModalToggle}
                  validityType={validityType}
                />
              )}
            </View>
          </View>
        ) : null}
      </View>
      <TouchableOpacity
        style={squareOffOrders.squareOffBtn}
        onPress={toggleConfirmModal}>
        <Text style={squareOffOrders.squareOffTxt}>Square Off</Text>
      </TouchableOpacity>
      <ConfirmModal
        visible={confirmModal}
        onClose={toggleConfirmModal}
        submit={onSubmit}
      />
      <SuccessModal visible={successModal} onClose={closeAndNavigate} />
      <Modal
        visible={validityModalVisible}
        onRequestClose={validityModalToggle}
        transparent={true}>
          <View style={validityModal.centeredView}/>
        <View style={validityModal.modalContainer}>
          <TouchableOpacity
            onPress={validityModalToggle}
            style={{alignItems: 'flex-end'}}>
            <AntDesign name="close" size={20} color={root.color_text} />
          </TouchableOpacity>
          <Text style={validityModal.titleTxt}>Choose Validity</Text>
          <FlatList
            data={validity}
            renderItem={({item}) => {
              return (
                <View style={validityModal.validityView}>
                  <RadioButton
                    color={root.color_text}
                    value={item}
                    onPress={() => onValiditySelection(item)}
                    status={validityType === item ? 'checked' : 'unchecked'}
                  />
                  <Text style={validityModal.itemTxt}>{item}</Text>
                </View>
              );
            }}
          />
        </View>
      </Modal>
    </View>
  );
};


const validityModal = StyleSheet.create({
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: root.color_active,
    paddingHorizontal:16,paddingTop:16,
    paddingBottom:24,
    borderTopLeftRadius:15,
    borderTopRightRadius:15
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
  },
  validityView: {
    ...alignment.row_alignC,
    paddingTop: 16,
  },
  itemTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
    paddingLeft: 10,
  },
  centeredView:{
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
    paddingLeft: 10,
    paddingTop: 10,
  },
});

export default SquareOffOrders;

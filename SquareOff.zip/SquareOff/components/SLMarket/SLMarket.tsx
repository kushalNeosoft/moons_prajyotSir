import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { slMarket } from '../../../../../theme/light';

const SLMarket = (props: any) => {
  const [trigger, setTrigger] = useState('');
  const [quantity, setQuantity] = useState('');
  return (
    <View>
      <View style={slMarket.triggerContainer}>
        <View>
          <Text style={slMarket.triggerTxt}>
            Trigger <Text style={slMarket.tickValue}>{`(Tick: 0.05)`}</Text>
          </Text>
          <TextInput
            style={slMarket.txtIp}
            placeholder="0.00"
            onChangeText={text => setQuantity(text)}
          />
          <View style={{paddingTop: 5}}>
            <Text style={slMarket.sell}>{`Sell @ Market after Trigger`}</Text>
            <Text style={slMarket.rangeTxt}>
              Range : <Text style={slMarket.rangeValue}>{`0-0`}</Text>
            </Text>
          </View>
        </View>
      </View>
      <View style={slMarket.txtIpMainContainer}>
        <View style={{width: '50%'}}>
          <Text style={slMarket.qtyTxt}>Quantity</Text>
          <TextInput
            style={slMarket.txtIp}
            onChangeText={text => setQuantity(text)}
            placeholder='0'
          />
        </View>
        <View style={slMarket.validityContainer}>
          <Text style={slMarket.validityTxt}>Validity</Text>
          <Text style={slMarket.validityValue}> DAY </Text>
        </View>
      </View>
      <View style={slMarket.btnContainer}>
        <TouchableOpacity>
          <Text style={slMarket.btnTxtModify}>Modify</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => props.close()}>
          <Text style={slMarket.btnTxtCancel}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};



export default SLMarket;

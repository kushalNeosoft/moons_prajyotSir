import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {Cfont, root} from '../../../../../styles/colors';
import alignment from '../../../../../components/utils/alignment';
import Tooltip from 'react-native-walkthrough-tooltip';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { limit } from '../../../../../theme/light';

const Limit = (props: any) => {
  const [range, setRange] = useState('');
  const [quantity, setQuantity] = useState('');
  const [toolTipVisible, setToolTipVisible] = useState(false);
  return (
    <View>
      <View style={{...alignment.row}}>
        <View>
          <TextInput
            style={limit.txtIp}
            placeholder="0.00"
            onChangeText={text => setRange(text)}
          />
          <View style={limit.toolTipContainer}>
            <Tooltip
              isVisible={toolTipVisible}
              content={
                <Text style={limit.tooltip}>
                  PNC Infra gets provionsnal completion certificate
                </Text>
              }
              placement="bottom"
              childContentSpacing={1}
              contentStyle={limit.toolkitView}
              onClose={() => setToolTipVisible(false)}>
              <TouchableOpacity
                onPress={() => {
                  setToolTipVisible(true);
                }}>
                <Ionicons
                  name="information-circle-outline"
                  size={18}
                  color="black"
                />
              </TouchableOpacity>
            </Tooltip>
            <Text style={limit.rangeTxt}>
              Range : <Text style={limit.rangeValue}>{`0-0`}</Text>
            </Text>
          </View>
        </View>
        <Text style={limit.tickTxt}>{`(Tick: 0.05)`}</Text>
      </View>
      <View style={limit.txtIpMainContainer}>
        <View style={{width: '50%'}}>
          <Text style={limit.qtyTxt}>Quantity</Text>
          <TextInput
            style={limit.txtIp}
            onChangeText={text => setQuantity(text)}
            placeholder='0'
          />
        </View>
        <TouchableOpacity style={limit.validityContainer}>
          <Text style={limit.validityTxt}>Validity</Text>
          <Text style={limit.validityValue}> {props.validityType}</Text>
        </TouchableOpacity>
      </View>
      <View style={limit.btnContainer}>
        <TouchableOpacity>
          <Text style={limit.btnTxtModify}>Modify</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => props.close()}>
          <Text style={limit.btnTxtCancel}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};



export default Limit;

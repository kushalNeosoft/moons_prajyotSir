import React, {useEffect, useState} from 'react';
import {View, Text, Modal, StyleSheet, TouchableOpacity} from 'react-native';
import {Cfont, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useRoute} from '@react-navigation/native';

const SuccessModal = ({visible, routes, onClose}: any) => {
  const route = useRoute();

  const goToOrders = () => {
    {
      route.name !== 'SquareOffOrders' ? onClose() : onClose();
    }
  };

  return (
    <Modal
      transparent={false}
      onRequestClose={() => onClose()}
      visible={visible}>
      <View style={successModal.modalContainer}>
        <AntDesign
          name="checkcircle"
          size={50}
          color={root.client_background}
        />
        {route.name === 'SquareOffOrders' ? (
          <>
            <Text style={successModal.orderText}>
              Square Off order has been submitted.
            </Text>
            <Text style={successModal.orderId}>{`Order ID : `}</Text>
          </>
        ) : (
          <Text
            style={
              successModal.orderText
            }>{`Your Position conversion request for Intraday Order for ACC(5 Shares) to MTF Order has been submitted.`}</Text>
        )}
      </View>
      <TouchableOpacity style={successModal.continueBtn} onPress={goToOrders}>
        <Text style={successModal.btnTxt}>View Order Status</Text>
      </TouchableOpacity>
    </Modal>
  );
};

const successModal = StyleSheet.create({
  modalContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: root.color_active,
    alignItems: 'center',
    justifyContent: 'center',
  },
  orderText: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 18,
    paddingTop: 16,
  },
  orderId: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: 16,
    paddingTop: 16,
  },
  continueBtn: {
    position: 'absolute',
    bottom: 20,
    left: 16,
    right: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    height: 40,
    borderRadius: 10,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.client_background,
  },
});
export default SuccessModal;

import React from 'react';
import {View, Text, Modal, StyleSheet, TouchableOpacity} from 'react-native';
import {Cfont, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import alignment from '../../../../../components/utils/alignment';

const ConfirmModal = (props: any) => {
  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <View style={confirmModal.centeredView} />
      <View style={confirmModal.container}>
        <TouchableOpacity
          onPress={() => props.onClose()}
          style={{alignItems: 'flex-end'}}>
          <AntDesign name="close" size={20} color={root.color_text} />
        </TouchableOpacity>
        <Text style={confirmModal.titleTxt}>Square Off Orders</Text>
        <Text style={confirmModal.confirmationTxt}>
          Are you sure you want to Square Off the following orders?
        </Text>
        <View style={confirmModal.symbolContainer}>
          <Text style={confirmModal.symbolTxt}>ACC</Text>
          <Text>NSE</Text>
        </View>
        <View style={confirmModal.detailContainer}>
          <View style={confirmModal.individualDetail}>
            <Text style={confirmModal.sellTxt}>Sell : </Text>
            <Text style={confirmModal.qtyAndPriceTxt}>{`5 Qty @ ₹ MARKET`}</Text>
          </View>
          <View style={confirmModal.individualDetail}>
            <Text style={confirmModal.executeTxt}>Execute : </Text>
            <Text style={confirmModal.qty}>{`5/5 Qty`}</Text>
          </View>
        </View>
        <TouchableOpacity
          style={confirmModal.submitBtn}
          onPress={() => props.submit()}>
          <Text style={confirmModal.btnTxt}>Square Off Orders</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

const confirmModal = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
    backgroundColor: root.color_active,
    padding: 16,
  },
  titleTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: 30,
  },
  confirmationTxt: {
    fontFamily: Cfont.rubik_light,
    fontSize: 14,
    color: root.color_text,
    paddingTop: 24,
  },
  symbolContainer: {
    ...alignment.row_alignC,
    paddingTop: 36,
  },
  symbolTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  detailContainer: {
    ...alignment.row_alingC_SpaceB,
    paddingTop: 5,
    paddingBottom: 32,
  },
  individualDetail: {
    ...alignment.row_alignC,
  },
  submitBtn: {
    height: 40,
    ...alignment.alignC_justifyC,
    backgroundColor: root.client_background,
    borderRadius: 10,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
    fontSize: 16,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  sellTxt:{
    fontFamily:Cfont.rubik_medium,
    color:root.color_negative,
    fontSize:12
  },
  qtyAndPriceTxt:{
    fontFamily:Cfont.rubik_light,
    fontSize:12,
    color:root.color_text
  },
  executeTxt:{
    fontFamily:Cfont.rubik_medium,
    color:root.color_text,
    fontSize:12
  },
  qty:{
    fontFamily:Cfont.rubik_regular,
    fontSize:12,
    color:root.color_text
  }
});

export default ConfirmModal;

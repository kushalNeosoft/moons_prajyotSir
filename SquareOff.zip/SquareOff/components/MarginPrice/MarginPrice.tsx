import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {Cfont, root} from '../../../../../styles/colors';
import alignment from '../../../../../components/utils/alignment';
import { marginPrice } from '../../../../../theme/light';

const MarginPrice = (props: any) => {
  const [quantity, setQuantity] = useState('');
  return (
    <View>
      <Text style={marginPrice.priceTxt}>
        Price: <Text style={marginPrice.priceTypeTxt}>Market</Text>
      </Text>
      <View style={marginPrice.txtIpMainContainer}>
        <View style={{width: '50%'}}>
          <Text style={marginPrice.qtyTxt}>Quantity</Text>
          <TextInput
            style={marginPrice.txtIp}
            onChangeText={text => setQuantity(text)}
            placeholder='0'
          />
        </View>
        <TouchableOpacity
          style={marginPrice.validityContainer}
          onPress={() => props.validityModalToggle()}>
          <Text style={marginPrice.validityTxt}>Validity</Text>
          <Text style={marginPrice.validityValue}> {props.validityType} </Text>
        </TouchableOpacity>
      </View>
      <View style={marginPrice.btnContainer}>
        <TouchableOpacity>
          <Text style={marginPrice.btnTxtModify}>Modify</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => props.close()}>
          <Text style={marginPrice.btnTxtCancel}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};



export default MarginPrice;

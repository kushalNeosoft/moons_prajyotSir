import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import {Cfont, root} from '../../../../../styles/colors';
import alignment from '../../../../../components/utils/alignment';
import { slLimit } from '../../../../../theme/light';

const SLLimit = (props: any) => {
  const [trigger, setTrigger] = useState('');
  const [limit, setLimit] = useState('');
  const [quantity, setQuantity] = useState('');
  return (
    <View>
      <View style={slLimit.triggerLimitContainer}>
        <View>
          <Text style={slLimit.triggerTxt}>
            Trigger <Text style={slLimit.tickValue}>{`(Tick: 0.05)`}</Text>
          </Text>
          <TextInput
            style={slLimit.txtIp}
            placeholder="0.00"
            onChangeText={text => setTrigger(text)}
          />
          <View style={{paddingTop: 5}}>
            <Text style={slLimit.sell}>{`Sell @ Market after Trigger`}</Text>
            <Text style={slLimit.rangeTxt}>
              Range : <Text style={slLimit.rangeValue}>{`0-0`}</Text>
            </Text>
          </View>
        </View>
        <View>
          <Text style={slLimit.triggerTxt}>
            Limit <Text style={slLimit.tickValue}>{`(Tick: 0.05)`}</Text>
          </Text>
          <TextInput
            style={slLimit.txtIp}
            placeholder="0.00"
            onChangeText={text => setLimit(text)}
          />
          <View style={{paddingTop: 5}}>
            <Text style={slLimit.sell}>{`Sell upto limit after Trigger`}</Text>
            <Text style={slLimit.rangeTxt}>
              Range : <Text style={slLimit.rangeValue}>{`0-0`}</Text>
            </Text>
          </View>
        </View>
      </View>
      <View style={slLimit.triggerLimitContainer}>
        <View style={{width: '50%'}}>
          <Text style={slLimit.qtyTxt}>Quantity</Text>
          <TextInput
            style={slLimit.txtIp}
            onChangeText={text => setQuantity(text)}
            placeholder='0'
          />
        </View>
        <View style={slLimit.validityContainer}>
          <Text style={slLimit.validityTxt}>Validity</Text>
          <Text style={slLimit.validityValue}> DAY </Text>
        </View>
      </View>
      <View style={slLimit.btnContainer}>
        <TouchableOpacity>
          <Text style={slLimit.btnTxtModify}>Modify</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => props.close()}>
          <Text style={slLimit.btnTxtCancel}>Cancel</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};



export default SLLimit;

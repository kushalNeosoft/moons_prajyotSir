import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableNativeFeedback,
  TouchableHighlight,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import DropDownIcon from '../../../assets/DropDownIcon';
import LinearGradient from 'react-native-linear-gradient';
import CloseIcon from '../../../assets/CloseIcon';
import FontSize from '../../../styles/Common/FontSize';
import ModalOne from '../../../components/CommonModal/ModalOne';

const TYPES = ['Market Depth', 'Key Stats', 'Pivot Points'];

const marketDepth = [
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
];
const keyStats = {
  open: '-',
  close: '216.00',
  dailyPriceRange: '172- 2459',
  today: {
    high: '-',
    low: '-',
  },
  week52: {
    high: '1000',
    low: '200',
  },
  atp: 0.0,
  value: 0,
  volume: '-',
  ltq: 5,
  ltt: '13.12.2',
  lut: '15.23.1',
  marketCap: '4 crores',
};
const pivot = {
  pivot: 216,
  support: [
    {key: 'S1', value: '100'},
    {key: 'S2', value: '100'},
    {key: 'S3', value: '100'},
    {key: 'S4', value: '100'},
  ],
  resistance: [
    {key: 'R1', value: '100'},
    {key: 'R2', value: '100'},
    {key: 'R3', value: '100'},
    {key: 'R4', value: '100'},
  ],
};
const exchanges = ['NSE', 'BSE', 'NSECDS'];
const MarketDepthDialog = (props: any) => {
  const [selectedType, setSelectedType] = useState<string>('Market Depth');
  const [se, setSe] = useState('NSE');
  const [showSeDialog, setShowSeDialog] = useState(false);
  return (
    <ModalOne visible={props.visible} onClose={props.onClose}>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
        onPress={() => {
          props.onClose();
        }}>
        <View style={{width: 24, height: 24, marginLeft: 'auto',}}>
          <CloseIcon style={{width: 24, height: 24, color: root.color_text}} />
        </View>
      </TouchableNativeFeedback>
      <View style={{width: '100%'}}>
        <View>
          <Text
            style={{fontSize: 16,fontFamily: Cfont.rubik_medium,
             color: root.color_text}}>
            ICICI Bank{' '}
            <Text style={{fontSize: 10,color: root.color_text ,
fontFamily: Cfont.rubik_regular}}>EQ</Text>
          </Text>
          <View style={{flexDirection: 'row',}}>
          <View style={{zIndex: 999}}>
              <TouchableOpacity
                onPress={() => {
                  setShowSeDialog(true);
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: '#F3EEEE',
                    paddingVertical: 2,
                    paddingHorizontal: 8,
                    
                  }}>
                  <Text style={{fontSize: 12, 
                  fontFamily: Cfont.rubik_medium}}>{se}</Text>
                  <DropDownIcon
                    style={{height: 18, width: 24, color: root.color_text}}
                  />
                </View>
              </TouchableOpacity>
            </View>
            <Text
              style={{
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                marginHorizontal: 5,
                fontSize: 14,
                
              }}>
              2123.9
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  color: root.color_text,
                  fontFamily: Cfont.rubik_regular,
                  marginHorizontal: 1,
                  marginTop: 1
                }}>
                123
              </Text>
              <Text
                style={{
                  fontSize: 10,
                  color: root.color_text,
                  fontFamily: Cfont.rubik_regular,
                  marginHorizontal: 1,
                  marginTop: 1
                }}>
                (00.00)
              </Text>
            
          </View>
        </View>
        {showSeDialog && (
                <View
                  style={{
                    
                    position: 'absolute',
                    //bottom: 0,
                    marginTop:  50,
                    zIndex: 999,
                    backgroundColor: root.color_active,
                    shadowColor: '#000',
                    height: 110,
                    width: 80,
                    shadowOffset: {
                      width: 0,
                      height: 2,
                    },
                    shadowOpacity: 0.23,
                    shadowRadius: 2.62,
                    elevation: 4,
                    borderRadius: 4,
                  }}>
                 
                 {exchanges.map(exchange => {
                    return (
                      <TouchableOpacity
                        key={exchange}
                        onPress={() => {
                          setSe(exchange);
                          setShowSeDialog(false);
                          // setSelectedExchange(exchange);
                          // setShowSelectExchange(false);
                        }}>
                        <View
                          key={exchange}
                          style={{
                            paddingHorizontal: 8,
                            paddingVertical: 4,
                            backgroundColor: 'white',
                            zIndex: 999,
                          }}>
                          <Text
                            style={{
                              marginTop: 10,
                              color: root.color_text,
                              fontFamily: Cfont.rubik_regular,
                            }}>
                            {exchange}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
        <View
          style={{
            zIndex: 0,
            marginTop: 12,
            flexDirection: 'row',
            borderWidth: 1,
            borderColor: root.client_background,
            borderRadius: 4,
          }}>
          {TYPES.map((type, index) => {
            return (
              <TouchableOpacity
                style={{flex: 1}}
                key={index}
                onPress={() => {
                  setSelectedType(type);
                }}>
                <View
                  style={{
                    paddingVertical: 8,
                    backgroundColor:
                      selectedType == type
                        ? root.client_background
                        : 'transparent',
                  }}>
                  <Text
                    style={{
                      textAlign: 'center',
                      color:
                        selectedType == type
                          ? root.color_active
                          : root.client_background,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    {type}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {selectedType === 'Market Depth' && (
          <>
            <View>
              <View style={{flexDirection: 'row', marginTop: 16, gap: 14 , marginBottom: 0}}>
                <View style={{flex: 1,}}>
                  <Text
                    style={{
                      textAlign: 'left',
                      //fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Qty
                  </Text>
                </View>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      textAlign: 'left',
                      //fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Orders
                  </Text>
                </View>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      textAlign: 'right',
                      // fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Bid
                  </Text>
                </View>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      textAlign: 'left',
                      //fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Ask
                  </Text>
                </View>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      textAlign: 'center',
                      //fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Orders
                  </Text>
                </View>
                <View style={{flex: 1}}>
                  <Text
                    style={{
                      textAlign: 'right',
                      // fontWeight: 'bold',
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                    }}>
                    Qty
                  </Text>
                </View>
              </View>
              {marketDepth.map((md, index) => {
                return (
                  <View
                    style={{flexDirection: 'row', marginTop: 4, gap: 16}}
                    key={index}>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'left', color: root.color_positive,
                      fontSize: 14, fontFamily: Cfont.rubik_regular,}}>
                        {md.quantity}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'center', color: root.color_positive,fontSize: 14,
                     fontFamily: Cfont.rubik_regular}}>
                        {md.orders}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'right', color: root.color_positive,
                      fontSize: 14, fontFamily: Cfont.rubik_regular,}}>
                        {md.bid}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'left', color: root.color_negative,
                    fontSize: 14, fontFamily: Cfont.rubik_regular,}}>
                        {md.ask}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'center', color: root.color_negative,
                    fontSize: 14, fontFamily: Cfont.rubik_regular,
                    }}>
                        {md.askOrders}
                      </Text>
                    </View>
                    <View style={{flex: 1}}>
                      <Text style={{textAlign: 'right', color: root.color_negative,
                      fontSize: 14, fontFamily: Cfont.rubik_regular,}}>
                        {md.askQuantity}
                      </Text>
                    </View>
                  </View>
                );
              })}
            </View>

            <View
              style={{
                height: 2,
                backgroundColor: 'lightgrey',
                marginVertical: 8,
              }}
            />
            <View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                    fontSize: 12
                  }}>
                  Total Bids
                </Text>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                    fontSize: 12
                  }}>
                  Total Ask
                </Text>
              </View>
              <View style={{marginTop: 10, position: 'relative'}}>
                <View style={{flexDirection: 'row', height: 28}}>
                  <View
                    style={{
                      backgroundColor: 'lightblue',
                      width: '80%',
                      paddingHorizontal: 8,
                      paddingVertical: 1,
                    }}>

                    </View>
                  <View
                    style={{
                      backgroundColor: 'lightpink',

                      width: '20%',
                      paddingHorizontal: 8,
                      paddingVertical: 1,
                    }}></View>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    position: 'absolute',
                    height: 28,
                    width: '100%',
                    alignItems: 'center',
                    paddingHorizontal: 8,
                  }}>
                  <Text style={{color: root.client_background,
                    fontSize: 14, fontFamily: Cfont.rubik_light,}}>1200 -(50%)</Text>
                  <Text style={{textAlign: 'right', color: root.color_negative,
                fontSize: 14, fontFamily: Cfont.rubik_light}}>1299(-50)</Text>
                </View>
              </View>

              <Text style={{marginTop: 16, fontSize: 12, textAlign: 'center',
            fontFamily: Cfont.rubik_light,}}>
                Select Your Limit Price By Clicking The Bid/Ask Amount
              </Text>
            </View>
          </>
        )}

        {selectedType === 'Key Stats' && (
          <View style={{marginTop: 16}}>
            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  Open
                </Text>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>
                  {keyStats.open}
                </Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                     fontSize: 12
                  }}>
                  Close
                </Text>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>
                  {keyStats.close}
                </Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  Daily Price Range
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.dailyPriceRange}</Text>
              </View>
            </View>
            <View
              style={{
                height: 1,
                backgroundColor: 'lightgrey',
                marginVertical: 6,
                
              }}
            />
            <View style={{flexDirection: 'row', gap: 32}}>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  Today's (Low High)
                </Text>

                <View style={{position: 'relative'}}>
                  <LinearGradient
                    start={{x: 0, y: 0}}
                    end={{x: 1, y: 0}}
                    colors={['red', 'orange', 'lightgreen']}
                    style={{height: 8, marginTop: 8, borderRadius: 2}}
                  />
                  <View
                    style={{
                      width: 4,
                      height: 16,
                      backgroundColor: 'grey',
                      position: 'absolute',
                      marginTop: 4,
                      right: 16,
                    }}
                  />
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 8,
                  }}>
                  <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.today.low}</Text>
                  <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.today.high}</Text>
                </View>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    textAlign: 'right',
                    fontSize: 12,
                  }}>
                  52 Week (Low High)
                </Text>
                <LinearGradient
                  start={{x: 0, y: 0}}
                  end={{x: 1, y: 0}}
                  colors={['red', 'orange', 'lightgreen']}
                  style={{height: 8, marginTop: 8, borderRadius: 2}}
                />
                <View
                    style={{
                      width: 4,
                      height: 16,
                      backgroundColor: 'grey',
                      position: 'absolute',
                      marginTop: 21,
                      right: 16,
                    }}
                  />
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 8,
                  }}>
                  <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.week52.low}</Text>
                  <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.week52.high}</Text>
                </View>
              </View>
            </View>
            <View
              style={{
                height: 1,
                backgroundColor: 'lightgrey',
                marginVertical: 6,
              }}
            />
            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  ATP
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.atp}</Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  Value
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.value}</Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  Volume
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.volume}</Text>
              </View>
            </View>
            <View
              style={{
                height: 1,
                backgroundColor: 'lightgrey',
                marginVertical: 6,
              }}
            />
            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  LTQ
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.ltq}</Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  LTT
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.ltt}</Text>
              </View>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                    fontSize: 12,
                  }}>
                  LUT
                </Text>
                <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.lut}</Text>
              </View>
            </View>
            <View
              style={{
                height: 1,
                backgroundColor: 'lightgrey',
                marginVertical: 6,
              }}
            />
            <View style={{}}>
              <Text
                style={{
                  color: root.color_text,
                  fontFamily: Cfont.rubik_medium,
                  fontSize: 12,
                }}>
                Market Cap
              </Text>
              <Text style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_regular,
                    fontSize: 12,
                  }}>{keyStats.marketCap}</Text>
            </View>
          </View>
        )}

        {selectedType === 'Pivot Points' && (
          <View style={{marginTop: 16}}>
            <View style={{flexDirection: 'row'}}>
              <View style={{flex: 3}}>
                <Text style={{textAlign: 'center',
              fontFamily: Cfont.rubik_medium,
              color: root.color_text , fontSize: 12}}>Support</Text>
              </View>
              <View style={{flex: 2}}></View>
              <View style={{flex: 3}}>
                <Text style={{textAlign: 'center',
              fontFamily: Cfont.rubik_medium,
              color: root.color_text , fontSize: 12}}>Resistance</Text>
              </View>
            </View>
            <View style={{flexDirection: 'row', marginTop: 8}}>
              <View style={{flex: 3}}>
                {pivot.support.map((r, index) => {
                  return (
                    <View
                      key={index}
                      style={{
                        paddingVertical: 8,
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Cfont.rubik_medium,
              color: root.color_text , fontSize: 12
                        }}>
                        {r.key}
                      </Text>
                      <Text style={{color: root.color_positive, 
                        fontFamily: Cfont.rubik_medium,fontSize: 14}}>{r.value}</Text>
                    </View>
                  );
                })}
              </View>
              <View
                style={{
                  width: 2,
                  marginHorizontal: 8,
                  backgroundColor: 'lightgrey',
                }}
              />
              <View
                style={{
                  flex: 2,
                  flexDirection: 'column',
                  justifyContent: 'center',
                }}>
                <Text style={{textAlign: 'center', color: root.color_text,
              fontFamily: Cfont.rubik_medium,
             fontSize: 14}}>
                  Pivot
                </Text>
                <Text style={{textAlign: 'center', color: root.color_text,
              fontFamily: Cfont.rubik_medium,
             fontSize: 14}}>
                  {pivot.pivot}
                </Text>
              </View>
              <View
                style={{
                  width: 2,
                  marginHorizontal: 8,
                  backgroundColor: 'lightgrey',
                }}
              />
              <View style={{flex: 3}}>
                {pivot.resistance.map((r, index) => {
                  return (
                    <View
                      key={index}
                      style={{
                        paddingVertical: 8,
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: Cfont.rubik_medium,
              color: root.color_text , fontSize: 12
                        }}>
                        {r.key}
                      </Text>
                      <Text style={{color: root.color_negative, 
                        fontFamily: Cfont.rubik_medium,fontSize: 14}}>{r.value}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          </View>
        )}
      </View>
    </ModalOne>
  );
};
export default MarketDepthDialog;

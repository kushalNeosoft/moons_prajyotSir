import React, {useEffect, useRef, useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {Cfont, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';
import FollowUpModal from '../components/FollowUpModal/FollowUpModal';
import Fontisto from 'react-native-vector-icons/Fontisto';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import {recommendations, screenFilter} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { useNavigation } from '@react-navigation/native';

function Recommendations(props: any) {
  const [modalVisible, setModalVisible] = useState(false);
  const [itemData, setItemData] = useState<any>();
  const [orderFilter, setOrderFilter] = useState(props.filterOrder);
  const [tagFilter, setTagFilter] = useState(props.brokerTags);
  const [filteredData, setFilteredData] = useState(props.data);
  const navigation=useNavigation()

  useEffect(() => {
    let result = props.data;
    if (props.filterOrder !== '') {
      result = filterOrder(result);
    }

    if (props.brokerTags !== '') {
      result = filterTags(result);
    }
    setOrderFilter(props.filterOrder);
    setTagFilter(props.brokerTags);
    setFilteredData(result);
  }, [props.filterOrder, props.brokerTags]);

  const filterOrder = (data: any) => {
    return [...data].filter(item => item.order.includes(props.filterOrder));
  };

  const filterTags = (data: any) => {
    return [...data].filter(item => item.tags.includes(props.brokerTags));
  };

  const modalToggle = () => {
    setModalVisible(prevState => !prevState);
  };

  const showModalData = (data: any) => {
    setItemData(data);
    setModalVisible(prevState => !prevState);
  };

  const progressBarView = () => {
    return (
      <View style={recommendations.innerProgress}>
        <View style={recommendations.outerProgress} />
      </View>
    );
  };

  const horizontalLine = () => {
    return <View style={recommendations.horzontalLine} />;
  };

  const renderCards = ({item}: any) => {
    return (
      <View style={[recommendations.card,{backgroundColor:root.color_active}]}>
        <View style={{padding: 12}}>
          <View style={recommendations.topView}>
            <View>
              <View style={recommendations.nameContainer}>
                <Text style={recommendations.stockName}>{item.name}</Text>
                <Text style={recommendations.nseText}>{item.sExchange}</Text>
                <Text style={recommendations.eQ}>{item.sSeries}</Text>
              </View>
              <View style={recommendations.gainerContainer}>
                <Text style={recommendations.volGainer}>{item.gainer}</Text>
              </View>
            </View>
            <TouchableOpacity onPress={()=>navigation.navigate('BuySell',{item:item})}>
              <Text
                style={
                  item.transaction === 'Buy'
                    ? recommendations.buyTxt
                    : [
                        recommendations.buyTxt,
                        {backgroundColor: root.color_negative},
                      ]
                }>
                {item.transaction}
              </Text>
            </TouchableOpacity>
          </View>
          <View style={{...alignment.row, paddingVertical: 16}}>
            <Text style={recommendations.buyTarget}>{item.buyType}</Text>
          </View>
          {progressBarView()}
          {horizontalLine()}
          <View style={recommendations.recommendationValidity}>
            <View>
              <Text style={recommendations.detailTxt}>Recommendation on</Text>
              <Text style={recommendations.detailTxt}>
                {item.recommendationOn}
              </Text>
            </View>
            <View>
              <Text style={recommendations.detailTxt}>Valid Till</Text>
              <Text style={recommendations.detailTxt}>{item.valid}</Text>
            </View>
          </View>
          {item.followUp > 1 ? (
            <TouchableOpacity
              onPress={() => showModalData(item)}
              style={[recommendations.followUpSection,{backgroundColor:root.color_active}]}>
              <Text style={recommendations.noOfFollupRecommendation}>
                {item.followUp}
              </Text>
              <Text style={recommendations.followUp}>
                Follow-up Recommendations
              </Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
    );
  };
  return (
    <View style={recommendations.container}>
      <View style={recommendations.header}>
        <Text style={recommendations.noOfRecommendations}>
          6 Recommendations
        </Text>
        <View style={recommendations.filterSearchContainer}>
          <TouchableOpacity onPress={() => props.searchModalToggle()}>
            <Fontisto
              name="search"
              size={20}
              color={'black'}
              style={{paddingRight: 25}}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => props.openSortFilterSheet()}>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
          </TouchableOpacity>
        </View>
      </View>
      {orderFilter !== '' || tagFilter !== '' ? (
        <View style={{...alignment.row_alignC,paddingHorizontal:16}}>
          <Text style={screenFilter.filterTitle}>Filters:</Text>
          {orderFilter !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Order:</Text>
              <Text style={screenFilter.filterTagData}>{orderFilter}</Text>
              <TouchableOpacity
                onPress={() => {
                  props.clearOrderFilter();
                }}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
          {tagFilter !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Broker Tags:</Text>
              <Text style={screenFilter.filterTagData}>{tagFilter}</Text>
              <TouchableOpacity
                onPress={() => {
                  props.clearTagFilter();
                }}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      ) : null}
      <FlatList
        data={filteredData}
        renderItem={renderCards}
        style={{marginTop: -10}}
      />
      <FollowUpModal
        onClose={modalToggle}
        visible={modalVisible}
        data={itemData}
      />
    </View>
  );
}

export default Recommendations;

import { useRoute } from '@react-navigation/native';
import React, {useCallback} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {demoData} from '../../../../assets/demoData';
import Searchstockcomponent from '../../../../components/StockListView/Searchstockcomponent';
import StockListView from '../../../../components/StockListView/StockListView';
import {root} from '../../../../styles/colors';
import {
  Allstyle,
  constituentsListComponent,
  Removescripstyle,
} from '../../../../theme/light';

const Commodity = ({route}:any) => {
  const [todos, setTodos] = React.useState(demoData.map(todo => ({...todo, selected: true})).filter(demoData=>demoData.commodity=="true"));
 
  const setNewlength = route.params?.setNewlength?.setNewlength;




  const handleToggleReview = (id:any) => {
    setTodos(prevTodos => {
      const updatedTodos = prevTodos.map(todo => {
        if (todo.id === id) {
          return {...todo, selected: !todo.selected};
        }
        return todo;
      });

      const result = updatedTodos.filter(
        updatedTodos => updatedTodos.selected == false,
      );
     
       setNewlength(result.length)
      //   setLength(result.length);

      return updatedTodos;
    });
  };

  const renderListView = useCallback(
    ({item, index}: any) => (
      <TouchableOpacity
        key={item?.id}
        onPress={() => handleToggleReview(item.id)}
        style={[
          {backgroundColor: item.selected ? root.color_active : root.color_negative_rgb},
        ]}>
            <Searchstockcomponent
              companyName={item.stockName}
              nindex={item.stockfrom}
              selected={item.selected}
            />
      </TouchableOpacity>
    ),
    [],
  );

  return (
    <FlatList
      data={todos}
      renderItem={renderListView}
      keyExtractor={(_, index) => `item-${index}`}
      style={{flex:1,backgroundColor:root.color_active}}
    />
  );
};

export default React.memo(Commodity);

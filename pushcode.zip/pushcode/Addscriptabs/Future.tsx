import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  ScrollView,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, root} from '../../../../styles/colors';
import {Allstyle} from '../../../../theme/light';

const screenWidth = Dimensions.get('window').width;

const Future: React.FC = () => {
  const navigation = useNavigation();

  const data = [
    {id: 1, name: 'ACC', value: 'A', fut: 'true'},
    {id: 2, name: 'ACC', value: 'b', fut: 'true'},
    {id: 3, name: 'ACC', value: 'c', fut: 'true'},
    {id: 4, name: 'ACC', value: 'd', spred: 'true'},
    {id: 5, name: 'ACC', value: 'e', spred: 'true'},
    {id: 6, name: 'SBIN', value: 'f', fut: 'true'},
    {id: 7, name: 'SBIN', value: 'g', fut: 'true'},
    {id: 8, name: 'SBIN', value: 'h', fut: 'true'},
    {id: 9, name: 'SBIN', value: 'i', spred: 'true'},
    {id: 10, name: 'SBIN', value: 'j', spred: 'true'},
    {id: 11, name: 'DR READDY', value: 'k', fut: 'true'},
    {id: 12, name: 'DR READDY', value: 'l', fut: 'true'},
    {id: 13, name: 'DR READDY', value: 'm', fut: 'true'},
    {id: 14, name: 'DR READDY', value: 'n', spred: 'true'},
    {id: 15, name: 'DR READDY', value: 'o', spred: 'true'},
    {id: 16, name: 'ACC', value: 'p', spred: 'true'},
    {id: 17, name: 'ACC', value: 'q', spred: 'true'},
    {id: 18, name: 'ACC', value: 'r', spred: 'true'},
  ];

  // Step 1: Identify the common names
  const commonNames = data.reduce((acc, current) => {
    if (!acc.includes(current.name)) {
      acc.push(current.name);
    }
    return acc;
  }, []);

  // Step 2: Filter the data based on the common names and store them in separate arrays
  const dataArrays = commonNames.map(name =>
    data.filter(item => item.name === name),
  );

  // State to keep track of selected data objects
  const [selectedItems, setSelectedItems] = useState<any[]>([]);

  // Function to handle data object selection
  const handleSelectItem = (item: any) => {
    setSelectedItems(prevState => {
      if (prevState.some(obj => obj.id === item.id)) {
        // If the data object is already in the selectedItems array, remove it
        return prevState.filter(obj => obj.id !== item.id);
      } else {
        // Otherwise, add it to the selectedItems array
        return [...prevState, item];
      }
    });
  };
  // Function to check if a data object is selected
  const isItemSelected = (item: any) =>
    selectedItems.some(obj => obj.id === item.id);

  // Render the FlatLists for each data array
  return (
    <ScrollView style={styles.container}>
      <View>
        {dataArrays.map((dataArray, index) => (
          <React.Fragment key={index}>
            <View style={{paddingHorizontal: 10}}>
              <Text style={Allstyle.tittxtstyle}>{commonNames[index]} EQ</Text>
              <View style={Allstyle.innercontainer}>
                <Text style={Allstyle.nsetxt}>
                  NSE
                  {/* {item?.stockfrom} */}
                </Text>
                <Text style={Allstyle.banktxt}>STATE BANK OF INDIA</Text>
              </View>
            </View>
            {/* First flatlist */}
            <View style={{height: 132}}>
              <FlatList
                horizontal
                data={dataArray.filter(neo => neo.fut === 'true')}
                keyExtractor={item => item.id.toString()}
                renderItem={({item}) => (
                  <TouchableOpacity onPress={() => handleSelectItem(item)}>
                    <View
                      style={[
                        isItemSelected(item)
                          ? styles.selectedItem
                          : styles.constiner,
                      ]}>
                      <Text style={styles.dattxt}>
                        {/* {item?.date} */}31 AUG
                        <Text style={styles.yrtxt}>
                          {/* {item?.year} */} '23
                        </Text>{' '}
                      </Text>

                      <View style={styles.endcontainer}>
                        <TouchableOpacity
                          style={styles.bottonView}
                          onPress={() => {
                            navigation.navigate('BuySell', {
                              item: item,
                            });
                          }}>
                          <Text style={{fontWeight: 'bold', color: 'black'}}>
                            T
                          </Text>
                        </TouchableOpacity>

                        {isItemSelected(item) ? (
                          <AntDesign
                            name="minuscircleo"
                            size={20}
                            color={'black'}
                          />
                        ) : (
                          <AntDesign
                            name="pluscircleo"
                            size={20}
                            color={'black'}
                          />
                        )}
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              />
            </View>
            <Text style={styles.lengthone}>
              {dataArray.filter(neo => neo.fut === 'true').length} Expiries
              available till OCT '23
            </Text>
            {/* second flatlist */}
            <View style={{height: 132}}>
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={dataArray.filter(neo => neo.spred === 'true')}
                keyExtractor={item => item.id.toString()}
                renderItem={({item}) => (
                  <TouchableOpacity onPress={() => handleSelectItem(item)}>
                    <View
                      style={[
                        isItemSelected(item)
                          ? styles.selectedItem
                          : styles.constiner,
                      ]}>
                      <Text style={styles.txtname}>{item.name}-1</Text>
                      <Text style={styles.txttwoname}>
                        {/* {item.date} */}31 AUG - SEP '23'
                      </Text>
                      <View style={styles.endcontainer}>
                        <TouchableOpacity
                          style={styles.bottonView}
                          onPress={() => {
                            navigation.navigate('BuySell', {
                              item: item,
                            });
                          }}>
                          <Text style={{fontWeight: 'bold', color: 'black'}}>
                            T
                          </Text>
                        </TouchableOpacity>

                        {isItemSelected(item) ? (
                          <AntDesign
                            name="minuscircleo"
                            size={20}
                            color={'black'}
                          />
                        ) : (
                          <AntDesign
                            name="pluscircleo"
                            size={20}
                            color={'black'}
                          />
                        )}
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
              />
            </View>

            <Text style={styles.lengthone}>
              {dataArray.filter(neo => neo.spred === 'true').length} Expiries
              available till OCT '23
            </Text>
          </React.Fragment>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 10,
    paddingHorizontal: 10,
    backgroundColor: 'white',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  item: {
    padding: 10,
    marginVertical: 15,
    borderRadius: 8,
    borderWidth: 1,
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    borderColor: '#ccc',
  },
  selectedItem: {
    backgroundColor: root.color_negative_rgb,
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 6,
    marginVertical: 12,
    marginRight: 9,
    marginLeft: 8,
    paddingVertical: 12,
    paddingHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.53,
    shadowRadius: 13.97,

    elevation: 0,
  },
  constiner: {
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    backgroundColor: root.color_active,
    borderRadius: 6,
    marginVertical: 12,
    marginRight: 9,
    marginLeft: 8,
    paddingVertical: 12,
    paddingHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.53,
    shadowRadius: 13.97,
    elevation: 10,
  },
  lengthone: {
    paddingHorizontal: 10,
    marginBottom: 16,
    fontSize: 10,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 20,
    height: 20,
    borderRadius: 24 / 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },
  endcontainer: {
    flexDirection: 'row',
    marginTop: 25,
    alignSelf: 'flex-end',
  },
  dattxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
  },
  yrtxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
    color: root.color_text,
  },
  txtname: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txttwoname: {
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});

export default Future;

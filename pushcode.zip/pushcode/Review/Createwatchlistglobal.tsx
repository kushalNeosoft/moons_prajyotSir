import {useNavigation, useRoute, StackActions} from '@react-navigation/native';

import * as React from 'react';
import {useEffect, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  Animated,
  Easing,
  ScrollView,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import Toast from 'react-native-toast-message';
import { Addscripstyle, Removescripstyle } from '../../theme/light';
import CustomHeader from '../../components/IndicesHeader/CustomHeader';
import Remove from '../WatchList/Scrips/Removescrip/Remove';


const Review = () => {
  const route = useRoute();
  const item = route.params?.item;
  const title=route.params?.title
  const [getlength, setLength] = useState(0);

  //for scroll
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  const [show, setShow] = useState(false);

  const pop = StackActions.pop(1);
   const navigation = useNavigation();
  // SCrollview animation

  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      setShow(false);
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [180, 58],
    extrapolate: 'clamp',
  });

  const onpressDone=()=>{
    if(getlength==0){
      Toast.show({
        type: 'tomatoToast',
        props: 'Alleast one should be selected',
        position: 'bottom',
      });

    }else{
      console.log("other function");
    }
  }


 

  return (
    <View style={Removescripstyle.Maincontainer}>
      <CustomHeader
        title={scrollValue == 1 ? item?.title : ''}
        leftComponent={
          <TouchableOpacity onPress={() => navigation.dispatch(pop)}>
            <Ionicons name="arrow-back" size={25} color={'black'} />
          </TouchableOpacity>
        }
      />
        <ScrollView
          style={{flex: 1}}
          onScroll={evt => {
            if (evt?.nativeEvent?.contentOffset.y == 0) {
              setScrollValue(0);
            } else {
              if (evt?.nativeEvent?.contentOffset.y > 100) {
                setScrollValue(1);
              }
            }
          }}>
          <View style={Removescripstyle.innoecontainer}>
            <Text style={Removescripstyle.RemoveTitle}>Review & add this watchlist</Text>
            <View style={Removescripstyle.containerinner}>
              <Text style={Removescripstyle.removetxt}>
                {title}
              </Text>
              <Text style={Removescripstyle.removetxttwo}>
              {getlength} Scrip
              </Text>
            </View>
          </View>
         
    <Remove setLength={setLength} title={title}  />
        </ScrollView>
        <View style={Addscripstyle.bottomconatiner}>
        <View>
         
          <View style={Addscripstyle.rowconatiner}>
            <Text style={Addscripstyle.watchlisttitle}>{title}</Text>
            <Text style={Addscripstyle.numtxt}>{getlength}</Text>
          </View>
        </View>
        <TouchableOpacity style={Addscripstyle.doneconatiner} onPress={onpressDone}>
          <Text style={Addscripstyle.donetxt}>Done</Text>
        </TouchableOpacity>
      </View>


        
      

      {/* {newone == true ? <Done /> : null} */}
    </View>
  );
};

export default Review;

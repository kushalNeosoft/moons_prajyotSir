import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  FlatList,
  StyleSheet,
  TouchableWithoutFeedback,
} from 'react-native';
import BackIcon from '../../assets/BackIcon';
import { useNavigation } from '@react-navigation/native';
import { addToWatchList } from '../../theme/light';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Toast from 'react-native-toast-message';
import Done from '../WatchList/Scrips/Removescrip/Done';
import Donetwo from '../WatchList/Scrips/Removescrip/Donetwo';



function AddToWatchList() {
  const[listname,setListName]=useState('')
  const [newone, setNewone] = useState(false);
  const [show, setshow] = useState();


  const navigation=useNavigation();
 
  const newmessage='Create your watchlist'

  const DATA = [
    {
      id: 'bd7acbea-c1b1-46c2-aed5-3ad53abb28ba',
      title: 'Global',
      // onPress: (item: any) => {
      //   console.log(item);
      //   navigation.navigate('Review')
      // },
    },
    {
      id: '3ac68afc-c605-48d3-a4f8-fbd91aa97f63',
      title: 'Second Item',
      // onPress: (item: any) => {
      //   console.log(item);
      //   navigation.navigate('Review')
      // },
    },
  ];

  
  type ItemProps = {title: string};
  
  const Item = ({title}: ItemProps) => (
    <TouchableWithoutFeedback onPress={()=>navigation.navigate('Review',{
      title:title
    })}>

    <View style={addToWatchList.item}>
      <Ionicons name='square-sharp' size={36} color={'#1C86FF3D'}/>
      {/* <Text style={styles.title}>{title}</Text> */}
      <Text style={addToWatchList.toptxt}>Top 20</Text>
      <Text style={addToWatchList.titletxtx}>{title}</Text>
      <View style={addToWatchList.newbottom}>
        <FontAwesome name='users' size={16} color={'black'}/>
        <Text style={addToWatchList.subtx}>Subscribers</Text>

      </View>
    </View>
    </TouchableWithoutFeedback>
  );
  const onPresscreate=({title}:any)=>{
    if(listname===''){
      Toast.show({
        type: 'tomatoToast',
        props: 'Name is required to create a watchlist',
        position: 'bottom',
      });
    }
    else{
      setNewone(true)
      setTimeout(() => {
          navigation.navigate('Addscrip',{
            newlist:listname,   
          })
          setNewone(false);
        }, 2000);
       
        
      
     
    }
  }

  const coll=2


  return (
    <View style={addToWatchList.container}>
      <View style={addToWatchList.innerContainer}>
        <View style={addToWatchList.topContainerView}>
            <TouchableOpacity onPress={()=>navigation.goBack()}>
          <BackIcon style={addToWatchList.backIcon} />
          </TouchableOpacity>
          <TouchableOpacity style={addToWatchList.skipContainer}onPress={()=>navigation.goBack()} >
            <Text style={addToWatchList.skipTxt}>Skip</Text>
          </TouchableOpacity>
        </View>
        <View style={addToWatchList.titleTxtContainer}>
          <Text style={addToWatchList.titleTxt}>
            Let's setup your new watchlist
          </Text>
        </View>
        <Text style={addToWatchList.subTitleTxt}>Create your watchlist</Text>
        <View style={addToWatchList.textIpContainer}>
          <TextInput
            style={addToWatchList.textIp}
            placeholder="Name your watchlist"
            onChangeText={(t)=>setListName(t.toUpperCase())}
            autoCapitalize="characters"
            value={listname}
            keyboardType="email-address"
          />
          <TouchableOpacity style={addToWatchList.createBtnContainer} onPress={onPresscreate}>
            <Text style={listname!=''?addToWatchList.createTxttwo:addToWatchList.createTxt}>Create</Text>
          </TouchableOpacity>
        </View>
      </View>
      <Text style={addToWatchList.oddtxt}>Or add fromthese</Text>
      <View style={addToWatchList.starcontainer}>
        <Entypo name='star' size={24} color={'black'}/>
        <Text style={addToWatchList.toppicktxt}>Top Picks</Text>

      </View>
    
      <FlatList
      numColumns={coll}
        data={DATA}
        renderItem={({item}) => <Item title={item.title} />}
        keyExtractor={item => item.id}
        style={{marginLeft:10,
          }}
      />


{newone == true ? <Donetwo  newmessage={newmessage} /> : null}

    </View>
  );
}


export default AddToWatchList;

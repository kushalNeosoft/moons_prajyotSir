import {useNavigation, useRoute} from '@react-navigation/native';
import * as React from 'react';
import {TouchableOpacity, TouchableWithoutFeedback} from 'react-native';
import {TextInput} from 'react-native';
import {View, Text} from 'react-native';
import Toast from 'react-native-toast-message';
import Entypo from 'react-native-vector-icons/Entypo';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  demoData,
  PartofIndices,
  recommdata,
  trendingmmdata,
} from '../../../../assets/demoData';
import Addscriptab from '../../../../navigators/AddscriptabNavigation';
import {root} from '../../../../styles/colors';
import {Addscripstyle} from '../../../../theme/light';
import Done from '../Removescrip/Done';

const Addscrip = () => {
  const route = useRoute();
  const [newone, setNewone] = React.useState(false);
  const [newtwo, setNewtwo] = React.useState(false);
  const [show, setshow] = React.useState(true);
  const [filterData, setFilterData] = React.useState<any>();

  

  const item = route.params?.newlist;
  const watchList = route.params?.watchlistname;
  const [watchlistdata, setWatchlistdata] = React.useState(
    route.params?.watchlistdata,
  );  
  const [search, setSearch] = React.useState('');
  const [newlenght, setNewlength] = React.useState(0);
  const navigation = useNavigation();
  const newmessage='Adding stock to your new watchlist';
  const updatemessage='Updating stock to your watchlist';


  React.useEffect(() => {
    const searchFilterOnList = (value: string) => {
      if (value && value.length > 1) {
        var mainList = [];
        mainList = demoData;
        const filterTempList = mainList.filter((item: any) =>
          item.stockName.toLowerCase().includes(value.toLowerCase()),
        );
        setFilterData(filterTempList);
      }
       else {
        setFilterData([]);
      }
    };

    searchFilterOnList(search);
  }, [search]);

  const onPressdone = () => {
    if(item==undefined){
      if(newlenght == 0){
        Toast.show({
          type: 'tomatoToast',
          props: 'There is no change in Watchlist!',
          position: 'bottom',
        });
      }
      else{
        setNewtwo(true)
        setTimeout(() => {
            navigation.navigate('TestScreen')
            setNewtwo(false);
          }, 2000);


      }

    }
    else{

      if (newlenght == 0) {        
        Toast.show({
          type: 'tomatoToast',
          props: 'Add at least one scrip to save your watchlist',
          position: 'bottom',
        });
      } else {
        setNewone(true)
        setTimeout(() => {
            navigation.navigate('TestScreen')
            setNewone(false);
          }, 2000);

  
      }
    }
  };
 

  return (
    <View style={Addscripstyle.Maincontainer}>
      <View
        style={[
          Addscripstyle.textinput,
          {
            borderBottomColor:
              search !== '' ? root.color_active : root.color_border,
          },
        ]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Entypo name="cross" size={24} color={'black'} />
        </TouchableOpacity>
        <TextInput
          placeholder="Search eg:infy fut, gold mcx, acc opt"
          value={search}
          onChangeText={t => setSearch(t.toUpperCase())}
        />
        {search !== '' ? (
          <>
            <TouchableWithoutFeedback onPress={() => setSearch('')}>
              <Text>Clear</Text>
            </TouchableWithoutFeedback>
          </>
        ) : (
          <>
            <MaterialCommunityIcons
              name="microphone"
              size={24}
              color={'black'}
            />
          </>
        )}
      </View>
      {search !== '' ? (
        <>
          <Addscriptab  search={search} setNewlength={setNewlength} />
        </>
      ) : (
        <>
          <View style={Addscripstyle.innerconatiner}>
            <Text style={Addscripstyle.recomtxt}>
              <MaterialCommunityIcons name="thumb-up" size={24} />{' '}
              Recommendation
            </Text>
          </View>
          <View style={Addscripstyle.flexallign}>
            {recommdata.map(item => {
              return (
                <TouchableWithoutFeedback onPress={() => setSearch(item.title)}>
                  <View style={Addscripstyle.recomdata}>
                    <Text style={Addscripstyle.rcomtxt}>{item.title}</Text>
                  </View>
                </TouchableWithoutFeedback>
              );
            })}
          </View>

          <View style={Addscripstyle.innerconatiner}>
            <Text style={Addscripstyle.recomtxt}>
              <Ionicons name="trending-up" size={24} /> Trending
            </Text>
          </View>
          <View style={Addscripstyle.flexallign}>
            {trendingmmdata.map(item => {
              return (
                <TouchableWithoutFeedback onPress={() => setSearch(item.title)}>
                  <View style={Addscripstyle.recomdata}>
                    <Text style={Addscripstyle.rcomtxt}>{item.title}</Text>
                  </View>
                </TouchableWithoutFeedback>
              );
            })}
          </View>
        </>
      )}

      <View style={[Addscripstyle.bottomconatiner,{position:search !== '' ?"relative":"absolute"}]}>
        <View>
          <Text style={Addscripstyle.addtxt}>Add scrip to</Text>
          <View style={Addscripstyle.rowconatiner}>
            <Text style={Addscripstyle.watchlisttitle}>
              {item == undefined ? watchList : item}
            </Text>
            <Text style={Addscripstyle.numtxt}>{item == undefined ? watchlistdata.length+newlenght : newlenght}</Text>
          </View>
        </View>
        <TouchableOpacity
          style={Addscripstyle.doneconatiner}
          onPress={onPressdone}>
          <Text style={Addscripstyle.donetxt}>Done</Text>
        </TouchableOpacity>
      </View>
      {newtwo == true ? <Done  newmessage={updatemessage} show={show} /> : null}

      {newone == true ? <Done  newmessage={newmessage} show={show} /> : null}
    </View>
  );
};

export default React.memo(Addscrip);

import {useNavigation, useRoute, StackActions} from '@react-navigation/native';

import * as React from 'react';
import {useEffect, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  View,
  Animated,
  Easing,
  ScrollView,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

import {demoData} from '../../../../assets/demoData';

import CustomHeader from '../../../../components/IndicesHeader/CustomHeader';
import {Removescripstyle} from '../../../../theme/light';
// import {Item, mapIndexToData} from '.';
import Toast from 'react-native-toast-message';
import {RemoveScripmodal} from './RemoveScripmodal';
import Reorder from './Reorder';
import Done from './Done';
import Remove from './Remove';

const Removescrip = () => {
  const route = useRoute();
  const item = route.params?.item;
  const stockdata = route.params?.stockdata;
  const [todos, setTodos] = useState(demoData);
  const [removemodal, setRemovemodal] = useState(false);
  const [newone, setNewone] = useState(false);
  const [getlength, setLength] = useState(0);

  //for scroll
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  const [show, setShow] = useState(false);

  const pop = StackActions.pop(1);
  const onRemoveClose = () => {
    setRemovemodal(prevState => !prevState);
  };

  React.useEffect(() => {
    if (newone == true) {
      setTimeout(() => {
        setNewone(false);
        navigation.goBack();
      }, 2000);
    }
  }, [newone]);

  const navigation = useNavigation();

  React.useEffect(() => {
    const todosWithSelected = demoData.map(todo => ({...todo, selected: true}));
    setTodos(todosWithSelected);
  }, []);

  const onPressyes = () => {
    navigation.goBack();
  };

  const onPressdone = () => {
    if (getlength >= 1) {
      console.log('onpen modal for conformation');
      setRemovemodal(true);
    } else {
      if (item.title == 'Remove Scrips') {
        navigation.goBack();
        Toast.show({
          type: 'tomatoToast',
          props: 'No item is removed from list',
          position: 'bottom',
        });
      } else {
        navigation.goBack();
      }
    }
  };

  // SCrollview animation

  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      setShow(false);
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [180, 58],
    extrapolate: 'clamp',
  });

  return (
    <View style={Removescripstyle.Maincontainer}>
      <CustomHeader
        title={scrollValue == 1 ? item?.title : ''}
        leftComponent={
          <TouchableOpacity onPress={() => navigation.dispatch(pop)}>
            <Ionicons name="arrow-back" size={25} color={'black'} />
          </TouchableOpacity>
        }
        rightComponent={
          <TouchableOpacity
            style={Removescripstyle.donecontainer}
            onPress={onPressdone}>
            <Text style={Removescripstyle.donetxt}>Done</Text>
          </TouchableOpacity>
        }
      />
      {item?.title === 'Remove Scrips' ? (
        <ScrollView
          style={{flex: 1}}
          onScroll={evt => {
            if (evt?.nativeEvent?.contentOffset.y == 0) {
              setScrollValue(0);
            } else {
              if (evt?.nativeEvent?.contentOffset.y > 100) {
                setScrollValue(1);
              }
            }
          }}>
          <View style={Removescripstyle.innoecontainer}>
            <Text style={Removescripstyle.RemoveTitle}>{item?.title}</Text>
            <View style={Removescripstyle.containerinner}>
              <Text style={Removescripstyle.removetxt}>
                <MaterialIcons
                  name="arrow-forward-ios"
                  size={16}
                  color={'black'}
                />
                PRAGATI
              </Text>
              <Text style={Removescripstyle.removetxttwo}>
                {stockdata.length} Scrip
              </Text>
            </View>
          </View>
          <Remove setLength={setLength}  />
        </ScrollView>
      ) : (
        <Reorder setScrollValue={setScrollValue} data={item} />
      )}

      <RemoveScripmodal
        visible={removemodal}
        onClose={onRemoveClose}
        onPressyes={onPressyes}
        showfun={(e: any) => {
          setNewone(e);
        }}
      />
      {newone == true ? <Done /> : null}
    </View>
  );
};

export default Removescrip;

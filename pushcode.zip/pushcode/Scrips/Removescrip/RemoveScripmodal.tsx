import React, {useState} from 'react';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import CommonModalfive from '../../../../components/CommonModal/CommModalfive';
import {
  Removescripstyle,
} from '../../../../theme/light';


export const RemoveScripmodal = (props: any) => {

  return (
    <CommonModalfive visible={props.visible} onClose={props.onClose}>
      <View style={Removescripstyle.removemodal}>
        <View style={Removescripstyle.innercontainerone}>
          <Text style={Removescripstyle.modeltitle}>Watchlist</Text>
        </View>
        <View style={Removescripstyle.innercontainertwo}>
          <Text style={Removescripstyle.desptxt}>
            Are you sure you want to delete the selected scrip (s)?
          </Text>
        </View>
        <View style={Removescripstyle.innercontainerthree}>
          <TouchableOpacity
            style={Removescripstyle.yescontainer}
            onPress={() => {
              props.onClose()
              props.showfun(true)

            }}>
            <Text style={Removescripstyle.yestxt}>Yes</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={Removescripstyle.nocontainer}
            onPress={props.onClose}>
            <Text style={Removescripstyle.notxt}>No</Text>
          </TouchableOpacity>
        </View>
      </View>
    </CommonModalfive>
  );
};

import * as React from 'react';
import {
  TouchableOpacity,
} from 'react-native-gesture-handler';
import {Removescripstyle} from '../../../../theme/light';
import {View, Text, FlatList} from 'react-native';
import {demoData} from '../../../../assets/demoData';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';
import Toast from 'react-native-toast-message';
import { useEffect } from 'react';


const Remove = ({setLength,title,props}:any) => {
  const [todos, setTodos] = React.useState(demoData);

  React.useEffect(() => {
    const todosWithSelected = demoData.map(todo => ({...todo, selected: true}));
    setTodos(todosWithSelected);
    setLength(todos.length)
  }, []);

  const handleToggleTodo = id => {
    setTodos(prevTodos => {
      const updatedTodos = prevTodos.map(todo => {
        if (todo.id === id) {
          return {...todo, selected: !todo.selected};
        }
        return todo;
      });
      const allUnselected = updatedTodos.every(todo => !todo.selected);
      if (allUnselected) {
        const lastSelectedIndex = prevTodos.findIndex(todo => todo.selected);

        updatedTodos[lastSelectedIndex].selected = true;
        Toast.show({
          type: 'tomatoToast',
          props: 'Alleast one should be selected',
          position: 'bottom',
        });
      }

      const result = updatedTodos.filter(
        updatedTodos => updatedTodos.selected == false,
      );
      setLength(result.length);
      if(result.length==0){
        Toast.show({
          type: 'tomatoToast',
          props: 'Alleast one should be selected',
          position: 'bottom',
        });

      }
      
      
      return updatedTodos;
    });
  };


  const handleToggleReview = id => {
    setTodos(prevTodos => {
      const updatedTodos = prevTodos.map(todo => {
        if (todo.id === id) {
          return {...todo, selected: !todo.selected};
        }
        return todo;
      });

      const result = updatedTodos.filter(
        updatedTodos => updatedTodos.selected == true,
      );
      setLength(result.length);
      
      return updatedTodos;
    });

  };
 
  const renderRemovelist = ({item}: any) => {
    return (
      <TouchableOpacity
        key={item?.id}
        onPress={() =>title?handleToggleReview(item.id): handleToggleTodo(item.id)}
        style={[
          Removescripstyle.removeconatiner,
          {backgroundColor: item.selected ? root.color_negative_rgb : null},
        ]}>
        <View style={Removescripstyle.innercontainer}>
          <Text style={Removescripstyle.tittxtstyle}>{item?.stockName}</Text>
          <Text style={Removescripstyle.nsetxt}>{item?.stockfrom}</Text>
          <Text style={Removescripstyle.eqtxt}>EQ</Text>
        </View>
        {item.selected ? (
          <AntDesign name="pluscircleo" size={24} color={'black'} />
        ) : (
          <AntDesign name="minuscircleo" size={24} color={'black'} />
        )}
      </TouchableOpacity>
    );
  };
  return (
    <FlatList
      nestedScrollEnabled
      scrollEnabled={false}
      data={todos}
      renderItem={renderRemovelist}
      keyExtractor={item => item.id}
      style={{paddingBottom:title?80:0}}
    />
  );
};

export default Remove;

import React from 'react';
import {TouchableOpacity} from 'react-native-gesture-handler';
import DraggableFlatList, {
  ScaleDecorator,
} from 'react-native-draggable-flatlist';
import {Removescripstyle} from '../../../../theme/light';
import {View, Text} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {demoData} from '../../../../assets/demoData';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const Reorder = ({setScrollValue, data}: any) => {
  console.log(data.title, 'Titlevalue===>');

  const [todos, setTodos] = React.useState(demoData);
  const [newew, setNewew] = React.useState(false);

  const listheader = () => {
    return (
      <View style={Removescripstyle.innoecontainer}>
        <Text style={Removescripstyle.RemoveTitle}>{data.title}</Text>
        <View style={Removescripstyle.containerinner}>
          <Text style={Removescripstyle.removetxt}>
            <MaterialIcons name="arrow-forward-ios" size={16} color={'black'} />
            PRAGATI
          </Text>
          <Text style={Removescripstyle.removetxttwo}>
            {todos.length} Scrip
          </Text>
        </View>
      </View>
    );
  };

  const renderListViewtwo = ({item, index, drag, isActive}: any) => {
    return (
      <ScaleDecorator>
        <TouchableOpacity
          style={
            isActive
              ? Removescripstyle.shadowconationer
              : Removescripstyle.removeconatiner
          }
          onLongPress={drag}>
          <View style={Removescripstyle.innercontainer}>
            <Text style={Removescripstyle.tittxtstyle}>{item?.stockName}</Text>
            <Text style={Removescripstyle.nsetxt}>{item?.stockfrom}</Text>
            <Text style={Removescripstyle.eqtxt}>EQ</Text>
          </View>
          <Entypo name="menu" size={24} color={'black'} />
        </TouchableOpacity>
      </ScaleDecorator>
    );
  };
  return (
    <DraggableFlatList
      data={todos}
      onDragEnd={({data}: any) => {
        setTodos(data);
      }}
      onScrollOffsetChange={evt => {
        if (evt == 0) {
          setScrollValue(0);
        } else {
          if (evt > 100) {
            setScrollValue(1);
          }
        }
      }}
      ListHeaderComponent={listheader}
      keyExtractor={item => item.id}
      renderItem={renderListViewtwo}
    />
  );
};

export default Reorder;

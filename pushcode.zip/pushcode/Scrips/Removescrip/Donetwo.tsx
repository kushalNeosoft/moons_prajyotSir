
import {View, Text, ActivityIndicator} from 'react-native';
import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';
import {Donestyle} from '../../../../theme/light';

const Donetwo = props => {
  return (
    <View style={Donestyle.maincon}>
      {props.newmessage != '' ? (
        <ActivityIndicator size="large"  color={root.client_background}/>
      ) : (
        <AntDesign
          name="checkcircle"
          size={30}
          color={root.client_background}
        />
      )}
      <Text style={Donestyle.donetxt}>
        {props.newmessage != '' ? props.newmessage : 'Done'}
      </Text>
    </View>
  );
};

export default Donetwo;

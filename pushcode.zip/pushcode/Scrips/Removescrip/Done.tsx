import {View, Text, ActivityIndicator} from 'react-native';
import React, {useEffect, useState} from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';
import {Donestyle} from '../../../../theme/light';

const Done = props => {
  
  const [show, setshow] = useState(props.show);
  useEffect(() => {
    setTimeout(() => {
      setshow(false);
    }, 1000);
  }, [show]);
  return (
    <View style={Donestyle.maincon}>
     
      
      {show == true ? (
        <>
          {props.newmessage != '' ? (
            <ActivityIndicator size="large" color={root.client_background} />
          ) : (
            <AntDesign
              name="checkcircle"
              size={30}
              color={root.client_background}
            />
          )}
        </>
      ) : (
        <AntDesign
          name="checkcircle"
          size={30}
          color={root.client_background}
        />
      )}

      {show == true ? (
        <Text style={Donestyle.donetxt}>
          {props.newmessage != '' ? props.newmessage : 'Done'}
        </Text>
      ) : (
        <Text style={Donestyle.donetxt}>Done</Text>
      )}
      
      
    </View>
  );
};

export default Done;

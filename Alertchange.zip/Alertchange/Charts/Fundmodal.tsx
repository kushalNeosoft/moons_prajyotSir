import React, {useState} from 'react';
import {ScrollView} from 'react-native';
import {Touchable} from 'react-native';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  annualmodaldata,
  fundmodaldata,
} from '../../../../assets/demoData';
import CommonModal from '../../../../components/CommonModal/CommonModal';


import {
  Analysisstyle,
  Companymodalstyle,
  Eventmodaistyle,
} from '../../../../theme/light';

export const Fundmodal = (props: any) => {
  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>

      <View style={[Analysisstyle({}).innermanage]}>
        <Text style={[Analysisstyle({}).txtstylemange]}>
          {props?.funddata?.title}
        </Text>
        <View style={Analysisstyle({}).allignprice}>
          <Text style={[Analysisstyle({}).txtstylemagegreen]}>
            {props?.funddata?.price}
          </Text>
          <Text style={Analysisstyle({}).txtstylemagetwo}>
            {props?.funddata?.date}
          </Text>
        </View>
      </View>
      {fundmodaldata.map((item, index) => {
        return (
          <View style={Companymodalstyle.listoneone}>
            <Text style={Companymodalstyle.txtstyletwo}>{item.title}</Text>
            <Text style={Companymodalstyle.txtstyle}>
              {item.title == 'Shares' ? null : (
                <>
                  <FontAwesome name="rupee" size={10} color={'black'} />
                </>
              )}{' '}
              {item.value}
            </Text>
          </View>
        );
      })}
    </CommonModal>
  );
};

export const FundmodalAnnual = (props: any) => {
  const [modalvlue, setModalvalue] = useState(0);

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>

      <Text style={Analysisstyle({}).annnualmodal}>Annual Report</Text>
      {annualmodaldata.map((item, index) => {
        return (
          <TouchableOpacity
          style={{marginTop:16,}}
            onPress={() => {
                props.onClose()
                props.callfun(item.title)
            
              setModalvalue(index);
              
            }}>
            {modalvlue === index ? (
              <View style={Analysisstyle({}).annualmodalone}>
                <MaterialCommunityIcons name="circle-slice-8" size={20} color={'black'} />
                <Text style={Analysisstyle({}).annualmodaltwo}>{item.title}</Text>
              </View>
            ) : (
              <View style={Analysisstyle({}).annualmodalone}>
                <Feather name="circle" size={20} color={'black'} />
                <Text style={Analysisstyle({}).annualmodaltwo}>{item.title}</Text>
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </CommonModal>
  );
};

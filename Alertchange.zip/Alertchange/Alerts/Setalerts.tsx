import {useNavigation, useRoute} from '@react-navigation/native';
import React, {useState} from 'react';
import {Text, View, TouchableOpacity, Switch} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {setalertdata} from '../../../../assets/demoData';
import CustomHeader from '../../../../components/IndicesHeader/CustomHeader';
import globalStyleClass from '../../../../theme/globalStyleClass';
import {Setalertstyle} from '../../../../theme/light';
import {Setmodal} from './Setmodal';

const Setalerts = () => {
  const route = useRoute();
  const detail = route.params?.detail?.detail?.item;
  const [selectedItem, setSelectedItem] = useState(0);
  const [managemodalvisible, setManagemodalvisible] = useState(false);

  const [isEnabled, setIsEnabled] = useState(false);
  const [isEnabledone, setIsEnabledone] = useState(false);
  const [isEnabledtwo, setIsEnabledtwo] = useState(false);

  const onNewsModalClose = () => {
    setManagemodalvisible(prevState => !prevState);
  };

  const toggleSwitchone = (index: any) => {
    setManagemodalvisible(true);

    setIsEnabled((previousState: any) => !previousState);
  };
  const toggleSwitchtwo = (index: any) => {
    // setIsEnabledone((previousState: any) => !previousState);
  };
  const toggleSwitchthree = (index: any) => {
    setIsEnabledtwo((previousState: any) => !previousState);
  };

  const navigation = useNavigation();
  return (
    <View style={Setalertstyle.conatiner}>
      <CustomHeader
        title={''}
        leftComponent={
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="arrowleft" size={24} color={'black'} />
          </TouchableOpacity>
        }
      />
      <View style={Setalertstyle.maincon}>
        <Text style={[Setalertstyle.Title, globalStyleClass.color.text]}>
          Set Alerts
        </Text>
        <View style={Setalertstyle.mainnew}>
          <View style={Setalertstyle.innertitleconatiner}>
            <Text style={Setalertstyle.companytxt}>{detail?.companyName}</Text>
            <Text style={Setalertstyle.nsetxt}>NSE</Text>
          </View>
          <View style={Setalertstyle.innertitleconatiner}>
            <Text style={Setalertstyle.futtxt}>{detail?.date?.day}</Text>
            <Text style={Setalertstyle.futtxt}>{detail?.date?.value}</Text>
          </View>
          <Text style={Setalertstyle.valuetxtx}>{detail?.value}</Text>
        </View>

        {setalertdata.map((item, i) => {
          return (
            <View style={[Setalertstyle.piceconatiner]}>
              <View>
                <Text style={Setalertstyle.txtstyle}>{item.title}</Text>
                <Text style={Setalertstyle.txtdesc}>{item.desc}</Text>
              </View>

              <Switch
                trackColor={{false: '#767577', true: 'lightgreen'}}
                thumbColor={'#f4f3f4'}
                ios_backgroundColor="#3e3e3e"
                onValueChange={
                  i == 0
                    ? toggleSwitchone
                    : i == 1
                    ? toggleSwitchtwo
                    : toggleSwitchthree
                }
                value={
                  i == 0 ? isEnabled : i == 1 ? isEnabledone : isEnabledtwo
                }
              />
            </View>
          );
        })}
      </View>
      <Setmodal
        visible={managemodalvisible}
        onClose={onNewsModalClose}
        data={detail}
      />
    </View>
  );
};

export default Setalerts;

import React, { useState } from "react";
import { Text, TouchableOpacity, View } from "react-native";
import CustomHeader from "../../../../components/IndicesHeader/CustomHeader";
import {WebView} from 'react-native-webview';
import { Scriptviewstyle } from "../../../../theme/light";
import Entypo from "react-native-vector-icons/Entypo";
import { root } from "../../../../styles/colors";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import Ionicons from "react-native-vector-icons/Ionicons";
import { useNavigation } from "@react-navigation/native";
import { Advancechartmodal } from "./Advancechartmodal";


const Advancechart=()=>{
  const [annualmodal, setAnnualmodal] = useState(false);

  const onNewsModalAnnual = () => {
    setAnnualmodal(prevState => !prevState);
  };

    const navigation=useNavigation()
    return(
        <View style={Scriptviewstyle.maincontainer}>
            
            <View style={Scriptviewstyle.headertwo}>
            <View style={Scriptviewstyle.innerheadconatiner}>
              <View style={Scriptviewstyle.innerflexone}>
                <TouchableOpacity onPress={()=>navigation.goBack()}>
                  <Entypo name="cross" size={24} color={'black'} />
                </TouchableOpacity>
                
              </View>
              <View style={Scriptviewstyle.innerflextwo}>
                <TouchableOpacity onPress={()=>navigation.navigate('Screen3')}>

                <MaterialIcons name='search' size={24} color={'grey'} style={{marginRight:15}}/>
                </TouchableOpacity>
                <Ionicons name="phone-landscape-sharp"size={24} color={'black'} style={{marginRight:15}}/>
                <View style={Scriptviewstyle.buysmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Buy</Text>
                </View>
                <View style={Scriptviewstyle.sellsmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Sell</Text>
                </View>
                <TouchableOpacity
                  onPress={() => {
                     setAnnualmodal(true);
                  }}>
                  <Entypo
                    name="dots-three-vertical"
                    color={'black'}
                    size={20}
                  />
                </TouchableOpacity>
               
              </View>
            </View>
          </View>
          <Advancechartmodal
          visible={annualmodal}
          onClose={onNewsModalAnnual}
          
          />
          <WebView
           javaScriptEnabled={true}
           domStorageEnabled={true}
           startInLoadingState={true}
          source={{uri:'https://razorpay.com/integrations/'}}
          style={{ flex: 1}}
          />
        
        </View>
    )
}

export default Advancechart;
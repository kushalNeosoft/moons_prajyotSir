import React, {useState} from 'react';
import {ScrollView} from 'react-native';
import {Touchable} from 'react-native';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import Feather from 'react-native-vector-icons/Feather';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  annualmodaldata,
  fundmodaldata,
  webmodaldata,
} from '../../../../assets/demoData';
import CommonModal from '../../../../components/CommonModal/CommonModal';


import {
  Analysisstyle,
  Companymodalstyle,
  Eventmodaistyle,
} from '../../../../theme/light';


export const Advancechartmodal = (props: any) => {
  const [modalvlue, setModalvalue] = useState(0);

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>

      {webmodaldata.map((item, index) => {
        return (
          <TouchableOpacity
          style={{marginTop:16,}}
            onPress={() => {
                props.onClose()
            
              setModalvalue(index);
              
            }}>
            {modalvlue === index ? (
              <View style={Analysisstyle({}).annualmodalone}>
                <MaterialCommunityIcons name="circle-slice-8" size={20} color={'black'} />
                <Text style={Analysisstyle({}).annualmodaltwo}>{item.title}</Text>
              </View>
            ) : (
              <View style={Analysisstyle({}).annualmodalone}>
                <Feather name="circle" size={20} color={'black'} />
                <Text style={Analysisstyle({}).annualmodaltwo}>{item.title}</Text>
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </CommonModal>
  );
};

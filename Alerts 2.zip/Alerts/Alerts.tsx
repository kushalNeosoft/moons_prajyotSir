import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList, StyleSheet} from 'react-native';
import {
  constituentsListComponent,
  recommendations,
  screenFilter,
} from '../../../theme/light';
import Fontisto from 'react-native-vector-icons/Fontisto';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import alignment from '../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import SearchAlerts from './components/SearchModal';
import Ionicons from 'react-native-vector-icons/Ionicons';

function Alerts(props: any) {
  const [searchModal, setSearchModal] = useState(false);
  const [categoryF, setCategoryF] = useState(props.categoryFilters);
  const [alertF, setAlertF] = useState(props.alertFilters);
  const [filteredData, setFilteredData] = useState<any>();

  const data = [
    {
      symbol: 'TCS',
      exchange: 'NSE',
      time: '10:43 AM',
      date: "20 Jul '23",
      price: '3463.30',
      change: '0.00',
      percentageChange: '0.00',
      range: '3447.00',
      category: 'Equity',
      alert: 'Price',
    },
    {
      symbol: 'RELIANCE',
      exchange: 'NSE',
      time: '10:43 AM',
      date: "20 Jul '23",
      price: '2619.30',
      change: '0.00',
      percentageChange: '0.00',
      range: '2621.00',
      category: 'F&O',
      alert: '52WH',
    },
  ];

  const filterCategory = (data: any) => {
    return [...data].filter(item =>
      item.category.includes(props.categoryFilters),
    );
  };

  const filterAlerts = (data: any) => {
    return [...data].filter(item => item.alert.includes(props.alertFilters));
  };

  useEffect(() => {
    let result = data;
    if (props.alertFilters !== '') {
      result = filterAlerts(result);
    }

    if (props.categoryFilters !== '') {
      result = filterCategory(result);
    }
    setFilteredData(result);
    setAlertF(props.alertFilters);
    setCategoryF(props.categoryFilters);

    console.log('alerts', props.alertFilters, props.categoryFilters);
  }, [props.categoryFilters, props.alertFilters]);

  const navigation = useNavigation();

  const renderAlerts = ({item}: any) => {
    return (
      <View style={alerts.card}>
        <View style={alerts.cardTopView}>
          <View>
            <View style={alerts.symbolView}>
              <Text style={alerts.symbolTxt}>{item.symbol}</Text>
              <Text style={alerts.exchangeTxt}>{item.exchange}</Text>
            </View>
            <Text
              style={alerts.dateTimeTxt}>{`${item.time} ${item.date}`}</Text>
          </View>
          <View style={alerts.cardRightView}>
            <View style={alerts.priceView}>
              <Text style={alerts.priceTxt}>{item.price}</Text>
              <Text
                style={
                  alerts.changeTxt
                }>{`${item.change}(${item.percentageChange})`}</Text>
            </View>
            <TouchableOpacity style={constituentsListComponent.bottonView}>
              <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={alerts.alertView}>
          <FontAwesome name="bell" color={'red'} size={13} />
          <Text
            style={
              alerts.rangeTxt
            }>{`Price has gone below ${item.range}`}</Text>
        </View>
      </View>
    );
  };
  return (
    <View style={alerts.container}>
      <View style={recommendations.header}>
        <TouchableOpacity onPress={() => navigation.navigate('ManageAlerts')}>
          <View style={alerts.header}>
            <Fontisto
              name="bell"
              size={20}
              color={root.client_background}
              style={{paddingRight: 15}}
            />
            <Text style={recommendations.alertsTxt}>Manage Alerts</Text>
            <View style={alerts.bottomCountView}>
              <Text style={alerts.bottomCountText}>{4}</Text>
            </View>
          </View>
        </TouchableOpacity>
        <View style={recommendations.filterSearchContainer}>
          <TouchableOpacity onPress={() => setSearchModal(prev => !prev)}>
            <Fontisto
              name="search"
              size={20}
              color={'black'}
              style={{paddingRight: 25}}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => props.openAlertFilterSheet()}>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
          </TouchableOpacity>
        </View>
      </View>
      {categoryF !== '' || alertF !== '' ? (
        <View style={{...alignment.row_alignC, paddingHorizontal: 16}}>
          <Text style={screenFilter.filterTitle}>Filters:</Text>
          {categoryF !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Category:</Text>
              <Text style={screenFilter.filterTagData}>{categoryF}</Text>
              <TouchableOpacity
                onPress={() => {
                  props.clearCategoryFilter();
                }}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
          {alertF !== '' ? (
            <View style={screenFilter.filterDataView}>
              <Text style={screenFilter.filterTag}>Alerts:</Text>
              <Text style={screenFilter.filterTagData}>{alertF}</Text>
              <TouchableOpacity
                onPress={() => {
                  props.clearAlertFilter();
                }}>
                <Ionicons
                  name="md-close-outline"
                  style={screenFilter.closeIcon}
                />
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      ) : null}
      <FlatList data={filteredData} renderItem={renderAlerts} />
      <SearchAlerts
        visible={searchModal}
        onClose={() => setSearchModal(prev => !prev)}
        data={data}
      />
    </View>
  );
}

const alerts = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
  },
  card: {
    backgroundColor: root.color_active,
    marginHorizontal: 10,
    marginTop: 10,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 8,
    marginBottom: 1,
  },
  cardTopView: {
    ...alignment.row_alingC_SpaceB,
  },
  symbolView: {
    ...alignment.row_alignC,
  },
  symbolTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 16,
    color: root.color_text,
  },
  exchangeTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 10,
    color: root.color_subtext,
    backgroundColor: root.backgroung_exchange_chip_color,
    paddingHorizontal: 3,
    marginLeft: 5,
    textAlign: 'center',
  },
  dateTimeView: {
    ...alignment.row_alignC,
    paddingTop: 10,
  },
  dateTimeTxt: {
    fontFamily: Cfont.rubik_light,
    fontSize: 10,
    color: root.color_text,
    paddingTop: 10,
  },
  cardRightView: {
    ...alignment.row_alignC,
  },
  priceView: {
    paddingRight: 10,
  },
  priceTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 14,
    color: root.color_text,
  },
  changeTxt: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 12,
    color: root.color_text,
    paddingTop: 10,
  },
  alertView: {
    ...alignment.row_alignC,
    paddingTop: 10,
  },
  rangeTxt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: 12,
    paddingLeft: 8,
  },
  bottomCountView: {
    backgroundColor: root.color_negative,
    height: 16,
    width: 20,
    borderRadius: 25,
    marginLeft: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bottomCountText: {
    color: root.color_active,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
});

export default Alerts;

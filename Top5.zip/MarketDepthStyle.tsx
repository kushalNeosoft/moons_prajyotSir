import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
import {Cfont, Font, root} from '../colors';
import DropDownIcon from '../../components/replacement-svg/DropDownIcon';

const height = Dimensions.get('window').height;

export default function MarketDepthStyle() {
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  //Componenets




  const MarketDepthS = StyleSheet.create({

    MainView: {width: 24, height: 24, marginLeft: 'auto',},
    CloseIcon: {width: 24, height: 24, color: root.color_text},
    Stock: {fontSize: 16,fontFamily: Cfont.rubik_medium,
        color: root.color_text},

      EQ: {fontSize: 10,color: root.color_text ,
        fontFamily: Cfont.rubik_regular},

        flex: {flexDirection: 'row',},

        DialogMain: {
            flexDirection: 'row',
            alignItems: 'center',
            backgroundColor: '#F3EEEE',
            paddingVertical: 2,
            paddingHorizontal: 8,
            
          },

          seText: {fontSize: 12, 
            fontFamily: Cfont.rubik_medium},

            DropDownIcon: {height: 18, width: 24, color: root.color_text},

            Price: {
                fontFamily: Cfont.rubik_medium,
                color: root.color_text,
                marginHorizontal: 5,
                fontSize: 14,
                
              },

              Change: {
                fontSize: 10,
                color: root.color_text,
                fontFamily: Cfont.rubik_regular,
                marginHorizontal: 1,
                marginTop: 1
              },
              Percent: {
                fontSize: 10,
                color: root.color_text,
                fontFamily: Cfont.rubik_regular,
                marginHorizontal: 1,
                marginTop: 1
              },

ShowDialogMain: {
                    
    position: 'absolute',
    //bottom: 0,
    marginTop:  50,
    zIndex: 999,
    backgroundColor: root.color_active,
    shadowColor: '#000',
    height: 110,
    width: 80,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
    borderRadius: 4,
  },

  ExcMain: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    backgroundColor: root.color_active,
    zIndex: 999,
  },

  ExcText: {
    marginTop: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },

  TypeMain: {
    zIndex: 0,
    marginTop: 12,
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: root.client_background,
    borderRadius: 4,
  },

  SelectTabMain: {flexDirection: 'row', marginTop: 16, gap: 14 , marginBottom: 0},

  Flex1: {flex: 1,},

  QtyText: {
    textAlign: 'left',
    //fontWeight: 'bold',
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
BidText: {
  textAlign: 'right',
  // fontWeight: 'bold',
  fontFamily: Cfont.rubik_medium,
  color: root.color_text,
},
OrderText: {
  textAlign: 'center',
  //fontWeight: 'bold',
  fontFamily: Cfont.rubik_medium,
  color: root.color_text,
},
Gap: {flexDirection: 'row', marginTop: 4, gap: 16},

QuantityText: {textAlign: 'left', color: root.color_positive,
fontSize: 14, fontFamily: Cfont.rubik_regular,},

OrderText1: {textAlign: 'center', color: root.color_positive,fontSize: 14,
fontFamily: Cfont.rubik_regular},

Bid: {textAlign: 'right', color: root.color_positive,
fontSize: 14, fontFamily: Cfont.rubik_regular},

Ask: {textAlign: 'left', color: root.color_negative,
fontSize: 14, fontFamily: Cfont.rubik_regular},

AskOrder: {textAlign: 'center', color: root.color_negative,
fontSize: 14, fontFamily: Cfont.rubik_regular
},

AskQty: {textAlign: 'right', color: root.color_negative,
fontSize: 14, fontFamily: Cfont.rubik_regular,},


LinerMain: {
  height: 2,
  backgroundColor: 'lightgrey',
  marginVertical: 8,
},

LinerStyle: {flexDirection: 'row', justifyContent: 'space-between'},

TotalBids: {
  fontFamily: Cfont.rubik_medium,
  color: root.color_text,
  fontSize: 12
},

Main1: {marginTop: 10, position: 'relative'},

FlexRow: {flexDirection: 'row', height: 28},

LeftRange: {
  backgroundColor: 'lightblue',
  width: '80%',
  paddingHorizontal: 8,
  paddingVertical: 1,
},

RightRange: {
  backgroundColor: 'lightpink',

  width: '20%',
  paddingHorizontal: 8,
  paddingVertical: 1,
},

PrinceRangeMain: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  position: 'absolute',
  height: 28,
  width: '100%',
  alignItems: 'center',
  paddingHorizontal: 8,
},

LeftPrice: {color: root.client_background,
  fontSize: 14, fontFamily: Cfont.rubik_light,},

  RightPrice: {textAlign: 'right', color: root.color_negative,
  fontSize: 14, fontFamily: Cfont.rubik_light},

  BottomText: {marginTop: 16, fontSize: 12, textAlign: 'center',
  fontFamily: Cfont.rubik_light,},


  Margin: {marginTop: 16},

flexRow: {flexDirection: 'row'},

OpenText: {
  color: root.color_text,
  fontFamily: Cfont.rubik_medium,
  fontSize: 12,
},

OpenKey: {
  color: root.color_text,
  fontFamily: Cfont.rubik_regular,
  fontSize: 12,
},

LinerHead: {
  height: 1,
  backgroundColor: 'lightgrey',
  marginVertical: 6,
  
},

Gap1: {flexDirection: 'row', gap: 32},

LowMain: {
  width: 4,
  height: 16,
  backgroundColor: 'grey',
  position: 'absolute',
  marginTop: 4,
  right: 16,
},

KeyMain: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginTop: 8,
},

LowHigh: {
  color: root.color_text,
  fontFamily: Cfont.rubik_medium,
  textAlign: 'right',
  fontSize: 12,
},


LinearGradient: {height: 8, marginTop: 8, borderRadius: 2},

View3: {
  width: 4,
  height: 16,
  backgroundColor: 'grey',
  position: 'absolute',
  marginTop: 21,
  right: 16,
},

View4: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginTop: 8,
},

View5: {
  height: 1,
  backgroundColor: 'lightgrey',
  marginVertical: 6,
},

View6: {
  height: 1,
  backgroundColor: 'lightgrey',
  marginVertical: 6,
},

View8: {
  height: 1,
  backgroundColor: 'lightgrey',
  marginVertical: 6,
},

MarketCap: {
  color: root.color_text,
  fontFamily: Cfont.rubik_medium,
  fontSize: 12,
},

flex3: {flex: 3},


SupportText: {textAlign: 'center',
fontFamily: Cfont.rubik_medium,
color: root.color_text , fontSize: 12},

flex2: {flex: 2},

flexMargin: {flexDirection: 'row', marginTop: 8},

KeyMain1: {
  paddingVertical: 8,
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
},

Keyr: {
  fontFamily: Cfont.rubik_medium,
color: root.color_text , fontSize: 12
},



Valuer: {color: root.color_positive, 
  fontFamily: Cfont.rubik_medium,fontSize: 14},


  View9: 
  {
    width: 2,
    marginHorizontal: 8,
    backgroundColor: 'lightgrey',
  },

  PivotMain: {
    flex: 2,
    flexDirection: 'column',
    justifyContent: 'center',
  },

  PivotTxt: {textAlign: 'center', color: root.color_text,
  fontFamily: Cfont.rubik_medium,
 fontSize: 14},

 Pivot1: {textAlign: 'center', color: root.color_text,
 fontFamily: Cfont.rubik_medium,
fontSize: 14},

View10: {
  width: 2,
  marginHorizontal: 8,
  backgroundColor: 'lightgrey',
},

Key2: {
  paddingVertical: 8,
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
},

Key3: {
  fontFamily: Cfont.rubik_medium,
color: root.color_text , fontSize: 12
},

Value2: {color: root.color_negative, 
  fontFamily: Cfont.rubik_medium,fontSize: 14}

  });





  return {
    MarketDepthS
    
  };
}

import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableNativeFeedback,
  TouchableHighlight,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import DropDownIcon from '../../../assets/DropDownIcon';
import LinearGradient from 'react-native-linear-gradient';
import CloseIcon from '../../../assets/CloseIcon';
import FontSize from '../../../styles/Common/FontSize';
import ModalOne from '../../../components/CommonModal/ModalOne';
import MarketDepthStyle from '../../../styles/Views/MarketDepthStyle';

const TYPES = ['Market Depth', 'Key Stats', 'Pivot Points'];

const marketDepth = [
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
  {
    quantity: 100,
    orders: 2,
    bid: 215.0,
    ask: 200,
    askOrders: 1,
    askQuantity: 199,
  },
];
const keyStats = {
  open: '-',
  close: '216.00',
  dailyPriceRange: '172- 2459',
  today: {
    high: '-',
    low: '-',
  },
  week52: {
    high: '1000',
    low: '200',
  },
  atp: 0.0,
  value: 0,
  volume: '-',
  ltq: 5,
  ltt: '13.12.2',
  lut: '15.23.1',
  marketCap: '4 crores',
};
const pivot = {
  pivot: 216,
  support: [
    {key: 'S1', value: '100'},
    {key: 'S2', value: '100'},
    {key: 'S3', value: '100'},
    {key: 'S4', value: '100'},
  ],
  resistance: [
    {key: 'R1', value: '100'},
    {key: 'R2', value: '100'},
    {key: 'R3', value: '100'},
    {key: 'R4', value: '100'},
  ],
};
const exchanges = ['NSE', 'BSE', 'NSECDS'];
const MarketDepthDialog = (props: any) => {
  const [selectedType, setSelectedType] = useState<string>('Market Depth');
  const [se, setSe] = useState('NSE');
  const [showSeDialog, setShowSeDialog] = useState(false);

  const {MarketDepthS} = MarketDepthStyle();
  return (
    <ModalOne visible={props.visible} onClose={props.onClose}>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
        onPress={() => {
          props.onClose();
        }}>
        <View style={MarketDepthS.MainView}>
          <CloseIcon style={MarketDepthS.CloseIcon} />
        </View>
      </TouchableNativeFeedback>
      <View style={{width: '100%'}}>
        <View>
          <Text
            style={MarketDepthS.Stock}>
            ICICI Bank{' '}
            <Text style={MarketDepthS.EQ}>EQ</Text>
          </Text>
          <View style={MarketDepthS.flex}>
          <View style={{zIndex: 999}}>
              <TouchableOpacity
                onPress={() => {
                  setShowSeDialog(true);
                }}>
                <View
                  style={MarketDepthS.DialogMain}>
                  <Text style={MarketDepthS.seText}>{se}</Text>
                  <DropDownIcon
                    style={MarketDepthS.DropDownIcon}
                  />
                </View>
              </TouchableOpacity>
            </View>
            <Text
              style={MarketDepthS.Price}>
              2123.9
              </Text>
              <Text
                style={MarketDepthS.Change}>
                123
              </Text>
              <Text
                style={MarketDepthS.Change}>
                (00.00)
              </Text>
            
          </View>
        </View>
        {showSeDialog && (
                <View
                  style={MarketDepthS.ShowDialogMain}>
                 
                 {exchanges.map(exchange => {
                    return (
                      <TouchableOpacity
                        key={exchange}
                        onPress={() => {
                          setSe(exchange);
                          setShowSeDialog(false);
                          // setSelectedExchange(exchange);
                          // setShowSelectExchange(false);
                        }}>
                        <View
                          key={exchange}
                          style={MarketDepthS.ExcMain}>
                          <Text
                            style={MarketDepthS.ExcText}>
                            {exchange}
                          </Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
        <View
          style={MarketDepthS.TypeMain}>
          {TYPES.map((type, index) => {
            return (
              <TouchableOpacity
                style={MarketDepthS.Flex1}
                key={index}
                onPress={() => {
                  setSelectedType(type);
                }}>
                <View
                  style={{
                    paddingVertical: 8,
                    backgroundColor:
                      selectedType == type
                        ? root.client_background
                        : 'transparent',
                  }}>
                  <Text
                    style={{
                      textAlign: 'center',
                      fontFamily: Cfont.rubik_medium,
                      color:
                        selectedType == type
                          ? root.color_active
                          : root.client_background,
                     
                    }}>
                    {type}
                  </Text>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {selectedType === 'Market Depth' && (
          <>
            <View>
              <View style={MarketDepthS.SelectTabMain}>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.QtyText}>
                    Qty
                  </Text>
                </View>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.QtyText}>
                    Orders
                  </Text>
                </View>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.BidText}>
                    Bid
                  </Text>
                </View>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.QtyText}>
                    Ask
                  </Text>
                </View>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.OrderText}>
                    Orders
                  </Text>
                </View>
                <View style={MarketDepthS.Flex1}>
                  <Text
                    style={MarketDepthS.BidText}>
                    Qty
                  </Text>
                </View>
              </View>
              {marketDepth.map((md, index) => {
                return (
                  <View
                    style={MarketDepthS.Gap}
                    key={index}>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.QuantityText}>
                        {md.quantity}
                      </Text>
                    </View>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.OrderText1}>
                        {md.orders}
                      </Text>
                    </View>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.Bid}>
                        {md.bid}
                      </Text>
                    </View>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.Ask}>
                        {md.ask}
                      </Text>
                    </View>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.AskOrder}>
                        {md.askOrders}
                      </Text>
                    </View>
                    <View style={MarketDepthS.Flex1}>
                      <Text style={MarketDepthS.AskQty}>
                        {md.askQuantity}
                      </Text>
                    </View>
                  </View>
                );
              })}
            </View>

            <View
              style={MarketDepthS.LinerMain}
            />
            <View>
              <View
                style={MarketDepthS.LinerStyle}>
                <Text
                  style={MarketDepthS.TotalBids}>
                  Total Bids
                </Text>
                <Text
                  style={MarketDepthS.TotalBids}>
                  Total Ask
                </Text>
              </View>
              <View style={MarketDepthS.Main1}>
                <View style={MarketDepthS.FlexRow}>
                  <View
                    style={MarketDepthS.LeftRange}>

                    </View>
                  <View
                    style={MarketDepthS.RightRange}></View>
                </View>
                <View
                  style={MarketDepthS.PrinceRangeMain}>
                  <Text style={MarketDepthS.LeftPrice}>1200 -(50%)</Text>
                  <Text style={MarketDepthS.RightPrice}>1299(-50)</Text>
                </View>
              </View>

              <Text style={MarketDepthS.BottomText}>
                Select Your Limit Price By Clicking The Bid/Ask Amount
              </Text>
            </View>
          </>
        )}

        {selectedType === 'Key Stats' && (
          <View style={MarketDepthS.Margin}>
            <View style={MarketDepthS.flexRow}>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Open
                </Text>
                <Text
                  style={MarketDepthS.OpenKey}>
                  {keyStats.open}
                </Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Close
                </Text>
                <Text
                  style={MarketDepthS.OpenKey}>
                  {keyStats.close}
                </Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Daily Price Range
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.dailyPriceRange}</Text>
              </View>
            </View>
            <View
              style={MarketDepthS.LinerHead}
            />
            <View style={MarketDepthS.Gap1}>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Today's (Low High)
                </Text>

                <View style={{position: 'relative'}}>
                  <LinearGradient
                    start={{x: 0, y: 0}}
                    end={{x: 1, y: 0}}
                    colors={['red', 'orange', 'lightgreen']}
                    style={{height: 8, marginTop: 8, borderRadius: 2}}
                  />
                  <View
                    style={MarketDepthS.LowMain}
                  />
                </View>
                <View
                  style={MarketDepthS.KeyMain}>
                  <Text style={MarketDepthS.OpenKey}>{keyStats.today.low}</Text>
                  <Text style={MarketDepthS.OpenKey}>{keyStats.today.high}</Text>
                </View>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.LowHigh}>
                  52 Week (Low High)
                </Text>
                <LinearGradient
                  start={{x: 0, y: 0}}
                  end={{x: 1, y: 0}}
                  colors={['red', 'orange', 'lightgreen']}
                  style={MarketDepthS.LinearGradient}
                />
                <View
                    style={MarketDepthS.View3}
                  />
                <View
                  style={MarketDepthS.View4}>
                  <Text style={MarketDepthS.OpenKey}>{keyStats.week52.low}</Text>
                  <Text style={MarketDepthS.OpenKey}>{keyStats.week52.high}</Text>
                </View>
              </View>
            </View>
            <View
              style={MarketDepthS.View5}
            />
            <View style={MarketDepthS.flexRow}>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  ATP
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.atp}</Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Value
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.value}</Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  Volume
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.volume}</Text>
              </View>
            </View>
            <View
              style={MarketDepthS.View6}
            />
            <View style={MarketDepthS.flexRow}>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  LTQ
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.ltq}</Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  LTT
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.ltt}</Text>
              </View>
              <View style={MarketDepthS.Flex1}>
                <Text
                  style={MarketDepthS.OpenText }>
                  LUT
                </Text>
                <Text style={MarketDepthS.OpenKey}>{keyStats.lut}</Text>
              </View>
            </View>
            <View
              style={MarketDepthS.View8}
            />
            <View style={{}}>
              <Text
                style={MarketDepthS.MarketCap}>
                Market Cap
              </Text>
              <Text style={MarketDepthS.OpenKey}>{keyStats.marketCap}</Text>
            </View>
          </View>
        )}

        {selectedType === 'Pivot Points' && (
          <View style={{marginTop: 16}}>
            <View style={MarketDepthS.flexRow}>
              <View style={MarketDepthS.flex3}>
                <Text style={MarketDepthS.SupportText}>Support</Text>
              </View>
              <View style={MarketDepthS.flex2}></View>
              <View style={MarketDepthS.flex3}>
                <Text style={MarketDepthS.SupportText}>Resistance</Text>
              </View>
            </View>
            <View style={MarketDepthS.flexMargin}>
              <View style={MarketDepthS.flex3}>
                {pivot.support.map((r, index) => {
                  return (
                    <View
                      key={index}
                      style={MarketDepthS.KeyMain1}>
                      <Text
                        style={MarketDepthS.Keyr}>
                        {r.key}
                      </Text>
                      <Text style={MarketDepthS.Valuer}>{r.value}</Text>
                    </View>
                  );
                })}
              </View>
              <View
                style={MarketDepthS.View9}
              />
              <View
                style={MarketDepthS.PivotMain}>
                <Text style={MarketDepthS.PivotTxt}>
                  Pivot
                </Text>
                <Text style={MarketDepthS.Pivot1}>
                  {pivot.pivot}
                </Text>
              </View>
              <View
                style={MarketDepthS.View10}
              />
              <View style={MarketDepthS.flex3}>
                {pivot.resistance.map((r, index) => {
                  return (
                    <View
                      key={index}
                      style={MarketDepthS.Key2}>
                      <Text
                        style={MarketDepthS.Key3}>
                        {r.key}
                      </Text>
                      <Text style={MarketDepthS.Value2}>{r.value}</Text>
                    </View>
                  );
                })}
              </View>
            </View>
          </View>
        )}
      </View>
    </ModalOne>
  );
};
export default MarketDepthDialog;

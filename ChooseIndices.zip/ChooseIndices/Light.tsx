//Choose Indices Serach Modal styles

export const chooseIndicesSearch = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: 300,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: root.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    marginHorizontal: 13,
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  micIcon: {
    marginHorizontal: 13,
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
  },
  textInput: {
    flex: 1,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

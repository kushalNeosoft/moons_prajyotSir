
// import add this useState in ChooseIndicesModal.tsx
  import SearchModal from './SearchModal';
  const [searchModalVisible, setSearchModalVisible] = useState<boolean>(false);

// add this serach modal in last
  <SearchModal
  modalVisible={searchModalVisible}
  setModalVisible={setSearchModalVisible}
/>

// Add this Onpree on serach Icon Touchable for opening Search modal
onPress={() => {
  setSearchModalVisible(true);
}}

  
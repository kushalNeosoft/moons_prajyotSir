// Add this inside ChooseIndices Component

import React, { useState } from "react";
import { TouchableOpacity } from "react-native";
import { View, Text, Modal, Dimensions } from "react-native";
import AntIcon from "react-native-vector-icons/AntDesign";
import MaterialCommunityIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { TextInput } from "react-native";
import { chooseIndicesSearch } from "../../../theme/light";
const SearchModal = ({ modalVisible, setModalVisible }) => {
  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={chooseIndicesSearch.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}
    >
      <View>
        <View style={chooseIndicesSearch.headerView}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(false);
            }}
          >
            <AntIcon name="close" style={chooseIndicesSearch.crossIcon} />
          </TouchableOpacity>
          <TextInput
            style={chooseIndicesSearch.textInput}
            placeholder="Search eg: Nifty 50"
            placeholderTextColor={"grey"}
          />
          <TouchableOpacity onPress={() => {}}>
            <MaterialCommunityIcons
              name="microphone"
              style={chooseIndicesSearch.micIcon}
            />
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default SearchModal;

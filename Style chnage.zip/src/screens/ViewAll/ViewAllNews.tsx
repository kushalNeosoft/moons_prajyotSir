import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
const ViewAllNews = props => {
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginTop: 12,
            alignItems: 'center',
          }}>
          <TouchableOpacity
            onPress={() => {
              props.navigation.goBack();
            }}
            style={styles.backBotton}>
            <AntDesign name="arrowleft" size={26} color="black" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.searchBotton}>
            <MaterialIcons name="search" size={26} color={'black'} style={{}} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default ViewAllNews;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
  },
  header: {
    width: '100%',
    height: 50,
    backgroundColor: 'white',
  },
  searchBotton: {
    marginRight: 20,
  },
  backBotton: {
    marginHorizontal: 17,
  },
});

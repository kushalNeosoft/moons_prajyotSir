import React from "react";
import { View,Text } from "react-native";

const Screen3=()=>{
    return(
       <View>
        <Text style={{fontSize:50,backgroundColor:"yellow"}}>
            New Screen Log
        </Text>
       </View>
    )
}
export default Screen3;
import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { SortModal } from '../../../../Theme/Light';
// import {Cfont, Font, root} from '../../styles/colors';
// import {styles} from '../Component/BottomSheet/BottomSheetStyle';
// import CustomHeader from '../Component/Header/CustomHeader';

const Filtercom = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [percentageValue, setPercentageValue] = useState('');
  const [typeValue, setTypeValue] = useState('');
  const [priceValue, setPriceValue] = useState('');
  const [exValue, setExValue] = useState('');

  //   const dispatch = useDispatch();
  //   const navigation=useNavigation();
  const navigation = useNavigation();
  const navtoback = () => {
    navigation.goBack();
  };

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['High to Low', 'Low to High'];
  const type = ['Equity', 'Equity F&O'];
  const percentage = ['High to Low', 'Low to High'];
  const Exchnages = ['BSE', 'NSE'];
  return (
    <View style={SortModal.Maincon}>
      <View style={SortModal.space}>
        <View style={SortModal.spaceinner}>
          <Text style={SortModal.titleText}>Alphabetically</Text>
        </View>

        <FlatList
          horizontal={true}
          data={alphabet}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setAlphabetValue(item)}
              style={
                alphabetValue === item
                  ? SortModal.commonHtZSelected
                  : SortModal.commonHtZUnSelected
              }>
              <Text style={SortModal.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={SortModal.spacetwo}>
        <View style={SortModal.spacetwoinner}>
          <Text style={SortModal.titleText}>Price</Text>
        </View>

        <FlatList
          horizontal={true}
          data={price}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setPriceValue(item)}
              style={
                priceValue === item
                  ? SortModal.commonHtLSelected
                  : SortModal.commonHtLUnSelected
              }>
              <Text style={SortModal.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={SortModal.spacetwo}>
        <View style={SortModal.spacetwoinner}>
          <Text style={SortModal.titleText}>Percentage</Text>
        </View>

        <FlatList
          horizontal={true}
          data={percentage}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setPercentageValue(item)}
              style={
                percentageValue === item
                  ? SortModal.commonHtLSelected
                  : SortModal.commonHtLUnSelected
              }>
              <Text style={SortModal.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={SortModal.space}>
        <View style={SortModal.spaceinner}>
          <Text style={SortModal.titleText}>Type</Text>
        </View>

        <FlatList
          data={type}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setTypeValue(item)}
              style={
                typeValue === item
                  ? SortModal.commonHtZSelected
                  : SortModal.commonHtZUnSelected
              }>
              <Text style={SortModal.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
      <View style={SortModal.space}>
        <View style={SortModal.spaceinner}>
          <Text style={SortModal.titleText}>Exchnages</Text>
        </View>

        <FlatList
          data={Exchnages}
          horizontal={true}
          renderItem={({item}) => (
            <TouchableOpacity
              onPress={() => setExValue(item)}
              style={
                exValue === item
                  ? SortModal.commonHtZSelected
                  : SortModal.commonHtZUnSelected
              }>
              <Text style={SortModal.text}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );
};
export default Filtercom;

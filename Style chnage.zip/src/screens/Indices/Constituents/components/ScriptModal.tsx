import React, {useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import {Font, root} from '../../../../styles/colors';
import alignment from '../../../../components/utils/alignment';
import {RadioButton} from 'react-native-paper';
import Entypo from 'react-native-vector-icons/Entypo';
import {Cfont} from '../../../../styles/colors';

function ScriptModal(props: any) {
  const [checked, setChecked] = useState(false);
  const data = [
    'BSE',
    'TEST11',
    'MISSSCRIP',
    'TEST',
    'SUMTG',
    'GLOBAL',
    'NEWLISTED',
    'COMMODITY',
    'PRE-SALES',
  ];

  const renderItem = ({item}: any) => {
    return (
      <View style={styles.itemContainer}>
        <RadioButton
          color={root.color_text}
          value={item}
          onPress={() => setChecked(item)}
          status={checked == item ? 'checked' : 'unchecked'}
        />
        <Text style={styles.watchlistNameTxt}>{item}</Text>
      </View>
    );
  };

  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={styles.container}>
        <View style={styles.innerContainer}>
          <View style={styles.titleTxtContainer}>
            <Text style={styles.select_watchList_Txt}>Select</Text>
            <Text style={styles.select_watchList_Txt}>WatchList</Text>
          </View>

          <View style={styles.listViewContainer}>
            <FlatList data={data} renderItem={renderItem} />
          </View>

          <View style={styles.createWatchListContainer}>
            <Entypo name="plus" size={25} color={root.client_background} />
            <Text style={styles.createWatchListTxt}>
              Create WatchList(9/10)
            </Text>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '30%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  select_watchList_Txt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  watchlistNameTxt: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
    paddingHorizontal: 10,
  },
  innerContainer: {
    height: '100%',
    paddingHorizontal: 10,
    paddingVertical: 16,
  },
  titleTxtContainer: {
    marginLeft: 6,
  },
  listViewContainer: {
    marginTop: '12%',
    height: '65%',
  },
  createWatchListContainer: {
    paddingLeft: 5,
    ...alignment.row,
    alignItems: 'center',
  },
  createWatchListTxt: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
    marginLeft: 10,
  },
  itemContainer: {
    ...alignment.row_alignC,
    marginVertical: '2%',
  },
});

export default ScriptModal;

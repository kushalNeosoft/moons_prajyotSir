import React from 'react';
import {View, Text, Dimensions, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {constituentsBoxComponent} from '../../../../../Theme/Light';

const ConstituentsBoxList = props => {
  const num = 1400;
  return (
    <TouchableOpacity
      style={{paddingTop: 0, marginHorizontal: 5}}
      activeOpacity={1}
      onPress={async () => {}}>
      <View
        style={[
          constituentsBoxComponent.container,
          {backgroundColor: props.colors},
        ]}>
        <View>
          <Text
            style={constituentsBoxComponent.companyName}>
            {props.companyName}
          </Text>
          <MaterialCommunityIcons
            name="crown-circle"
            size={22}
            color="white"
            style={{marginVertical: 5}}
          />
          <Text
            style={constituentsBoxComponent.price}>
            {props.price}
          </Text>
          <Text
            style={constituentsBoxComponent.changes}>
            {props.changes.replace(props.changes[0], '+')}
          </Text>
        </View>
        <View>
          <TouchableOpacity>
            <View
              style={constituentsBoxComponent.T_container}>
              <Text style={constituentsBoxComponent.T_text}>
                T
              </Text>
            </View>
          </TouchableOpacity>
          <AntDesign
            name="pluscircleo"
            size={29}
            color="#ffffff"
            style={{marginTop: 15}}
          />
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default ConstituentsBoxList;

import React from 'react';
import {View, Modal, TouchableOpacity, StyleSheet} from 'react-native';
import { callPutCommonModal } from '../../../../../Theme/Light';

function Common(props: any) {
  return (
    <Modal
      onRequestClose={() => props.onClose()}
      transparent={true}
      visible={props.visible}>
      <TouchableOpacity
        style={callPutCommonModal.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={callPutCommonModal.container}>{props.children}</View>
    </Modal>
  );
}

const styles = StyleSheet.create({

});

export default Common;

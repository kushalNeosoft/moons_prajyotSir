import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import Common from '../CallPutCommonModal/Common';
import {putModal} from '../../../../../Theme/Light';

function PutModal(props: any) {
  const leftData = [
    {
      name: 'LTP',
      value: '0.0',
    },
    {
      name: 'LTP (%)',
      value: '0.0',
    },
    {
      name: 'OI',
      value: '0.0',
    },
    {
      name: 'OI (%)',
      value: '0.0',
    },
    {
      name: 'IV',
      value: 0,
    },
  ];

  const rightData = [
    {
      name: 'Delta',
      value: 0,
    },
    {
      name: 'Gamma',
      value: '-',
    },
    {
      name: 'Theta',
      value: 0,
    },
    {
      name: 'Vega',
      value: 0,
    },
    {
      name: 'Rho',
      value: 0,
    },
  ];

  const renderLeftData = ({item}: any) => {
    return (
      <View style={putModal.nameValueContainer}>
        <Text style={putModal.txt}>{item.name}</Text>
        <Text style={putModal.txt}>{item.value}</Text>
      </View>
    );
  };

  const renderRightData = ({item}: any) => {
    return (
      <View style={putModal.nameValueContainer}>
        <Text style={putModal.txt}>{item.name}</Text>
        <Text style={putModal.txt}>{item.value}</Text>
      </View>
    );
  };
  return (
    <Common onClose={props.onClose} visible={props.visible}>
      <View style={putModal.topTxtContainer}>
        <Text style={putModal.callValue}>Nifty 13590</Text>
        <Text style={putModal.callTxt}>Put</Text>
      </View>
      <View style={putModal.horizontalLine} />
      <View style={putModal.dataContainer}>
        <View style={putModal.singleDataContainer}>
          <FlatList data={leftData} renderItem={renderLeftData} />
        </View>
        <View style={putModal.singleDataContainer}>
          <FlatList data={rightData} renderItem={renderRightData} />
        </View>
      </View>
      <View style={putModal.btnContainer}>
        <View style={putModal.buyBtn}>
          <Text style={putModal.btnTxt}>Buy</Text>
        </View>
        <TouchableOpacity style={putModal.sellBtn}>
          <Text style={putModal.btnTxt}>Sell</Text>
        </TouchableOpacity>
      </View>
    </Common>
  );
}

const styles = StyleSheet.create({});

export default PutModal;

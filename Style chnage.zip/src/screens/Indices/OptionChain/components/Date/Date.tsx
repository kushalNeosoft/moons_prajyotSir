import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import { dateComponent } from '../../../../../Theme/Light';

function Date(props: any) {
  return (
    <View style={dateComponent.container}>
      <TouchableOpacity
        onPress={() => props.onPress(props.date)}
        style={
          props.date === props.selectedDate
            ? dateComponent.dateContainerSelected
            : dateComponent.dateContainerUnselected
        }>
        <Text
          style={
            props.date === props.selectedDate
              ? dateComponent.dateTxtSelected
              : dateComponent.dateTxtUnselected
          }>
          {props.date}
        </Text>
        <View style={dateComponent.monthYearContainer}>
          <Text
            style={
              props.date === props.selectedDate
                ? dateComponent.monthTxtSelected
                : dateComponent.monthTxtUnselected
            }>
            {props.month}
          </Text>
          <Text
            style={
              props.date === props.selectedDate
                ? dateComponent.yearTxtSelected
                : dateComponent.yearTxtUnselected
            }>
            {props.year}
          </Text>
        </View>
      </TouchableOpacity>
     </View>
  );
}

export default Date;

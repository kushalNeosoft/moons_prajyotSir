import {Text, TextInput, TouchableNativeFeedback, View} from 'react-native';
import VisibilityIcon from '../../../assets/VisibilityIcon';
import VisibilityOffIcon from '../../../assets/VisibilityOffIcon';
import React, {useRef, useState} from 'react';
import {createPasswordStyles} from '../styles/password.styles';
import useStyles from '../../../styles/useStyles';
//import React from 'react';
import { Cfont, Font, root } from '../../../styles/colors';
import DropDownIcon from '../../../assets/DropDownIcon';
import CommonModal from '../../../components/CommonModal/CommonModal';
import WatchlistDialog from './WatchlistDialog';
import { useNavigation } from '@react-navigation/native';
import { t } from 'i18next';
import { PasswordStyles } from '../../../Theme/Light';

const PasswordComponent = ({props}) => {
  const [password, setPassword] = useState<string>(); 
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const {colors, styles} = useStyles(createPasswordStyles);
  const [watchModalVisible, setWatchModalVisible] = useState(false);
  const [deleteModal, setDeleteModal] = useState(false);
  const navigation=useNavigation();
  const onNorClose = () => {
    setWatchModalVisible(prevState => !prevState);
  };
  const showDeleteModal = () => {
    setDeleteModal(prevState => !prevState);
  };
  return (
    <View>
      
      <View style={[PasswordStyles.inputContainer, {marginTop: 16}]}>

        <TextInput
          style={PasswordStyles.input}
          placeholder='Password'
          placeholderTextColor={'gray'}
          secureTextEntry={!showPassword}
          onChangeText={text => {
            setPassword(text);
          }}
          //placeholderTextColor={'lightgrey'}
        />
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('grey', true)}
          onPress={() => {
            // onLogin();
            console.log('Here');
            setShowPassword(prev => !prev);
          }}>
          <View>
            {showPassword ? (
              <VisibilityIcon style={[PasswordStyles.inputIcon, {flex: 1}]} />
            ) : (
              <VisibilityOffIcon style={[PasswordStyles.inputIcon, {flex: 1}]} />
            )}
          </View>
        </TouchableNativeFeedback>
      </View>
      <View
        style={{
          borderRadius: 8,
          marginTop: 32,
        }}>
        <TouchableNativeFeedback
        disabled={!password}
          // background={TouchableNativeFeedback.Ripple('blue', true)}
          onPress={() => {
            // onLogin();
            // i18next.changeLanguage('hin');
          }}>
          <View
            style={[
              PasswordStyles.buttonContainer,
              // {
              //   backgroundColor: password ? root.client_background : 'lightblue',
              // },
            ]}>
            <Text style={[PasswordStyles.buttonText,{
                    color:
                         password
                          ? root.color_active
                          : root.color_disable,
                        opacity: password
                        ? 1
                        : 0.3,
                  }]}>Verify</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
      <View
        style={{
          marginTop: 32,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <Text style={[PasswordStyles.takeme]}>Take Me To </Text>


          <View
            style={{
              borderRadius: 16,
            }}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('gray', true)}
              onPress={() => setWatchModalVisible(true)}
              >
              <View
                style={{
                  flexDirection: 'row',

                  paddingLeft: 12,
                  paddingRight: 6,
                }}>
              <Text
                  style={[PasswordStyles.watchList]}>
                  Watchlist
                </Text>
                <DropDownIcon
                  style={[PasswordStyles.dropdownIcon]}
                />
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <View
          style={{
            borderRadius: 16,
          }}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              navigation.navigate('ForgotPasswordScreen');
              // i18next.changeLanguage('en');
            }}
            // disabled={socketStatus === SocketStatus.CONNECTED}
          >
            <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
            <Text style={[PasswordStyles.forgotPassword]}>
                Forgot Password?
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <WatchlistDialog
        visible={watchModalVisible}
        onClose={onNorClose}
        
        />
    </View>
  );
};
export default PasswordComponent;

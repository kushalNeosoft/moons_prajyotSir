import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import HoldingList from './component/HoldingList';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {holdingScreen} from '../../../Theme/Light';

const Holdings = ({setScrollValue}) => {
  const [stockData, setStockData] = useState([]);
  const [handleRefresh, setHandleRefresh] = useState(false);
  useEffect(() => {
    pushStockData();
  }, []);
  const pushStockData = () => {
    setHandleRefresh(true);
    let StockArraydata = [];
    for (let i = 0; i < 5; i++) {
      StockArraydata.push({
        companyName: 'ABB',
        title: '1000 @ Avg. 1,300.00',
        index: 'NSE',
        value: 1035.78 + Math.floor(Math.random() * 999),
        changes: '+3.65(+0.44%)',
      });
    }
    setStockData(StockArraydata);

    setHandleRefresh(false);
  };
  const renderItem = ({item}) => {
    return (
      <HoldingList
        stockName={item.companyName}
        stockTtile={item.title}
        price={item.value}
        changes={item.changes}
      />
    );
  };

  return (
    <View style={holdingScreen.container}>
      <View style={holdingScreen.header}>
        <Text style={holdingScreen.headerScripsText}>
          {stockData.length} Scrips
        </Text>
        <View style={holdingScreen.headerIconsView}>
          <TouchableOpacity onPress={() => {}}>
            <Ionicons
              name="information-circle-outline"
              size={18}
              color="black"
              style={holdingScreen.headerInfoIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => {}}>
            <Ionicons
              name="search-sharp"
              size={22}
              color="black"
              style={holdingScreen.headerSearchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons
              name="options-outline"
              size={22}
              color="black"
              style={holdingScreen.headerFilterIcon}
            />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        data={stockData}
        renderItem={renderItem}
        keyExtractor={(_, index) => `item-${index}`}
        refreshing={handleRefresh}
        onRefresh={() => {
          pushStockData();
        }}
        onScroll={evt => {
          if (evt?.nativeEvent?.contentOffset.y == 0) {
            setScrollValue(0);
          } else {
            if (evt?.nativeEvent?.contentOffset.y > 100) {
              setScrollValue(1);
            }
          }
        }}
        // renderScrollComponent={props => (
        //   <ScrollView
        //     {...props}
        //     onScroll={evt => {
        //       // console.log(
        //       //   'VALUES>>>>>>>',
        //       //   evt,
        //       //   evt?.nativeEvent?.contentOffset,
        //       // );

        //       if (evt?.nativeEvent?.contentOffset.y == 0) {
        //         setScrollValue(0);
        //       } else {
        //         if (evt?.nativeEvent?.contentOffset.y > 100) {
        //           setScrollValue(1);
        //         }
        //       }
        //     }}
        //   />
        // )}
        onEndReachedThreshold={0.3}
        ListFooterComponent={
          <View style={holdingScreen.holdingFlatlistFooter}></View>
        }
        contentContainerStyle={{}}
      />
    </View>
  );
};
export default Holdings;

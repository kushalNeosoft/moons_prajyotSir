import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {holdingListComp} from '../../../../Theme/Light';

const HoldingList = props => {
  return (
    <View style={holdingListComp.container}>
      <View>
        <Text style={holdingListComp.listTitle}>{props.stockName}</Text>
        <Text style={holdingListComp.listSubTitle}>{props.stockTtile}</Text>
      </View>
      <View style={holdingListComp.listPlLtpView}>
        <View style={{flexDirection: 'row'}}>
          <Text style={holdingListComp.listPlText}>P/L : </Text>
          <Text style={holdingListComp.listPlValue}>19,30,250.00(148.48%)</Text>
        </View>
        <View style={{flexDirection: 'row'}}>
          <Text style={holdingListComp.listLtpText}>LTP : </Text>
          <Text style={holdingListComp.listLtpValue}>3,230.25(+0.83%)</Text>
        </View>
      </View>
    </View>
  );
};
export default HoldingList;

import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {View, Text, StyleSheet, ScrollView, Animated} from 'react-native';
import AnimatedTopBar from '../../navigators/PortfolioTopBar/AnimatedTopBar';
import Ionicons from 'react-native-vector-icons/Ionicons';
import PortfolioHeader from './PortfolioScreenHeaders/PortfolioHeader';
import NiftyAndSensexHeader from './PortfolioScreenHeaders/NiftyAndSensexHeader';
import {portFolioScreen} from '../../Theme/Light';

const Portfolio = () => {
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));

  // This useEffect is calling for FadeIn and fadeOut effect
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [135, 60],
    extrapolate: 'clamp',
  });

  return (
    <View style={portFolioScreen.portFolioContainer}>
      <Animated.View style={[portFolioScreen.animatedView, {height: height}]}>
        {scrollValue == 1 ? (
          <PortfolioHeader
            scrollValue={scrollValue}
            price={'1,70,81,763.00'}
            changes={'1,65,74,858(97.28%)'}
          />
        ) : (
          <NiftyAndSensexHeader
            scrollValue={scrollValue}
            currentVal={'18,73,38,879.00'}
            investedVal={'18,73,38,879.00'}
            overallPL={'83,73,60.00(98.36%)'}
            todaysPL={'83,73,60.00(98.36%)'}
          />
        )}
      </Animated.View>
      <AnimatedTopBar setScrollValue={setScrollValue} />
    </View>
  );
};

export default Portfolio;

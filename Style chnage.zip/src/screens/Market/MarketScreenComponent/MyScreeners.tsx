import React from 'react';
import {View, Text, TouchableOpacity, FlatList, ScrollView} from 'react-native';
import {screenersData} from './SampleData';
import MyScreenersComponent from '../Component/MyScreenersComponent';
import {marketScreen} from '../../../Theme/Light';
const MyScreeners = () => {
  const renderScreenersItem = ({item}) => {
    return <MyScreenersComponent title={item.title} />;
  };
  return (
    <View style={{}}>
      <View style={marketScreen.myScreenerHeadView}>
        <Text style={marketScreen.myScreenerHeadText}>My Screeners</Text>
        <TouchableOpacity>
          <Text style={marketScreen.myScreenerViewAllbtn}>View All</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        directionalLockEnabled={true}
        alwaysBounceVertical={false}
        style={marketScreen.myScreenerScrollView}>
        <FlatList
          contentContainerStyle={{alignSelf: 'flex-start'}}
          numColumns={Math.ceil(screenersData.length / 2)}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
          data={screenersData}
          renderItem={renderScreenersItem}
        />
      </ScrollView>
    </View>
  );
};
export default MyScreeners;

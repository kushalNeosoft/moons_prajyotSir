import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';

import {ipoData} from './SampleData';
import IPOComponent from '../Component/IpoComponent';
import {marketScreen} from '../../../Theme/Light';
const IPO = () => {
  const renderIpoItem = ({item}) => {
    return (
      <IPOComponent
        title={item.title}
        range={item.range}
        date={item.date}
        minQty={item.minQty}
        minAmount={item.minAmount}
      />
    );
  };
  return (
    <View>
      <Text style={marketScreen.ipoHeadText}>IPO</Text>
      <View>
        <FlatList
          data={ipoData}
          renderItem={renderIpoItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          contentContainerStyle={marketScreen.ipoFlatList}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
      <View style={marketScreen.ipoFooter}></View>
    </View>
  );
};
export default IPO;

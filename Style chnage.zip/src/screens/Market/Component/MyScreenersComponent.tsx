import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {myScreenerComp} from '../../../Theme/Light';

const MyScreenersComponent = props => {
  return (
    <TouchableOpacity
      style={myScreenerComp.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <Text style={myScreenerComp.title}>{props.title}</Text>
    </TouchableOpacity>
  );
};
export default MyScreenersComponent;

import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {newsListComp} from '../../../Theme/Light';

const NewsListComponent = props => {
  return (
    <View style={newsListComp.container}>
      <TouchableOpacity style={newsListComp.newsLeftView}>
        <Text style={newsListComp.title}>{props.title}</Text>
        <Text style={newsListComp.time}>{props.time}</Text>
      </TouchableOpacity>
      <View style={newsListComp.line}></View>
      <TouchableOpacity style={{}}>
        <Text style={newsListComp.nse}>NSE</Text>
        <Text style={newsListComp.stockName}>{props.stockName}</Text>
        <Text style={newsListComp.price}>{props.price}</Text>
        <Text style={newsListComp.changes}>{props.change}</Text>
      </TouchableOpacity>
    </View>
  );
};
export default NewsListComponent;

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Linking,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {newProductComp} from '../../../Theme/Light';

const NewProductComponent = props => {
  const navigation = useNavigation();
  return (
    <TouchableOpacity
      style={[
        newProductComp.container,
        {backgroundColor: props.title === 'IPO' ? '#EFF3FF' : '#B4EBCC'},
      ]}
      onPress={() => {
        if (props.title === 'IPO') {
          navigation.navigate('IpoScreen');
        } else {
          Linking.openURL(
            'https://mobileuat.odinwave.com/Wave2BackOffice/outstanding-report?userId=OM',
          );
        }
      }}>
      <View style={newProductComp.imageView}>
        <Image
          resizeMode="contain"
          source={require('../../../assets/demo.jpeg')}
          style={newProductComp.image}
        />
      </View>
      {/* <Text>{props.link}</Text> */}
    </TouchableOpacity>
  );
};
export default NewProductComponent;

import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import Holdings from '../../screens/Portfolio/Holding/Holdings';
import Positions from '../../screens/Portfolio/Position/Positions';
import {portFolioScreen} from '../../Theme/Light';

const Tab = createMaterialTopTabNavigator();

function AnimatedTopBar({setScrollValue}) {
  return (
    <Tab.Navigator
      //   scrollEnabled={true}
      screenOptions={{
        // tabBarScrollEnabled: true,
        lazy: true,
        tabBarLabelStyle: portFolioScreen.tabBarLabelStyle,
        tabBarStyle: portFolioScreen.tabBarStyle,
        tabBarIndicatorStyle: portFolioScreen.tabBarIndicatorStyle,
      }}>
      <Tab.Screen
        name="Holdings"
        // component={Holdings}
        children={props => (
          <Holdings setScrollValue={setScrollValue} {...props} />
        )}
        options={{tabBarLabel: 'Holdings'}}
      />
      <Tab.Screen
        name="Positions"
        component={Positions}
        options={{tabBarLabel: 'Positions'}}
      />
    </Tab.Navigator>
  );
}
export default AnimatedTopBar;

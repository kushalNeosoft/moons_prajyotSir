import { Dimensions, StyleSheet } from 'react-native';
import { Cfont, Font, root } from '../../../../styles/colors';



export const Drawerstyling = StyleSheet.create({

    Maincon: {
        flex: 1

    },
    slideimgcon:{
        height:'50%',
        width:'75%',
        borderRadius:20,
        backgroundColor:"red"
    },
    slideimgcontwo:{
        height:'100%',
        width:'100%',
        borderRadius:20,
        backgroundColor:"red"
    },
    imgconstyl:{
        borderBottomWidth:1,
        borderBottomColor: "#E0E0E0"
    },
    Innerconstart: {
        height: 200,
        flexDirection: "row",
        justifyContent: 'center',
        alignItems: "center",
        borderBottomWidth: 1,
        padding: 10,

    },
    Innercon: {
        height: 70,
        flexDirection: "row",
        justifyContent: 'space-between',
        alignItems: "center",
        borderBottomWidth: 1,
        padding: 15,
        borderBottomColor: "#E0E0E0"


    },
    Imgcon: {
        borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
        width: Dimensions.get('window').width * 0.12,
        height: Dimensions.get('window').width * 0.12,

    },
    imagemain: {
        borderRadius: Math.round(Dimensions.get('window').width + Dimensions.get('window').height) / 2,
        width: Dimensions.get('window').width * 0.12,
        height: Dimensions.get('window').width * 0.12,

    },
    texticon: {
        fontSize:Font.font_normal_three,
        color: root.color_text,
        fontFamily:Cfont.rubik_medium,

    },
    Innerconone: {
        height: 90,
        flexDirection: "row",
        justifyContent: 'space-between',
        alignItems: "center",
        borderBottomWidth: 1,
        borderTopWidth:1,
        borderBottomColor: "#E0E0E0",
        borderTopColor:"#E0E0E0",
        padding: 15,


    },
    stylingtxt: {
        right: '140%'
    },
    protextalign: {
        fontSize:Font.font_normal_three,
        color: root.color_text,
        fontFamily:Cfont.rubik_medium,
        paddingLeft:16,
    },
    protextaligntwo: {
        fontSize:Font.font_normal_two,
        color: root.color_text,
        fontFamily:Cfont.rubik_light,
        paddingLeft:16,
    },
    Innercotwo: {
        height: 110,
        justifyContent: 'space-between',
        borderBottomWidth: 1,
        borderBottomColor: "#E0E0E0",
        padding: 15,

    },
    Innertwoone: {
        flexDirection: "row",
        justifyContent: 'space-between',
        alignItems: "center",
        marginBottom: 10
    },
    Innercothree: {
        
        borderBottomColor: "#E0E0E0",
        padding: 15,
    },
    newcontact:{
        borderBottomColor: "#E0E0E0",
        height:80,
        borderBottomWidth:1
    },
    usagecon: {
        height: 50,
        width: "90%",
        borderWidth: 1,
        borderRadius: 10,
        borderColor: "#000080",
        alignItems: "center",
        justifyContent: "center",
        marginTop:10
    },
    styleb: {
        color: root.client_background,
        fontSize: Font.font_normal_three,
        fontFamily:Cfont.rubik_medium,
    },
    radio: {
        flexDirection: "row",
        alignItems: "center",



    },
    Lighttxt: {
        color: root.color_text,
        fontSize: Font.font_normal_three,
        fontFamily:Cfont.rubik_regular,
        marginRight: 50
    },
    Darktxt: {
        color: root.color_text,
        fontSize: Font.font_normal_three,
        fontFamily:Cfont.rubik_regular,

    },
    Buttomtxtcon: {
        height: 50,
        width: "100%",
        top:-35

    },
    Innercokyc: {
        height: 190,
        justifyContent: 'space-between',
        borderBottomWidth: 1,
        borderBottomColor: "#E0E0E0",
        padding: 15,

    },
    buttontxt: {
        textAlign: "center",
        alignSelf: "center",
        marginTop: 15,
        color: "black",
        fontWeight: "500"
    },
    versiontxt: {
        color:'black',
        fontSize:15
    }




});

import React from 'react';
import {View, Text, Image} from 'react-native';
import { Drawerstyling } from '../../navigators/SideDrawerNavigation/components/Customdrawer/Drawerstyling';
// import {Drawerstyling} from '../Customdrawer/Drawerstyling';
import Entypo from 'react-native-vector-icons/Entypo';
import {useSelector} from 'react-redux';


interface ProfileinfoProps {
    
    rightComponent?: React.ReactNode;
  
    
  }
const Profileinfo = (
    {
        rightComponent,
      }: ProfileinfoProps
) => {
  const storeimg = useSelector(state => state.Login.imgstore);

  const urldf = 'https://reactnative.dev/img/tiny_logo.png';
  return (
    <View style={Drawerstyling.Innerconone}>
      <View style={Drawerstyling.Imgcon}>
        <Image
          style={Drawerstyling.imagemain}
          source={storeimg == '' ? {uri: urldf} : {uri: storeimg}}
        />
      </View>
      <View style={Drawerstyling.stylingtxt}>
        <Text style={Drawerstyling.protextalign}>Om Prakash</Text>
        <Text style={Drawerstyling.protextaligntwo}>User ID: OM</Text>
      </View>
      <View>
            {rightComponent}
      </View>
    </View>
  );
};

export default Profileinfo;

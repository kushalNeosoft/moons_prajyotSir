import "react-native-reanimated";
import React from 'react';
import type {FC} from 'react';

// import RootNavigator from './src/navigators/RootNavigator';
import MainNavigator from './src/navigators/Mainnav/MainStack';
import {ThemeProvider} from './src/styles/ThemeContext';
import './src/localization/i18n';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { persistor, store } from './src/redux/Store';

const App: FC = () => (
  <ThemeProvider>

  <Provider store={store}>

  <PersistGate persistor={persistor}loading={null}>
    <MainNavigator />
  </PersistGate>


</Provider>
</ThemeProvider>
);

export default App;

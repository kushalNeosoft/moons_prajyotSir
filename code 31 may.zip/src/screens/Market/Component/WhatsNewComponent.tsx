import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {whatsNewComp} from '../../../theme/light';
const WhatsNewComponent = props => {
  const navigation = useNavigation();
  const title = props.title;
  return (
    <View
      style={[
        whatsNewComp.whatsNewContainer,
        {backgroundColor: title == 'IPO is incoming!!' ? '#EFF3FF' : '#B4EBCC'},
      ]}>
      <View>
        <Text style={whatsNewComp.whatsNewTitle}>{props.title}</Text>
        <Text style={whatsNewComp.whatsNewSubTitle}>{props.subTitle}</Text>
        <TouchableOpacity
          style={whatsNewComp.whatsNewButton}
          onPress={() => {
            if (title == 'IPO is incoming!!') {
              navigation.navigate('IpoScreen');
            } else {
              Linking.openURL(
                'https://mobileuat.odinwave.com/Wave2BackOffice/outstanding-report?userId=OM',
              );
            }
          }}>
          <Text style={whatsNewComp.whatsNewButtonText}>Apply Now</Text>
        </TouchableOpacity>
      </View>
      <View style={whatsNewComp.whatsNewImage}>
        <Image
          resizeMode="contain"
          source={require('../../../assets/demo.jpeg')}
          style={whatsNewComp.whatsNewImage}
        />
      </View>
    </View>
  );
};
export default WhatsNewComponent;

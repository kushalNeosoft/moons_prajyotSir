import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import {assets} from '../assets';
// import {colors} from '../../constants/colors';
import { colors } from '../../../constants/colors';
// import {texts} from '../../constants/text';
import alignment from '../utils/alignment';
import CommonModal from '../Component/CommonModal/CommonModal';

import ImagePicker from 'react-native-image-crop-picker';
import {useDispatch} from 'react-redux';
import {CamText} from './CamText';
import { imgcon } from '../../redux/Action';

const Cammodal = (props: any) => {
  const [checked, setChecked] = useState(0);
  const dispatch = useDispatch();
  const [imagest, setImagest] = useState(
    'https://api.adorable.io/avatars/80/abott@adorable.png',
  );
  console.log(CamText, 'KSKSKSKSKSK----->');

  const cameraOpen = () => {
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      console.log(image, 'PPPPPP--->');
      setImagest(image.path);
      console.log(imagest, 'KAKAKAK2222->');

      dispatch(imgcon({imgstore: image.path}));
    });
  };

  const galleryOpen = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      console.log(image);
      setImagest(image.path);
      dispatch(imgcon({imgstore: image.path}));
    });
  };

  const CamFunction = (drawerType: string) => {
    {
      drawerType == 'Open'
        ? galleryOpen()
        : drawerType == 'Capture'
        ? cameraOpen()
        : drawerType == 'Remove'
        ? 'remove'
        : props.onClose;
    }
  };

  useEffect(() => {}, [checked]);

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <View
        style={{
          ...alignment.row_alingC_SpaceB,
        }}>
        <Text style={styles.watchListText}>Profile Picture Setting</Text>
      </View>
      {CamText.map(CamText => {
        return (
          <TouchableOpacity
            onPress={
              CamText?.drawerType == 'Close'
                ? props.onClose
                : () => CamFunction(CamText.drawerType)
                
            }>
            <View style={{paddingVertical:20}}>
              <Text style={{ color: 'black',fontSize:20,fontWeight:"400"}}>
                {CamText.name}
              </Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </CommonModal>
  );
};

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    top: 300,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 10,
  },
  commonTimingView: {
    height: 300,
    width: 120,
    alignItems: 'flex-start',
  },
  container: {
    backgroundColor: 'yellow',
  },
  img: {
    height: 20,
    width: 20,
  },
  btn: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  watchListText: {
    fontSize: 30,
    color: colors.black,
  },
  createWatchListText: {
    paddingLeft: 30,
    fontSize: 20,
    color: colors.black,
  },
});

export default Cammodal;

import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  TouchableNativeFeedback,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/CommonModal/CommonModal';
import CommonModalone from '../../../components/CommonModal/CommonModalone';
import CalendarPicker from 'react-native-calendar-picker';

const DatePickerDialog = (props: any) => {
  const [date, setDate] = useState<Date>();
  return (
    <CommonModalone visible={props.visible} onClose={props.onClose}>
      <View style={{width: '100%'}}>
        <Text
          style={{
            fontSize: Font.font_title,
            fontFamily: Cfont.rubik_medium,
            color: root.color_text,
          }}>
          Choose Start Date
        </Text>
        <View style={{height: 16}} />
        <CalendarPicker
          onDateChange={(d: any) => {
            setDate(d);
          }}
        />

        <View style={{borderRadius: 15, overflow: 'hidden',}}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              props.onChange(date);
            }}>
            <View
              style={{
                borderRadius: 12,
                marginTop: 16,
                backgroundColor: root.client_background,
                paddingHorizontal: 24,
                paddingVertical: 12,
              }}>
              <Text style={{fontSize: 16, color: 'white', textAlign: 'center'}}>
                Done
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
    </CommonModalone>
  );
};
export default DatePickerDialog;

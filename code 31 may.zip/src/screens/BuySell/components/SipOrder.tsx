import {
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import DropDownIcon from '../../../assets/DropDownIcon';
import MinusIcon from '../../../assets/MinusIcon';
import AddIcon from '../../../assets/AddIcon';
import ChooseFrequencyDialog from './ChooseFrequencyDialog';
import {useState} from 'react';
import DatePickerDialog from './DatePickerDialog';
import moment from 'moment';
import React from 'react';
import { Cfont, root } from '../../../styles/colors';
import ExpandIcon from '../../../assets/ExpandIcon';

const SipOrder = ({operation}: any) => {
  const [chooseFrequencyVisible, setChooseFrequencyVisible] = useState(false);
  const [datePickerVisible, setDatePickerVisible] = useState(false);
  const [date, setDate] = useState<Date>();
  return (
    <View style={{flexDirection: 'column', flex: 1 , marginTop : 22 }}>
      <ScrollView style={{flex: 1, padding: 18  }}>
        <View>
          <Text style={{fontSize: 14, color: root.color_text,  fontFamily: Cfont.rubik_bold}}>
            How many?
          </Text>
          <View style={{flexDirection: 'row', marginTop: 20}}>
            <View style={{flex: 1}}>
              <Text style={{color: root.color_text,  fontFamily: Cfont.rubik_regular, fontSize: 14}}>
                Quantity
              </Text>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TextInput
                  style={{
                    flex: 1,
                    marginHorizontal: 8,
                    borderBottomWidth: 2,
                    borderColor: 'lightgrey',
                    paddingVertical: 0,
                    paddingHorizontal: 8,
                    fontSize: 26,
                  }}
                  placeholder="0"
                  keyboardType="number-pad"
                />
              </View>
            </View>
            <View style={{alignSelf: 'center', marginHorizontal: 16}}>
              <Text>Or</Text>
            </View>
            <View style={{flex: 1}}>
              <Text style={{color: root.color_text,  fontFamily: Cfont.rubik_regular, fontSize: 14}}>
                Amount
              </Text>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TextInput
                  style={{
                    flex: 1,
                    marginHorizontal: 8,
                    borderBottomWidth: 2,
                    borderColor: 'lightgrey',
                    paddingVertical: 0,
                    paddingHorizontal: 8,
                    fontSize: 26,
                  }}
                  keyboardType="number-pad"
                  placeholder="0"
                />
              </View>
            </View>
          </View>
          <View style={{flexDirection: 'row', marginTop: 8}}>
            <View style={{flex: 1, marginTop: 30,marginLeft: 1}}>
              <Text style={{color: root.color_text,  fontFamily: Cfont.rubik_regular, fontSize: 14}}>
                Cap Price
              </Text>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TextInput
                  style={{
                    flex: 1,
                    marginHorizontal: 8,
                    borderBottomWidth: 2,
                    borderColor: 'lightgrey',
                    paddingVertical: 0,
                    paddingHorizontal: 8,
                    fontSize: 26,
                  }}
                  keyboardType="number-pad"
                  placeholder="0"
                />
              </View>
              <Text style={{color:root.color_text, fontSize: 12, marginTop: 8,marginLeft: 8}}>
                Dont Buy Above This Price
              </Text>
            </View>
            <View style={{flex: 1, marginLeft: 48}}></View>
          </View>
          <View
            style={{marginTop: 30, flexDirection: 'row', alignItems: 'center'}}>
            <Text style={{color: root.color_text, fontWeight: 'bold'}}>Frequency</Text>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  setChooseFrequencyVisible(true);
                  // navigation.navigate('SignupScreen');
                }}>
                <View
                  style={{
                    paddingHorizontal: 10,
                    paddingVertical: 2,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <Text style={{color: root.color_text}}>Choose</Text>
                  <ExpandIcon
                    style={{height: 28, width: 16, color: root.color_text}}
                  />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          <View
            style={{marginTop: 24, flexDirection: 'row', alignItems: 'center'}}>
            <Text style={{color: root.color_text,fontFamily: Cfont.rubik_medium,fontSize: 14}}>
              No Of Installments
            </Text>
            <View
              style={{marginHorizontal: 14, borderWidth: 1.5, borderRadius: 16}}>
              <MinusIcon
                style={{
                  height: 14,
                  width: 14,
                  
                  color: 'black',
                }}
              />
            </View>

            <Text style={{marginHorizontal: 16}}>0</Text>
            <View
              style={{marginHorizontal: 14, borderWidth: 1.5, borderRadius: 16}}>
              <AddIcon
                style={{
                  height: 14,
                  width: 14,
                  color: 'black',
                }}
              />
            </View>
          </View>
          <View
            style={{marginTop: 40, flexDirection: 'row', alignItems: 'center'}}>
            <Text style={{color: 'grey', fontSize: 12}}>
              Your <Text style={{color: root.client_background,fontSize: 12,fontFamily: Cfont.rubik_medium}}>Equity</Text> SIP Will Start
              On{' '}
              <Text>
                {moment(date ? date : Date.now()).format('Do MMM, yy')}
              </Text>
            </Text>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  // navigation.navigate('SignupScreen');
                  setDatePickerVisible(true);
                }}>
                <View
                  style={{
                    paddingHorizontal: 4,
                    paddingVertical: 2,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <Text style={{color: root.client_background,fontSize: 12,fontFamily: Cfont.rubik_medium}}>Change</Text>
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
        </View>
      </ScrollView>
      <View
        style={{
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 4,
          },
          shadowOpacity: 0.3,
          shadowRadius: 4.65,
          backgroundColor: 'white',
          elevation: 8,
          padding: 16,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text style={{fontSize: 11, color: 'gray', fontFamily:Cfont.rubik_regular}}>
            Brokerage and charges
          </Text>
          <ArrowForwardIcon style={{width: 28, height: 24, color:  root.client_background}} />
        </View>

        <Text
          style={{
            paddingHorizontal: 16,
            paddingVertical: 10,
            backgroundColor: operation == 'BUY' ? root.client_background : 'red',
            fontSize: 16,
            color: 'white',
            borderRadius: 8,
            textAlign: 'center',
            marginTop: 16,
            fontFamily:Cfont.rubik_semibold
          }}>
          Place Order
        </Text>
      </View>
      <ChooseFrequencyDialog
        visible={chooseFrequencyVisible}
        onClose={() => {
          setChooseFrequencyVisible(false);
        }}
      />
      <DatePickerDialog
        visible={datePickerVisible}
        onClose={() => {
          setDatePickerVisible(false);
        }}
        onChange={(d: Date) => {
          setDatePickerVisible(false);

          console.log('Date', moment(d).format('DD/mm/YYYY'));

          setDate(d);
        }}
      />
    </View>
  );
};
export default SipOrder;

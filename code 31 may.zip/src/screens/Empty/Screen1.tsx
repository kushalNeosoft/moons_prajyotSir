import React from 'react';
import {View, Text, Dimensions} from 'react-native';


import Tab2 from '../../assets/tab-background-latest.svg';


const Screen1 = () => {
  return (
    <View style={{flex: 1,
    // flexDirection:'row'
    }}>
      <View
        style={{
          height: 52,
          width: 300,
          backgroundColor: 'yellow',
          borderWidth: 1,
          
        }}>
        <Text>Hello</Text>
      </View>
      <View
        style={{
          height: Dimensions.get('window').width * 0.127,
           width: Dimensions.get('window').width * 0.73,
        
          backgroundColor: 'pink',
          borderWidth: 1,
          
        }}>
        <Tab2
          width={'100%'}
          height={128}
          style={{
            position: 'absolute',
            alignSelf: 'center',
            backgroundColor: '#0000000',
            opacity:0.1/4,
            bottom: -30,
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.23,
            shadowRadius: 2.62,

            elevation: 24,
          }}
        />
      </View>

      {/* <Tabsvg
        width={500}
        style={{
          position: 'absolute',
          alignSelf:'center',
          bottom: -10,
          
          width:'100%',
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 12,
          },
          shadowOpacity: 0.58,
          shadowRadius: 16.0,

          elevation: 24,
        }}
      /> */}
      <Tab2 fill={'red'} height={200} width={200} />
      {/* <Tabnew/>
        <TabComponent/> */}
    </View>
  );
};
export default Screen1;

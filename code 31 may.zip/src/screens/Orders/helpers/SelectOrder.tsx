import {
  allEquityOrders,
  closeEquityOrders,
  openEquityOrders,
} from '../data/equityOrdersData';
import {
  goodTillDateAllOrders,
  goodTillDateCloseOrders,
  goodTillDateOpenOrders,
} from '../data/goodTillDateData';
import {
  multiLegAllOrders,
  multiLegCloseOrders,
  multiLegOpenOrders,
} from '../data/multiLegOrdersData';
import {
  singleScriptAllOrders,
  singleScriptCloseOrders,
  singleSriptOpenOrders,
} from '../data/singleScriptOrdersData';
import {
  spreadAllOrders,
  spreadCloseOrders,
  spreadOpenOrders,
} from '../data/spreadOrdersData';

export const selectOpenOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleSriptOpenOrders;
    case 'Spread Orders':
      return spreadOpenOrders;
    case 'Multileg Orders':
      return multiLegOpenOrders;
    case 'Good Till Date':
      return goodTillDateOpenOrders;
    case 'Equity SIP':
      return openEquityOrders;
  }
};

export const selectCompletedOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleScriptCloseOrders;
    case 'Spread Orders':
      return spreadCloseOrders;
    case 'Multileg Orders':
      return multiLegCloseOrders;
    case 'Good Till Date':
      return goodTillDateCloseOrders;
    case 'Equity SIP':
      return closeEquityOrders;
  }
};

export const selectAllOrders = (scriptName: string) => {
  switch (scriptName) {
    case 'Single Script Orders':
      return singleScriptAllOrders;
    case 'Spread Orders':
      return spreadAllOrders;
    case 'Multileg Orders':
      return multiLegAllOrders;
    case 'Good Till Date':
      return goodTillDateAllOrders;
    case 'Equity SIP':
      return allEquityOrders;
  }
};


/* Use this kind of switch statement if you dont want to render each data differently
Need to add data
*/
// export const selectOrders = (scriptName: string, selectedBtn: number) => {
//   switch (scriptName) {
//     case 'Equity SIP':
//       switch (selectedBtn) {
//         case 0:
//           return openEquityOrders;
//         case 1:
//           return closeEquityOrders;
//         case 2:
//           return allEquityOrders;
//       }
//   }
// };

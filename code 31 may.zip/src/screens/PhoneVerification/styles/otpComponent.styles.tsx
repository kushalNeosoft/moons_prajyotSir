import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../../styles/colors';

export const createOtpComponentStyles = (colors: TColors) => {
  return StyleSheet.create({
    heading: {
      fontSize: Font.font_title,
      fontFamily:Cfont.rubik_medium,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: 'grey',
    },
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 14,
      flexDirection: 'row',
    },
    buttonText: {
      color: 'white',
      fontSize: 16,
      // alignSelf: 'center',
    },
    buttonImage: {
      color: 'white',
      width: 40,
      marginLeft: 19,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_text,
      borderWidth: 0.5,
     
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
      color:root.color_text,
    },
  });
};

import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {chooseIndices} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import ChooseIndicesCard from './Component/ChooseIndicesCard';
import ChooseIndicesModal from './Component/ChooseIndicesModal';

const ChooseIndices = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const navigation = useNavigation();
  return (
    <View style={chooseIndices.mainView}>
      <TouchableOpacity
        onPress={() => {
          navigation.goBack();
        }}>
        <Ionicons name="close-sharp" style={chooseIndices.crossicon} />
      </TouchableOpacity>
      <Text style={chooseIndices.title}>Choose Indices</Text>
      <ChooseIndicesCard
        leftStockName={'BSEPBI'}
        rightStockName={'ALLCAP'}
        leftStockPrice={200}
        rightStockPrice={73773.9}
        leftStockChanges={'+48.71(+0.30%)'}
        rightStockChanges={'+9.36(+0.13%)'}
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
      <ChooseIndicesModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
    </View>
  );
};
export default ChooseIndices;

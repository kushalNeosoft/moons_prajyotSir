import React, {useState} from 'react';
import {TouchableOpacity, FlatList} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {TextInput} from 'react-native';
import {chooseIndicesModal} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import IndicesList from './IndicesList';
const ChooseIndicesModal = ({modalVisible, setModalVisible}: any) => {
  const stockData = [
    {
      stockName: 'NIFTY MNC',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY NEXT 50',
      price: 16727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY 50',
      price: 13427.48,
      changes: '-4.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY IT',
      price: 17746.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY BANK',
      price: 17464.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY 100',
      price: 16627.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY PSE',
      price: 15727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY PHARAMA',
      price: 16527.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY CPSE',
      price: 17777.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY ENERGY',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'SHA 50',
      price: 16527.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'CONDIS',
      price: 15527.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'INDSTR',
      price: 17627.48,
      changes: '+48.71(+0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'TELCOM',
      price: 13727.48,
      changes: '-3.71(-0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'MIDSEL',
      price: 12727.48,
      changes: '-2.71(-0.30%)',
      chip: 'bse',
    },
    {
      stockName: 'MSX7N10YIR',
      price: 17727.46,
      changes: '+48.71(+0.30%)',
      chip: 'nsecds',
    },
    {
      stockName: 'NIFTY HGDA',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY HSHA',
      price: 17727.48,
      changes: '+48.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JDHS',
      price: 17727.48,
      changes: '+78.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JHSN',
      price: 17727.48,
      changes: '+54.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY JDJDJ',
      price: 17827.48,
      changes: '+47.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCJD',
      price: 17727.48,
      changes: '+33.71(+0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCHD',
      price: 13727.48,
      changes: '-48.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNCJD',
      price: 12727.48,
      changes: '-8.71(-0.30%)',
      chip: 'nse',
    },
    {
      stockName: 'NIFTY MNJDKDC',
      price: 11727.48,
      changes: '-2.71(-0.30%)',
      chip: 'nse',
    },
  ];
  const renderItem = ({item}) => {
    return <IndicesList stockName={item.stockName} />;
  };
  return (
    <Modal
      style={chooseIndicesModal.modal}
      animationType="none"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={chooseIndicesModal.headerView}>
        <View style={{flexDirection: 'row'}}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(false);
            }}>
            <Ionicons name="close-sharp" style={chooseIndicesModal.crossIcon} />
          </TouchableOpacity>
          <Text style={chooseIndicesModal.headerTitle}>Choose Indices</Text>
        </View>

        <TouchableOpacity onPress={() => {}}>
          <MaterialIcons name="search" style={chooseIndicesModal.searchIcon} />
        </TouchableOpacity>
      </View>
      <View style={chooseIndicesModal.listView}>
        <FlatList
          data={stockData}
          renderItem={renderItem}
          contentContainerStyle={{marginBottom: 8, paddingTop: 22}}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
    </Modal>
  );
};
export default ChooseIndicesModal;

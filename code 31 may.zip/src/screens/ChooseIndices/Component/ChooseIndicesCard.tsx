import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {chooseIndicesCard} from '../../../theme/light';

const ChooseIndicesCard = (props: any) => {
  return (
    <View style={chooseIndicesCard().mainView}>
      <View style={chooseIndicesCard().innerView}>
        <View>
          <Text style={chooseIndicesCard().stockName}>
            {props.leftStockName}
          </Text>
          <Text
            style={
              chooseIndicesCard({leftPrice: props.leftStockPrice})
                .leftStockprice
            }>
            {props.leftStockPrice}
          </Text>
          <Text
            style={
              chooseIndicesCard({leftPrice: props.leftStockPrice})
                .leftStockchanges
            }>
            {props.leftStockChanges}
          </Text>
          <TouchableOpacity
            onPress={() => {
              props.setModalVisible(true);
            }}
            style={chooseIndicesCard().changeBotton}>
            <Text style={chooseIndicesCard().changeBottonText}>Change</Text>
          </TouchableOpacity>
        </View>
        <View style={chooseIndicesCard().centerLine}></View>
        <View>
          <Text style={chooseIndicesCard().stockName}>
            {props.rightStockName}
          </Text>
          <Text
            style={
              chooseIndicesCard({rightPrice: props.rightStockPrice})
                .rightStockprice
            }>
            {props.rightStockPrice}
          </Text>
          <Text
            style={
              chooseIndicesCard({rightPrice: props.rightStockPrice})
                .rightStockchanges
            }>
            {props.rightStockChanges}
          </Text>
          <TouchableOpacity
            style={chooseIndicesCard().changeBotton}
            onPress={() => {
              props.setModalVisible(true);
            }}>
            <Text style={chooseIndicesCard().changeBottonText}>Change</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default ChooseIndicesCard;

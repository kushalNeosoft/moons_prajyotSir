import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import {indicesList} from '../../../theme/light';

const IndicesList = (props: any) => {
  return (
    <TouchableOpacity activeOpacity={0.8} style={indicesList.mainView}>
      <Feather name="circle" style={indicesList.circleIcon} />
      <Text style={indicesList.title}>{props.stockName}</Text>
    </TouchableOpacity>
  );
};
export default IndicesList;

import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {ScrollView, Text, View} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import {eventdata} from '../../../assets/demoData';
import {root} from '../../../styles/colors';
import {Eventstylecom} from '../../../theme/light';

const Events: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);

  const renderItem = ({item, index}: any) => (
    <TouchableOpacity onPress={() => setSelectedItem(index)}>
      {selectedItem === index ? (
        <>
          <View style={Eventstylecom.menuitem}>
            <Text style={Eventstylecom.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={Eventstylecom.menuitemtwo}>
            <Text style={Eventstylecom.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  return (
    <ScrollView
      style={Eventstylecom.mainconatiner}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Eventstylecom.innerconatiner} key={1}>
        <View style={Eventstylecom.innertwo}>
          <Text style={Eventstylecom.cortxt}>Corporate Action</Text>
        </View>
      </View>
      <ScrollView horizontal key={2} nestedScrollEnabled showsHorizontalScrollIndicator={false}>
        <FlatList
          style={{paddingLeft: 16}}
          data={eventdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>
      <ScrollView horizontal key={3} nestedScrollEnabled showsHorizontalScrollIndicator={false}>
        <View style={Eventstylecom.oneflex}>
          {eventdata.map((events, i) => {
            if (selectedItem == i) {
              return (
                <FlatList
                showsHorizontalScrollIndicator={false}
                  data={events.data.date}
                  style={{paddingLeft: 17}}
                  horizontal
                  nestedScrollEnabled
                  renderItem={({item, index}) => {
                    return (
                      <>
                        <View style={Eventstylecom.dateconatiner}>
                          <View style={Eventstylecom.dateconatinerinner}>
                            <Text style={Eventstylecom.txtdate}>
                              {item.day}
                            </Text>
                            <Text style={Eventstylecom.txtdatetwo}>
                              {item.year}
                            </Text>
                          </View>
                          <View style={Eventstylecom.iconallign}>
                            <Feather
                              name="arrow-right-circle"
                              size={24}
                              color={root.color_text}
                            />
                          </View>
                        </View>
                      </>
                    );
                  }}
                />
              );
            }
          })}
        </View>
      </ScrollView>
      <View style={Eventstylecom.emptyview}/>
    </ScrollView>
  );
};

export default Events;

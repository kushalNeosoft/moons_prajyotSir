import React, {useState} from 'react';
import {FlatList, ScrollView, Text, TouchableOpacity, View} from 'react-native';
import {useDispatch} from 'react-redux';
import {
  CompanyData,
  Contactdata,
  SecurityDetail,
} from '../../../assets/demoData';
import {CompanyStyle} from '../../../theme/light';

const Companyinformation: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);

  const renderItem = ({item, index}: any) => (
    <TouchableOpacity onPress={() => setSelectedItem(index)}>
      {selectedItem === index ? (
        <>
          <View style={CompanyStyle.menuitem}>
            <Text style={CompanyStyle.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={CompanyStyle.menuitemtwo}>
            <Text style={CompanyStyle.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );
  return (
    <ScrollView
      style={CompanyStyle.maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={CompanyStyle.Startcon}>
        {CompanyData.map((item, index) => {
          return (
            <View style={CompanyStyle.listone}>
              <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
              <Text style={CompanyStyle.txtstyle}>{item.Value}</Text>
            </View>
          );
        })}
      </View>
      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Security Details</Text>
      </View>
      {SecurityDetail.map((item, index) => {
        return (
          <View style={CompanyStyle.listone}>
            <Text style={CompanyStyle.txtstyle}>{item.title}</Text>
            <Text style={CompanyStyle.txtstyle}>{item.Value}</Text>
          </View>
        );
      })}
      <View style={CompanyStyle.securitycon}>
        <Text style={CompanyStyle.sectxtstyle}>Contact Information</Text>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          data={Contactdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>

      
        {Contactdata.map((events, i) => {
          if (selectedItem == i) {
            return (
              <FlatList
                scrollEnabled={false}
                showsHorizontalScrollIndicator={false}
                data={events.data}
                horizontal
                nestedScrollEnabled
                renderItem={({item, index}) => {
                  return (
                    <>
                      <View style={{width: '100%'}}>
                        {item.RegName == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Register Name
                            </Text>
                            {item.RegName == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.RegName}
                            </Text>
                          )}
                          </View>
                        )}
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Address</Text>
                          {item.addvalue == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.addvalue}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>
                            Telephone
                          </Text>
                          {item.telephone == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.telephone}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Fax</Text>
                          {item.fax == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.fax}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Email</Text>
                          {item.email == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.email}
                            </Text>
                          )}
                        </View>
                        <View style={CompanyStyle.newallign}>
                          <Text style={CompanyStyle.detaistxttwo}>Website</Text>
                          {item.website == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.website}
                            </Text>
                          )}
                        </View>
                        {item.author == '' ? null : (
                          <View style={CompanyStyle.newallign}>
                            <Text style={CompanyStyle.detaistxttwo}>
                              Author
                            </Text>
                            {item.author == '' ? (
                            <Text style={CompanyStyle.detaistxt}>-</Text>
                          ) : (
                            <Text style={CompanyStyle.detaistxt}>
                              {item.author}
                            </Text>
                          )}
                          </View>
                        )}
                      </View>
                    </>
                  );
                }}
              />
            );
          }
        })}
     
    </ScrollView>
  );
};

export default Companyinformation;

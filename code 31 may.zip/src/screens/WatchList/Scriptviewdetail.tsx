import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Modal,
  Dimensions,
  TouchableOpacity,
  Animated,
  Easing,
  
} from 'react-native';
import {useNavigation, useRoute} from '@react-navigation/native';
import {Scriptviewstyle} from '../../theme/light';
import Entypo from 'react-native-vector-icons/Entypo';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../styles/colors';
import Scriptviewtab from '../../navigators/ScriptviewtabNavigation';
import Dropdown from '../../components/Dropdown/Dropdown';

const Scriptviewdetail = () => {
  const route = useRoute();
  const detail = route.params?.detail;
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [180, 58],
    extrapolate: 'clamp',
  });
  const navigation = useNavigation();

  return (
    <View style={Scriptviewstyle.maincontainer}>
      <Animated.View
        style={{
          height: height,
          backgroundColor: 'white',
        }}>
        {scrollValue == 1 ? (
          <View style={Scriptviewstyle.headertwo}>
            <View style={Scriptviewstyle.innerheadconatiner}>
              <View style={Scriptviewstyle.innerflexone}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Entypo name="cross" size={24} color={'black'} />
                </TouchableOpacity>
                <View>
                  <View style={Scriptviewstyle.aligntxt}>
                    <Text style={Scriptviewstyle.companyname}>
                      {detail?.item?.companyName}
                    </Text>
                    <Text style={Scriptviewstyle.Astyle}>A</Text>
                  </View>

                  <View
                    style={{flexDirection: 'row', justifyContent: 'center'}}>
                    <View style={Scriptviewstyle.filtler}>
                      <Text style={Scriptviewstyle.Bsetxtstyle}>BSE</Text>

                      <Entypo
                        name="chevron-small-down"
                        size={16}
                        color={root.color_subtext}
                      />
                    </View>
                    <View style={Scriptviewstyle.bseflexallign}>
                      <Text style={Scriptviewstyle.valtxt}>
                        {detail?.item?.value}
                      </Text>
                      <Text style={Scriptviewstyle.chgvaltxt}>
                        {detail?.item?.changes}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              <View style={Scriptviewstyle.innerflextwo}>
                <View style={Scriptviewstyle.buysmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Buy</Text>
                </View>
                <View style={Scriptviewstyle.sellsmallbtn}>
                  <Text style={Scriptviewstyle.buysellsmalltxt}>Sell</Text>
                </View>
                <Entypo name="dots-three-vertical" color={'black'} size={20} />
              </View>
            </View>
          </View>
        ) : (
          <>
            <View style={Scriptviewstyle.header}>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Entypo name="cross" size={24} color={'black'} />
              </TouchableOpacity>
            </View>
            <View style={Scriptviewstyle.detailblock}>
              <View style={Scriptviewstyle.detailone}>
                <View style={Scriptviewstyle.aligntxt}>
                  <Text style={Scriptviewstyle.companyname}>
                    {detail?.item?.companyName}
                  </Text>
                  <Text style={Scriptviewstyle.Astyle}>A</Text>
                </View>
                <TouchableOpacity
                // onPress={() => setVisible(true)}
                >
                  <View style={Scriptviewstyle.filtler}>
                    <Text style={Scriptviewstyle.Bsetxtstyle}>BSE</Text>
                    <Entypo
                      name="chevron-small-down"
                      size={16}
                      color={root.color_subtext}
                    />
                  </View>
                </TouchableOpacity>
              </View>

              <View style={Scriptviewstyle.detailtwo}>
                <Text style={Scriptviewstyle.valtxt}>
                  {detail?.item?.value}
                </Text>
                <Text style={Scriptviewstyle.chgvaltxt}>
                  {detail?.item?.changes}
                </Text>
                <View style={Scriptviewstyle.iconcontainer}>
                  <MaterialCommunityIcons
                    name="bell-outline"
                    color={'black'}
                    size={23}
                  />
                  <TouchableOpacity style={Scriptviewstyle.circle}>
                    <Feather name="bar-chart-2" size={20} color="black" />
                  </TouchableOpacity>
                  <AntDesign
                    name="pluscircleo"
                    size={24}
                    color={root.color_text}
                  />
                </View>
              </View>
            </View>
            <View style={Scriptviewstyle.byselconatiner}>
              <TouchableOpacity style={Scriptviewstyle.buycontainer}>
                <Text style={Scriptviewstyle.buyselltxt}>Buy</Text>
              </TouchableOpacity>
              <TouchableOpacity style={Scriptviewstyle.sellconstainer}>
                <Text style={Scriptviewstyle.buyselltxt}>Sell</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Animated.View>

      <Modal
        transparent={true}
        visible={visible}
        onRequestClose={() => setVisible(!visible)}>
        <TouchableOpacity onPress={() => setVisible(!visible)}>
          <View style={Scriptviewstyle.dropbox}></View>
        </TouchableOpacity>
      </Modal>

      <Scriptviewtab data={detail} setScrollValue={setScrollValue} />
    </View>
  );
};

export default Scriptviewdetail;

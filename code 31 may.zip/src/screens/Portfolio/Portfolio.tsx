import React, {useState, useEffect, useRef} from 'react';
import {Dimensions, Easing, TouchableHighlight} from 'react-native';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  TouchableOpacity,
} from 'react-native';
import AnimatedTopBar from '../../navigators/PortfolioTopBar/AnimatedTopBar';
import {portFolioScreen} from '../../theme/light';
import Header from '../../components/IndicesHeader/IndicesHeader';
import Bottomsheet from '../../components/BottomSheet/BottomSheet';
import HoldingFilterComp from './Component/HoldingFilterComp';
import PositionFilter from './Component/PositionFilter';
import alignment from '../../components/utils/alignment';
import {Cfont, Font, root} from '../../styles/colors';
import Holdings from './Holding/Holdings';
import Positions from './Position/Positions';
const Portfolio = () => {
  const bottomSheetRef = useRef<BottomSheet>(null);
  const buttons = ['Holdings', 'Positions'];
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [tabFilter, setTabFilter] = useState('');
  const Holding = () => {
    return (
      <Holdings setTabFilter={setTabFilter} bottomSheetRef={bottomSheetRef} />
    );
  };

  const Position = () => {
    return (
      <Positions setTabFilter={setTabFilter} bottomSheetRef={bottomSheetRef} />
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return Holding();
      case buttons[1]:
        return Position();
    }
  };

  const renderBtn = () => {
    return (
      <View style={portFolioScreen.tabBarContainer}>
        {buttons &&
          buttons.map((btn, key) => {
            return (
              <TouchableHighlight
                underlayColor={'#F0F2F5'}
                key={key}
                style={
                  selectedBtn === key
                    ? portFolioScreen.selectedTabBtns
                    : portFolioScreen.unSelectedTabBtns
                }
                // onPress={() => props.onPressSelectedBtn(key)}
                onPress={() => setSelectedBtn(key)}>
                <Text
                  style={
                    selectedBtn === key
                      ? portFolioScreen.selectedBtnText
                      : portFolioScreen.tabBtnsText
                  }>
                  {btn}
                </Text>
              </TouchableHighlight>
            );
          })}
      </View>
    );
  };

  return (
    <View style={portFolioScreen.portFolioContainer}>
      <Header />
      {renderBtn()}
      {renderView(buttons[selectedBtn])}
      <Bottomsheet ref={bottomSheetRef} index={-1}>
        {tabFilter == 'Holding' ? <HoldingFilterComp /> : <PositionFilter />}
      </Bottomsheet>
    </View>
  );
};

export default Portfolio;

import {Dimensions, StyleSheet} from 'react-native';
import alignment from '../components/utils/alignment';
import {root, Cfont, Font, TColors} from '../styles/colors';
const height = Dimensions.get('window').height;

// Login Screen componets styling
const screenHeight = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

// console.log(height);
// const statusHeight = StatusBar?.currentHeight ? StatusBar?.currentHeight : 0;

export const Login = StyleSheet.create({
  scrollContainer: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    flex: 1,
    height: height,
    backgroundColor: root.color_active,
  },
  block1: {
    flex: 1,
    flexGrow: 1,
    flexDirection: 'column',
    padding: 16,
  },
  block1ButtonContainer: {
    flexDirection: 'row',
    marginTop: 48,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },
  buttonTextone: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
    fontFamily: Cfont.rubik_medium,
  },
  buttonImage: {
    color: root.color_active,
    width: Font.font_normal_three,
    marginLeft: 16,
  },
  buttonImageone: {
    color: root.color_text,
    width: Font.font_normal_three,
    marginLeft: 16,
  },
  forgettxt: {
    color: root.color_textual,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  haventtxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  registertxt: {
    color: root.client_background,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  signupContainer: {
    flexDirection: 'row',
    marginTop: 32,
    alignItems: 'center',
    backgroundColor: 'black',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 16,
  },
  signupContainerHeading: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  signupContainerSubHeading: {
    color: root.signup_wrap_subtitle,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    marginTop: 8,
  },
  Avaltxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  rowtxt: {
    fontSize: Font.font_normal_one,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
  },
  exchtxt: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
  },
  block2: {
    padding: 16,
  },
  heading: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: 'lightgrey',
    borderWidth: 2,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
  inputIcon: {
    width: 24,
    color: 'grey',
    margin: 12,
  },
  sectionContainer: {
    marginTop: 32,
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
  },
  highlight: {
    fontWeight: '700',
  },
  footerContainer: {
    marginTop: 8,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

// SignUP page

export const SignupStyles = StyleSheet.create({
  scrollContainer: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    flex: 1,
    // height: height,
    backgroundColor: root.color_active,
    padding: 16,
  },
  block1ButtonContainer: {
    flexDirection: 'row',
    marginTop: 7,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  buttonContainer: {
    flexDirection: 'row',
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 9,
    paddingHorizontal: 18,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },
  buttonImage: {
    color: root.color_active,
    width: 24,
    marginLeft: 22,
  },
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 25,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

//Forgot password & MPIN

export const ForgotPasswordStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    padding: 16,
  },
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  Sendotp: {
    marginTop: 16,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  user: {
    fontSize: Font.font_normal_four,
    marginTop: 32,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  userId: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
  email: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  mobile: {
    paddingVertical: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  om: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  moons: {
    paddingVertical: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  99: {
    paddingVertical: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },

  backIcon: {
    width: 32,
    height: 22,

    color: root.color_text,
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 11,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    alignSelf: 'center',
  },
});

//Phone component (SignUP button from Login Screen)
export const PhoneComponentStyles = StyleSheet.create({
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
    flexDirection: 'row',
  },
  buttonText: {
    // color: root.color_active,
    fontSize: Font.font_normal_three,
    // alignSelf: 'center',
  },
  buttonImage: {
    color: 'white',
    width: 24,
    marginLeft: 16,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.8,
    color: root.color_text,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
});
//OTP Component  (Sign UP Button from Login Screen)

export const OtpComponentStyles = StyleSheet.create({
  heading: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    flexDirection: 'row',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    // alignSelf: 'center',
  },
  buttonImage: {
    color: 'white',
    width: 40,
    marginLeft: 19,
  },
  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,

    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    color: root.color_text,
  },
});

//Phone Verification

export const PhoneVerificationStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    padding: 16,
  },
  backIcon: {
    width: 32,
    height: 32,
    color: 'grey',
  },
});

//Input MPin Profile Screen

export const MpinStyles = StyleSheet.create({
  titleContainer: {
    marginTop: 34,
  },
  title: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 2,
  },
  pinContainer: {
    flexDirection: 'row',
    marginTop: 16,
  },
  pinInput: {
    color: root.color_text,
    borderColor: root.color_text,
    borderWidth: 0.5,
    borderRadius: 4,
    margin: 0,
    paddingVertical: 8,
    paddingHorizontal: 16,
    height: 40,
    width: 40,
    textAlign: 'center',
  },
  buttonContainer: {
    backgroundColor: 'darkblue',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
    alignSelf: 'center',
  },

  inputContainer: {
    flexDirection: 'row',
    borderColor: 'lightgrey',
    borderWidth: 2,
    borderRadius: 8,
  },
  input: {
    margin: 0,
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  inputIcon: {
    width: 24,
    color: 'grey',
    margin: 12,
  },
  secondaryContainer: {
    marginTop: 32,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  takeMe: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  watchlist: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    paddingVertical: 4,
  },
  dropdownIcon: {
    height: 22,
    width: 22,
    color: root.client_background,
  },
  forgotMpin: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
});

//Password screen

export const PasswordStyles = StyleSheet.create({
  buttonContainer: {
    backgroundColor: root.client_background,
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  buttonText: {
    color: root.color_active,
    fontSize: Font.font_normal_three,
    alignSelf: 'center',
  },

  inputContainer: {
    flexDirection: 'row',
    borderColor: root.color_text,
    borderWidth: 0.5,
    borderRadius: 8,
  },
  input: {
    margin: 0,
    color: root.color_text,

    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  inputIcon: {
    width: 24,
    color: root.color_text,

    margin: 12,
  },
  takeme: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  watchList: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    paddingVertical: 4,
  },
  dropdownIcon: {
    height: 22,
    width: 24,
    color: 'black',
  },
  forgotPassword: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
});

//Profile screen with MPIN Screen

export const ProfileStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  headerContainer: {
    backgroundColor: 'white',
    shadowColor: 'black',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,

    elevation: 8,
  },
  userContainer: {
    flexDirection: 'row',
    padding: 26,
  },
  userProfilePic: {
    width: 64,
    height: 64,
    backgroundColor: 'gray',
    borderRadius: 32,
  },
  userInfoContainer: {
    // flex: 1,
    marginLeft: 16,
  },
  userName: {
    fontSize: 16,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 9,
  },
  userId: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  switchAccountContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  switchAccount: {
    fontSize: 14,
    color: 'black',
    fontWeight: 'bold',
  },
  dropDownIcon: {
    height: 24,
    width: 24,
    color: 'black',
  },
  tabContainer: {
    flexDirection: 'row',
  },
  tabItem: {
    flex: 1,
    alignItems: 'center',
  },
  itemText: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    //fontWeight: 'bold',
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  itemUnderlineContainer: {
    paddingHorizontal: 16,
    height: 2,
    width: '100%',
  },
  itemUnderline: {
    height: 2,
    flex: 1,
    width: '100%',
  },
  bodyContainer: {
    padding: 16,
    flex: 1,
    backgroundColor: 'white',
  },
});

// Watchlist Screen & Components styles

export const watchlistheader = StyleSheet.create({
  container: {
    flexDirection: 'row',
    height: Dimensions.get('window').width * 0.146,
    paddingTop: 8,
    //  justifyContent:'flex-end',
    backgroundColor: root.color_active,
    // backgroundColor:'yellow'
  },
  image: {
    height: 20,
    width: 20,
  },
  titleText: {
    top: -2.5,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    paddingHorizontal: 40,
  },
  changePercentage: {
    // color: colors.bright_green,
    top: -2.5,
    marginRight: 4,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    color: root.color_positive,
  },
  changePercentageminus: {
    // color: colors.bright_green,
    top: -2.5,
    marginRight: 4,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    color: root.color_negative,
  },
  headerLeft: {
    flex: 0.65,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerMiddle: {
    flex: 4,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'white',
    alignItems: 'center',
  },
  headerRight: {
    flex: 1,
    height: Dimensions.get('window').width * 0.121,
    backgroundColor: 'white',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  midtxt: {
    alignItems: 'center',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    padding: 0,
    top: -4,
  },
  headercon: {
    alignItems: 'center',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    height: Dimensions.get('window').width * 0.121,
  },
  rupeicon: {
    height: 16,
    width: 16,
  },
});

export const nortabstyles = StyleSheet.create({
  headerComponentView: {
    height: Dimensions.get('window').width * 0.117,
    backgroundColor: 'white',
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  norflex: {
    flexDirection: 'row',
    flex: 1.4,
  },
  downicon: {
    justifyContent: 'flex-end',
    marginLeft: '5%',
  },
  Nortxt: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  headerFlexEndView: {
    flex: 1,
    flexDirection: 'row',
    width: 150,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lenght: {
    color: 'white',
    borderColor: root.color_active,
    borderWidth: 1,
    fontSize: Font.font_normal_eight,
    fontWeight: 'bold',
    backgroundColor: 'red',
    paddingLeft: '36%',
    //marginLeft:'6%',
    height: 16,
    width: 16,
    borderRadius: 20,
    alignItems: 'center',
    position: 'absolute',
    right: -4,
    justifyContent: 'center',
  },
  addText: {
    paddingHorizontal: 11,
    paddingVertical: 3,

    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

export const watchlistdata = StyleSheet.create({
  stock: {
    height: 60,
    flex: 1.5,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingTop: 2,
    backgroundColor: 'white',
  },
  stockcomp: {
    flex: 4,
    height: 36,
  },
  Nsetxt: {
    marginLeft: '3%',
    marginTop: '3%',
    height: '50%',
    width: '13%',
    backgroundColor: root.backgroung_exchange_chip_color,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 2,
  },
  index: {
    color: root.color_subtext,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
  Atxt: {
    marginLeft: '2%',
    fontSize: 10,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    // marginTop: 3,
  },
  nertxt: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '55%',
    justifyContent: 'space-between',
  },
  valtxt: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    marginLeft: '4%',
  },
  plustxt: {
    color: root.color_positive,
    fontWeight: '300',
    fontSize: Font.font_normal_six,
  },
  minustxt: {
    color: root.color_negative,
    fontWeight: '300',
    fontSize: Font.font_normal_six,
  },
  volGainerTxt: {
    marginLeft: 3,
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    backgroundColor: root.color_positive_rgb,
  },
  prLoserTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_negative,
    backgroundColor: root.color_negative_rgb,
  },
  defaultTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    fontWeight: 'bold',
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_active,
  },
  stockContainerPositive: {
    alignItems: 'flex-end',
    // justifyContent: 'center',
    // backgroundColor: '#e6ffe6',
  },
  stockContainerNegative: {
    alignItems: 'flex-end',
    // backgroundColor: '#ffe6e6',
  },
  stockPriceText: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  endcom: {
    flex: 0.85,
    alignItems: 'center',
    paddingTop: 5,
    paddingLeft: '1%',
  },
  endT: {
    borderWidth: 1.5,
    height: 26,
    width: 26,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  endTtext: {
    fontWeight: 'bold',
    color: 'black',
  },
  perchantxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  stocktxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  felxrow: {
    flexDirection: 'row',
  },
  flatallign: {
    height: '85%',
    backgroundColor: 'white',
  },
  flexallign: {
    flex: 1,
    backgroundColor: 'white',
  },
});

export const NormodalStyle = StyleSheet.create({
  Normain: {
    // ...alignment.row_alingC_SpaceB,
    flex: 1,
    height: '70%',
    flexDirection: 'row',
    paddingHorizontal: 6,
  },
  Normaininner: {
    flex: 1,
    justifyContent: 'space-between',
    height: Dimensions.get('window').width * 0.292,
    paddingTop: 16,
  },
  watchListText: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  closestyle: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  NorMaxheight: {
    maxHeight: Dimensions.get('window').width * 0.8,
  },
  NorBanner: {
    height: 48,
    width: '100%',
    paddingRight: 10,
  },
  img: {
    height: 20,
    width: 20,
  },
  norModtxt: {
    color: root.ion_rb_2,
    marginLeft: '10%',
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  norModdis: {
    color: root.ion_rb_2,
    marginLeft: '10%',
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  binheart: {
    width: 55,
    ...alignment.row_SpaceB,
  },
  norbannertwo: {
    ...alignment.row,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createWatchListText: {
    paddingLeft: 10,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    color: root.client_background,
  },
  footallign: {
    ...alignment.row_alignC,
    paddingVertical: 10,
    padding: 10,
  },
  btn: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});

export const TrendModalStyle = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  modalView: {
    position: 'absolute',
    //top: Dimensions.get('window').width * 0.9,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    // paddingHorizontal: 15,
    paddingVertical: 20,
    paddingBottom: 0,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    // borderRadius: 10,
  },
  commonTimingView: {
    height: Dimensions.get('window').width * 0.619,
    width: 120,
    alignItems: 'flex-start',
  },
  notificationView: {
    height: 32,
    width: 32,
    borderRadius: 12.5,
    backgroundColor: 'white',
    alignSelf: 'flex-end',
    marginRight: 20,
    right: 0,
    top: -20,
  },
  itemBox: {
    // height: Dimensions.get('window').width * 0.35,
    // width: Dimensions.get('window').width * 0.33,
    height: Dimensions.get('window').width * 0.272,
    width: Dimensions.get('window').width * 0.272,

    borderRadius: 8,
    justifyContent: 'space-around',
    marginHorizontal: 10,
    paddingHorizontal: 10,
    marginBottom: 40,
    marginTop: 40,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 24,
  },
  tradeText: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 10,
    top: -20,
    left: 3,
  },
  image: {
    height: 15,
    width: 15,
  },
  companyNameText: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    top: -20,
    left: 3,
  },
  gainer: {
    backgroundColor: root.color_positive_rgb,
    height: 14,
    width: 60,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -15,
    left: 3,
  },
  gaTxt: {
    marginLeft: 3,
    fontSize: 10,
    fontFamily: Cfont.rubik_medium,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    // backgroundColor: root.color_positive_rgb,
  },
  Loser: {
    backgroundColor: root.color_negative_rgb,
    height: 14,
    width: 52,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -15,
    left: 3,
  },
  Lotxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    // fontWeight: '400',
  },
  lenght: {
    color: root.color_active,
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    backgroundColor: root.color_negative,
    paddingLeft: '5%',
    paddingTop: '2%',
    marginLeft: '6%',
    height: 16,
    width: 20,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewbox: {
    flexDirection: 'row',
    width: '35%',
    // justifyContent: 'space-between',
    alignItems: 'center',
  },
  Donttxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginRight: 10,
  },
  bannerallign: {
    ...alignment.row_alingC_SpaceB,
    paddingHorizontal: 16,
  },
  valpercentage: {
    flexDirection: 'row',
    top: -20,
    left: 3,
  },
  valtxtstyl: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  percentagestyl: {
    color: root.color_negative,
    fontSize: Font.font_normal_seven,
    marginLeft: '3%',
    fontFamily: Cfont.rubik_regular,
  },
});

//Caurosal list style
export const Courselstyles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignSelf: 'center',
    height: '100%',
    zIndex: 100,
     backgroundColor: 'rgba(52, 52, 52, 0.8)',
  },
  scrillview:{
    
      paddingLeft: 16,
      paddingRight: 16,
      backgroundColor: root.color_active,
      maxHeight:'80%'
    
  },
  subContainer: {
    // borderTopLeftRadius: 20,
    // borderTopRightRadius: 20,
    // width: screenWidth - 50,
    //  height: screenHeight / 1.5,
     height: '100%',
    width: '100%',
    bottom: 0,
    // backgroundColor: 'rgba(52, 52, 52, 0.8)',
    alignSelf: 'center',
    position: 'relative',

    // padding: 16,
  },
  subContainertwo: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    // width: screenWidth - 50,
    height: screenHeight / 1.5,
    // height:"100%",
    // width:'100%',
    // top: screenHeight / 4.4,
    bottom: 0,
    // backgroundColor: 'white',
    alignSelf: 'center',
    position: 'absolute',

    // padding: 16,
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 16,
    width:'100%',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor:root.color_active,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
     height: 106,
  },
  companyName_Value_Text: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    padding: 2,
    fontSize: Font.font_normal_five,
  },
  buy_sell_Text: {
    paddingHorizontal: 40,
    fontSize: Font.font_normal_three,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    paddingVertical: 7,
  },
  buttonContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 10,
  },
  ordersView: {
    ...alignment.row_SpaceB,
    marginTop: '4%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  buySellViewContainer: {
    height: 160,
    width: '49%',
  },
  buyText: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  sellText: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  ordersHeaderText: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  progressMain: {
    backgroundColor: root.color_negative_rgb,
    height: 20,
    width: '100%',
    marginTop: '5%',
    alignSelf: 'center',

    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressOuter: {
    width: '50%',
    backgroundColor: root.color_positive_rgb,
    justifyContent: 'center',
    height: 20,
  },
  corhedval: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  chaval: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  iconall: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 2,
  },
  bsesty: {
    marginTop: '3%',
    backgroundColor: '#F0F0F0',
    flexDirection: 'row',
    width: '35%',

    justifyContent: 'space-around',
  },
  txtsty: {
    color: root.color_text,
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
  buysty: {
    backgroundColor: root.color_positive,
    borderRadius: 6,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    width: '47%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  sellsty: {
    backgroundColor: root.color_negative,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 6,
    shadowColor: '#000',
    height: 40,
    width: '47%',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 5,
  },
  Bidtxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  perplus: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  negtxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  oneflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  twoflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txtallign: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  prtitle: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  prval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  prline: {
    height: '5%',
    backgroundColor: 'yellow',
  },
  over: {
    width: '40%',
    height: 60,
    justifyContent: 'space-between',
  },
  threeflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
  },
  endstyle: {
    margin: '1%',
  },
});

export const DotModalStyle = StyleSheet.create({
  dotmodalallign: {
    flexDirection: 'row',
    height: 48,
    alignItems: 'center',
  },
  commonTimingView: {
    height: 300,
    width: 120,
    alignItems: 'flex-start',
  },
  image: {
    height: 14,
    width: 14,
    marginVertical: 10,
    alignSelf: 'flex-end',
  },
  dotmain: {
    color: root.color_text,
    paddingLeft: 20,
    fontSize: Font.font_normal_three,
    paddingVertical: 10,
    fontFamily: Cfont.rubik_regular,
  },
  imgsize: {
    height: 24,
    width: 24,
  },
});
export const SortModal = StyleSheet.create({
  Maincon: {
    flex: 1,
  },
  space: {
    height: 82,
    backgroundColor: 'white',
    marginBottom: 8,
  },
  spacetwo: {
    height: 82,
    backgroundColor: 'white',
    marginBottom: 8,
  },
  spaceinner: {
    backgroundColor: 'white',
    height: 30,
    padding: 16,
    paddingBottom: 0,
  },
  spacetwoinner: {
    backgroundColor: 'white',
    height: 30,
    padding: 16,
    paddingBottom: 0,
  },
  titleText: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: root.client_background,
    height: 40,
    width: 126.86,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F7FA',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtLUnSelected: {
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 10,
    height: 40,
    width: 126.86,
    alignItems: 'center',
    justifyContent: 'center',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    borderColor: root.client_background,
    height: 40,
    width: 81,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F5F7FA',
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  commonHtZUnSelected: {
    borderWidth: 1,
    borderColor: root.color_border,
    borderRadius: 10,
    height: 40,
    // width: 81,
    alignItems: 'center',
    justifyContent: 'center',
    paddingRight: 24,
    paddingLeft: 24,
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    // marginHorizontal:20
  },
  text: {
    color: root.color_text,
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
  },
  Sorttitle: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: '5%',
  },
});

export const CloseModal = StyleSheet.create({
  innermain: {
    flex: 1.5,
    height: '100%',
    alignItems: 'center',
  },
  Wavetitle: {
    fontSize: 20,
    color: 'black',
    marginTop: '15%',
    fontWeight: 'bold',
    marginBottom: '20%',
  },
  leftallign: {
    justifyContent: 'flex-end',
    flex: 3,
    height: '100%',
    paddingBottom: '5%',
  },
  centeredView: {
    flex: 1,

    justifyContent: 'center',
    alignItems: 'center',

    backgroundColor: 'rgba(48,48,48,0.8)',
  },
  modalView: {
    flexDirection: 'row',
    margin: 30,
    height: Dimensions.get('window').height * 0.2,
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 5,

    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
  },
  modalText: {
    marginBottom: 15,
    textAlign: 'left',
    fontSize: 15,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  button: {
    borderRadius: 20,
    height: 30,
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.client_background,
  },
  textStyle: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
  },
  buttontwo: {
    borderRadius: 20,
    height: 30,
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    backgroundColor: 'white',
  },
  textStyletwo: {
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
  },
});

//Constituents screen and its Components
export const constituentsScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  topBar: {
    marginTop: 10,
    // height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  switchBotton: {
    flexDirection: 'row',
    padding: 3,
    backgroundColor: 'rgba(0,0,0,0.07)',
    width: 90,
    borderRadius: 5,
    marginLeft: 10,
    marginTop: 10,
  },
  searchIcon: {
    marginRight: 20,
  },
  leftSwitchButtonWhite: {
    width: '45%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'white',
  },
  leftSwitchButtonTransparent: {
    width: '45%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'transparent',
  },
  rightSwitchButtonWhite: {
    width: '55%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'white',
  },
  rightSwitchButtonTransparent: {
    width: '55%',
    height: 25,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
    backgroundColor: 'transparent',
  },
  searchFilterContainer: {
    flexDirection: 'row',
    marginRight: 20,
    alignItems: 'center',
    marginTop: 10,
  },
  listViewContainer: {
    marginTop: 15,
    marginBottom: 50,
    width: '100%',
  },
  faltListBottomGap: {
    width: '100%',
    marginTop: 23,
    borderBottomWidth: 1,
    borderBottomColor: '#ededed',
  },
});
export const addToWatchListModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '30%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#ffffff',
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  select_watchList_Txt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  watchlistNameTxt: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
    paddingHorizontal: 10,
  },
  innerContainer: {
    height: '100%',
    paddingHorizontal: 10,
    paddingVertical: 16,
  },
  titleTxtContainer: {
    marginLeft: 6,
  },
  listViewContainer: {
    marginTop: '12%',
    height: '65%',
  },
  createWatchListContainer: {
    paddingLeft: 5,
    ...alignment.row,
    alignItems: 'center',
  },
  createWatchListTxt: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
    marginLeft: 10,
  },
  itemContainer: {
    ...alignment.row_alignC,
    marginVertical: '1.7%',
  },
});
export const constituentsListComponent = StyleSheet.create({
  container: {
    // borderBottomColor: 'grey',
    paddingHorizontal: 16,
    backgroundColor: 'yellow',

    // paddingVertical: 3,
    ...alignment.row_SpaceB,
  },
  stockName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    top: -2,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
  nseTxt: {
    fontSize: Font.font_normal_eight,
    // marginTop: 3,
    marginLeft: 5,
    //  backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    // borderColor: '#979797',
    // borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  volGainerTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    borderRadius: 10,
    paddingHorizontal: 5,
    top: -3,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    backgroundColor: '#4caf5026',
    fontFamily: Cfont.rubik_medium,
  },
  prLoserTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_six,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_negative,
    backgroundColor: '#d32f2f26',
    fontFamily: Cfont.rubik_medium,
  },
  defaultTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    borderRadius: 10,
    paddingHorizontal: 5,
    fontWeight: 'bold',
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_active,
  },
  changes: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  rightValuesView_200_300: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',
    // marginRight: 15,
    backgroundColor: root.color_positive_rgb,
  },
  rightValuesView_300_500: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',

    // width: 120,
    // marginRight: 15,
    backgroundColor: root.color_negative_rgb,
  },
  rightValuesDefault: {
    alignItems: 'flex-end',
    width: '100%',
    height: '100%',

    // width: 120,
    // marginRight: 15,
    backgroundColor: root.color_active,
  },
  currentPriceTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
  },
});
export const constituentsBoxComponent = StyleSheet.create({
  container: {
    borderRadius: 10,
    shadowOffset: {width: 1, height: 1},
    shadowColor: '#0000001A',
    shadowOpacity: 0.8,
    marginTop: 10,
    elevation: 5,
    width: (Dimensions.get('window').width - 20) / 2 - 10,
    marginLeft: 5,
    marginBottom: 5,
    height: 130,
    borderColor: '#F4F4F4',
    padding: 10,
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  companyName: {
    color: '#ffffff',
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
  },
  price: {
    color: '#ffffff',
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_four,
  },
  changes: {
    color: 'white',
    fontFamily: Cfont.rubik_regular,
    marginTop: 5,
    fontSize: Font.font_normal_two,
  },
  T_container: {
    width: 30,
    height: 30,
    borderRadius: 40,
    borderWidth: 2,
    borderColor: 'white',
    marginTop: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  T_text: {
    color: 'white',
    fontWeight: '500',
    fontSize: 15,
  },
});

//Overview Screen
export const overViewScreen = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#ffffff',
  },
  keyStatsContainer: {
    backgroundColor: 'white',
    height: 166,
    marginTop: 16,
  },
  keyStatsTxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  innerContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  keyStatsLowerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 16,
  },
  headingTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valuesTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 5,
  },
  horizontalLine: {
    borderWidth: 0.2,
    borderColor: 'grey',
    width: '100%',
    alignSelf: 'center',
    marginTop: 19,
    opacity: 0.3,
  },
  lowToHighTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 12,
  },
  dailyPriceTxt: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
  },
  linearGradient: {
    height: 4,
    width: 135,
    borderRadius: 5,
    marginTop: 6,
  },
});

//Future screen and its components
export const futureScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0)',
  },
});
export const listItem = StyleSheet.create({
  conatiner: {
    padding: 12,
  },
  card: {
    marginTop: 17,
    marginHorizontal: 16,
    backgroundColor: '#FFFFFF',
    height: 110,
    borderRadius: 20,
  },
  date: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  price: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  change: {
    fontSize: Font.font_normal_one,
    paddingTop: 4,
    paddingLeft: 3,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  discountTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
  },
  discount: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingLeft: 3,
    fontFamily: Cfont.rubik_medium,
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
  dayPriceContainer: {
    ...alignment.row_alingC_SpaceB,
  },
  dateYearContainer: {
    ...alignment.row,
  },
  priceChangeContainer: {
    ...alignment.row,
    paddingTop: 10,
  },
  iconsContainer: {
    ...alignment.row,
  },
  plusCircleIcon: {
    marginHorizontal: 5,
  },
  discountConatiner: {
    ...alignment.row,
    paddingTop: 20,
  },
  T_text: {
    fontWeight: 'bold',
    color: 'black',
  },
  yearText: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_light,
    color: root.color_primary,
    marginLeft: 6,
  },
});

//Option chain and its components
export const optionChainScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  callsPutInner: {
    ...alignment.row_SpaceB,
    height: '100%',
  },
  expiryTxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 32,
    paddingLeft: 15,
  },
  dayValueTxtContainer: {
    justifyContent: 'center',
  },
  callsPutTxtContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: 12,
    marginTop: 34,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
  },
  callsPutContainer: {
    height: 150,
  },
  value: {
    fontSize: Font.font_normal_two,
  },
  dayValue: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  dashedLine: {
    width: '100%',
    zIndex: 1,
    position: 'absolute',
    top: 14,
    borderWidth: 0.5,
    borderStyle: 'dashed',
  },
  hexagonContainer: {
    position: 'absolute',
    height: 20,
    zIndex: 1,
    width: '100%',
    left: 110,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
});
export const putModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  dataContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  singleDataContainer: {
    width: '45%',
  },
  topTxtContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  nameValueContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 5,
  },
  horizontalLine: {
    borderWidth: 0.5,
    marginHorizontal: 16,
    borderColor: '#979797',
  },
  callValue: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  callTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  buyBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_positive,
    borderRadius: 10,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
    paddingHorizontal: 16,
  },
});
export const callModal = StyleSheet.create({
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
  dataContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  singleDataContainer: {
    width: '45%',
  },
  nameValueContainer: {
    ...alignment.row_SpaceB,
    paddingVertical: 5,
  },
  topTxtContainer: {
    ...alignment.row_SpaceB,
    padding: 16,
  },
  horizontalLine: {
    borderWidth: 0.5,
    marginHorizontal: 16,
    borderColor: '#979797',
  },
  callValue: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  callTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txt: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  btnTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_active,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  buyBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_positive,
    borderRadius: 10,
  },
  sellBtn: {
    height: 40,
    width: 153.5,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: root.color_negative,
    borderRadius: 10,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 20,
    paddingHorizontal: 16,
  },
});
export const callPutList = StyleSheet.create({
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 22,
    height: 22,
    borderRadius: 22 / 2,
    ...alignment.alignC_justifyC,
  },
  leftContainerView: {
    height: '100%',
    width: 115,
    backgroundColor: '#FFFED6',
  },
  rightContainerView: {
    height: '100%',
    width: 115,
    backgroundColor: '#FFFFFF',
  },
  propertyValueContainer: {
    ...alignment.row,
  },
  leftContainerIconFlexDisplay: {
    paddingVertical: 5,
    alignItems: 'flex-end',
  },
  rightContainerIconFlexFlexDisplay: {
    paddingVertical: 5,
    alignItems: 'flex-start',
  },
  ltpTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiTxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ivValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  oiValue: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  iconsContainer: {
    ...alignment.row,
    width: '60%',
    alignSelf: 'center',
    justifyContent: 'space-between',
    marginTop: 34,
  },
});
export const dateComponent = StyleSheet.create({
  dateContainerUnselected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
  },
  monthYearContainer: {
    ...alignment.row,
  },
  container: {
    paddingLeft: 10,
    paddingTop: 16,
  },
  dateContainerSelected: {
    borderWidth: 0.3,
    height: 48,
    width: 80,
    // marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
    backgroundColor: root.client_background,
  },
  dateTxtUnselected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  dateTxtSelected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  monthTxtUnselected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  monthTxtSelected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
  },
  yearTxtUnselected: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  yearTxtSelected: {
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
  },
  expiryTxt: {
    fontSize: Font.font_normal_seven,
    color: 'grey',
    fontFamily: Cfont.rubik_regular,
    paddingTop: 25,
    paddingLeft: 15,
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});
export const callPutCommonModal = StyleSheet.create({
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  container: {
    position: 'absolute',
    top: '60%',
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    borderTopRightRadius: 15,
    borderTopLeftRadius: 15,
  },
});

//Market Screen and Components styling

export const marketScreen = StyleSheet.create({
  marketContainer: {
    backgroundColor: '#FFFFFF',
    flex: 1,
    // borderBottomColor: root.color_primary,
  },
  marketHeaderView: {
    width: '100%',
    height: 56,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_primary,
    paddingLeft: 17,
    paddingRight: 16,
  },
  marketHeaderIcon: {
    width: 15,
    backgroundColor: '#303030',
    height: 1.8,
    marginVertical: 1.5,
  },
  marketHeaderText: {
    color: root.color_text,
    fontSize: 16,
    marginLeft: 20,
    fontFamily: Cfont.rubik_medium,
  },
  scrollBarBackgroundView: {
    width: '100%',
    paddingHorizontal: 13,
    flexDirection: 'row',
    // alignSelf: 'center',
  },
  scrollBarView: {
    flexDirection: 'row',
    borderRadius: 25,
    // alignItems:"center",
    // justifyContent:"center",
    height: 32,
  },
  scrollView: {
    borderRadius: 25,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.10)',
    marginVertical: 0,
    marginLeft: 0,
    height: 32,
  },
  scrollBarTextBg: {
    paddingHorizontal: 10,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    // backgroundColor: index == 0 ? root.color_textual : 'transparent',
  },
  scrollBarText: {
    fontSize: 11,
    marginHorizontal: 9,
    fontFamily: Cfont.rubik_medium,
  },
  whatsNewHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 14,
  },
  WhatsNewFlatlistFooter: {
    width: 16,
  },
  WhatsNewContentContainer: {
    marginLeft: 16,
  },
  newProductHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newProductFlatList: {
    marginLeft: 16,
  },
  indicesHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  indicesHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 17,
  },
  indicesViewAllBtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
    marginTop: 15,
  },
  indicesFlateList: {
    marginLeft: 16,
  },
  myScreenerHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  myScreenerHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 9,
    marginBottom: 3,
  },
  myScreenerViewAllbtn: {
    color: root.color_textual,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  myScreenerScrollView: {
    marginLeft: 13,
  },
  newsAndAnnounceHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  newAndAnnounceHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  newAndAnnounceSearchBtn: {
    color: root.color_text,
    paddingTop: 16,
  },
  newAndAnnounceFlatListFooter: {
    width: 16,
  },
  newAndAnnounceFlatlist: {
    marginTop: -10,
  },
  newAndAnnounceBottomListView: {
    marginTop: 18,
  },
  viewAllNews: {
    color: root.color_textual,
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
    marginTop: 20,
    marginBottom: 33,
  },
  eventHeadView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingRight: 15,
  },
  eventHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 5,
  },
  eventSearchBtn: {
    color: root.color_text,
    paddingTop: 19,
    marginBottom: 7,
  },
  eventDateView: {
    backgroundColor: root.calendar_bg,
    height: 60,
    width: '100%',
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  eventCurrentDate: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 16,
    fontSize: 15,
  },
  eventCalendarIcon: {
    marginRight: 15,
  },
  eventCalendar: {
    width: '100%',
  },
  eventCalendarTheme: {
    calendarBackground: '#F5F7FA',
    dayTextColor: '#303030',
    textDayFontWeight: '800',
    textDayFontSize: 17,
    textSectionTitleColor: '#303030',
    textSectionTitleFontWeight: '800',
    textDayHeaderFontSize: 17,
    textDayHeaderFontWeight: '800',
  },
  eventFlatList: {
    marginTop: 15,
    marginBottom: 30,
  },
  noEventView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  noEventImage: {
    height: 110,
    width: 115,
    marginTop: 10,
  },
  emptyEventText: {
    color: root.color_subtext,
    fontSize: 14,
    marginBottom: 60,
    marginTop: 13,
    fontFamily: Cfont.rubik_regular,
  },
  ipoHeadText: {
    color: root.color_text,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
    marginTop: 10,
  },
  ipoFlatList: {
    marginLeft: 13,
  },
  ipoFooter: {
    height: 135,
  },
});

export const whatsNewComp = StyleSheet.create({
  whatsNewContainer: {
    // marginLeft: 16,
    height: 127,
    width: Dimensions.get('window').width / 1.25,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    flexDirection: 'row',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    overflow: 'hidden',
  },
  whatsNewTitle: {
    color: '#303030',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 15,
    marginTop: 13,
  },
  whatsNewSubTitle: {
    color: '#303030',
    fontSize: 12,
    marginLeft: 15,
    marginTop: 8,
    fontFamily: Cfont.rubik_regular,
  },
  whatsNewButton: {
    backgroundColor: '#25325C',
    width: 100,
    height: 35,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 15,
    marginTop: 11,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  whatsNewButtonText: {
    color: 'white',
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  whatsNewImage: {
    height: 85,
    width: 90,
    marginTop: 11,
    marginRight: 15,
    backgroundColor: 'white',
  },
});

export const newProductComp = StyleSheet.create({
  container: {
    backgroundColor: '#B6D0E2',
    height: 131,
    width: 171,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
    borderStartColor: '#EFF3FF',
  },
  container2: {
    backgroundColor: '#B6D0E2',
    height: 131,
    width: 171,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
    borderStartColor: '#B4EBCC',
  },
  image: {
    height: 83,
    width: 95,
    marginTop: 15,
    backgroundColor: 'white',
  },
  imageView: {
    height: 83,
    width: 95,
    marginTop: 15,
    backgroundColor: 'white',
  },
});

export const indicesComp = StyleSheet.create({
  container: {
    backgroundColor: root.indices_red,
    height: 133,
    width: 145,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    marginTop: 10,
    paddingBottom: 25,
    fontSize: 13,
  },
  price: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    paddingBottom: 2,
    fontSize: 17,
  },
  changes: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    fontSize: 11,
  },
  date: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_light,
    marginLeft: 12,
    marginTop: 14,
    fontSize: 9,
  },
});

export const myScreenerComp = StyleSheet.create({
  container: {
    backgroundColor: root.color_active,
    height: 115,
    width: 112,
    marginVertical: 10,
    marginBottom: 18,
    marginRight: 13,
    marginLeft: 3,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    paddingTop: 20,
    paddingRight: 18,
    paddingBottom: 18,
    fontSize: 13,
  },
});

export const newsComp = StyleSheet.create({
  container: {
    backgroundColor: root.color_text,
    height: 175,
    width: 150,
    marginVertical: 15,
    borderRadius: 8,
    marginLeft: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    marginLeft: 12,
    marginRight: 15,
    marginBottom: 8,
    marginTop: -7,
  },
  subTitle: {
    color: root.color_active,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    marginRight: 17,
  },
  icon: {
    textAlign: 'right',
    padding: 3,
  },
});

export const newsListComp = StyleSheet.create({
  container: {
    // backgroundColor: '#fff',
    height: 90,
    width: '90%',
    marginTop: 5,
    alignSelf: 'center',
    flexDirection: 'row',
    marginLeft: 16,
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    marginRight: 5,
    paddingBottom: 8,
  },
  time: {
    color: '#303030',
    fontSize: 9,
    paddingTop: 6,
    fontFamily: Cfont.rubik_regular,
  },
  nse: {
    color: root.color_text,
    fontSize: 9,
    fontFamily: Cfont.rubik_medium,
    paddingBottom: 8,
  },
  stockName: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 13,
    paddingBottom: 2,
  },
  price: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: 13,
    paddingBottom: 2,
  },
  changes: {
    color: root.indices_red,
    fontFamily: Cfont.rubik_regular,
    fontSize: 11,
  },
  line: {
    height: 57,
    width: 0.5,
    backgroundColor: 'grey',
    marginTop: 10,
    alignSelf: 'center',
    marginRight: 10,
    opacity: 0.2,
    marginLeft: 8,
  },
  newsLeftView: {
    width: '60%',
  },
});

//Calendar Date event component style

export const dateEventComp = StyleSheet.create({
  container: {
    marginVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: 15,
  },
  subTitle: {
    color: root.color_textual,
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    fontSize: 8,
    width: 45,
    height: 15,
    textAlign: 'center',
    borderRadius: 25,
    marginLeft: 15,
    marginTop: 6,
  },
});

export const ipoComp = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    height: 238,
    width: 195,
    borderRadius: 8,
    marginTop: 20,
    marginVertical: 10,
    marginRight: 13,
    marginLeft: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  innerView: {
    marginLeft: 13,
  },
  imageView: {
    backgroundColor: '#FF6700',
    height: 40,
    width: 40,
    borderRadius: 25,
    marginTop: 10,
    opacity: 0.7,
    justifyContent: 'center',
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 11,
    width: '60%',
    marginTop: 10,
    marginLeft: 6,
  },
  subTitle: {
    color: 'white',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#4CAF50',
    fontSize: 9,
    width: 65,
    height: 17,
    textAlign: 'center',
    borderRadius: 25,
    marginTop: 12,
  },
  pricerRange: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 36,
    fontSize: 11,
  },
  issueDate: {
    color: root.color_text,
    marginTop: 12,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  date: {
    color: root.color_text,
    fontSize: 11,
    fontFamily: Cfont.rubik_regular,
  },
  minQty: {
    color: root.color_text,
    marginTop: 12,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  qty: {
    color: '#303030',
    fontSize: 11,
    fontFamily: Cfont.rubik_regular,
  },
  minAmount: {
    color: root.color_text,
    marginTop: 12,
    fontSize: 11,
    fontFamily: Cfont.rubik_medium,
  },
  amount: {
    color: root.color_text,
    fontSize: 11,
    fontFamily: Cfont.rubik_regular,
  },
  titleAndImgView: {
    flexDirection: 'row',
  },
  imageText: {
    alignSelf: 'center',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    color: 'white',
  },
  minQtyAndAmmountView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginRight: 25,
  },
});

// Porfolio Screen styling

export const portFolioScreen = StyleSheet.create({
  // portFolio Screen
  portFolioContainer: {
    flex: 1,
  },
  // porfolio Material top Tab stayle

  // tabBarLabelStyle: {
  //   fontSize: 12,
  //   fontFamily: 'Rubik-Medium',
  //   textTransform: 'none',
  //   color: '#25335C',
  //   marginBottom: 20,
  // },
  // tabBarStyle: {
  //   height: 40,
  //   elevation: 10,
  // },
  // tabBarIndicatorStyle: {
  //   backgroundColor: '#25335C',
  //   width: 180,
  //   marginLeft: 15,
  //   marginRight: 15,
  //   height: 1.8,
  // },

  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: '#25335C',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  selectedBtnText: {
    textAlign: 'center',
    color: '#25335C',
    fontSize: 12,
    fontFamily: 'Rubik-Medium',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'grey',
    fontSize: 12,
    fontFamily: 'Rubik-Medium',
  },

  //portfolio Header

  portFolioHeaderView: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 7,
  },
  portFolioHeader: {
    marginLeft: 32,
  },
  PortfolioText: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  PortfolioSubTitle: {
    fontSize: Font.font_normal_five,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  PortfolioChanges: {
    fontSize: Font.font_normal_eight,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  portFolioHeaderIconView: {
    paddingLeft: 16,
  },
  portFolioHeaderIcon: {
    width: 15,
    height: 1.8,
    marginVertical: 1.5,
  },

  // Nifty and Sensex Header styling

  currentAndInvestedView: {
    flexDirection: 'row',
    marginTop: 7,
    justifyContent: 'space-between',
  },
  currentValue: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 16,
  },
  currentValueNumber: {
    fontSize: 17,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 16,
  },
  overAllPl: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 16,
    marginTop: 3,
  },
  overAllPlNumber: {
    fontSize: Font.font_normal_seven,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 16,
  },
  investedValue: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  investedValueNumber: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  todaysPl: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    flex: 1,
    paddingTop: 10,
  },
  todaysNumber: {
    fontSize: Font.font_normal_seven,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
});

// Holding Screen Styling

export const holdingScreen = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    flexDirection: 'row',
    color: root.color_active,
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 45,
  },
  headerScripsText: {
    color: root.color_text,
    marginLeft: 16,
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
  },
  headerIconsView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerInfoIcon: {
    marginRight: 15,
  },
  headerSearchIcon: {
    marginRight: 15,
  },
  headerFilterIcon: {
    marginRight: 20,
  },
  holdingFlatlistFooter: {
    width: '100%',
    height: Dimensions.get('window').height / 2.5,
    marginBottom: 50,
  },
  toolkitText: {
    color: root.color_active,
    fontSize: Font.font_normal_eight,
  },
  toolkitView: {
    height: 38,
    width: 200,
    backgroundColor: '#303030',
    borderRadius: 7,
  },
});

// holdingListComponent code
export const holdingListComp = StyleSheet.create({
  container: {
    padding: 3,
    paddingLeft: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 52,
    borderRadius: 7,
    width: '94%',
    alignSelf: 'center',
    backgroundColor: '#FFFFFF',

    marginTop: 6,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    // overflow: 'hidden',
  },
  listTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
  },
  listSubTitle: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 7,
  },
  listPlLtpView: {
    alignItems: 'flex-end',
    marginRight: 5,
  },
  listPlText: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  listLtpText: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 8,
  },
  listPlValue: {
    fontSize: Font.font_normal_six,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  listLtpValue: {
    fontSize: Font.font_normal_six,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    marginTop: 8,
  },
});

//Footer
export const FooterStyles = StyleSheet.create({
  footerContainer: {
    padding: 16,

    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: 'white',
  },
  itemContainer: {
    paddingHorizontal: 12,
    paddingVertical: 4,
  },
  text: {
    fontSize: Font.font_normal_six,
    color: root.client_background,
    fontFamily: Cfont.rubik_medium,
  },
  cliper: {
    borderRadius: 16,
  },
});

//Holding Search Modal

export const HoldingSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
    //   backgroundColor : "#00BCD4",
    //   height: 300 ,
    //   width: '80%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_active,
    //  width: 300,
    //  height: 60,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    marginHorizontal: 13,
  },
  textInput: {
    flex: 1,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
  },
  cleanBtn: {
    fontFamily: Cfont.rubik_medium,
    marginHorizontal: 15,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
});

//position Search modal

export const positionSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
    //   backgroundColor : "#00BCD4",
    //   height: 300 ,
    //   width: '80%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_active,
    //  width: 300,
    //  height: 60,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    marginHorizontal: 13,
  },
  textInput: {
    flex: 1,
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
  },
  cleanBtn: {
    fontFamily: Cfont.rubik_medium,
    marginHorizontal: 15,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
});

// holding Screen bottom Modal
export const holdingBottomModal = StyleSheet.create({
  modalView: {
    // height: 254,
    width: '100%',
    paddingHorizontal: 7,
  },
  stockName: {
    color: root.color_text,
    marginTop: 10,
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
  },
  stockTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    marginVertical: 6,
  },
  stockDetailsView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    marginTop: 12,
  },
  stockDetailsText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
    marginVertical: 6,
  },
  stockDetailsValue: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    marginVertical: 6,
  },
  additionalDetailsText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
  },
  additionalDetailsTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
    marginVertical: 8,
  },
  additionalDetailsValues: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    marginVertical: 8,
  },
  additionalTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 17,
  },
  upDownIcon: {
    marginLeft: 9,
  },
});

// BuySellButton Style
export const BuySellBtn = StyleSheet.create({
  conatiner: title => ({
    // flex: 1,
    backgroundColor: title == 'Buy' ? root.color_positive : root.color_negative,
    borderRadius: 7,
    height: 40,
    // width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  }),
  btnText: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active_text,
  },
});

// position screen Bottom Modal

export const positionBottomModal = StyleSheet.create({
  positionmodalView: {
    // height: 254,
    width: '100%',
    paddingHorizontal: 7,
  },
  positionlistTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    marginTop: 4,
  },
  positiontitleChip: {
    marginLeft: 5,
    backgroundColor: 'rgba(151,151,151,0.1)',
    borderRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  positiontitleChipText: {
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
    color: root.color_subtext,
  },
  positionbuyText: {
    color: root.color_positive,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    marginTop: 7,
  },
  positionlistSubTitle: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 7,
  },
  positionbottomChip: {
    backgroundColor: '#EFF3FF',
    borderRadius: 10,
    marginTop: 10,
    // justifyContent: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 2,
    paddingHorizontal: 4,
  },
  positionbottomChipText: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
  },
  positionlistPlLtpView: {
    alignItems: 'flex-end',
    marginRight: 5,
  },
  positionlistPlText: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginBottom: 10,
  },
  positionlistPlValue: {
    fontSize: Font.font_normal_seven,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    marginBottom: 10,
  },
  positionlistLtpText: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    // marginTop: 3,
  },
  positionlistLtpValue: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    // marginTop: 3,
  },

  positionadditionalDetailsText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
  },
  positionadditionalDetailsTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
    marginVertical: 18,
  },
  positionadditionalDetailsHTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_seven,
    marginBottom: 6,
    marginTop: 12,
  },
  positionadditionalDetailsValues: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_seven,
    marginVertical: 18,
  },
  positionaddtionaldetailsView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  closeIcon: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 4,
  },
  additionalTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 17,
  },
  upDownIcon: {
    marginLeft: 7,
  },
});

//position Bottom modal button

export const positionModalButton = StyleSheet.create({
  conatiner: {
    // flex: 1,
    backgroundColor: 'white',
    borderWidth: 1,
    borderBottomColor: root.color_textual,
    borderRadius: 7,
    height: 40,
    // width: 100,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 23,
    marginTop: 5,
  },
  btnText: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
  },
});

//Holding Screen filter style

export const holdingFilter = (props = {}) =>
  StyleSheet.create({
    Maincon: {
      // flex: 1,
      // backgroundColor: 'red',
      marginBottom: 100,
      marginTop: 20,
    },
    space: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spacetwo: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spaceinner: {
      backgroundColor: 'white',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    spacetwoinner: {
      backgroundColor: 'white',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    titleText: {
      color: root.color_text,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
    },
    commonHtLSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 126,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 10,
      marginTop: 15,
      // marginHorizontal:20
    },

    commonHtZSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 5,
      marginTop: 15,
      // marginHorizontal:20
    },
    commonMinMaxSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor: props.showBoxBorder
        ? root.client_background
        : root.color_border,
      height: 40,
      width: 180,
      // justifyContent: 'space-between',
      backgroundColor: props.showBoxBorder ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 0,
      // marginHorizontal:20
      flexDirection: 'row',
      alignItems: 'center',
    },
    minMaxTextInput: {
      borderBottomColor: 'gray',
      borderBottomWidth: props.showBorder ? 0.8 : 0,
      //   borderWidth: 1,
      height: 20,
      padding: 0,
      margin: 0,
      width: 130,
      flex: 1,
      marginRight: 5,
      textAlign: 'right',
      color: root.client_background,
    },
    minMaxText: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 17,
    },
    text: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
    },

    Sorttitle: {
      fontSize: Font.font_title,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      marginLeft: '5%',
    },
  });

//position Screen styles
export const positionScreen = (props: any) =>
  StyleSheet.create({
    mainView: {
      flex: 1,
      backgroundColor: 'white',
    },
    switchButtonView: {
      width: '100%',
      height: 30,
      alignSelf: 'center',
      borderRadius: 25,
      marginTop: 10,
      flexDirection: 'row',
      paddingHorizontal: 13,
    },
    todaysView: {
      backgroundColor: props?.selectedIndex == 0 ? '#25335C' : 'white',
      height: 30,
      justifyContent: 'center',
      alignItems: 'center',
      width: '50%',
      flex: 1,
      borderTopLeftRadius: 25,
      borderBottomLeftRadius: 25,
      borderWidth: props?.selectedIndex == 0 ? 0 : 0.3,
      borderColor: 'grey',
    },
    todayText: {
      color: props?.selectedIndex == 0 ? 'white' : '#25335C',
      fontFamily: Cfont.rubik_medium,
      fontSize: 12,
    },
    overallView: {
      backgroundColor: props?.selectedIndex == 1 ? '#25335C' : 'white',
      height: 30,
      justifyContent: 'center',
      alignItems: 'center',
      width: '50%',
      flex: 1,
      borderTopEndRadius: 25,
      borderBottomEndRadius: 25,
      borderWidth: props?.selectedIndex == 1 ? 0 : 0.3,
      borderColor: 'grey',
    },
    overallText: {
      color: props?.selectedIndex == 1 ? 'white' : '#25335C',
      fontFamily: Cfont.rubik_medium,
      fontSize: 12,
    },
    header: {
      flexDirection: 'row',
      color: root.color_active,
      justifyContent: 'space-between',
      alignItems: 'center',
      height: 45,
      marginTop: 5,
    },
    todayPlTextValueView: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    todaysPlText: {
      color: root.color_text,
      marginLeft: 16,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_six,
    },
    todaysPlValue: {
      color: root.color_negative,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_six,
    },
    actualPlTextValueView: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 2,
    },
    actualPlText: {
      color: root.color_text,
      marginLeft: 16,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_six,
    },
    actualPlValue: {
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_six,
    },

    headerIconsView: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    headerSearchIcon: {
      marginRight: 15,
    },
    headerFilterIcon: {
      marginRight: 20,
    },
    squareOffView: {
      backgroundColor: '#25335C',
      borderRadius: 25,
      width: 85,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: 20,
      height: 24,
    },
    squareOffViewText: {
      color: 'white',
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_regular,
    },
  });

//position Filter style
export const positionFilter = (props = {}) =>
  StyleSheet.create({
    Maincon: {
      // flex: 1,
      // backgroundColor: 'red',
      marginBottom: 100,
      marginTop: 20,
    },
    space: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spacetwo: {
      // height: 82,
      backgroundColor: 'white',
      marginBottom: 8,
    },
    spaceinner: {
      backgroundColor: 'white',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    spacetwoinner: {
      backgroundColor: 'white',
      height: 30,
      padding: 16,
      paddingBottom: 0,
    },
    titleText: {
      color: root.color_text,
      fontSize: Font.font_normal_one,
      fontFamily: Cfont.rubik_medium,
    },
    commonHtLSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 117,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 10,
      marginTop: 15,
      // marginHorizontal:20
    },

    commonHtZSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor:
        props?.selected == true ? root.client_background : root.color_border,
      height: 40,
      width: 81,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 5,
      marginTop: 15,
      // marginHorizontal:20
    },
    commonMinMaxSelected: {
      borderWidth: 1,
      borderRadius: 10,
      borderColor: props.showBoxBorder
        ? root.client_background
        : root.color_border,
      height: 40,
      width: 180,
      // justifyContent: 'space-between',
      backgroundColor: props.showBoxBorder ? '#F5F7FA' : 'white',
      margin: 12,
      marginRight: 0,
      marginBottom: 0,
      // marginHorizontal:20
      flexDirection: 'row',
      alignItems: 'center',
    },
    minMaxTextInput: {
      borderBottomColor: 'gray',
      borderBottomWidth: props.showBorder ? 0.8 : 0,
      //   borderWidth: 1,
      height: 20,
      padding: 0,
      margin: 0,
      width: 130,
      flex: 1,
      marginRight: 5,
      textAlign: 'right',
      color: root.client_background,
    },
    minMaxText: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
      marginLeft: 17,
    },
    text: {
      color: root.color_text,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_regular,
    },

    Sorttitle: {
      fontSize: Font.font_title,
      fontFamily: Cfont.rubik_medium,
      color: root.color_text,
      marginLeft: '5%',
    },
  });
//ToadysList Component

export const todaysList = StyleSheet.create({
  container: {
    padding: 3,
    paddingLeft: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    height: 85,
    borderRadius: 7,
    width: '94%',
    alignSelf: 'center',
    backgroundColor: '#FFFFFF',
    marginTop: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },
  listTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    marginTop: 4,
  },
  titleChip: {
    marginLeft: 5,
    backgroundColor: 'rgba(151,151,151,0.3)',
    borderRadius: 2,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  titleChipText: {
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
    color: '#979797',
  },
  buyText: {
    color: root.color_positive,
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    marginTop: 7,
  },
  listSubTitle: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    marginTop: 7,
  },
  bottomChip: {
    backgroundColor: '#EFF3FF',
    borderRadius: 10,
    marginTop: 10,
    // justifyContent: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 2,
    paddingHorizontal: 4,
  },
  bottomChipText: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_textual,
  },
  listPlLtpView: {
    alignItems: 'flex-end',
    marginRight: 5,
  },
  listPlText: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginBottom: 10,
  },
  listPlValue: {
    fontSize: Font.font_normal_seven,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    marginBottom: 10,
  },
  listLtpText: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginTop: 4,
  },
  listLtpValue: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 4,
  },
});

// Square Off screen style

export const squareOff = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    width: '100%',
  },
  subContainer: {
    // paddingHorizontal: 18,
    flex: 1,
    width: '100%',
  },
  squareHeaderView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
    paddingHorizontal: 16,
  },
  backIcon: {
    color: root.color_text,
    fontSize: 23,
  },
  squareOffText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    marginLeft: 15,
  },
  orderHeadView: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 30,
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  orderText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  selectAllTextIconView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  selectAllText: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_five,
  },
  selectAllIcon: {
    color: root.color_text,
    fontSize: 24,
    marginLeft: 10,
  },
  headerBorder: {
    color: root.color_subtext,
    borderWidth: 0.2,
    opacity: 0.1,
    marginTop: 15,
    marginHorizontal: 16,
  },
  bottomView: {
    backgroundColor: root.color_textual,
    height: 71,
    width: '100%',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  bottominnerView: {
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomSquareOffText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: '#FFFFFF',
  },
  bottomSelectedText: {
    color: '#FFFFFF',
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_two,
    marginTop: 3,
  },
  bottomDoneBtn: {
    backgroundColor: '#FFFFFF',
    borderRadius: 8,
    height: 43,
    width: 81,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomDoneText: (length: number) => ({
    fontSize: Font.font_normal_two,
    color: length > 0 ? root.color_textual : root.color_subtext,
    fontFamily: Cfont.rubik_medium,
  }),
  bottomCountView: {
    backgroundColor: root.color_negative,
    height: 16,
    width: 20,
    borderRadius: 25,
    marginLeft: 5,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 3,
  },
  bottomCountText: {
    color: '#FFFFFF',
    fontSize: Font.font_normal_eight,
    fontFamily: Cfont.rubik_medium,
  },
});

//square Off list styles
export const squareOffList = (props = {}) =>
  StyleSheet.create({
    container: {
      padding: 3,
      flexDirection: 'row',
      justifyContent: 'space-between',
      height: 120,
      width: '100%',
      alignSelf: 'center',
      backgroundColor:
        props.clicked === true ? 'rgba(211, 47, 47, 0.15)' : '#FFFFFF',
      paddingTop: 15,
      paddingHorizontal: 16,
    },
    listTitle: {
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      fontSize: Font.font_normal_fifteen,
      marginTop: 4,
    },
    titleChip: {
      marginLeft: 5,
      backgroundColor: 'rgba(151,151,151,0.1)',
      borderRadius: 2,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 4,
      // padding: 1,
    },
    titleChipText: {
      fontSize: Font.font_normal_eight,
      fontFamily: Cfont.rubik_medium,
      color: '#979797',
    },
    buyText: {
      color: root.color_positive,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_medium,
      marginTop: 12,
    },
    listSubTitle: {
      fontSize: Font.font_normal_six,
      color: root.color_text,
      fontFamily: Cfont.rubik_light,
      marginTop: 12,
    },
    bottomChip: {
      backgroundColor: '#25335C33',
      borderRadius: 10,
      marginTop: 13,
      // justifyContent: 'center',
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      padding: 2,
      paddingHorizontal: 4,
    },
    bottomChipText: {
      fontSize: Font.font_normal_six,
      fontFamily: Cfont.rubik_medium,
      color: root.color_textual,
    },
    listPlLtpView: {
      alignItems: 'flex-end',
    },
    listPlText: {
      fontSize: Font.font_normal_six,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      // marginBottom: 5,
      marginTop: 4,
    },
    listPlValue: {
      fontSize: Font.font_normal_six,
      color: root.color_negative,
      fontFamily: Cfont.rubik_regular,
      // marginBottom: 10,
      marginTop: 4,
    },
    listLtpText: {
      fontSize: Font.font_normal_seven,
      color: root.color_text,
      fontFamily: Cfont.rubik_medium,
      marginTop: 4,
    },
    listLtpValue: {
      fontSize: Font.font_normal_seven,
      color: root.color_text,
      fontFamily: Cfont.rubik_regular,
      marginTop: 4,
    },
    selectAllIcon: {
      color: root.color_text,
      fontSize: 24,
    },
  });

// Choose Indiecs screen style

export const chooseIndices = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
    paddingHorizontal: 16,
  },
  crossicon: {
    fontSize: Font.font_normal_twenty_six,
    color: root.color_text,
    marginTop: 16,
  },
  title: {
    fontSize: Font.font_sub_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 16,
  },
});

//ChooseIndices Card styles

export const chooseIndicesCard = (props = {}) =>
  StyleSheet.create({
    mainView: {
      backgroundColor: root.choose_indices_background,
      height: 157,
      width: '100%',
      marginTop: 42,
      borderRadius: 8,
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 3,
    },
    innerView: {
      paddingTop: 18,
      paddingHorizontal: 18,
      paddingBottom: 10,
      flexDirection: 'row',
      // justifyContent: 'space-between',
    },
    stockName: {
      color: root.color_active,
      fontSize: Font.font_normal_two,
      fontFamily: Cfont.rubik_medium,
      paddingBottom: 26,
    },
    leftStockprice: {
      color: props.leftPrice > 500 ? root.color_positive : root.color_negative,
      fontSize: Font.font_normal_twenty_two,
      fontFamily: Cfont.rubik_regular,
    },
    rightStockprice: {
      color: props.rightPrice > 500 ? root.color_positive : root.color_negative,
      fontSize: Font.font_normal_twenty_two,
      fontFamily: Cfont.rubik_regular,
    },
    leftStockchanges: {
      color: props.leftPrice > 500 ? root.color_positive : root.color_negative,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_regular,
    },
    rightStockchanges: {
      color: props.rightPrice > 500 ? root.color_positive : root.color_negative,
      fontSize: Font.font_normal_seven,
      fontFamily: Cfont.rubik_regular,
    },
    changeBotton: {
      backgroundColor: root.color_active,
      height: 23,
      width: 69,
      justifyContent: 'center',
      alignItems: 'center',
      borderRadius: 25,
      marginTop: 10,
    },
    changeBottonText: {
      fontSize: Font.font_normal_seven,
      color: root.color_textual,
      fontFamily: Cfont.rubik_medium,
    },
    centerLine: {
      height: '99%',
      width: 0.8,
      backgroundColor: root.color_active,
      opacity: 0.4,
      marginRight: 22,
      marginLeft: 67,
      // position: 'absolute',
    },
  });

// Choose Indices  Modal

export const chooseIndicesModal = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  modal: {
    width: Dimensions.get('window').width,
    height: 300,
    justifyContent: 'center',
    alignItems: 'center',
    //   backgroundColor : "#00BCD4",
    //   height: 300 ,
    //   width: '80%',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
    marginTop: 80,
    marginLeft: 40,
  },
  headerView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: root.color_active,
    width: '100%',
    height: 58,
    shadowColor: '#000',
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  headerTitle: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_ten,
  },
  crossIcon: {
    paddingLeft: 16,
    fontSize: Font.font_normal_twenty_six,
    color: root.color_text,
  },
  searchIcon: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_twenty_six,
    marginRight: 22,
  },
  listView: {
    flex: 1,
    paddingHorizontal: 16,
  },
});

// IndicesList style

export const indicesList = StyleSheet.create({
  mainView: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    marginBottom: 27,
  },
  circleIcon: {
    color: root.color_text,
    fontSize: Font.font_normal_twenty_one,
  },
  title: {
    fontSize: Font.font_normal_five,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 25,
  },
});
//Add to watchList Screen
export const addToWatchList = StyleSheet.create({
  container: {
    flex: 1,
  },
  innerContainer: {
    padding: 16,
  },
  topContainerView: {
    ...alignment.row_SpaceB,
  },
  backIcon: {
    height: 24,
    width: 24,
    color: root.color_text,
  },
  skipContainer: {
    width: 55,
    height: 24,
    borderRadius: 18,
    backgroundColor: root.client_background,
    ...alignment.alignC_justifyC,
  },
  skipTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active_text,
  },
  titleTxt: {
    fontSize: 30,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingBottom: 10,
  },
  titleTxtContainer: {
    height: 82,
    width: '80%',
    marginTop: 32,
  },
  subTitleTxt: {
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 20,
    color: root.color_text,
  },
  textIp: {
    height: 38,
    borderWidth: 1,
    paddingLeft: 16,
    borderTopLeftRadius: 10,
    borderBottomLeftRadius: 10,
    flexGrow: 1,
  },
  textIpContainer: {
    ...alignment.row,
    paddingTop: 20,
  },
  createBtnContainer: {
    width: 90,
    backgroundColor: root.client_background,
    height: 38,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  createTxt: {
    fontSize: 14,
    fontFamily: Cfont.rubik_regular,
    color: '#ffffff4d',
  },
});
//SideDrawer style

export const SideDrawerstyling = StyleSheet.create({
  Maincon: {
    flex: 1,
  },
  slideimgcon: {
    height: '50%',
    width: '75%',
    borderRadius: 20,
    backgroundColor: 'red',
  },
  slideimgcontwo: {
    height: '100%',
    width: '100%',
    borderRadius: 20,
    backgroundColor: 'red',
  },
  imgconstyl: {
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  Innerconstart: {
    height: 200,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 1,
    padding: 10,
  },
  Innercon: {
    height: 70,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    padding: 15,
    borderBottomColor: '#E0E0E0',
  },
  Imgcon: {
    borderRadius:
      Math.round(
        Dimensions.get('window').width + Dimensions.get('window').height,
      ) / 2,
    width: Dimensions.get('window').width * 0.12,
    height: Dimensions.get('window').width * 0.12,
    backgroundColor: 'red',
  },
  imagemain: {
    borderRadius:
      Math.round(
        Dimensions.get('window').width + Dimensions.get('window').height,
      ) / 2,
    width: Dimensions.get('window').width * 0.12,
    height: Dimensions.get('window').width * 0.12,
  },
  texticon: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  Innerconone: {
    height: 90,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderTopWidth: 1,
    borderBottomColor: '#E0E0E0',
    borderTopColor: '#E0E0E0',
    padding: 15,
  },
  stylingtxt: {
    right: '140%',
  },
  protextalign: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  protextaligntwo: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_light,
    paddingLeft: 16,
  },
  Innercotwo: {
    height: 110,
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  Innertwoone: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  Innercothree: {
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  newcontact: {
    borderBottomColor: '#E0E0E0',
    height: 80,
    borderBottomWidth: 1,
  },
  usagecon: {
    height: 50,
    width: '90%',
    borderWidth: 1,
    borderRadius: 10,
    borderColor: '#000080',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  styleb: {
    color: root.client_background,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  radio: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  Lighttxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
    marginRight: 50,
  },
  Darktxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
  },
  Buttomtxtcon: {
    height: 50,
    width: '100%',
    top: -35,
  },
  Innercokyc: {
    height: 190,
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    padding: 15,
  },
  buttontxt: {
    textAlign: 'center',
    alignSelf: 'center',
    marginTop: 15,
    color: 'black',
    fontWeight: '500',
  },
  versiontxt: {
    color: 'black',
    fontSize: 15,
  },
});

// Script View design and Style.

export const Scriptviewstyle = StyleSheet.create({
  maincontainer: {
    flex: 1,
    // paddingHorizontal: 16,
    backgroundColor: root.color_active,
  },
  header: {
    width: '100%',
    height: screenWidth * 0.136,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  detailblock: {
    width: '100%',
    height: screenWidth * 0.163,
    flexDirection: 'row',
    paddingHorizontal: 16,
  },
  detailone: {
    flex: 1.11,
    height: '100%',
  },
  detailtwo: {
    flex: 1,
    height: '100%',
  },
  aligntxt: {
    flexDirection: 'row',
    // marginTop:-2,
  },
  companyname: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: -2,
    marginRight: 5,
  },
  Astyle: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  filtler: {
    height: 16,
    width: 50.53,
    backgroundColor: 'rgba(151, 151, 151, 0.1)',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    alignItems: 'center',
    borderRadius: 2,
    paddingHorizontal: 4,
    borderWidth: 1,
    borderColor: root.color_border,
    marginRight: 5,
  },
  Bsetxtstyle: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_subtext,
    marginRight: 8,
  },
  valtxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
    textAlign: 'right',
    top: -2,
  },
  chgvaltxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    textAlign: 'right',
    marginLeft: 5,
  },
  iconcontainer: {
    height: 32,
    width: screenWidth * 0.346,
    flexDirection: 'row',
    paddingTop: 5,
    justifyContent: 'flex-end',
    alignSelf: 'flex-end',
  },
  byselconatiner: {
    height: screenWidth * 0.136,
    width: '100%',
    paddingTop: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  buycontainer: {
    height: 40,
    width: screenWidth * 0.397,
    backgroundColor: root.color_positive,

    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
  },
  sellconstainer: {
    height: 40,
    width: screenWidth * 0.397,
    backgroundColor: root.color_negative,

    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,

    elevation: 4,
  },
  buyselltxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_regular,
    color: root.color_active,
  },
  circle: {
    borderWidth: 1.5,
    borderRadius: 50,
    height: 24,
    width: 24,
    marginHorizontal: 15,
  },
  headertwo: {
    width: '100%',
    height: screenWidth * 0.141,
    backgroundColor: root.color_active,
    padding: 10,
    // paddingRight: 0,
  },
  innerheadconatiner: {
    flexDirection: 'row',
    width: '100%',
    height: '100%',
  },
  innerflexone: {
    flex: 1.5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  innerflextwo: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  bseflexallign: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  buysmallbtn: {
    width: 42.59,
    height: 24,
    backgroundColor: root.color_positive,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sellsmallbtn: {
    width: 42.59,
    height: 24,
    backgroundColor: root.color_negative,

    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
    marginRight: 5,
  },
  buysellsmalltxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_active,
  },
  dropbox: {
    height: 100,
    width: 100,
    bottom: 0,
    top: 90,
    backgroundColor: 'yellow',
  },
});

export const Overviewstylecom = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innerconatiner: {
    flex: 1,
    marginTop: 16,
    backgroundColor: root.color_active,
    paddingTop: 16,
    paddingHorizontal: 16,
  },
  marketxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  bidcontainer: {
    marginTop: 16,
    paddingBottom: 16,
    height: 171,
    width: '100%',
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
  },
  buySellViewContainer: {
    height: 171,
    width: '49.9%',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
  },
  buyText: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
  },
  buyTextorder: {
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
    textAlign: 'center',
  },
  sellText: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    width: 46,
  },
  sellTextorder: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    textAlign: 'center',
    width: 46,
  },
  sellTextqty: {
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingHorizontal: 4,
    paddingVertical: 2,
    height: 20,
    textAlign: 'right',
    width: 46,
  },
  ordersHeaderText: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    paddingHorizontal: 10,
  },
  totalbidareacontainer: {
    flexDirection: 'row',
    height: 36,
    paddingTop: 16,
    justifyContent: 'space-between',
  },
  totaltxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  progressMain: {
    backgroundColor: root.color_active,
    height: screenWidth * 0.102,
    paddingVertical: 12,
    width: '100%',
    alignSelf: 'center',
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  progressOuter: {
    width: '50%',
    backgroundColor: root.color_positive_rgb,
    justifyContent: 'center',
    height: 16,
  },
  progressnetive: {
    width: '50%',
    backgroundColor: root.color_negative_rgb,
    justifyContent: 'center',
    height: 16,
  },
  perplus: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  negtxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    textAlign: 'right',
  },
  keytxtx: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
  },
  oneflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
    flex: 1,
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  twoflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  txtallign: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  prtitle: {
    fontSize: Font.font_normal_seven,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  prval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  prline: {
    height: '5%',
    backgroundColor: 'yellow',
  },
  over: {
    width: '40%',
    height: 60,
    justifyContent: 'space-between',
  },
  threeflex: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: '5%',
    paddingBottom: '5%',
    borderBottomWidth: 1,
    borderBottomColor: root.color_border,
    flex: 1,
  },
  endstyle: {
    flex: 1,
  },
  endingcom: {
    height: 36,
    width: '100%',
    paddingTop: 16,
    marginBottom: 16,
  },
  Markettxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },

  endnodata: {
    height: 58,
    width: '100%',
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
    alignContent: 'center',
  },
  txtnostyle: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  allflex: {
    flex: 1,
    alignSelf: 'flex-start',
  },

  Tradeview: {
    height: screenWidth * 0.338,
    backgroundColor: root.color_active,
    paddingVertical: 12,
  },
  Tradlistconatiner: {
    height: screenWidth * 0.272,
    width: screenWidth * 0.272,
    backgroundColor: root.color_active,
    marginHorizontal: 9,
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 8,
    borderTopWidth: 1,
    borderTopColor: root.color_border,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 5,
  },
  tradetxt: {
    fontSize: Font.font_normal_four,
    color: root.color_positive,
    fontFamily: Cfont.rubik_medium,
  },

  datetxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  cetxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  changetxtx: {
    fontSize: Font.font_normal_six,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
    paddingLeft: 5,
  },
  changetxtxnegtive: {
    fontSize: Font.font_normal_six,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingLeft: 5,
  },
  valtxt: {
    fontSize: Font.font_normal_six,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  allignvc: {
    flexDirection: 'row',
  },
  R1brokecontainer: {
    height: screenWidth * 0.066,
    width: '100%',
    paddingTop: 10,
  },
  Broketxt: {
    fontSize: Font.font_normal_six,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
    backgroundColor: root.color_positive_rgb,
    height: 14,
    width: 63.88,
    borderRadius: 20,
    textAlign: 'center',
  },
});

export const Eventstylecom = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innerconatiner: {
    height: 52,
    width: '100%',
    paddingHorizontal: 16,
    marginTop: 16,
  },
  innertwo: {
    height: 52,
    width: '100%',
    justifyContent: 'center',
  },
  cortxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  menuitem: {
    backgroundColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    borderWidth: 1,
    borderColor: root.client_background,
    justifyContent: 'center',
    marginBottom: 16,
  },
  menuitemtwo: {
    backgroundColor: root.color_active,
    borderWidth: 1,
    borderColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    justifyContent: 'center',
    marginBottom: 16,
  },
  titletxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
  },
  titletxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },
  calendercontainer: {
    height: 155,
    backgroundColor: 'yellow',
    flexDirection: 'row',
  },
  dateconatiner: {
    marginVertical: 12,
    marginRight: 18,
    height: 128,
    width: 128,
    backgroundColor: root.color_active,
    paddingHorizontal: 8,
    paddingVertical: 12,
    borderRadius: 8,
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderLeftColor: root.color_border,
    borderTopColor: root.color_border,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 5,
  },
  oneflex: {
    // justifyContent: 'space-between',

    flex: 1,
  },
  txttitle: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  txtval: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  allflextwo: {
    flex: 1,
    alignSelf: 'flex-start',
    height: 150,
    width: 150,
  },
  txtdate: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  txtdatetwo: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    paddingLeft: 5,
  },
  dateconatinerinner: {
    flexDirection: 'row',
    marginBottom: 45,
  },
  iconallign: {
    alignItems: 'flex-end',
  },
  emptyview: {
    height: 300,
    width: '100%',
  },
});

export const Recommendationsstyle = StyleSheet.create({
  mainconatiner: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  innercon: {
    marginTop: 16,
    height: screenWidth * 0.18,
    width: '100%',
    padding: 16,
  },
  srytxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_regular,
    color: root.color_subtext,
    textAlign: 'center',
  },
  emptyview: {
    height: 500,
    width: '100%',
  },
});

export const CompanyStyle = StyleSheet.create({
  maincon: {
    flex: 1,
    backgroundColor: root.color_active,
    paddingHorizontal: 16,
  },
  Startcon: {
    marginTop: 32,
  },
  innerView: {},
  listone: {
    height: screenWidth * 0.063,
    paddingVertical: 5,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  txtstyle: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  securitycon: {
    height: screenWidth * 0.127,
    width: '100%',
    paddingVertical: 16,
    marginTop: 16,
  },
  sectxtstyle: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  menuitem: {
    backgroundColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    borderWidth: 1,
    borderColor: root.client_background,
    justifyContent: 'center',
    marginBottom: 32,
  },
  menuitemtwo: {
    backgroundColor: root.color_active,
    borderWidth: 1,
    borderColor: root.client_background,
    height: screenWidth * 0.074,
    borderRadius: 25,
    paddingHorizontal: 12,
    marginTop: 5,
    marginRight: 5,
    justifyContent: 'center',
    marginBottom: 32,
  },
  titletxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
  },
  titletxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },
  allignlast: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    alignItems: 'center',
    flex: 1,
    width: '100%',
  },
  detaistxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    textAlign: 'right',
    width: 180,
  },
  detaistxttwo: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  newallign: {
    width: 379,
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 32,
  },
});

export const Analysisstyle = StyleSheet.create({
  maincon: {
    flex: 1,
    backgroundColor: root.color_active,
    paddingHorizontal: 16,
  },
  innercon: {
    width: '100%',
    height: 700,
  },
});

// Orders screen and its components
export const equitySipCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    height: 81,
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: 'green',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  eqSIP: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  activeTxt:{
    fontSize:Font.font_normal_one,
    fontFamily:Cfont.rubik_medium,
    color:root.color_text
  }
});

export const goodTillDateCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completed:{
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
    paddingRight:5
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: 8,
    paddingBottom:20
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  frequenctTxt: {
    fontSize: 9,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const multiLeg = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completed:{
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
    paddingRight:5
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  date: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

export const singleScriptCard = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  completedTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingRight:5
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const spreadOrders = StyleSheet.create({
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily: Cfont.rubik_medium,
  },
  container: {
    marginHorizontal: 16,
    marginTop: 10,
    backgroundColor: 'white',
    borderRadius: 10,
  },
  companyNameContainer: {
    ...alignment.row_SpaceB,
    padding: 8,
    // height: '100%',
  },
  companyNameTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: '#4caf50',
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  installMent: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  frequenctTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  buyQty: {
    fontFamily: Cfont.rubik_regular,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  sellTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  completedTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingRight:5
  },
});

export const equitySipSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  modifyBtn: {
    width: 171,
    backgroundColor: root.client_background,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelBtn: {
    width: 153,
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  modifyOrderTxt: {
    color: 'white',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  cancelOrderTxt: {
    color: '#25335c',
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
    color:root.color_text
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  installments: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  eqSIP: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const goodTillDateSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 16,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  qty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
});

export const multiLegSheet = StyleSheet.create({
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 32,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  active: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
    paddingTop: 10,
  },
  leg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'center',
  },
  multileg: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    marginLeft: 7,
    alignSelf: 'flex-start',
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  name: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  date: {
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
    fontSize: Font.font_normal_five,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  sellTxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  quantity: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
    paddingTop: 10,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 24,
  },
  orderName: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    top: '70%',
    backgroundColor: 'white',
    paddingHorizontal: 16,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    paddingVertical: 16,
  },
  modalSelectLeg: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  legName: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export const netPositionSheet = StyleSheet.create({
  container: {
    overflow:'hidden'
  },
  netPositionTxt: {
    fontSize: Font.font_title,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 10,
  },
  pL: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_three,
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
    elevation: 3,
    marginTop: 12,
  },
  plContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 16,
  },
  plView: {
    ...alignment.row,
  },
  overAllCard: {
    backgroundColor: root.color_active,
    marginVertical: 10,
    elevation: 3,
    shadowOpacity: 0.5,
  },
  overAllCardInnerContainer: {
    padding: 8,
  },
  companyDetailView: {
    ...alignment.row_SpaceB,
  },
  companyNameView: {
    ...alignment.row,
    alignItems: 'center',
  },
  topView: {
    ...alignment.row,
  },
  qtyPlContainer: {
    ...alignment.row_SpaceB,
    paddingTop: 5,
  },
  buyQty: {
    ...alignment.row,
  },
  deliveryTxt: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  companyNameTxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  ltp: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    color: root.color_negative,
    fontFamily: Cfont.rubik_regular,
  },
  plTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  topPl: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  squareOffTxt: {
    backgroundColor: root.client_background,
    color: root.color_active,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_positive,
    fontFamily: Cfont.rubik_regular,
  },
  eqCombined: {
    fontFamily: Cfont.rubik_medium,
    color: '#979797',
    fontSize: 9,
  },
});

export const singleSheetScript = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  noTrades:{
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
    color: root.color_text,
    paddingTop: 16,
  },
  marketRate: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  nxtDate: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
    paddingTop: 10,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 50,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderHistoryTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: 18,
    color: root.color_text,
    paddingVertical: 32,
  },
  noOrdersTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    alignSelf: 'center',
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  dayTxt: {
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
  },
});

export const spreadOrdersSheet = StyleSheet.create({
  buyTxt: {
    fontSize: Font.font_normal_one,
    color: '#4caf50',
    fontFamily: Cfont.rubik_medium,
  },
  ltp: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  reOrderBtn: {
    backgroundColor: 'white',
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    height: 40,
    marginTop: 42,
    borderWidth: 1,
    borderColor: root.client_background,
  },
  reOrderTxt: {
    color: root.client_background,
    fontSize: 16,
    fontFamily: Cfont.rubik_medium,
  },
  orderDetailsTxt: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
  detailedTitleTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  detailedValueTxt: {
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  companyName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
  },
  linearGradient: {
    height: 2,
    borderRadius: 5,
    marginTop: 6,
  },
  timePeriodTxt: {
    fontSize: Font.font_normal_five,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  executedTxt: {
    paddingTop: 10,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  sellTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_negative,
  },
  buyQty: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_one,
    color: root.color_text,
  },
  plValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_positive,
  },
  plTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  tradesTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingTop: 32,
  },
});

export const headerComp = StyleSheet.create({
  headerView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    backgroundColor: 'white',
    paddingHorizontal: '4%',
    paddingVertical: '2%',
  },
  headerLeftContainer: {
    ...alignment.row_spacebtn,
    alignItems: 'center',
  },
  chooseOrderContainer: {
    paddingLeft: '3%',
    ...alignment.row,
    alignItems: 'center',
  },
  orderTxt: {
    fontSize: Font.font_normal_four,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  chosenOrderTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
});

export const ordersNavigation = StyleSheet.create({
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: 40,
    backgroundColor: 'white',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  selectedBtnText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  tabBtnsText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
  },
  netPositionValueContainer: {
    ...alignment.row_SpaceB,
    paddingHorizontal: '4%',
    alignItems: 'center',
    backgroundColor: '#F0F2F5',
    height: 56,
    paddingVertical: 4,
  },
  netPositionTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_four,
    color: root.color_text,
  },
  pLvalueTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '43%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  modalFullView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '67%',
    backgroundColor: 'white',
    paddingHorizontal: 18,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  modalCompanyTitleView: {
    ...alignment.row_SpaceB,
    alignItems: 'center',
    paddingTop: 10,
  },
  modalCompanyName: {
    ...alignment.row,
    alignItems: 'center',
  },
  additionalDetailsTxt: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: 20,
  },
  btnContainer: {
    ...alignment.row_SpaceB,
  },
  btns: {
    height: 38,
    width: '45%',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: root.client_background,
    borderRadius: 10,
    marginTop: 20,
  },
  squareOffBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    height: 38,
    borderWidth: 1,
    marginTop: 32,
    borderColor: root.client_background,
    borderRadius: 10,
  },
  name: {
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  eqCombined: {
    fontSize:9,
    fontFamily:Cfont.rubik_medium,
    color:'#979797',
    backgroundColor:'#9797971A',
    paddingHorizontal:5,
  },
  todaysPlTxt: {
    fontSize: Font.font_normal_seven,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  todaysPlValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_negative,
  },
  buyTxt: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  buyValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  delivery: {
    fontSize: Font.font_normal_six,
    color: '#25335C',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    paddingHorizontal: 6,
    borderRadius: 30,
    paddingVertical: 1,
    marginLeft: 7,
    alignSelf: 'flex-start',
    marginTop: 5,
  },
  ltpTxt: {
    fontSize: Font.font_normal_one,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  ltpValue: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_positive,
  },
  additionalDetailsText: {
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  btnTxt: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.client_background,
  },

  container: { backgroundColor: '#fff' ,paddingTop:16},
  head: {paddingLeft:'10%'},
  wrapper: { flexDirection: 'row' },
  row: {  height: 48 },
  headText: {
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
  },
  dataText:{
    fontSize:Font.font_normal_one,
    color:root.color_text,
    fontFamily:Cfont.rubik_medium,
    alignSelf:'center'
  }
});

export const ordersModal = StyleSheet.create({
  container: {
    position: 'absolute',
    height: '47%',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  innerContainer: {
    paddingVertical: 15,
    paddingHorizontal: 10,
  },
  orderTxt: {
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  scriptsTxt: {
    fontSize: Font.font_normal_two,
    fontFamily: Cfont.rubik_medium,
    color: '#000000',
  },
  renderItemView: {
    ...alignment.row,
    alignItems: 'center',
    height: 48,
    paddingTop: 16,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
});

export const shiftButton = StyleSheet.create({
  tabBarContainer: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    height: '5%',
    backgroundColor: 'white',
  },
  selectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
    borderBottomWidth: 1,
    borderBottomColor: 'blue',
  },
  unSelectedTabBtns: {
    justifyContent: 'space-around',
    flexGrow: 1,
  },
  tabBtnsText: {
    textAlign: 'center',
    color:root.color_subtext,
    fontFamily:Cfont.rubik_medium
  },
  selectedBtnText: {
    textAlign: 'center',
    color:root.color_text,
    fontFamily:Cfont.rubik_medium
  },
});

import React, {useState} from 'react';
import {TextInput} from 'react-native';

const NumericTextInput = props => {
  const {
    style,
    onChangeText,
    value,
    maxDecimalDigits = Infinity,
    maxIntegerDigits = Infinity,
    maxInputValue = Infinity,
    addZerosOnBlur = false, // Default behavior
    type = 'decimal',
    ...restProps
  } = props;
  const [inputValue, setInputValue] = useState('');
  const [test, settest] = useState(true);

  let integerPart;
  let decimalPart;

  const handleTextChange = val => {
    if (type === 'number' && val.includes('.')) {
      return;
    }
    // Allow only one dot
    if (val.split('.').length > 2) {
      return;
    }

    // Split the value by the decimal point
    const parts = val.split('.');
    integerPart = parts[0];
    decimalPart = parts[1] || '';

    // Calculate total value
    const combinedValue = parseFloat(integerPart + '.' + decimalPart);

    // allow max input value
    if (combinedValue > maxInputValue) {
      return;
    }

    // allow max integer digits
    if (integerPart.length > maxIntegerDigits) {
      return;
    }

    if (decimalPart.length > maxDecimalDigits) {
      return;
    }

    setInputValue(val);
    if (onChangeText) {
      onChangeText(val);
    }
  };

  const handleBlur = () => {
    if (!addZerosOnBlur) {
      return;
    }
    if (!inputValue.toString().includes('.')) {
      setInputValue(inputValue + '.00');
    } else if (inputValue.toString().split('.')[1].length === 1) {
      setInputValue(inputValue + '0');
    }
  };

  const defaultStyle = {
    borderBottomWidth: 1,
    borderBottomColor: '#000000',
    marginLeft: 20,
    width: '20%',
  };

  return (
    <TextInput
      style={style ? style : defaultStyle}
      value={inputValue}
      onChangeText={handleTextChange}
      onBlur={handleBlur}
      keyboardType="decimal-pad"
      {...restProps}
    />
  );
};

export default NumericTextInput;

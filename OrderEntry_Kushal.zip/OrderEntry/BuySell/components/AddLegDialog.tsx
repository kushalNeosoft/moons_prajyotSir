import React, {useState} from 'react';
//import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import {
  View,
  Text,
  TouchableOpacity,
  Modal,
  TouchableNativeFeedback,
  ScrollView,
} from 'react-native';
import CloseIcon from '../../../assets/CloseIcon';
import Futures from '../../Indices/Futures/Futures';
import OptionChain from '../../Indices/OptionChain/OptionChain';
const dates = [
  {
    date: '01',
    month: 'Jun',
    year: '23',
  },
  {
    date: '08',
    month: 'Jun',
    year: '23',
  },
  {
    date: '15',
    month: 'Jun',
    year: '23',
  },
  {
    date: '22',
    month: 'Jun',
    year: '23',
  },
];
const AddLegDialog = (props: any) => {
  const {item} = props;
  const [selectedTab, setSelectedTab] = useState('FUTURE');
  const [selectedDate, setSelectedDate] = useState(0);
  return (
    <Modal
      // animationType="slide"
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <View
        style={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          left: 0,
          right: 0,
          height: '100%',
          backgroundColor: '#f9f9f9',
        }}>
        <View style={{width: '100%', height: '100%'}}>
          <View
            style={{
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 4,
              },
              shadowOpacity: 0.3,
              shadowRadius: 4.65,
              backgroundColor: 'white',
              elevation: 8,
            }}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                props.onClose();
              }}>
              <View style={{width: 40, height: 40, padding: 8}}>
                <CloseIcon
                  style={{width: 24, height: 24, color: root.color_text}}
                />
              </View>
            </TouchableNativeFeedback>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                padding: 16,
              }}>
              <View>
                <Text
                  style={{
                    fontWeight: 'bold',
                    fontSize: 16,
                    color: root.color_text,
                  }}>
                  {item.stockName}
                </Text>
                <View>
                  <Text
                    style={{
                      marginTop: 4,
                      color: 'grey',
                      fontSize: 8,
                      backgroundColor: '#EFF2F2',
                      borderRadius: 2,
                      paddingVertical: 1,
                      paddingHorizontal: 4,
                      // alignSelf: 'center',
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    {item.stockTtile}
                  </Text>
                </View>
              </View>
              <View>
                <Text
                  style={{
                    fontWeight: 'bold',
                    fontSize: 16,
                    color: root.color_text,
                  }}>
                  {item.price}
                </Text>
                <Text
                  style={{
                    fontSize: 14,
                    color: 'red',
                    textAlign: 'right',
                  }}>
                  {item.changes}
                </Text>
              </View>
            </View>
            <View style={{height: 1, backgroundColor: '#11111111'}} />
            <View
              style={{
                flexDirection: 'row',
              }}>
              <View style={{flex: 1}}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setSelectedTab('FUTURE');
                    // setSelectedTab(tab.id);
                  }}>
                  <View>
                    <Text
                      style={{
                        textAlign: 'center',
                        paddingVertical: 12,
                        paddingHorizontal: 16,
                        color:
                          selectedTab === 'FUTURE' ? root.color_text : 'grey',
                        fontFamily: Cfont.rubik_regular,
                      }}>
                      Future
                    </Text>
                    <View
                      style={{
                        height: 2,
                        backgroundColor:
                          selectedTab === 'FUTURE'
                            ? root.client_background
                            : 'transparent',
                        borderRadius: 2,
                        marginHorizontal: 8,
                      }}
                    />
                  </View>
                </TouchableNativeFeedback>
              </View>
              <View style={{flex: 1}}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    // setSelectedTab(tab.id)
                    setSelectedTab('OPTIONS');
                  }}>
                  <View>
                    <Text
                      style={{
                        textAlign: 'center',
                        paddingVertical: 12,
                        paddingHorizontal: 16,
                        color:
                          selectedTab === 'OPTIONS' ? root.color_text : 'grey',
                        fontFamily: Cfont.rubik_regular,
                      }}>
                      Options
                    </Text>
                    <View
                      style={{
                        height: 2,
                        backgroundColor:
                          selectedTab === 'OPTIONS'
                            ? root.client_background
                            : 'transparent',
                        borderRadius: 2,
                        marginHorizontal: 8,
                      }}
                    />
                  </View>
                </TouchableNativeFeedback>
              </View>
            </View>
          </View>

          {selectedTab == 'FUTURE' && <Futures />}
          {selectedTab == 'OPTIONS' && <OptionChain />}

          {/* <ScrollView
            horizontal={true}
            style={{paddingVertical: 12, paddingHorizontal: 16}}>
            {dates.map((date, index) => {
              return (
                <View
                  key={index}
                  style={{
                    borderRadius: 8,
                    overflow: 'hidden',
                    borderWidth: 1,
                    borderColor: 'lightgrey',
                    marginLeft: index != 0 ? 16 : 0,
                  }}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setSelectedDate(index);
                    }}>
                    <View
                      style={{
                        paddingVertical: 6,
                        paddingHorizontal: 16,
                        backgroundColor:
                          selectedDate == index ? 'darkblue' : 'transparent',
                      }}>
                      <Text
                        style={{
                          color: 'black',
                          fontWeight: 'bold',
                          color: selectedDate == index ? 'white' : 'black',
                        }}>
                        01
                      </Text>
                      <Text
                        style={{
                          color: 'black',
                          fontWeight: 'bold',
                          color: selectedDate == index ? 'white' : 'black',
                        }}>
                        Jun '<Text style={{fontWeight: 'normal'}}>23</Text>
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>
              );
            })}
          </ScrollView>

          <Text style={{paddingHorizontal: 16}}>
            4 Expires available till Jun '23
          </Text>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              paddingHorizontal: 16,
              marginTop: 16,
            }}>
            <Text style={{fontWeight: 'bold', color: 'black'}}>Calls</Text>
            <Text style={{fontWeight: 'bold', color: 'black'}}>Puts</Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              width: '100%',
              marginTop: 16,
              alignItems: 'center',
            }}>
            <View
              style={{
                flex: 1,
                borderBottomColor: 'grey',
                borderBottomWidth: 1,
                borderStyle: 'dashed',
                height: 1,
              }}
            />
            <View
              style={{
                backgroundColor: 'black',
                paddingVertical: 4,
                paddingHorizontal: 16,
                borderRadius: 16,
              }}>
              <Text style={{color: 'white'}}>334422</Text>
            </View>
            <View
              style={{
                flex: 1,
                borderBottomWidth: 1,
                borderStyle: 'dashed',
                borderBottomColor: 'grey',
                height: 1,
              }}
            />
          </View> */}
        </View>
      </View>
    </Modal>
  );
};
export default AddLegDialog;

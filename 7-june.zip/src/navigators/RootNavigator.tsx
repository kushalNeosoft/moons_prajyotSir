import {createStackNavigator} from '@react-navigation/stack';
import {FC, useEffect} from 'react';
import React from 'react';
import {useColorScheme} from 'react-native';
import Colors from '../styles/colors';
import useColors from '../styles/useColors';
import { SideDrawerNavigation } from './SideDrawerNavigation/SiderawerStack';

// import { SideDrawerNavigation } from './SiderawerStack';


const RootStack = createStackNavigator();

const RootNavigator: FC = () => {
  const {colors, applyColors} = useColors();
  const colorScheme = useColorScheme();

  useEffect(() => {
    applyColors(colorScheme === 'dark' ? Colors.dark : Colors.light);
  }, [applyColors, colorScheme]);

  return (
    
      <RootStack.Navigator
        screenOptions={{headerShown: false}}
        >
        {/* <RootStack.Screen name="Loginstack" component={LoginStack} /> */}

        <RootStack.Screen name="Dash" component={SideDrawerNavigation} />
        
        
      </RootStack.Navigator>
  
  );
};

export default RootNavigator;

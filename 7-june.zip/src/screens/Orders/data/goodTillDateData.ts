export const goodTillDateOpenOrders=[];
export const goodTillDateCloseOrders=[];
export const goodTillDateAllOrders=[
    {
        name:'INNOVANA',
        buy:'400 Qty @ 300.00',
        qty:'0/400 Qty',
        validity:"29 May'23",
        ltp:305.00
    }
];
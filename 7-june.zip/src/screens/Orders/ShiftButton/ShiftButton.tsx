import {memo} from 'react';
import React from 'react';
import {Text, TouchableHighlight, View, StyleSheet} from 'react-native';
import { shiftButton } from '../../../theme/light';

const RenderButtons=(props:any)=>{
  return(
    <View style={shiftButton.tabBarContainer}>
    {props.buttons &&
      props.buttons.map((btn:any, key:any) => {
        return (
          <TouchableHighlight
            underlayColor={'#F0F2F5'}
            key={key}
            style={
              props.selectedBtn === key
                ? shiftButton.selectedTabBtns
                : shiftButton.unSelectedTabBtns
            }
            onPress={() => props.setButton(key)}>
            <Text
              style={
                props.selectedBtn === key
                  ? shiftButton.selectedBtnText
                  : shiftButton.tabBtnsText
              }>
              {btn}
            </Text>
          </TouchableHighlight>
        );
      })}
  </View>
  )
}


export default memo(RenderButtons);

import React, {useRef} from 'react';
import {View, Text, StyleSheet, TouchableOpacity, FlatList} from 'react-native';
import alignment from '../../../components/utils/alignment';
import Ionicons from 'react-native-vector-icons/Ionicons';
import LinearGradient from 'react-native-linear-gradient';
import BottomSheet from '@gorhom/bottom-sheet';
import { useSelector } from 'react-redux';
import { equitySipSheet } from '../../../theme/light';

const EquitySipSheet = (props: any) => {
  const bottomSheetRef = useRef<BottomSheet>(null);
  const storeEquityData = useSelector(state => state.Reducer.bottomSheetData);
  const orderdetails = [
    {
      title: 'Product Type',
      value: props.allData.productType,
    },
    {
      title: 'Quantity',
      value: props.allData.quantity,
    },
    {
      title: 'Price',
      value: props.allData.price,
    },
    {
      title: 'Cap Price',
      value: props.allData.capPrice,
    },
    {
      title: 'No. of Installments',
      value: props.allData.noOfInstallments,
    },
    {
      title: 'Frequency',
      value: props.allData.frequency,
    },
    {
      title: 'Start Date',
      value: props.allData.startDate,
    },
    {
      title: 'Invested',
      value: props.allData.invested,
    },
    {
      title: 'CMV',
      value: props.allData.CMV,
    },
  ];

  const additionalDetails = [
    {
      title: 'SIP ID',
      value: props.allData.sipId,
    },
    {
      title: 'Transaction Type',
      value: props.allData.transactionType,
    },
    {
      title: 'Order Entry Date',
      value: props.allData.orderEntryDate,
    },
    {
      title: 'Pending Installments',
      value: props.allData.pendingInstallments,
    },
    {
      title: 'Installments Completed',
      value: props.allData.installmentsCompleted,
    },
    {
      title: 'Failed Installments',
      value: props.allData.failedInstallments,
    },
    {
      title: 'Rejection Reason',
      value: props.allData.rejectionReason,
    },
    {
      title: 'Initiated From',
      value: props.allData.initiatedFrom,
    },
    {
      title: 'Modified From',
      value: props.allData.modifiedFrom,
    },
  ];

  return (
    <>
      {props.reachedTop ? (
        <>
          <LinearGradient
            colors={['#d4d4d4', '#e9e9e9']}
            style={equitySipSheet.linearGradient}
            useAngle={true}
          />
        </>
      ) : null}
      <View style={{...alignment.row_SpaceB, alignItems: 'center'}}>
        <View>
          {!props.reachedTop && (
            <Text style={equitySipSheet.companyName}>{props.allData.name}</Text>
          )}
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={equitySipSheet.buyTxt}>Buy : </Text>
            <Text style={equitySipSheet.marketRate}>{props.allData.buy}</Text>
          </View>
          <View
            style={{...alignment.row, alignItems: 'center', paddingTop: 10}}>
            <Text style={equitySipSheet.dayTxt}>{props.allData.day} </Text>
            <Text style={equitySipSheet.eqSIP}>EQ SIP</Text>
          </View>
          <Text
            style={
              equitySipSheet.nxtDate
            }>{`Next date : ${props.allData.nextDate}`}</Text>
        </View>
        <View style={{height: '90%', alignItems: 'center'}}>
          {!props.reachedTop && (
            <View style={{height: 27, ...alignment.row}}>
              <Text style={equitySipSheet.activeTxt}>Active</Text>
              <Ionicons name="md-at-circle-outline" size={15} />
            </View>
          )}
          <Text style={equitySipSheet.installments}>{props.allData.installments}</Text>
          <Text style={equitySipSheet.ltp}>{`LTP : ${props.allData.ltp}`}</Text>
        </View>
      </View>
      {/*  */}
      <View style={{height: 40, ...alignment.row_SpaceB, marginTop: 16}}>
        <TouchableOpacity style={equitySipSheet.modifyBtn}>
          <Text style={equitySipSheet.modifyOrderTxt}>Modify Order</Text>
        </TouchableOpacity>
        <TouchableOpacity style={equitySipSheet.cancelBtn}>
          <Text style={equitySipSheet.cancelOrderTxt}>Cancel Order</Text>
        </TouchableOpacity>
      </View>
      {/*  */}
      <Text style={equitySipSheet.orderHistoryTxt}>Order History</Text>
      <Text style={equitySipSheet.noOrdersTxt}>
        No order so far : Next Order due on 7 May'23{' '}
      </Text>
      {/*  */}
      <Text style={equitySipSheet.orderDetailsTxt}>Order Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20}}>
        <FlatList
          data={orderdetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={equitySipSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={equitySipSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
      {/*  */}
      <Text style={equitySipSheet.orderDetailsTxt}>Additional Details</Text>
      {/*  */}
      <View style={{paddingVertical: 20, marginBottom: 50}}>
        <FlatList
          data={additionalDetails}
          renderItem={({item}) => (
            <View style={{...alignment.row, paddingTop: 10}}>
              <View style={{width: '40%'}}>
                <Text style={equitySipSheet.detailedTitleTxt}>{item.title}</Text>
              </View>
              <View style={{width: '60%'}}>
                <Text style={equitySipSheet.detailedValueTxt}>{item.value}</Text>
              </View>
            </View>
          )}
        />
      </View>
    </>
  );
};

export default EquitySipSheet;

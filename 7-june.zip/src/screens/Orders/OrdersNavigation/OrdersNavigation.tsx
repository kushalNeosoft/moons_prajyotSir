import React, {memo, useEffect, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Modal,
} from 'react-native';
import Bottomsheet from '../../../components/BottomSheet/BottomSheet';
import alignment from '../../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import EquitySipSheet from '../Component/EquitySipSheet';
import {Table, Row, Rows,Col,TableWrapper} from 'react-native-table-component';
import { ordersNavigation } from '../../../theme/light';
import {
  selectOpenOrders,
  selectCompletedOrders,
  selectAllOrders,
} from '../helpers/SelectOrder';
import SingleScriptComp from '../Component/SingleScript';
import NetPosition from '../Component/NetPosition';
import SpreadOrdersComp from '../Component/SpreadOrders';
import GoodTillDateComp from '../Component/GoodTillDate';
import MultiLegComp from '../Component/MultiLegComp';
import RenderButtons from '../ShiftButton/ShiftButton';
import RenderCardView from '../helpers/RenderCardView';
import HeaderComp from '../HeaderComp/HeaderComp';
import { useDispatch } from 'react-redux';
import { changeScriptName, showInBottomSheetData } from '../../../redux/Action';

const OrdersNavigation = React.forwardRef((props: any, ref) => {
  const buttons = ['Open', 'Completed', 'All Orders'];
  const [reachedTop, setReachedTop] = useState(false);
  const [selectedBtn, setSelectedBtn] = useState<number>(0);
  const [allData, setAllData] = useState({});
  const [openNetPosition, setOpenNetPosition] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalData, setModalData] = useState<object>({});
  const [additionalDetailsVisible, setAdditionalDetailsVisible] =
    useState(false);

  const tableHead = ['', 'Qty', 'Avg Price', 'Total Value'];
  const tableData = [
    ['1', '7.05', '7.05'],
    ['0', '0.00', '0.00'],
    ['1', '7.05', '-7.05'],
  ];
  const tableTitle=['Buy','Sell','Net'];
  const dispatch=useDispatch();

  useEffect(()=>{
    dispatch(changeScriptName(props.scriptName))
  },[])

  const open = () => {
    return (
      <FlatList
        style={{flex: 1}}
        data={selectOpenOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const completed = () => {
    return (
      <FlatList
        data={selectCompletedOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const allOrders = () => {
    return (
      <FlatList
        data={selectAllOrders(props.scriptName)}
        renderItem={({item}) => (
          <RenderCardView
            item={item}
            scriptName={props.scriptName}
            openSheet={openSheet}
          />
        )}
      />
    );
  };

  const renderView = (tabName: string) => {
    switch (tabName) {
      case buttons[0]:
        return open();
      case buttons[1]:
        return completed();
      case buttons[2]:
        return allOrders();
    }
  };

  const closeModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const renderComponent = () => {
    if (openNetPosition) {
      dispatch(changeScriptName('Net Position'))
      return <NetPosition openModal={openModal} reachedTop={reachedTop} closeModal={closeModal}/>;
    } else {
      switch (props.scriptName) {
        case 'Single Script Orders':
          return <SingleScriptComp allData={allData} reachedTop={reachedTop} />;
        case 'Equity SIP':
          return <EquitySipSheet allData={allData} reachedTop={reachedTop} />;
        case 'Spread Orders':
          return <SpreadOrdersComp allData={allData} reachedTop={reachedTop} />;
        case 'Good Till Date':
          return <GoodTillDateComp allData={allData} reachedTop={reachedTop} />;
        case 'Multileg Orders':
          return <MultiLegComp allData={allData} reachedTop={reachedTop} />;
      }
    }
  };

  const getHeightValue = (value: boolean) => {
    setReachedTop(value);
  };

  const openSheet = async (item?: object) => {
    setOpenNetPosition(false);
    setAllData(item);
    dispatch(showInBottomSheetData(item));
    dispatch(changeScriptName(props.scriptName))
    await props.onPress();
  };

  const netPositionSheetView = async () => {
    setOpenNetPosition(true);
    // setAllData({name:'himanshu',age:24}) pas value like this for the header
    await props.onPress();
  };

  const openModal = () => {
    setModalVisible(prevState => !prevState);
  };

  const setSelectedButton = (value: any) => {
    setSelectedBtn(value);
  };

  const addtionalDetailsComp = () => {
    return (
      <View style={ordersNavigation.container}>
        <Table >
          <Row data={tableHead}  style={ordersNavigation.head} textStyle={ordersNavigation.headText}/>
          <TableWrapper style={ordersNavigation.wrapper}>
            <Col data={tableTitle} heightArr={[48,48]} textStyle={ordersNavigation.headText}/>
            <Rows data={tableData} flexArr={[1, 1,1]} style={ordersNavigation.row} textStyle={ordersNavigation.dataText}/>
          </TableWrapper>
        </Table>
      </View>
    );
  };

  return (
    <View style={{flex: 1}}>
      <HeaderComp
        orderModalToggle={props.orderModalToggle}
        scriptName={props.scriptName}
      />
      <View style={ordersNavigation.netPositionValueContainer}>
        <TouchableOpacity
          style={{...alignment.row, alignItems: 'center'}}
          onPress={netPositionSheetView}>
          <Text style={ordersNavigation.netPositionTxt}>Net Position</Text>
          <AntDesign
            name="caretdown"
            size={10}
            color={'black'}
            style={{paddingLeft: '4%'}}
          />
        </TouchableOpacity>
        <Text style={ordersNavigation.pLvalueTxt}>Today's P/L: 0</Text>
      </View>
      <RenderButtons
        buttons={buttons}
        selectedBtn={selectedBtn}
        setButton={setSelectedButton}
      />
      {renderView(buttons[selectedBtn])}
      <Bottomsheet
        ref={ref}
        index={props.index}
        getHeightValue={getHeightValue}
        closeSheet={() => props.closeSheet()}
        scriptName={props.scriptName}
        allData={allData}>
        {renderComponent()}
      </Bottomsheet>
      <Modal visible={modalVisible} transparent={true}>
        <View
          style={ordersNavigation.centeredView}
        />
        <View style={additionalDetailsVisible?ordersNavigation.modalFullView: ordersNavigation.modalView}>
          <TouchableOpacity onPress={()=>setModalVisible(prevState=>!prevState)}>
          <AntDesign
            name="close"
            size={24}
            color={'black'}
            style={{alignSelf: 'flex-end'}}
          />
          </TouchableOpacity>
          <View style={ordersNavigation.modalCompanyTitleView}>
            <View style={ordersNavigation.modalCompanyName}>
              <Text style={ordersNavigation.name}>IDEA</Text>
              <Text style={ordersNavigation.eqCombined}>EQ Combined</Text>
            </View>
            <View style={ordersNavigation.modalCompanyName}>
              <Text style={ordersNavigation.todaysPlTxt}>Today's P/L : </Text>
              <Text style={ordersNavigation.todaysPlValue}>0.05(0.71%)</Text>
            </View>
          </View>
          <View style={ordersNavigation.modalCompanyTitleView}>
            <View style={ordersNavigation.modalCompanyName}>
              <Text style={ordersNavigation.buyTxt}>Buy</Text>
              <Text style={ordersNavigation.buyValue}>1 Qty @ ₹7.05</Text>
            </View>
            <View style={ordersNavigation.modalCompanyName}>
              <Text style={ordersNavigation.ltpTxt}>LTP : </Text>
              <Text style={ordersNavigation.ltpValue}>7.05(0.71%)</Text>
            </View>
          </View>
          <Text style={ordersNavigation.delivery}>Delivery</Text>
          <TouchableOpacity
            style={ordersNavigation.additionalDetailsTxt}
            onPress={() =>
              setAdditionalDetailsVisible(prevState => !prevState)
            }>
            <Text style={ordersNavigation.additionalDetailsText}>Additional Details</Text>
            {!additionalDetailsVisible ? (
              <AntDesign
                name="caretdown"
                size={10}
                color={'black'}
                style={{paddingLeft: '4%'}}
              />
            ) : (
              <AntDesign
                name="caretup"
                size={10}
                color={'black'}
                style={{paddingLeft: '4%'}}
              />
            )}
          </TouchableOpacity>
          {additionalDetailsVisible ? <>{addtionalDetailsComp()}</> : null}
          <View style={ordersNavigation.btnContainer}>
            <View style={ordersNavigation.btns}>
              <Text style={ordersNavigation.btnTxt}>Convert Position</Text>
            </View>
            <View style={ordersNavigation.btns}>
              <Text style={ordersNavigation.btnTxt}>Add More</Text>
            </View>
          </View>
          <TouchableOpacity style={ordersNavigation.squareOffBtn}>
            <Text style={ordersNavigation.btnTxt}>Square Off</Text>
          </TouchableOpacity>
        </View>
      </Modal>
    </View>
  );
});


export default memo(OrdersNavigation);

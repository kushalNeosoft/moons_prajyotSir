import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { callPutList } from '../../../../../theme/light';

function CallPutList(props: any) {
  return (
    <TouchableOpacity
      activeOpacity={1}
      style={
        props.leftView === true
          ? callPutList.leftContainerView
          : callPutList.rightContainerView
      }
      onPress={() => props.modalView()}>
      <View
        style={
          props.leftView === true
            ? callPutList.leftContainerIconFlexDisplay
            : callPutList.rightContainerIconFlexFlexDisplay
        }>
        <View style={callPutList.propertyValueContainer}>
          <Text style={callPutList.ltpTxt}>{`${props.ltpTxt}:`}</Text>
          <Text style={callPutList.ltpValue}>{props.ltpValue}</Text>
        </View>
        <View style={callPutList.propertyValueContainer}>
          <Text style={callPutList.ivTxt}>{`${props.ivTxt}:`}</Text>
          <Text style={callPutList.ivValue}>{props.ivValue}</Text>
        </View>
        <View style={callPutList.propertyValueContainer}>
          <Text style={callPutList.oiTxt}>{`${props.oiTxt}:`}</Text>
          <Text style={callPutList.oiValue}>{props.oiValue}</Text>
        </View>
        <View style={callPutList.iconsContainer}>
          {props.leftView === true ? (
            <>
              <TouchableOpacity onPress={()=>props.showAddToWatchlistModal()}>
                <AntDesign name="pluscircleo" size={22} color="black" />
              </TouchableOpacity>
              <TouchableOpacity style={callPutList.bottonView}>
                <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
              </TouchableOpacity>
            </>
          ) : (
            <>
              <TouchableOpacity style={callPutList.bottonView}>
                <Text style={{fontWeight: 'bold', color: 'black'}}>T</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={()=>props.showAddToWatchlistModal()}>
                <AntDesign name="pluscircleo" size={22} color="black" />
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default CallPutList;

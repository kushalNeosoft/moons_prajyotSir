import React from 'react';
import {ScrollView, Text, View} from 'react-native';
import {Recommendationsstyle} from '../../../theme/light';

const Recommendations: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  return (
    <ScrollView
      style={Recommendationsstyle.mainconatiner}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Recommendationsstyle.innercon}>
        <Text style={Recommendationsstyle.srytxt}>
          Sorry! We don't have any recommendations for the scrip
        </Text>
      </View>
      <View style={Recommendationsstyle.emptyview}/>
    </ScrollView>
  );
};

export default Recommendations;

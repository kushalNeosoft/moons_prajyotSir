import React from 'react';
import {ScrollView} from 'react-native';
import {Touchable} from 'react-native';
import {TouchableOpacity} from 'react-native';
import {View, Text} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import { companymodaldata } from '../../../../assets/demoData';
import CommonModal from '../../../../components/CommonModal/CommonModal';


import { root } from '../../../../styles/colors';
import {Companymodalstyle, Eventmodaistyle, Eventstylecom} from '../../../../theme/light';

export const Companymodal = (props: any) => {
    console.log('companydata=====>>><<<<-======',props?.companydata?.title);
    
  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
        <View style={Eventmodaistyle.header}>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
      </TouchableOpacity>
      <View style={Companymodalstyle.maincon}>
        <Text style={Companymodalstyle.titletxt}>{props?.companydata?.title}</Text>
        <Text style={Companymodalstyle.desctxt}>{props?.companydata?.value}</Text>
        <View style={Companymodalstyle.partconatiner}>
              <Text style={Companymodalstyle.txtstyleindes}>-</Text>
            </View>
      </View>
      {companymodaldata.map((item, index) => {
          return (
            <View style={Companymodalstyle.listoneone}>
              <Text style={Companymodalstyle.txtstyletwo}>{item.title}</Text>
              <Text style={Companymodalstyle.txtstyle}>{item.value}</Text>
            </View>
          );
        })}
    </CommonModal>
  );
};
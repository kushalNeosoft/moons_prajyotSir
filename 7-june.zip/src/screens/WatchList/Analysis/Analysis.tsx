import { useNavigation } from "@react-navigation/native";
import React, { useState } from "react";
import { ScrollView, Text, TouchableOpacity, View } from "react-native";
import { Analysisstyle, positionScreen } from "../../../theme/light";

const Analysis: React.FC =({route}: any)=>{
    const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState([]);
  const [handleRefresh, setHandleRefresh] = useState(false);
  const navigation = useNavigation();

    return(
        <ScrollView
      style={Analysisstyle.maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
         <View style={Analysisstyle({selectedIndex}).switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).todaysView}>
          <Text style={Analysisstyle({selectedIndex}).todayText}>
            Technicals 
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({selectedIndex}).overallView}>
          <Text style={Analysisstyle({selectedIndex}).overallText}>
            Fundamentals 
          </Text>
        </TouchableOpacity>
      </View>
        <View style={Analysisstyle.innercon} />

      </ScrollView>
    )
}

export default Analysis;
import React from 'react';
import {ScrollView, TouchableOpacity} from 'react-native';
import {FlatList, Text, View} from 'react-native';
import {
  courselDemodata,
  endDemodata,
  Itemtrade,
  marketdata,
  newDemodata,
  newsecondDemodata,
  progressData,
  tradeData,
} from '../../../assets/demoData';
import alignment from '../../../components/utils/alignment';
import {styles} from '../../../navigators/Curverbottom';
import {Overviewstylecom} from '../../../theme/light';
import {buyData, sellData} from '../WatchListComponent/CarouselList/constData';

const Overview: React.FC = ({route}:any) => {
//   const {item} = route.params;
console.log(route.params,"hsashkahskahshak");

  const setScrollValue = route.params.setScrollValue;

  const renderItem = ({item}: {item: Itemtrade}) => (
    <View style={Overviewstylecom.Tradlistconatiner}>
      <Text style={Overviewstylecom.tradetxt}>{item?.title}</Text>
      <Text style={Overviewstylecom.datetxt}>{item?.date}</Text>
      <Text style={Overviewstylecom.cetxt}>{item?.cevalue}</Text>
      <View style={Overviewstylecom.allignvc}>
        <Text style={Overviewstylecom.valtxt}>{item?.value}</Text>
        {item?.ptive == 'true' ? (
          <>
            <Text style={Overviewstylecom.changetxtx}>{item?.change}</Text>
          </>
        ) : (
          <>
            <Text style={Overviewstylecom.changetxtxnegtive}>
              {item?.change}
            </Text>
          </>
        )}
      </View>
      <View style={Overviewstylecom.R1brokecontainer}>
        <Text style={Overviewstylecom.Broketxt}>{item?.Broken}</Text>
      </View>
    </View>
  );

  const sellView = () => {
    return (
      <View style={Overviewstylecom.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={Overviewstylecom.ordersHeaderText}>Ask</Text>
          <Text style={Overviewstylecom.ordersHeaderText}>Orders</Text>
          <Text style={Overviewstylecom.ordersHeaderText}>Qty</Text>
        </View>
        <FlatList
          data={sellData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={Overviewstylecom.sellText}>{item.ask}</Text>
              <Text style={Overviewstylecom.sellTextorder}>{item.orders}</Text>
              <Text style={Overviewstylecom.sellTextqty}>{item.qty}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  const buyView = () => {
    return (
      <View style={Overviewstylecom.buySellViewContainer}>
        <View style={{...alignment.row_SpaceB}}>
          <Text style={Overviewstylecom.ordersHeaderText}>Qty</Text>
          <Text style={Overviewstylecom.ordersHeaderText}>Orders</Text>
          <Text style={Overviewstylecom.ordersHeaderText}>Bid</Text>
        </View>
        <FlatList
          data={buyData}
          renderItem={({item}) => (
            <View style={{...alignment.row_SpaceB, padding: 4}}>
              <Text style={Overviewstylecom.buyText}>{item.qty}</Text>
              <Text style={Overviewstylecom.buyTextorder}>{item.orders}</Text>
              <Text style={Overviewstylecom.buyText}>{item.bid}</Text>
            </View>
          )}
        />
      </View>
    );
  };

  return (
    <ScrollView
      nestedScrollEnabled
      style={Overviewstylecom.mainconatiner}
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
            setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}
      >
   
      <View style={Overviewstylecom.innerconatiner} key={1}>
        <Text style={Overviewstylecom.marketxt}>Market Depth</Text>
        <View style={Overviewstylecom.bidcontainer}>
          {buyView()}
          {sellView()}
        </View>
        <View style={Overviewstylecom.totalbidareacontainer}>
          <Text style={Overviewstylecom.totaltxt}>Total Bids</Text>
          <Text style={Overviewstylecom.totaltxt}>Total Asks</Text>
        </View>
        <View style={Overviewstylecom.progressMain}>
          <View style={Overviewstylecom.progressOuter}>
            <Text style={Overviewstylecom.perplus}>10</Text>
          </View>
          <View style={Overviewstylecom.progressnetive}>
            <Text style={Overviewstylecom.negtxt}>30</Text>
          </View>
        </View>
        <Text style={Overviewstylecom.keytxtx}>Key Stats</Text>
        <View style={Overviewstylecom.oneflex}>
          {courselDemodata.map(item => {
            return (
              <View style={Overviewstylecom.allflex}>
                <Text style={Overviewstylecom.txttitle}>{item.title}</Text>
                <Text style={Overviewstylecom.txtval}>{item.value}</Text>
                <Text style={Overviewstylecom.txtval}>{item.valuetwo}</Text>
              </View>
            );
          })}
        </View>
        <View style={Overviewstylecom.twoflex}>
          {progressData.map(item => {
            return (
              <View style={Overviewstylecom.over}>
                <Text style={Overviewstylecom.prtitle}>{item.title}</Text>
                <View style={Overviewstylecom.prline} />
                <View style={Overviewstylecom.txtallign}>
                  <Text style={Overviewstylecom.prval}>{item.price}</Text>
                  <Text style={Overviewstylecom.prval}>{item.pricetwo}</Text>
                </View>
              </View>
            );
          })}
        </View>
        <View style={Overviewstylecom.threeflex}>
          {newDemodata.map(item => {
            return (
              <View style={Overviewstylecom.endstyle}>
                <Text style={Overviewstylecom.txttitle}>{item.title}</Text>
                <Text style={Overviewstylecom.txtval}>{item.value}</Text>
              </View>
            );
          })}
        </View>
        <View style={Overviewstylecom.threeflex}>
          {newsecondDemodata.map(item => {
            return (
              <View style={Overviewstylecom.endstyle}>
                <Text style={Overviewstylecom.txttitle}>{item.title}</Text>
                <Text style={Overviewstylecom.txtval}>{item.value}</Text>
              </View>
            );
          })}
        </View>
        <View style={Overviewstylecom.threeflex}>
          {marketdata.map(item => {
            return (
              <View style={Overviewstylecom.endstyle}>
                <Text style={Overviewstylecom.txttitle}>{item.title}</Text>
                <Text style={Overviewstylecom.txtval}>{item.value}</Text>
              </View>
            );
          })}
        </View>
        <View style={Overviewstylecom.endingcom}>
          <Text style={Overviewstylecom.Markettxt}>Market Pulse</Text>
        </View>
      </View>
      <View style={Overviewstylecom.Tradeview} key={2}>
        <FlatList
          style={{paddingHorizontal:6}}
          data={tradeData}
          renderItem={renderItem}
          keyExtractor={(item,index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </View>
      

      
     </ScrollView>
  );
};

export default Overview;

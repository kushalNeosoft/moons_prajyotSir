import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {newsComp} from '../../../theme/light';

const NewsComponent = props => {
  return (
    <TouchableOpacity style={newsComp.container}>
      <Ionicons
        name="md-notifications-circle"
        size={20}
        color={'white'}
        style={newsComp.icon}
      />
      <Text style={newsComp.title}>{props.title}</Text>
      <Text style={newsComp.subTitle}>{props.subTitle}</Text>
    </TouchableOpacity>
  );
};
export default NewsComponent;

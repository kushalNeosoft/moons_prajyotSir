import React from 'react';
import {View,Text} from 'react-native';

const Global = ()=>{
    return(<View>

    </View>)
}
export default Global
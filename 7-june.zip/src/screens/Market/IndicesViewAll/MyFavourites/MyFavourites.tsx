import React from 'react';
import {View,Text} from 'react-native';

const MyFavourites = ()=>{
    return(<View>

    </View>)
}
export default MyFavourites
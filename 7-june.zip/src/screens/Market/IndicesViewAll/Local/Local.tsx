import React from 'react';
import {View, Text} from 'react-native';

const Local = () => {
  return <View></View>;
};
export default Local;

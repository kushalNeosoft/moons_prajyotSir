import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {View, Text} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {portFolioScreen} from '../../../../theme/light';

const TopHeader = props => {
  const navigation = useNavigation();
  return (
    <View>
      <View style={portFolioScreen.currentAndInvestedView}>
        <View>
          <Text style={portFolioScreen.currentValue}>{props.leftTopText}</Text>
          <Text style={portFolioScreen.currentValueNumber}>
            ₹ {props.currentVal}
          </Text>
          <Text style={portFolioScreen.overAllPl}>{props.leftBottomText}</Text>
          <Text style={portFolioScreen.overAllPlNumber}>
            ₹ {props.overallPL}
          </Text>
        </View>
        <View
          style={{
            marginRight: 18,
            alignItems: 'flex-end',
          }}>
          <Text style={portFolioScreen.investedValue}>
            {props.rightTopText}
          </Text>
          <Text style={portFolioScreen.investedValueNumber}>
            ₹ {props.investedVal}
          </Text>
          <Text style={portFolioScreen.todaysPl}>{props.rightBottomText}</Text>
          <Text style={portFolioScreen.todaysNumber}>₹ {props.todaysPL}</Text>
        </View>
      </View>
    </View>
  );
};
export default TopHeader;

import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {root} from '../../../styles/colors';
import {positionFilter} from '../../../theme/light';
import MinMaxInput from './MinMaxInput';
import {ScrollView} from 'react-native-gesture-handler';

const PositionFilter = () => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [quantityValue, setQuantityValue] = useState('');
  const [cmvValue, setcmvValue] = useState('');
  const [daysPlValue, setDaysPlValue] = useState('');
  const [overallPlValue, setOverallPlValue] = useState('');
  const [daysPlPercentage, setDaysPlPercentage] = useState('');
  const [overallPlPercentage, setOverallPlPercenatge] = useState('');
  const [textInputLine, setTextInputLine] = useState(false);
  const [productValue, setProductValue] = useState('');
  const [positionValue, setPositionValue] = useState('');
  const [segmentValue, setSegmentValue] = useState('');

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['Low to High', 'High to Low'];
  const quantity = ['Low to High', 'High to Low'];
  const product = ['Delivery'];
  const position = ['Open', 'Close'];
  const segment = ['All', 'All Combined', 'EQ Combined'];
  const [daysPlRange, setDaysPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);

  return (
    <View>
      <View style={positionFilter().Maincon}>
        <View style={positionFilter().space}>
          <View style={positionFilter().spaceinner}>
            <Text style={positionFilter().titleText}>Alphabetically</Text>
          </View>

          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabetValue(item)}
                style={
                  positionFilter({selected: alphabetValue === item})
                    .commonHtZSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>Quantity</Text>
          </View>

          <FlatList
            horizontal={true}
            data={quantity}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setQuantityValue(item)}
                style={
                  positionFilter({selected: quantityValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>
              Current Mraket Value(CMV)
            </Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setcmvValue(item)}
                style={
                  positionFilter({selected: cmvValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>Day's P/L</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlValue(item)}
                style={
                  positionFilter({selected: daysPlValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlRange}
                item={item}
                rangeArr={daysPlRange}
              />
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>Product</Text>
          </View>

          <FlatList
            horizontal={true}
            data={product}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setProductValue(item)}
                style={
                  positionFilter({selected: productValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>Position</Text>
          </View>

          <FlatList
            horizontal={true}
            data={position}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setPositionValue(item)}
                style={
                  positionFilter({selected: positionValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter().spacetwo}>
          <View style={positionFilter().spacetwoinner}>
            <Text style={positionFilter().titleText}>Segment</Text>
          </View>

          <FlatList
            horizontal={true}
            data={segment}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setSegmentValue(item)}
                style={
                  positionFilter({selected: segmentValue === item})
                    .commonHtLSelected
                }>
                <Text style={positionFilter().text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
    </View>
  );
};
export default PositionFilter;

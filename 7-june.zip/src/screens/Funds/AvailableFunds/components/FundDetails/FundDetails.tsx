import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SectionList,
  FlatList,
} from 'react-native';
import List from '../List/List';
import alignment from '../../../../../components/utils/alignment';

const FundDetails = () => {

  const data = [
    {
      name: 'Himanshu',
      age: '23',
      city: 'Mumbai',
    },
  ];

  const keys=['Deposit','Collateral','Credit For Sale','Option CFS','Limit Utilization','Funds Withdrawal/Allocation','MTM Profit/Loss','Booked Profit/Loss']
  
  return (
    <View style={styles.container}>
        <TouchableOpacity>
            <Text>Deposit</Text>
            <List  data={data} dataTwo={keys}/>
        </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  titleContainer: {
    ...alignment.row_SpaceB,
  },
});

export default FundDetails;

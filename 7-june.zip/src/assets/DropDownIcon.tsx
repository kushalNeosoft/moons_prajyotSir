import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const DropDownIcon = (props: any) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    fill={'currentColor'}
    viewBox="0 96 960 960"
    {...props}>
    <Path d="M480 696 280 497h400L480 696Z" />
  </Svg>
);
export default DropDownIcon;

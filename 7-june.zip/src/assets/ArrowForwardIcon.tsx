import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

export default function ArrowForwardIcon(props: any) {
  return (
    <Svg
      xmlns="http://www.w3.org/2000/svg"
      fill={'currentColor'}
      viewBox="0 96 960 960"
      {...props}>
      <Path d="M480 896l-42-43 247-247H160v-60h525L438 299l42-43 320 320-320 320z" />
    </Svg>
  );
}

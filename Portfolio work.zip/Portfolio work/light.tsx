// Replace Styles

// First
export const portFolioScreen = StyleSheet.create({
  portFolioContainer: {
    flex: 1,
  },
  tabBarContainer: {
    ...alignment.row,
    ...p.h_16,
    height: 40,
    ...bgColor.color_active,
  },
  selectedTabBtns: {
    justifyContent: "space-around",
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: root.color_textual,
  },
  unSelectedTabBtns: {
    justifyContent: "space-around",
    flexGrow: 1,
    borderBottomWidth: 2,
    borderBottomColor: "transparent",
  },
  selectedBtnText: {
    textAlign: "center",
    ...color.client_background,
    ...size_family.rm_12,
  },
  tabBtnsText: {
    textAlign: "center",
    ...color.subtext,
    ...size_family.rm_12,
  },

  // Nifty and Sensex Header styling

  currentAndInvestedView: {
    ...m.t_8,
    ...alignment.row_SpaceB,
  },
  currentValue: {
    ...size_family.rm_9,
    ...color.text,
    ...m.m_l_16,
  },
  currentValueNumber: {
    ...size_family.rr_17,
    ...color.text,
    ...m.m_l_16,
  },
  overAllPl: {
    ...color.text,
    ...size_family.rm_9,
    ...m.m_l_16,
    ...m.t_3,
  },
  overAllPlNumber: {
    ...color.positive,
    ...size_family.rr_11,
    ...m.m_l_16,
  },
  investedValue: {
    ...color.text,
    ...size_family.rm_9,
  },
  investedValueNumber: {
    ...color.text,
    ...size_family.rr_11,
  },
  todaysPl: {
    ...color.text,
    ...size_family.rm_9,
    flex: 1,
    ...p.t_10,
  },
  todaysNumber: {
    color: root.color_negative,
    ...size_family.rr_11,
  },
});

// Second

export const holdingFilter = StyleSheet.create({
  Maincon: {
    width: Dimensions.get("window").width,
  },
  contentView: {
    ...m.b_100,
    ...m.t_20,
  },
  space: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spacetwo: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spaceinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  spacetwoinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  titleText: {
    ...color.text,
    ...size_family.rm_12,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 126,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },

  commonAtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 81,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_5,
    ...m.t_15,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
  applyBtn: {
    width: "100%",
    ...bgColor.client_background,
    height: 50,
    ...alignment.alignC_justifyC,
    position: "absolute",
    bottom: 0,
  },
  applyBottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});

// Third

export const positionFilter = StyleSheet.create({
  Maincon: {
    width: Dimensions.get("window").width,
  },
  contentView: {
    ...m.b_100,
    ...m.t_20,
  },
  space: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spacetwo: {
    ...bgColor.color_active,
    ...m.b_8,
  },
  spaceinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  spacetwoinner: {
    ...bgColor.color_active,
    height: 30,
    ...p.p_16,
    ...p.b_0,
  },
  titleText: {
    ...color.text,
    ...size_family.rm_12,
  },
  commonHtLSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 117,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },

  commonAtZSelected: {
    borderWidth: 1,
    borderRadius: 10,
    // borderColor:
    //   props?.selected == true ? root.client_background : root.color_border,
    height: 40,
    width: 81,
    ...alignment.alignC_justifyC,
    // backgroundColor: props?.selected == true ? '#F5F7FA' : 'white',
    ...m.m_12,
    ...m.r_0,
    ...m.b_10,
    ...m.t_15,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
  applyBtn: {
    width: "100%",
    ...bgColor.client_background,
    height: 50,
    ...alignment.alignC_justifyC,
    position: "absolute",
    bottom: 0,
  },
  applyBottonText: {
    ...color.active,
    ...size_family.rm_14,
  },
});

// Fourth

export const holdingScreen = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  header: {
    ...alignment.row_alingC_SpaceB,
    height: 45,
    ...m.v_1,
  },
  headerScripsText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rl_12,
  },
  headerIconsView: {
    ...alignment.row_alignC,
  },
  headerInfoIcon: {
    ...m.r_15,
  },
  headerSearchIcon: {
    ...m.r_15,
  },
  headerFilterIcon: {
    ...m.r_20,
  },
  holdingFlatlistFooter: {
    width: "100%",
    height: Dimensions.get("window").height / 2.5,
    ...m.b_50,
  },
  toolkitText: {
    ...color.active,
    ...size_family.rr_9,
  },
  toolkitView: {
    height: 38,
    width: 200,
    backgroundColor: root.color_text,
    borderRadius: 7,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...m.m_l_16,
    flexWrap: "wrap",
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_5,
  },
  ammountTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_8,
  },
  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
    ...m.t_10,
  },
  filterTagData: {
    ...size_family.rm_10,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
});

//Fifth

export const BuySellBtn = StyleSheet.create({
  conatiner: {
    borderRadius: 7,
    height: 40,
    ...alignment.alignC_justifyC,
    ...m.b_16,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },
  btnText: {
    ...color.active,
    ...size_family.rr_14,
  },
});

// six

export const holdingListComp = StyleSheet.create({
  container: {
    ...p.p_3,
    ...p.l_10,
    // ...alignment.row_SpaceB,
    height: 75,
    borderRadius: 7,
    width: "94%",
    alignSelf: "center",
    ...bgColor.color_active,
    ...m.t_6,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    // overflow: 'hidden',
  },
  listTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...p.t_2,
  },
  listSubTitle: {
    ...size_family.rr_11,
    ...color.text,
    ...p.t_7,
  },
  listPlLtpView: {
    alignItems: "flex-end",
    ...m.r_5,
  },
  listPlText: {
    ...size_family.rr_11,
    ...color.text,
    ...m.t_10,
  },
  listLtpText: {
    ...size_family.rr_11,
    ...color.text,
    ...p.t_2,
  },
  listPlValue: {
    ...size_family.rr_11,
    ...p.t_10,
  },
  listLtpValue: {
    ...size_family.rr_11,
    ...m.t_2,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  rowSpaceBetween: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  rowSpaceBetweenCenter: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
});

// seven

export const holdingBottomModal = StyleSheet.create({
  modalView: {
    width: "100%",
    ...p.h_7,
  },
  stockName: {
    ...color.text,
    ...m.t_10,
    ...size_family.rm_14,
  },
  stockTitle: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_6,
  },
  stockDetailsView: {
    ...alignment.row_SpaceB,
    ...m.b_10,
    ...m.t_12,
  },
  stockDetailsText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_6,
  },
  stockDetailsValue: {
    ...size_family.rr_11,
    ...m.v_6,
  },
  additionalDetailsText: {
    ...color.text,
    ...size_family.rm_11,
  },
  additionalDetailsTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_8,
  },
  additionalDetailsValues: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_8,
  },
  additionalTextIconView: {
    ...alignment.row_alignC,
    ...m.t_17,
  },
  upDownIcon: {
    ...m.m_l_9,
  },
  row: {
    ...alignment.row,
  },
  additionDetailView: {
    ...alignment.row_SpaceB,
    ...m.b_28,
    ...m.t_22,
  },
  rowSpaceBtween: {
    ...alignment.row_SpaceB,
  },
});

//Eight

export const HoldingSearchModal = StyleSheet.create({
  modal: {
    width: Dimensions.get("window").width,
    height: "100%",
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: "center",
    ...m.t_100,
  },
});

// Nine

export const positionScreen = StyleSheet.create({
  mainView: {
    flex: 1,
    ...bgColor.color_active,
  },
  switchButtonView: {
    width: "100%",
    height: 30,
    alignSelf: "center",
    borderRadius: 25,
    ...m.t_10,
    ...alignment.row,
    ...p.h_13,
  },
  todaysView: {
    height: 30,
    ...alignment.alignC_justifyC,
    width: "50%",
    flex: 1,
    borderTopLeftRadius: 25,
    borderBottomLeftRadius: 25,
  },
  todayText: {
    ...size_family.rm_12,
  },
  overallView: {
    height: 30,
    ...alignment.alignC_justifyC,
    width: "50%",
    flex: 1,
    borderTopEndRadius: 25,
    borderBottomEndRadius: 25,
  },
  overallText: {
    ...size_family.rm_12,
  },
  header: {
    color: root.color_active,
    ...alignment.row_alingC_SpaceB,
    height: 45,
    ...m.t_5,
  },
  todayPlTextValueView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
  todaysPlText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rm_10,
  },
  todaysPlValue: {
    color: root.color_negative,
    ...size_family.rm_10,
  },
  actualPlTextValueView: {
    ...alignment.row_alignC,
    ...m.t_2,
  },
  actualPlText: {
    ...color.text,
    ...m.m_l_16,
    ...size_family.rm_10,
  },
  actualPlValue: {
    ...color.text,
    ...size_family.rm_10,
  },
  headerIconsView: {
    ...alignment.row_alignC,
  },
  headerSearchIcon: {
    ...m.r_15,
  },
  headerFilterIcon: {
    ...m.r_20,
  },
  squareOffView: {
    backgroundColor: root.color_textual,
    borderRadius: 25,
    width: 85,
    ...alignment.alignC_justifyC,
    ...m.r_20,
    height: 24,
  },
  squareOffViewText: {
    ...color.active,
    ...size_family.rr_12,
  },
  filterMainView: {
    ...alignment.row_alignC,
    ...p.p_1,
    ...p.l_16,
    flexWrap: "wrap",
    ...m.t_3,
  },
  filterText: {
    ...size_family.rr_13,
    ...color.text,
  },
  filterTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_5,
  },
  ammountTag: {
    ...size_family.rl_11,
    ...color.text,
    ...m.m_l_8,
  },

  filterDataView: {
    ...alignment.row_alignC,
    ...bgColor.backgroung_exchange_chip_color,
    ...p.p_3,
    borderRadius: 5,
    ...m.m_l_5,
    ...m.t_10,
  },
  filterTagData: {
    ...size_family.rm_10,
    ...color.text,
    ...p.l_4,
  },
  closeIcon: {
    ...color.text,
    fontSize: 20,
    ...p.l_8,
  },
});

// Ten

export const positionModalButton = StyleSheet.create({
  conatiner: {
    // flex: 1,
    ...bgColor.color_active,
    borderWidth: 1,
    borderBottomColor: root.color_textual,
    borderRadius: 7,
    height: 40,
    // width: 100,
    ...alignment.alignC_justifyC,
    ...m.b_23,
    ...m.t_5,
  },
  btnText: {
    ...size_family.rm_14,
    color: root.color_textual,
  },
});

// Eleven

export const positionSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: "100%",
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_16,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rr_15,
    alignSelf: "center",
    ...m.t_100,
  },
});

// Tweleve

export const todaysList = StyleSheet.create({
  container: {
    ...p.p_3,
    ...p.l_10,
    ...alignment.row_SpaceB,
    height: 85,
    borderRadius: 7,
    width: "94%",
    alignSelf: "center",
    ...bgColor.color_active,
    ...m.t_8,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
  },
  listTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...m.t_4,
  },
  titleChip: {
    ...m.m_l_5,
    backgroundColor: "rgba(151,151,151,0.1)",
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...m.t_4,
  },
  titleChipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  buyText: {
    color: root.color_positive,
    ...size_family.rm_11,
    ...m.t_7,
  },
  listSubTitle: {
    ...size_family.rl_10,
    ...color.text,
    ...m.t_7,
  },
  bottomChip: {
    backgroundColor: "#EFF3FF",
    borderRadius: 10,
    ...m.t_10,
    ...alignment.alignC_justifyC,
    ...alignment.row,
    ...p.p_2,
    ...p.h_4,
  },
  bottomChipText: {
    ...size_family.rm_10,
    ...color.client_background,
  },
  listPlLtpView: {
    alignItems: "flex-end",
    ...m.r_5,
  },
  listPlText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_10,
  },
  listPlValue: {
    ...size_family.rr_11,
    ...m.b_10,
  },
  listLtpText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.t_4,
  },
  listLtpValue: {
    ...color.text,
    ...size_family.rr_11,
    ...m.t_4,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  subView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
  row: {
    ...alignment.row,
  },
});

// Thirteen

export const positionBottomModal = StyleSheet.create({
  positionmodalView: {
    // height: 254,
    width: "100%",
    ...p.h_7,
  },
  positionlistTitle: {
    ...color.text,
    ...size_family.rm_14,
    ...m.t_4,
  },
  positiontitleChip: {
    ...m.m_l_5,
    backgroundColor: "rgba(151,151,151,0.1)",
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...m.t_4,
  },
  positiontitleChipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  positionbuyText: {
    color: root.color_positive,
    ...size_family.rm_11,
    ...m.t_7,
  },
  positionlistSubTitle: {
    ...color.text,
    ...size_family.rl_10,
    ...m.t_7,
  },
  positionbottomChip: {
    backgroundColor: "#EFF3FF",
    borderRadius: 10,
    ...m.t_10,
    ...alignment.row,
    ...alignment.alignC_justifyC,
    ...p.p_2,
    ...p.h_4,
  },
  positionbottomChipText: {
    ...size_family.rm_10,
    color: root.color_textual,
  },
  positionlistPlLtpView: {
    alignItems: "flex-end",
    ...m.r_5,
  },
  positionlistPlText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_10,
  },
  positionlistPlValue: {
    color: root.color_negative,
    ...size_family.rr_11,
    ...m.b_10,
  },
  positionlistLtpText: {
    ...color.text,
    ...size_family.rm_11,
    // marginTop: 3,
  },
  positionlistLtpValue: {
    ...color.text,
    ...size_family.rr_11,
    // marginTop: 3,
  },

  positionadditionalDetailsText: {
    ...color.text,
    ...size_family.rm_11,
  },
  positionadditionalDetailsTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.v_18,
  },
  positionadditionalDetailsHTitle: {
    ...color.text,
    ...size_family.rm_11,
    ...m.b_6,
    ...m.t_12,
  },
  positionadditionalDetailsValues: {
    ...color.text,
    ...size_family.rr_11,
    ...m.v_18,
  },
  positionaddtionaldetailsView: {
    ...alignment.row_SpaceB,
    ...m.b_10,
  },
  closeIcon: {
    ...alignment.row,
    justifyContent: "flex-end",
    ...m.t_4,
  },
  additionalTextIconView: {
    ...alignment.row_alignC,
    ...m.t_17,
  },
  upDownIcon: {
    ...m.m_l_8,
  },
  row: {
    ...alignment.row,
  },
  rowAlignC: {
    ...alignment.row_alignC,
  },
  rowSpacebetween: {
    ...alignment.row_SpaceB,
  },
  subView: {
    ...alignment.row,
    ...alignment.alignC_justifyC,
  },
});

// Add This new Style Object..........

export const minMaxcomp = StyleSheet.create({
  commonMinMaxSelected: {
    borderWidth: 1,
    borderRadius: 10,
    height: 40,
    width: 180,
    margin: 12,
    marginRight: 0,
    marginBottom: 0,
    ...alignment.row_alignC,
  },
  minMaxTextInput: {
    borderBottomColor: root.color_subtext,
    height: 20,
    padding: 0,
    margin: 0,
    width: 130,
    flex: 1,
    ...m.r_5,
    textAlign: "right",
    color: root.client_background,
  },
  minMaxText: {
    ...color.text,
    ...size_family.rr_14,
    ...m.m_l_17,
  },
  text: {
    ...color.text,
    ...size_family.rr_14,
  },
});

// Below is Current Padding And Margin OF global Styles just Copy and Past..............................

// margin

export const margin = {
  m_l_5: {
    marginLeft: 5,
  },
  m_l_6: {
    marginLeft: 6,
  },
  m_l_4: {
    marginLeft: 4,
  },
  m_l_3: {
    marginLeft: 3,
  },
  m_l_10: {
    marginLeft: 10,
  },
  m_l_9: {
    marginLeft: 9,
  },
  m_l_8: {
    marginLeft: 8,
  },
  m_l_15: {
    marginLeft: 15,
  },
  m_l_13: {
    marginLeft: 13,
  },
  m_l_16: {
    marginLeft: 16,
  },
  m_l_17: {
    marginLeft: 17,
  },
  m_l_32: {
    marginLeft: 32,
  },
  m_l_70: {
    marginLeft: 70,
  },
  m_12: {
    margin: 12,
  },
  t_26: {
    marginTop: 26,
  },
  t_25: {
    marginTop: 25,
  },
  t_18: {
    marginTop: 18,
  },
  t_20: {
    marginTop: 20,
  },
  t_21: {
    marginTop: 21,
  },
  t_17: {
    marginTop: 17,
  },
  t_23: {
    marginTop: 23,
  },
  t_22: {
    marginTop: 22,
  },
  t_28: {
    marginTop: 28,
  },
  t_10: {
    marginTop: 10,
  },
  t_11: {
    marginTop: 11,
  },
  t_58: {
    marginTop: 58,
  },
  t_14: {
    marginTop: 14,
  },
  t_15: {
    marginTop: 15,
  },
  t_12: {
    marginTop: 12,
  },
  t_13: {
    marginTop: 13,
  },
  t_30: {
    marginTop: 30,
  },
  t_31: {
    marginTop: 30,
  },
  t_34: {
    marginTop: 30,
  },
  t_35: {
    marginTop: 35,
  },
  t_36: {
    marginTop: 36,
  },
  t_42: {
    marginTop: 42,
  },
  t_40: {
    marginTop: 40,
  },
  t_41: {
    marginTop: 41,
  },
  t_45: {
    marginTop: 45,
  },
  t_8: {
    marginTop: 8,
  },
  t_48: {
    marginTop: 48,
  },
  t_50: {
    marginTop: 50,
  },
  t_100: {
    marginTop: 50,
  },
  t_16: {
    marginTop: 16,
  },
  t_6: {
    marginTop: 6,
  },
  t_7: {
    marginTop: 7,
  },
  t_5: {
    marginTop: 5,
  },
  t_4: {
    marginTop: 4,
  },
  t_2: {
    marginTop: 2,
  },
  t_3: {
    marginTop: 3,
  },
  b_8: {
    marginBottom: 8,
  },
  b_7: {
    marginBottom: 7,
  },
  b_12: {
    marginBottom: 12,
  },
  b_16: {
    marginBottom: 16,
  },
  b_18: {
    marginBottom: 18,
  },
  b_20: {
    marginBottom: 20,
  },
  b_23: {
    marginBottom: 23,
  },
  b_28: {
    marginBottom: 28,
  },
  b_30: {
    marginBottom: 30,
  },
  b_5: {
    marginBottom: 5,
  },
  b_32: {
    marginBottom: 32,
  },
  b_35: {
    marginBottom: 35,
  },
  b_60: {
    marginBottom: 60,
  },
  b_50: {
    marginBottom: 50,
  },
  b_100: {
    marginBottom: 100,
  },
  b_15: {
    marginBottom: 15,
  },
  b_14: {
    marginBottom: 14,
  },
  b_6: {
    marginBottom: 6,
  },
  b_9: {
    marginBottom: 9,
  },
  b_10: {
    marginBottom: 10,
  },
  b_0: {
    marginBottom: 0,
  },
  h_13: {
    marginHorizontal: 13,
  },
  h_16: {
    marginHorizontal: 16,
  },
  h_35: {
    marginHorizontal: 35,
  },
  r_12: {
    marginRight: 12,
  },
  r_13: {
    marginRight: 13,
  },
  r_15: {
    marginRight: 12,
  },
  r_25: {
    marginRight: 25,
  },
  r_20: {
    marginRight: 20,
  },
  r_30: {
    marginRight: 30,
  },
  r_10: {
    marginRight: 10,
  },
  r_5: {
    marginRight: 5,
  },
  r_0: {
    marginRight: 0,
  },
  v_20: {
    marginVertical: 20,
  },
  v_10: {
    marginVertical: 10,
  },
  v_6: {
    marginVertical: 6,
  },
  v_8: {
    marginVertical: 8,
  },
  v_1: {
    marginVertical: 1,
  },

  v_16: {
    marginVertical: 16,
  },
  v_18: {
    marginVertical: 18,
  },
};

// Padding

const padding = {
  16: {
    padding: 16,
  },
  l_25: {
    paddingLeft: 25,
  },
  l_20: {
    paddingLeft: 20,
  },
  r_15: {
    paddingRight: 15,
  },
  r_30: {
    paddingRight: 30,
  },
  r_10: {
    paddingRight: 10,
  },
  r_6: {
    paddingRight: 6,
  },
  r_11: {
    paddingRight: 11,
  },
  h_3: {
    paddingHorizontal: 3,
  },
  l_5: {
    paddingLeft: 5,
  },
  l_4: {
    paddingLeft: 4,
  },
  l_8: {
    paddingLeft: 8,
  },
  l_16: {
    paddingLeft: 16,
  },
  h_6: {
    paddingHorizontal: 6,
  },
  h_5: {
    paddingHorizontal: 5,
  },
  h_4: {
    paddingHorizontal: 4,
  },
  h_8: {
    paddingHorizontal: 8,
  },
  h_9: {
    paddingHorizontal: 9,
  },
  v_2: {
    paddingVertical: 2,
  },
  t_3: {
    paddingTop: 3,
  },
  t_2: {
    paddingTop: 2,
  },
  t_1: {
    paddingTop: 1,
  },
  t_8: {
    paddingTop: 8,
  },
  t_9: {
    paddingTop: 9,
  },
  t_7: {
    paddingTop: 7,
  },
  h_7: {
    paddingHorizontal: 7,
  },
  h_10: {
    paddingHorizontal: 10,
  },
  h_12: {
    paddingHorizontal: 12,
  },
  h_13: {
    paddingHorizontal: 13,
  },
  v_8: {
    paddingVertical: 8,
  },
  v_10: {
    paddingVertical: 10,
  },
  h_16: {
    paddingHorizontal: 16,
  },
  t_20: {
    paddingTop: 20,
  },
  h_14: {
    paddingHorizontal: 14,
  },
  h_15: {
    paddingHorizontal: 15,
  },
  h_18: {
    paddingHorizontal: 18,
  },
  h_20: {
    paddingHorizontal: 20,
  },
  t_40: {
    paddingTop: 40,
  },
  t_35: {
    paddingTop: 35,
  },
  t_36: {
    paddingTop: 36,
  },
  t_37: {
    paddingTop: 37,
  },
  t_18: {
    paddingTop: 18,
  },
  t_19: {
    paddingTop: 19,
  },
  b_17: {
    paddingBottom: 17,
  },
  b_10: {
    paddingBottom: 10,
  },
  b_8: {
    paddingBottom: 8,
  },
  b_2: {
    paddingBottom: 2,
  },
  b_0: {
    paddingBottom: 0,
  },
  b_30: {
    paddingBottom: 30,
  },
  t_5: {
    paddingTop: 10,
  },
  t_10: {
    paddingTop: 10,
  },
  p_11: {
    padding: 11,
  },
  p_16: {
    padding: 16,
  },
  p_10: {
    padding: 10,
  },
  p_6: {
    padding: 6,
  },
  p_5: {
    padding: 5,
  },
  p_7: {
    padding: 7,
  },
  p_1: {
    padding: 1,
  },
  p_3: {
    padding: 3,
  },
  p_2: {
    padding: 2,
  },
  l_10: {
    paddingLeft: 10,
  },
  t_12: {
    paddingTop: 12,
  },
  l_12: {
    paddingLeft: 12,
  },
  h_24: {
    paddingHorizontal: 24,
  },
  v_12: {
    paddingVertical: 12,
  },
};

import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {SafeAreaView} from 'react-native';
import {HoldingSearchModal} from '../../../../theme/light';
import HoldingList from './HoldingList';
const SearchModal = ({modalVisible, setModalVisible, data}) => {
  const [filterData, setFilterData] = useState<any>(''); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter(item =>
        item.companyName.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
      console.log('f...', filterData);
    } else {
      setFilterData([]);
    }
  };
  const renderItem = ({item}) => {
    return (
      <HoldingList
        stockName={item.companyName}
        stockTtile={item.title}
        PL={item.PL}
        LTP={item.LTP}
        invested={item.invested}
        cmv={item.cmv}
        overallPL={item.overallPL}
      />
    );
  };
  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={HoldingSearchModal.modal}>
        <View style={HoldingSearchModal.headerView}>
          <TouchableOpacity
            style={HoldingSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
              setTextInputValue('');
              setFilterData([]);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={HoldingSearchModal.textInput}
            placeholder="Search your holdings eg: Axis, Reliance"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={HoldingSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={HoldingSearchModal.noDataText}>
              No holding's available
            </Text>
          ) : (
            <FlatList
              data={filterData}
              renderItem={renderItem}
              contentContainerStyle={{paddingBottom: 10}}
              keyExtractor={(_, index) => `item-${index}`}
            />
          )}
        </View>
      </View>
    </Modal>
  );
};
export default SearchModal;

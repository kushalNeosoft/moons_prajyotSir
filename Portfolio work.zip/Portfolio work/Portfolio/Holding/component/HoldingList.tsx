import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {holdingListComp} from '../../../../theme/light';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import {holdingBottomModal} from '../../../../theme/light';
import BuySellButton from './BuySellButton';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';

const HoldingList = props => {
  const [visibleModal, setVisibleModal] = useState(false);
  const [additionalDetails, setAdditionalDetails] = useState(false);

  return (
    // <View style={{}}>
    <>
      <TouchableOpacity
        style={holdingListComp.container}
        onPress={() => {
          // openModal();
          setVisibleModal(true);
        }}>
        <View style={holdingListComp.rowSpaceBetween}>
          <View>
            <Text style={holdingListComp.listTitle}>{props.stockName}</Text>
            <Text style={holdingListComp.listSubTitle}>
              Qty : {props.stockTtile}
            </Text>
          </View>
          <View style={holdingListComp.listPlLtpView}>
            <View style={holdingListComp.rowAlignC}>
              <Text style={holdingListComp.listLtpText}>LTP : </Text>
              <Text
                style={[
                  holdingListComp.listLtpValue,
                  {
                    color: props?.LTP?.includes('-')
                      ? root.color_negative
                      : root.color_positive,
                  },
                ]}>
                {props.LTP}
              </Text>
            </View>
            <View style={holdingListComp.rowAlignC}>
              <Text style={holdingListComp.listPlText}>Today's P/L : </Text>
              <Text
                style={[
                  holdingListComp.listPlValue,
                  {
                    color: props?.PL?.includes('-')
                      ? root.color_negative
                      : root.color_positive,
                  },
                ]}>
                {props.PL}
              </Text>
            </View>
          </View>
        </View>
        {/* New data */}
        <View style={holdingListComp.rowSpaceBetweenCenter}>
          <Text style={holdingListComp.listSubTitle}>
            Invested : {props.invested}
          </Text>
          <View style={holdingListComp.rowAlignC}>
            <Text style={holdingListComp.listPlText}>Overall P/L : </Text>
            <Text
              style={[
                holdingListComp.listPlValue,
                {
                  color: props?.PL?.includes('-')
                    ? root.color_negative
                    : root.color_positive,
                },
              ]}>
              {props.overallPL}
            </Text>
          </View>
        </View>
      </TouchableOpacity>

      <CommonModal
        visible={visibleModal}
        onClose={() => {
          setVisibleModal(false);
          setAdditionalDetails(false);
        }}>
        <View style={holdingBottomModal.modalView}>
          <Text style={holdingBottomModal.stockName}>{props.stockName}</Text>
          <View style={holdingBottomModal.stockDetailsView}>
            <View>
              <Text style={holdingBottomModal.stockTitle}>
                <Text style={holdingBottomModal.stockDetailsText}>Qty : </Text>
                {props.stockTtile}
              </Text>
              <View style={holdingBottomModal.row}>
                <Text style={holdingBottomModal.stockDetailsText}>CMV : </Text>
                <Text style={holdingBottomModal.stockTitle}>{props.cmv}</Text>
              </View>
              <View style={holdingBottomModal.row}>
                <Text style={holdingBottomModal.stockDetailsText}>
                  Invested :{' '}
                </Text>
                <Text style={holdingBottomModal.stockTitle}>
                  {props.invested}
                </Text>
              </View>
            </View>
            <View>
              <View style={holdingBottomModal.row}>
                <Text style={holdingBottomModal.stockDetailsText}>LTP : </Text>
                <Text
                  style={[
                    holdingBottomModal.stockDetailsValue,
                    {
                      color: props?.LTP?.includes('-')
                        ? root.color_negative
                        : root.color_positive,
                    },
                  ]}>
                  {props.LTP}{' '}
                </Text>
              </View>

              <View style={holdingBottomModal.row}>
                <Text style={holdingBottomModal.stockDetailsText}>
                  Today's P/L :{' '}
                </Text>
                <Text
                  style={[
                    holdingBottomModal.stockDetailsValue,
                    {
                      color: props?.PL?.includes('-')
                        ? root.color_negative
                        : root.color_positive,
                    },
                  ]}>
                  {props.PL}
                </Text>
              </View>
              <View style={holdingBottomModal.row}>
                <Text style={holdingBottomModal.stockDetailsText}>
                  Overall P/L :{' '}
                </Text>
                <Text
                  style={[
                    holdingBottomModal.stockDetailsValue,
                    {
                      color: props?.overallPL?.includes('-')
                        ? root.color_negative
                        : root.color_positive,
                    },
                  ]}>
                  {props.overallPL}
                </Text>
              </View>
            </View>
          </View>
          <View>
            <TouchableOpacity
              onPress={() => {
                setAdditionalDetails(!additionalDetails);
              }}>
              <View style={holdingBottomModal.additionalTextIconView}>
                <Text style={holdingBottomModal.additionalDetailsText}>
                  Additional Details
                </Text>
                {additionalDetails === false ? (
                  <AntDesign
                    name="caretdown"
                    size={10}
                    color="#303030"
                    style={holdingBottomModal.upDownIcon}
                  />
                ) : (
                  <AntDesign
                    name="caretup"
                    size={10}
                    color="#303030"
                    style={holdingBottomModal.upDownIcon}
                  />
                )}
              </View>
            </TouchableOpacity>
            {additionalDetails ? (
              <View style={holdingBottomModal.additionDetailView}>
                <View>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Stocks
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Today's
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Receivable
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Pool
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    DP
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Available
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Pledged
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Blocked
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text style={holdingBottomModal.additionalDetailsTitle}>
                    Free
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                  <Text style={holdingBottomModal.additionalDetailsValues}>
                    0
                  </Text>
                </View>
              </View>
            ) : (
              <View style={{height: 33}}></View>
            )}
          </View>
          <View style={holdingBottomModal.rowSpaceBtween}>
            <BuySellButton title={'Buy'} style={{flex: 0.48}} />
            <BuySellButton title={'Sell'} style={{flex: 0.48}} />
          </View>
        </View>
      </CommonModal>
    </>
    // </View>
  );
};
export default HoldingList;

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {BuySellBtn} from '../../../../theme/light';
import {root} from '../../../../styles/colors';

const BuySellButton = props => {
  return (
    <TouchableOpacity
      style={[
        {...BuySellBtn.conatiner, ...props.style},
        {
          backgroundColor:
            props.title == 'Buy' ? root.color_positive : root.color_negative,
        },
      ]}
      onPress={props.onPress}>
      <Text style={BuySellBtn.btnText}>{props.title}</Text>
    </TouchableOpacity>
  );
};
export default BuySellButton;

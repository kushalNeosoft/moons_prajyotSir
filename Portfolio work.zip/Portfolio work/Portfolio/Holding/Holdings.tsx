import React, {useState, useEffect, useRef, useMemo, useCallback} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import HoldingList from './component/HoldingList';
import Ionicons from 'react-native-vector-icons/Ionicons';
import SearchModal from './component/SearchModal';
import Tooltip from 'react-native-walkthrough-tooltip';
import {holdingScreen} from '../../../theme/light';
import TopHeader from './component/TopHeader';
import SkeletonPlaceholder from '../../../components/Skeleton/SkeletonConstituents';
const stockData = [
  {
    companyName: 'ABB',
    title: `1000 @ Avg. 1,300.00`,
    PL: '-1,21,150.00(-2.68%)',
    overallPL: '31,07,300.00(239.02%)',
    LTP: '4,407.30(-2.68%)',
    invested: '13,00,000.00',
    cmv: '44,07,300.42',
    dayPlPercent: '55,377,00',
    overallPlPercent: '15,727,90',
  },
  {
    companyName: 'MRF',
    title: `1000 @ Avg. 70,025.00`,
    PL: '-11,609.40(-0.95%)',
    overallPL: '3,74,867.40(44.61%)',
    LTP: '1,01,263.95(-0.95%)',
    invested: '8,40,300.00',
    cmv: '12,15,167.40',
    dayPlPercent: '16,37,38,0',
    overallPlPercent: '12,00,000.0',
  },
  {
    companyName: 'NTPC',
    title: `1000 @ Avg. 70,025.00`,
    PL: '-14,500.40(-1.95%)',
    overallPL: '-60,500.40(1.52%)',
    LTP: '187.90(-1.95%)',
    invested: '10,40,300.00',
    cmv: '9,39,167.40',
    dayPlPercent: '80000',
    overallPlPercent: '900000',
  },
  {
    companyName: 'SBIN',
    title: `1000 @ Avg. 70,025.00`,
    PL: '-15,500.40(-1.95%)',
    overallPL: '-60,500.40(1.52%)',
    LTP: '165.90(-1.95%)',
    invested: '10,40,300.00',
    cmv: '6,39,167.40',
    dayPlPercent: '200000',
    overallPlPercent: '780000',
  },
  {
    companyName: 'RELIANCE',
    title: `1000 @ Avg. 70,025.00`,
    PL: '-84,150.00(-0.89%)',
    overallPL: '60,11,200.40(181.52%)',
    LTP: '2743.90(-0.89%)',
    invested: '33,40,300.00',
    cmv: '93,26,167.40',
    dayPlPercent: '2600089',
    overallPlPercent: '670000',
  },
  {
    companyName: 'TCS',
    title: `1000 @ Avg. 70,025.00`,
    PL: '3,340.55.00(+2.47%)',
    overallPL: '96,780,780.40(2.47%)',
    LTP: '2743.90(+1.89%)',
    invested: '40,40,300.00',
    cmv: '21,26,167.40',
    dayPlPercent: '3780000',
    overallPlPercent: '3987000',
  },
];
const Holdings = ({bottomSheetRef, setTabFilter, filter, setFilter}: any) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [toolTipVisible, setToolTipVisible] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // console.log('filter', filter);

  const renderItem = ({item}) => {
    return (
      <HoldingList
        stockName={item.companyName}
        stockTtile={item.title}
        PL={item.PL}
        overallPL={item.overallPL}
        LTP={item.LTP}
        invested={item.invested}
        cmv={item.cmv}
      />
    );
  };

  const isFilterValueAvailable = () => {
    for (const key in filter) {
      if (filter[key] !== '') {
        return true;
      }
    }
    return false;
  };

  const handleRemoveItem = index => {
    setFilter(prevFilter => {
      const newFilter = [...prevFilter];
      newFilter.splice(index, 1);
      return newFilter;
    });
  };

  useEffect(() => {
    applyFilters(stockData, filter);
  }, [filter]);

  const applyFilters = (data, filters) => {
    let filteredData = data.slice();
    filters.forEach(filter => {
      if (filter.name === 'Alphabetically') {
        if (filter.value === 'A-Z') {
          filteredData = filteredData.sort((a, b) =>
            a.companyName.localeCompare(b.companyName),
          );
        } else if (filter.value === 'Z-A') {
          filteredData = filteredData.sort((a, b) =>
            b.companyName.localeCompare(a.companyName),
          );
        }
      } else if (filter.name === 'CMV') {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.cmv.replace(/,/g, '')) -
              parseFloat(b.cmv.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.cmv.replace(/,/g, '')) -
              parseFloat(a.cmv.replace(/,/g, '')),
          );
        }
      } else if (filter.name === "Day's P/L") {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.PL.replace(/,/g, '')) -
              parseFloat(b.PL.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.PL.replace(/,/g, '')) -
              parseFloat(a.PL.replace(/,/g, '')),
          );
        }

        // Check if there are min and max values in the amount array
        console.log('ammmount', filter.amount);
        const minAmount = filter.amount?.find(
          item => item.key === 'Min',
        )?.value;
        const maxAmount = filter.amount?.find(
          item => item.key === 'Max',
        )?.value;

        // Filter based on min and max values
        if (minAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) >= parseFloat(minAmount),
          );
        }
        if (maxAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) <= parseFloat(maxAmount),
          );
        }
      } else if (filter.name === 'Overall P/L') {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.overallPL.replace(/,/g, '')) -
              parseFloat(b.overallPL.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.overallPL.replace(/,/g, '')) -
              parseFloat(a.overallPL.replace(/,/g, '')),
          );
        }

        // Check if there are min and max values in the amount array
        const minAmount = filter.amount?.find(
          item => item.key === 'Min',
        )?.value;
        const maxAmount = filter.amount?.find(
          item => item.key === 'Max',
        )?.value;

        // Filter based on min and max values
        if (minAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) >= parseFloat(minAmount),
          );
        }
        if (maxAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) <= parseFloat(maxAmount),
          );
        }
      } else if (filter.name === "Day's P/L Percentage") {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.dayPlPercent.replace(/,/g, '')) -
              parseFloat(b.dayPlPercent.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.dayPlPercent.replace(/,/g, '')) -
              parseFloat(a.dayPlPercent.replace(/,/g, '')),
          );
        }

        // Check if there are min and max values in the amount array
        const minAmount = filter.amount?.find(
          item => item.key === 'Min',
        )?.value;
        const maxAmount = filter.amount?.find(
          item => item.key === 'Max',
        )?.value;

        // Filter based on min and max values
        if (minAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) >= parseFloat(minAmount),
          );
        }
        if (maxAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) <= parseFloat(maxAmount),
          );
        }
      } else if (filter.name === 'Overall P/L Percentage') {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.overallPlPercent.replace(/,/g, '')) -
              parseFloat(b.overallPlPercent.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.overallPlPercent.replace(/,/g, '')) -
              parseFloat(a.overallPlPercent.replace(/,/g, '')),
          );
        }

        // Check if there are min and max values in the amount array
        const minAmount = filter.amount?.find(
          item => item.key === 'Min',
        )?.value;
        const maxAmount = filter.amount?.find(
          item => item.key === 'Max',
        )?.value;

        // Filter based on min and max values
        if (minAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) >= parseFloat(minAmount),
          );
        }
        if (maxAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.PL.replace(/,/g, '')) <= parseFloat(maxAmount),
          );
        }
      }
    });
    return filteredData;
  };

  const onRefresh = () => {
    //set isRefreshing to true
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false); //basic idea is to call api here and set false once response is recieved
    }, 2000);
    // and set isRefreshing to false at the end of your callApiMethod()
  };

  return (
    <View style={holdingScreen.container}>
      <TopHeader
        leftTopText={'Current value'}
        leftBottomText={'Overall P/L'}
        rightTopText={'Invested value'}
        rightBottomText={'Todays P/L'}
        currentVal={'18,73,38,879.00'}
        investedVal={'18,73,38,879.00'}
        overallPL={'83,73,60.00(98.36%)'}
        todaysPL={'83,73,60.00(98.36%)'}
      />
      <View style={holdingScreen.header}>
        <Text style={holdingScreen.headerScripsText}>
          {stockData.length} Scrips
        </Text>
        <View style={holdingScreen.headerIconsView}>
          <Tooltip
            isVisible={toolTipVisible}
            content={
              <Text style={holdingScreen.toolkitText}>
                PNC Infra gets provionsnal completion certificate
              </Text>
            }
            placement="bottom"
            childContentSpacing={1}
            contentStyle={holdingScreen.toolkitView}
            onClose={() => setToolTipVisible(false)}>
            <TouchableOpacity
              onPress={() => {
                setToolTipVisible(true);
              }}>
              <Ionicons
                name="information-circle-outline"
                size={18}
                color="black"
                style={holdingScreen.headerInfoIcon}
              />
            </TouchableOpacity>
          </Tooltip>
          <TouchableOpacity
            onPress={() => {
              // open Search modal here
              setModalVisible(true);
            }}>
            <Ionicons
              name="search-sharp"
              size={22}
              color="#303030"
              style={holdingScreen.headerSearchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setTabFilter('Holding');
              bottomSheetRef?.current?.snapToIndex?.(0);
            }}>
            <Ionicons
              name="options-outline"
              size={22}
              color="#303030"
              style={holdingScreen.headerFilterIcon}
            />
          </TouchableOpacity>
        </View>
        {/* filter View */}
      </View>
      {isFilterValueAvailable() ? (
        <View style={holdingScreen.filterMainView}>
          <Text style={holdingScreen.filterText}>Filters: </Text>
          {filter.map((itm, idx) => {
            return (
              <View style={holdingScreen.filterDataView}>
                <Text key={itm.name}>
                  <Text style={holdingScreen.filterTag}>{itm.name} : </Text>
                  <Text style={holdingScreen.filterTagData}>{itm.value}</Text>

                  {itm.amount?.length > 0 ? (
                    <Text style={holdingScreen.ammountTag}> Amount :</Text>
                  ) : null}

                  {itm.amount?.map?.((itm2, idx2) => {
                    return (
                      <>
                        <Text style={holdingScreen.filterTagData}>
                          {' '}
                          {itm2.key === 'Max' ? '- ' : ''}
                          {itm2.key} :{' '}
                        </Text>
                        <Text style={holdingScreen.filterTagData}>
                          {itm2.value}
                        </Text>
                      </>
                    );
                  })}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    handleRemoveItem(idx);
                  }}>
                  <Ionicons
                    name="md-close-outline"
                    style={holdingScreen.closeIcon}
                  />
                </TouchableOpacity>
              </View>
            );
          })}
        </View>
      ) : (
        <></>
      )}
      {stockData.length != 0 ? (
        <FlatList
          data={applyFilters(stockData, filter)}
          renderItem={renderItem}
          contentContainerStyle={{paddingBottom: 10}}
          keyExtractor={(_, index) => `item-${index}`}
          refreshing={isRefreshing}
          onRefresh={onRefresh}
          // style={{backgroundColor: ''}}
        />
      ) : (
        <SkeletonPlaceholder />
      )}

      <SearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={stockData}
      />
    </View>
  );
};
export default Holdings;

import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {root} from '../../../styles/colors';
import {positionFilter} from '../../../theme/light';
import MinMaxInput from './MinMaxInput';
import {ScrollView} from 'react-native-gesture-handler';

const PositionFilter = ({bottomSheetRef, pFilter, setpFilter}: any) => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [quantityValue, setQuantityValue] = useState('');
  const [cmvValue, setcmvValue] = useState('');
  const [daysPlValue, setDaysPlValue] = useState('');
  const [positionValue, setPositionValue] = useState('');
  const [segmentValue, setSegmentValue] = useState('');
  const alphabet = ['A-Z', 'Z-A'];
  const price = ['Low to High', 'High to Low'];
  const quantity = ['Low to High', 'High to Low'];
  const position = ['Open', 'Close'];
  const segment = ['All'];
  const [daysPlRange, setDaysPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);

  const reset = () => {
    setAlphabetValue('');
    setQuantityValue('');
    setcmvValue('');
    setDaysPlValue('');
    setPositionValue('');
    setSegmentValue('');
    setDaysPlRange([
      {type: 'Min', value: 0},
      {type: 'Max', value: 0},
    ]);
  };

  const onSubmit = () => {
    let arr = [];

    if (alphabetValue) {
      let obj = {
        name: 'Alphabetically',
        value: alphabetValue,
      };
      arr.push(obj);
    }
    if (quantityValue) {
      let obj = {
        name: 'Quantity',
        value: quantityValue,
      };
      arr.push(obj);
    }

    if (cmvValue) {
      let obj = {
        name: 'CMV',
        value: cmvValue,
      };

      arr.push(obj);
    }

    if (daysPlValue) {
      let obj = {
        name: `Day's P/L`,
        value: daysPlValue,
        amount: [],
      };

      if (daysPlRange[0].value) {
        obj.amount.push({
          key: 'Min',
          value: daysPlRange[0].value,
        });
      }

      if (daysPlRange[1].value) {
        obj.amount.push({
          key: 'Max',
          value: daysPlRange[1].value,
        });
      }

      arr.push(obj);
    }
    if (positionValue) {
      let obj = {
        name: 'Position',
        value: positionValue,
      };

      arr.push(obj);
    }
    setpFilter([...arr]);
  };

  return (
    <View style={positionFilter.Maincon}>
      <View style={positionFilter.contentView}>
        <View style={positionFilter.space}>
          <View style={positionFilter.spaceinner}>
            <Text style={positionFilter.titleText}>Alphabetically</Text>
          </View>
          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabetValue(item)}
                style={[
                  positionFilter.commonAtZSelected,
                  {
                    borderColor:
                      alphabetValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      alphabetValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter.spacetwo}>
          <View style={positionFilter.spacetwoinner}>
            <Text style={positionFilter.titleText}>Quantity</Text>
          </View>

          <FlatList
            horizontal={true}
            data={quantity}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setQuantityValue(item)}
                style={[
                  positionFilter.commonHtLSelected,
                  {
                    borderColor:
                      quantityValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      quantityValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter.spacetwo}>
          <View style={positionFilter.spacetwoinner}>
            <Text style={positionFilter.titleText}>
              Current Mraket Value(CMV)
            </Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setcmvValue(item)}
                style={[
                  positionFilter.commonHtLSelected,
                  {
                    borderColor:
                      cmvValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor: cmvValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter.spacetwo}>
          <View style={positionFilter.spacetwoinner}>
            <Text style={positionFilter.titleText}>Day's P/L</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlValue(item)}
                style={[
                  positionFilter.commonHtLSelected,
                  {
                    borderColor:
                      daysPlValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor: daysPlValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlRange}
                item={item}
                rangeArr={daysPlRange}
              />
            )}
          />
        </View>
        <View style={positionFilter.spacetwo}>
          <View style={positionFilter.spacetwoinner}>
            <Text style={positionFilter.titleText}>Position</Text>
          </View>

          <FlatList
            horizontal={true}
            data={position}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setPositionValue(item)}
                style={[
                  positionFilter.commonHtLSelected,
                  {
                    borderColor:
                      positionValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      positionValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={positionFilter.spacetwo}>
          <View style={positionFilter.spacetwoinner}>
            <Text style={positionFilter.titleText}>Segment</Text>
          </View>

          <FlatList
            horizontal={true}
            data={segment}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setSegmentValue(item)}
                style={[
                  positionFilter.commonHtLSelected,
                  {
                    borderColor:
                      segmentValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      segmentValue === item ? '#F5F7FA' : 'white',
                  },
                ]}>
                <Text style={positionFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
      <TouchableOpacity
        // disabled={filterData == '' ? true : false}
        style={positionFilter.applyBtn}
        onPress={() => {
          onSubmit();
          // reset();
          bottomSheetRef?.current?.forceClose();
        }}>
        <Text style={positionFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};
export default PositionFilter;

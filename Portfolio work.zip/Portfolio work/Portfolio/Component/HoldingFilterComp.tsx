import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {FlatList, Text, TouchableOpacity, View} from 'react-native';
import {root} from '../../../styles/colors';
import {holdingFilter} from '../../../theme/light';
import MinMaxInput from './MinMaxInput';
import {ScrollView} from 'react-native-gesture-handler';

const HoldingFilterComp = ({bottomSheetRef, filter, setFilter}: any) => {
  const [alphabetValue, setAlphabetValue] = useState('');
  const [cmvValue, setcmvValue] = useState('');
  const [daysPlValue, setDaysPlValue] = useState('');
  const [overallPlValue, setOverallPlValue] = useState('');
  const [daysPlPercentage, setDaysPlPercentage] = useState('');
  const [overallPlPercentage, setOverallPlPercenatge] = useState('');
  const [textInputLine, setTextInputLine] = useState(false);

  const alphabet = ['A-Z', 'Z-A'];
  const price = ['Low to High', 'High to Low'];
  const [daysPlRange, setDaysPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [daysPlPercentageRange, setDaysPlPercentageRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [overallPlRange, setOverallPlRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);
  const [overallPlPercentageRange, setOverallPlPercentageRange] = useState([
    {type: 'Min', value: 0},
    {type: 'Max', value: 0},
  ]);

  const reset = () => {
    setAlphabetValue('');
    setcmvValue('');
    setDaysPlValue('');
    setOverallPlValue('');
    setDaysPlPercentage('');
    setOverallPlPercenatge('');
    setDaysPlRange([
      {type: 'Min', value: 0},
      {type: 'Max', value: 0},
    ]);
    setDaysPlPercentageRange([
      {type: 'Min', value: 0},
      {type: 'Max', value: 0},
    ]);
    setOverallPlRange([
      {type: 'Min', value: 0},
      {type: 'Max', value: 0},
    ]);
    setOverallPlPercentageRange([
      {type: 'Min', value: 0},
      {type: 'Max', value: 0},
    ]);
  };

  const onSubmit = () => {
    let arr = [];

    if (alphabetValue) {
      let obj = {
        name: 'Alphabetically',
        value: alphabetValue,
      };

      arr.push(obj);
    }

    if (cmvValue) {
      let obj = {
        name: 'CMV',
        value: cmvValue,
      };

      arr.push(obj);
    }

    if (daysPlValue) {
      let obj = {
        name: `Day's P/L`,
        value: daysPlValue,
        amount: [],
      };

      if (daysPlRange[0].value) {
        obj.amount.push({
          key: 'Min',
          value: daysPlRange[0].value,
        });
      }

      if (daysPlRange[1].value) {
        obj.amount.push({
          key: 'Max',
          value: daysPlRange[1].value,
        });
      }

      arr.push(obj);
    }

    if (overallPlValue) {
      let obj = {
        name: 'Overall P/L',
        value: overallPlValue,
        amount: [],
      };

      if (overallPlRange[0].value) {
        obj.amount.push({
          key: 'Min',
          value: overallPlRange[0].value,
        });
      }

      if (overallPlRange[1].value) {
        obj.amount.push({
          key: 'Max',
          value: overallPlRange[1].value,
        });
      }

      arr.push(obj);
    }

    if (daysPlPercentage) {
      let obj = {
        name: "Day's P/L Percentage",
        value: daysPlPercentage,
        amount: [],
      };

      if (daysPlPercentageRange[0].value) {
        obj.amount.push({
          key: 'Min',
          value: daysPlPercentageRange[0].value,
        });
      }

      if (daysPlPercentageRange[1].value) {
        obj.amount.push({
          key: 'Max',
          value: daysPlPercentageRange[1].value,
        });
      }

      arr.push(obj);
    }

    if (overallPlPercentage) {
      let obj = {
        name: 'Overall P/L Percentage',
        value: overallPlPercentage,
        amount: [],
      };

      if (overallPlPercentageRange[0].value) {
        obj.amount.push({
          key: 'Min',
          value: overallPlPercentageRange[0].value,
        });
      }

      if (overallPlPercentageRange[1].value) {
        obj.amount.push({
          key: 'Max',
          value: overallPlPercentageRange[1].value,
        });
      }

      arr.push(obj);
    }

    setFilter([...arr]);
  };
  return (
    <View style={holdingFilter.Maincon}>
      <View style={holdingFilter.contentView}>
        <View style={holdingFilter.space}>
          <View style={holdingFilter.spaceinner}>
            <Text style={holdingFilter.titleText}>Alphabetically</Text>
          </View>

          <FlatList
            horizontal={true}
            data={alphabet}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setAlphabetValue(item)}
                style={[
                  holdingFilter.commonAtZSelected,
                  {
                    borderColor:
                      alphabetValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      alphabetValue === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={holdingFilter.spacetwo}>
          <View style={holdingFilter.spacetwoinner}>
            <Text style={holdingFilter.titleText}>
              Current Mraket Value(CMV)
            </Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setcmvValue(item)}
                style={[
                  holdingFilter.commonHtLSelected,
                  {
                    borderColor:
                      cmvValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      cmvValue === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View style={holdingFilter.spacetwo}>
          <View style={holdingFilter.spacetwoinner}>
            <Text style={holdingFilter.titleText}>Day's P/L</Text>
          </View>

          <FlatList
            horizontal={true}
            data={price}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlValue(item)}
                style={[
                  holdingFilter.commonHtLSelected,
                  {
                    borderColor:
                      daysPlValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      daysPlValue === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlRange}
                item={item}
                rangeArr={daysPlRange}
              />
            )}
          />
        </View>

        <View style={holdingFilter.space}>
          <View style={holdingFilter.spaceinner}>
            <Text style={holdingFilter.titleText}>Overall P/L</Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOverallPlValue(item)}
                style={[
                  holdingFilter.commonHtLSelected,
                  {
                    borderColor:
                      overallPlValue === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      overallPlValue === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={overallPlRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setOverallPlRange}
                item={item}
                rangeArr={overallPlRange}
              />
            )}
          />
        </View>
        <View style={holdingFilter.space}>
          <View style={holdingFilter.spaceinner}>
            <Text style={holdingFilter.titleText}>Day's P/L Percentage</Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setDaysPlPercentage(item)}
                style={[
                  holdingFilter.commonHtLSelected,
                  {
                    borderColor:
                      daysPlPercentage === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      daysPlPercentage === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={daysPlPercentageRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setDaysPlPercentageRange}
                item={item}
                rangeArr={daysPlPercentageRange}
              />
            )}
          />
        </View>
        <View style={holdingFilter.space}>
          <View style={holdingFilter.spaceinner}>
            <Text style={holdingFilter.titleText}>Overall P/L Percentage</Text>
          </View>

          <FlatList
            data={price}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOverallPlPercenatge(item)}
                style={[
                  holdingFilter.commonHtLSelected,
                  {
                    borderColor:
                      overallPlPercentage === item
                        ? root.client_background
                        : root.color_border,
                    backgroundColor:
                      overallPlPercentage === item
                        ? root.color_chipFilter
                        : root.color_active,
                  },
                ]}>
                <Text style={holdingFilter.text}>{item}</Text>
              </TouchableOpacity>
            )}
          />
          <FlatList
            horizontal={true}
            data={overallPlPercentageRange}
            renderItem={({item, index}) => (
              <MinMaxInput
                value={item.value}
                index={index}
                setValue={setOverallPlPercentageRange}
                item={item}
                rangeArr={overallPlPercentageRange}
              />
            )}
          />
        </View>
      </View>
      <TouchableOpacity
        // disabled={filterData == '' ? true : false}
        style={holdingFilter.applyBtn}
        onPress={() => {
          onSubmit();
          reset();
          bottomSheetRef?.current?.forceClose();
        }}>
        <Text style={holdingFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};
export default HoldingFilterComp;

import {useFocusEffect} from '@react-navigation/native';
import React, {useRef, useState} from 'react';
import {
  Text,
  TouchableOpacity,
  TextInput,
  TouchableHighlight,
  View,
} from 'react-native';
import {minMaxcomp} from '../../../theme/light';
import {root} from '../../../styles/colors';

const MinMaxInput = (props: any) => {
  const onChange = text => {
    inputRef?.current?.focus();
    let arr = [...props.rangeArr];
    arr[props.index].value = text;
    props.setValue([...arr]);
  };

  const [clickedItem, setClickedItem] = useState(false);
  const inputRef = useRef(null);

  useFocusEffect(
    React.useCallback(() => {
      setClickedItem(false);
    }, []),
  );

  return (
    <View
      // onPress={() => {
      //   setClickedItem(true);
      // }}
      style={[
        minMaxcomp.commonMinMaxSelected,
        {
          borderColor:
            props.item?.value.toString?.()?.length > 0 &&
            props.item?.value.toString?.() != 0
              ? root.client_background
              : root.color_border,
          backgroundColor:
            props.item?.value.toString?.()?.length > 0 &&
            props.item?.value.toString?.() != 0
              ? root.color_chipFilter
              : root.color_active,
        },
      ]}>
      <Text style={minMaxcomp.minMaxText}>{props.item?.type}</Text>
      <TextInput
        ref={inputRef}
        style={[
          minMaxcomp.minMaxTextInput,
          {
            borderBottomWidth: clickedItem ? 0.8 : 0,
          },
        ]}
        placeholder={'0'}
        value={props.item?.value.toString()}
        // editable={clickedItem}
        placeholderTextColor={'#303030'}
        keyboardType="numeric"
        onChangeText={text => onChange(text)}
        onFocus={() => {
          setClickedItem(true);
        }}
        onBlur={()=>{
          setClickedItem(false)
        }}
      />
    </View>
  );
};
export default MinMaxInput;

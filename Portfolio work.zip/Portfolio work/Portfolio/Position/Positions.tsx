import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {positionScreen} from '../../../theme/light';
import Ionicons from 'react-native-vector-icons/Ionicons';
import TodaysOverallList from './component/TodayOverallList';
import TopHeader from '../Holding/component/TopHeader';
import PositionSearchModal from './component/positionSearchModal';
import {useNavigation} from '@react-navigation/native';
import {root} from '../../../styles/colors';
import SkeletonPlaceholder from '../../../components/Skeleton/SkeletonConstituents';
const Positions = ({
  bottomSheetRef,
  setTabFilter,
  pFilter,
  setpFilter,
}: any) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const navigation = useNavigation();

  const todayPl = -73737.9;
  const actualPl = '0.00';

  const overallData = [
    {
      companyName: 'Wipro',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-6.65(-0.28%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '8000',
      quantity: '1',
      position: 'Open',
    },
    {
      companyName: 'TCS',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-3.65(-0.27%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '2000',
      quantity: '2',
      position: 'Open',
    },
    {
      companyName: 'SBIN',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-1.65(-0.26%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '3000',
      quantity: '3',
      position: 'Open',
    },
    {
      companyName: 'SBI',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '6.65(0.28%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '4000',
      quantity: '4',
      position: 'Open',
    },
    {
      companyName: 'HDFC',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '8.65(0.28%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '5000',
      quantity: '5',
      position: 'Open',
    },
    {
      companyName: 'TATA',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-1.65(-0.38%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '6000',
      quantity: '6',
      position: 'Close',
    },
    {
      companyName: 'ABB',
      buy: '2 Qty @ ₹ 4570.00',
      todaysPL: '-7.60(-0.77%)',
      LTP: '3316.27',
      titleChip: 'EQ Combined',
      bottomChip: 'MARGIN',
      status: 'Buy : ',
      cmv: '7000',
      quantity: '7',
      position: 'Close',
    },
  ];

  const renderItem = ({item}) => {
    return (
      <TodaysOverallList
        stockName={item.companyName}
        buy={item.buy}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };

  const isFilterValueAvailable = () => {
    for (const key in pFilter) {
      if (pFilter[key] !== '') {
        return true;
      }
    }
    return false;
  };

  const handleRemoveItem = index => {
    setpFilter(prevFilter => {
      const newFilter = [...prevFilter];
      newFilter.splice(index, 1);
      return newFilter;
    });
  };

  const applyFilters = (data, filters) => {
    console.log('filters----', filters);
    let filteredData = data.slice();
    filters.forEach(filter => {
      if (filter.name === 'Alphabetically') {
        if (filter.value === 'A-Z') {
          filteredData = filteredData.sort((a, b) =>
            a.companyName.localeCompare(b.companyName),
          );
        } else if (filter.value === 'Z-A') {
          filteredData = filteredData.sort((a, b) =>
            b.companyName.localeCompare(a.companyName),
          );
        }
      } else if (filter.name === 'CMV') {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.cmv.replace(/,/g, '')) -
              parseFloat(b.cmv.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.cmv.replace(/,/g, '')) -
              parseFloat(a.cmv.replace(/,/g, '')),
          );
        }
      } else if (filter.name === "Day's P/L") {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.todaysPL.replace(/,/g, '')) -
              parseFloat(b.todaysPL.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.todaysPL.replace(/,/g, '')) -
              parseFloat(a.todaysPL.replace(/,/g, '')),
          );
        }

        // Check if there are min and max values in the amount array
        const minAmount = filter.amount?.find(
          item => item.key === 'Min',
        )?.value;
        const maxAmount = filter.amount?.find(
          item => item.key === 'Max',
        )?.value;

        // Filter based on min and max values
        if (minAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.todaysPL.replace(/,/g, '')) >=
              parseFloat(minAmount),
          );
        }
        if (maxAmount) {
          filteredData = filteredData.filter(
            item =>
              parseFloat(item.todaysPL.replace(/,/g, '')) <=
              parseFloat(maxAmount),
          );
        }
      } else if (filter.name === 'Quantity') {
        if (filter.value === 'Low to High') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(a.quantity.replace(/,/g, '')) -
              parseFloat(b.quantity.replace(/,/g, '')),
          );
        } else if (filter.value === 'High to Low') {
          filteredData = filteredData.sort(
            (a, b) =>
              parseFloat(b.quantity.replace(/,/g, '')) -
              parseFloat(a.quantity.replace(/,/g, '')),
          );
        }
      } else if (filter.name === 'Position') {
        if (filter.value === 'Open') {
          filteredData = filteredData.filter(item => item.position === 'Open');
        } else if (filter.value === 'Close') {
          filteredData = filteredData.filter(item => item.position === 'Close');
        }
      }
    });
    return filteredData;
  };

  useEffect(() => {
    applyFilters(overallData, pFilter);
  }, [pFilter]);

  const onRefresh = () => {
    //set isRefreshing to true
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false); //basic idea is to call api here and set false once response is recieved
    }, 2000);
    // and set isRefreshing to false at the end of your callApiMethod()
  };

  return (
    <View style={positionScreen.mainView}>
      <TopHeader
        leftTopText={'Current value'}
        leftBottomText={'Overall P/L'}
        rightTopText={'Invested value'}
        rightBottomText={'Todays P/L'}
        currentVal={'18,73,38,879.00'}
        investedVal={'18,73,38,879.00'}
        overallPL={'83,73,60.00(98.36%)'}
        todaysPL={'83,73,60.00(98.36%)'}
      />
      {/* Filter UI Code */}
      {isFilterValueAvailable() ? (
        <View style={positionScreen.filterMainView}>
          <Text style={positionScreen.filterText}>Filters: </Text>
          {pFilter.map((itm, idx) => {
            return (
              <View style={positionScreen.filterDataView}>
                <Text key={itm.name}>
                  <Text style={positionScreen.filterTag}>{itm.name} : </Text>
                  <Text style={positionScreen.filterTagData}>{itm.value}</Text>

                  {itm.amount?.length > 0 ? (
                    <Text style={positionScreen.ammountTag}> Amount :</Text>
                  ) : null}

                  {itm.amount?.map?.((itm2, idx2) => {
                    return (
                      <>
                        <Text style={positionScreen.filterTagData}>
                          {' '}
                          {itm2.key === 'Max' ? '- ' : ''}
                          {itm2.key} :{' '}
                        </Text>
                        <Text style={positionScreen.filterTagData}>
                          {itm2.value}
                        </Text>
                      </>
                    );
                  })}
                </Text>
                <TouchableOpacity
                  onPress={() => {
                    handleRemoveItem(idx);
                  }}>
                  <Ionicons
                    name="md-close-outline"
                    style={positionScreen.closeIcon}
                  />
                </TouchableOpacity>
              </View>
            );
          })}
        </View>
      ) : (
        <></>
      )}
      <View style={positionScreen.switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={[
            positionScreen.todaysView,
            {
              backgroundColor:
                selectedIndex == 0 ? root.color_textual : root.color_active,
              borderWidth: selectedIndex == 0 ? 0 : 0.3,
              borderColor: root.color_subtext,
            },
          ]}>
          <Text
            style={[
              positionScreen.todayText,
              {
                color:
                  selectedIndex == 0 ? root.color_active : root.color_textual,
              },
            ]}>
            Today's ({overallData.length})
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={[
            positionScreen.overallView,
            {
              backgroundColor:
                selectedIndex == 1 ? root.color_textual : root.color_active,
              borderWidth: selectedIndex == 1 ? 0 : 0.3,
              borderColor: root.color_subtext,
            },
          ]}>
          <Text
            style={[
              positionScreen.overallText,
              {
                color:
                  selectedIndex == 1 ? root.color_active : root.color_textual,
              },
            ]}>
            Overall ({overallData.length})
          </Text>
        </TouchableOpacity>
      </View>

      {/* filter header */}

      <View style={positionScreen.header}>
        <View>
          <View style={positionScreen.todayPlTextValueView}>
            <Text style={positionScreen.todaysPlText}>Today's P/L : </Text>
            <Text style={positionScreen.todaysPlValue}>₹ {todayPl}</Text>
          </View>
          {selectedIndex === 1 ? (
            <View style={positionScreen.actualPlTextValueView}>
              <Text style={positionScreen.actualPlText}>Actual P/L : </Text>
              <Text style={positionScreen.actualPlValue}>₹ {actualPl}</Text>
            </View>
          ) : (
            <></>
          )}
        </View>

        <View style={positionScreen.headerIconsView}>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('SquareOff');
            }}
            style={positionScreen.squareOffView}>
            <Text style={positionScreen.squareOffViewText}>Square-Off</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              // open Search modal here
              setModalVisible(true);
            }}>
            <Ionicons
              name="search-sharp"
              size={22}
              color="#303030"
              style={positionScreen.headerSearchIcon}
            />
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              // dispatch(showAnimatedOverlay(true));
              setTabFilter('Position');
              bottomSheetRef?.current?.snapToIndex?.(0);
            }}>
            <Ionicons
              name="options-outline"
              size={22}
              color="#303030"
              style={positionScreen.headerFilterIcon}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Flatelist code start from here  */}
      {overallData.length != 0 ? (
        <FlatList
          // data={selectedIndex === 0 ? stockData : overallData}
          data={applyFilters(overallData, pFilter)}
          renderItem={renderItem}
          contentContainerStyle={{paddingBottom: 70}}
          keyExtractor={(_, index) => `item-${index}`}
          refreshing={isRefreshing}
          onRefresh={onRefresh}
        />
      ) : (
        <SkeletonPlaceholder />
      )}

      <PositionSearchModal
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
        data={overallData}
      />
    </View>
  );
};

export default Positions;

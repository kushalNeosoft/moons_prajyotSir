import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {positionSearchModal} from '../../../../theme/light';
import TodaysOverallList from './TodayOverallList';
const PositionSearchModal = ({modalVisible, setModalVisible, data}: any) => {
  const [filterData, setFilterData] = useState<any>(''); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter(item =>
        item.companyName.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };

  const renderItem = ({item}) => {
    return (
      <TodaysOverallList
        stockName={item.companyName}
        buy={item.buy}
        titleChip={item.titleChip}
        bottomChip={item.bottomChip}
        todaysPL={item.todaysPL}
        LTP={item.LTP}
        status={item.status}
      />
    );
  };
  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View style={positionSearchModal.modal}>
        <View style={positionSearchModal.headerView}>
          <TouchableOpacity
            style={positionSearchModal.crossIcon}
            onPress={() => {
              setModalVisible(false);
              setTextInputValue('');
              setFilterData([]);
            }}>
            <AntIcon name="close" size={21} color={'#303030'} />
          </TouchableOpacity>
          <TextInput
            style={positionSearchModal.textInput}
            placeholder="Search your positions eg: Axis, Reliance"
            placeholderTextColor={'grey'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={positionSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>
        <View>
          {filterData?.length === 0 && textInputValue !== '' ? (
            <Text style={positionSearchModal.noDataText}>
              No positions available
            </Text>
          ) : (
            <FlatList
              data={filterData}
              renderItem={renderItem}
              contentContainerStyle={{paddingBottom: 10}}
              keyExtractor={(_, index) => `item-${index}`}
            />
          )}
        </View>
      </View>
    </Modal>
  );
};
export default PositionSearchModal;

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {todaysList} from '../../../../theme/light';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import {positionBottomModal} from '../../../../theme/light';
import PositionModalBtn from './positionModalBtn';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../../styles/colors';

const TodaysOverallList = props => {
  const [visibleModal, setVisibleModal] = useState(false);
  const [additionalDetails, setAdditionalDetails] = useState(false);
  return (
    // <View style={{}}>
    <>
      <TouchableOpacity
        style={todaysList.container}
        onPress={() => {
          // openModal();
          setVisibleModal(true);
        }}>
        <View style={{alignItems: 'flex-start'}}>
          <View style={todaysList.rowAlignC}>
            <Text style={todaysList.listTitle}>{props.stockName}</Text>
            <View style={todaysList.titleChip}>
              <Text style={todaysList.titleChipText}>{props.titleChip}</Text>
            </View>
          </View>
          <View style={todaysList.subView}>
            <Text style={todaysList.buyText}>Buy : </Text>
            <Text style={todaysList.listSubTitle}>{props.buy}</Text>
          </View>
          <View style={todaysList.bottomChip}>
            <Text style={todaysList.bottomChipText}>{props.bottomChip}</Text>
          </View>
        </View>
        <View style={todaysList.listPlLtpView}>
          <View style={[todaysList.row, {flex: 1}]}>
            <Text style={todaysList.listLtpText}>LTP : </Text>
            <Text style={todaysList.listLtpValue}>{props.LTP}</Text>
          </View>
          <View style={todaysList.row}>
            <Text style={todaysList.listPlText}>Today's P/L : </Text>
            <Text
              style={[
                todaysList.listPlValue,
                {
                  color: props?.todaysPL?.includes('-')
                    ? root.color_negative
                    : root.color_positive,
                },
              ]}>
              {props.todaysPL}
            </Text>
          </View>
        </View>
      </TouchableOpacity>

      <CommonModal
        visible={visibleModal}
        onClose={() => {}}
        // onClose={() => {
        //   setVisibleModal(false);
        //   setAdditionalDetails(false);
        // }}
      >
        <View style={positionBottomModal.positionmodalView}>
          <TouchableOpacity
            onPress={() => {
              setVisibleModal(false);
              setAdditionalDetails(false);
            }}
            style={positionBottomModal.closeIcon}>
            <AntDesign name="close" size={21} color="#303030" />
          </TouchableOpacity>
          <View style={positionBottomModal.rowSpacebetween}>
            <View style={{alignItems: 'flex-start'}}>
              <View style={positionBottomModal.rowAlignC}>
                <Text style={positionBottomModal.positionlistTitle}>
                  {props.stockName}
                </Text>
                <View style={positionBottomModal.positiontitleChip}>
                  <Text style={positionBottomModal.positiontitleChipText}>
                    {props.titleChip}
                  </Text>
                </View>
              </View>
              <View style={positionBottomModal.subView}>
                <Text style={positionBottomModal.positionbuyText}>
                  {props.status}
                </Text>
                <Text style={positionBottomModal.positionlistSubTitle}>
                  {props.buy}
                </Text>
              </View>
              <View style={positionBottomModal.positionbottomChip}>
                <Text style={positionBottomModal.positionbottomChipText}>
                  {props.bottomChip}
                </Text>
              </View>
            </View>
            <View style={positionBottomModal.positionlistPlLtpView}>
              <View style={positionBottomModal.row}>
                <Text style={positionBottomModal.positionlistPlText}>
                  Today's P/L :{' '}
                </Text>
                <Text
                  style={[
                    positionBottomModal.positionlistPlValue,
                    {
                      color: props?.todaysPL?.includes('-')
                        ? root.color_negative
                        : root.color_positive,
                    },
                  ]}>
                  {props.todaysPL}
                </Text>
              </View>
              <View style={positionBottomModal.row}>
                <Text style={positionBottomModal.positionlistLtpText}>
                  LTP :{' '}
                </Text>
                <Text style={positionBottomModal.positionlistLtpValue}>
                  {props.LTP}
                </Text>
              </View>
            </View>
          </View>

          <View>
            <TouchableOpacity
              onPress={() => {
                setAdditionalDetails(!additionalDetails);
              }}>
              <View style={positionBottomModal.additionalTextIconView}>
                <Text style={positionBottomModal.positionadditionalDetailsText}>
                  Additional Details
                </Text>
                {additionalDetails === false ? (
                  <AntDesign
                    name="caretdown"
                    size={10}
                    color="#303030"
                    style={positionBottomModal.upDownIcon}
                  />
                ) : (
                  <AntDesign
                    name="caretup"
                    size={10}
                    color="#303030"
                    style={positionBottomModal.upDownIcon}
                  />
                )}
              </View>
            </TouchableOpacity>
            {additionalDetails ? (
              <View style={positionBottomModal.positionaddtionaldetailsView}>
                <View>
                  <Text
                    style={
                      positionBottomModal.positionadditionalDetailsHTitle
                    }></Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsTitle}>
                    Buy
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsTitle}>
                    Sell
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsTitle}>
                    Net
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsHTitle}>
                    Qty
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsHTitle}>
                    Avg Price
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                </View>
                <View style={{alignItems: 'flex-end'}}>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsHTitle}>
                    Total Value
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                  <Text
                    style={positionBottomModal.positionadditionalDetailsValues}>
                    0
                  </Text>
                </View>
              </View>
            ) : (
              <View style={{height: 18}}></View>
            )}
          </View>
          <View style={positionBottomModal.rowSpacebetween}>
            <PositionModalBtn title={'Convert Position'} style={{flex: 0.46}} />
            <PositionModalBtn title={'Add more'} style={{flex: 0.46}} />
          </View>
          <PositionModalBtn title={'Square Off'} />
        </View>
      </CommonModal>
    </>
    // </View>
  );
};
export default TodaysOverallList;

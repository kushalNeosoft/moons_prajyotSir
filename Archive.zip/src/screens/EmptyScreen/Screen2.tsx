import React from "react";
import { View,Text } from "react-native";

const Screen2=()=>{
    return(
       <View>
        <Text style={{fontSize:50,backgroundColor:"yellow"}}>
            New Screen Log
        </Text>
       </View>
    )
}
export default Screen2;
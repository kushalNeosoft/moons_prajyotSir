import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {View, Text, StyleSheet, ScrollView, Animated} from 'react-native';
import AnimatedTopBar from '../../navigators/PortfolioTopBarNavigation/animationTopbar';
import Ionicons from 'react-native-vector-icons/Ionicons';
import PortfolioHeader from '../../components/PortfolioScreenHeaders/PortfolioHeader';
import NiftyAndSensexHeader from '../../components/PortfolioScreenHeaders/NiftyAndSensexHeader';

const Portfolio = () => {
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [scrollValue, setScrollValue] = useState(0);
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));

  // This useEffect is calling for FadeIn and fadeOut effect
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  // this useEffect is calling for Header hight change
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(scrollY, {
        toValue: 1,
        duration: 200,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(scrollY, {
        toValue: 0,
        duration: 100,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  const height = scrollY.interpolate({
    inputRange: [0, 1],
    outputRange: [155, 80],
    extrapolate: 'clamp',
  });

  return (
    <View style={styles.container}>
      <Animated.View
        style={{
          height: height,
          backgroundColor: 'white',
        }}>
        {scrollValue == 1 ? (
          <PortfolioHeader scrollValue={scrollValue} />
        ) : (
          <NiftyAndSensexHeader scrollValue={scrollValue} />
        )}
      </Animated.View>
      <AnimatedTopBar setScrollValue={setScrollValue} />
    </View>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  PortfolioText: {
    fontSize: 20,
    color: 'black',
    fontWeight: '600',
    marginLeft: 60,
    marginTop: 3,
  },
  PortfolioSubTitle: {
    fontSize: 16,
    color: 'grey',
    fontWeight: '500',
    marginLeft: 60,
  },
  PortfolioChanges: {
    fontSize: 14,
    color: 'green',
    fontWeight: '500',
    marginLeft: 60,
  },
  currentValue: {
    fontSize: 13,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  currentValueNumber: {
    fontSize: 20,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  overAllPl: {
    fontSize: 13,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  overAllPlNumber: {
    fontSize: 13,
    color: 'green',
    fontWeight: '500',
    marginLeft: 15,
  },
  investedValue: {
    fontSize: 12,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  investedValueNumber: {
    fontSize: 15,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
    marginTop: 5,
  },
  todaysPl: {
    fontSize: 13,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  todaysNumber: {
    fontSize: 13,
    color: 'red',
    fontWeight: '500',
    marginLeft: 15,
  },
});
export default Portfolio;

import React from 'react';
import {View, Text, TouchableOpacity, FlatList, Alert} from 'react-native';
import {styles} from '../styles/styles';
import {newsData, newsListData} from './SampleData';
import NewsComponent from '../../../components/MarketScreen/NewsComponent';
import NewsListComponent from '../../../components//MarketScreen/NewsListComponent';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {useNavigation} from '@react-navigation/native';
const NewsAndAnnouncement = props => {
  const navigation = useNavigation();
  const renderNewsItem = ({item}) => {
    return <NewsComponent title={item?.title} subTitle={item.subTitle} />;
  };
  const renderNewsListItem = ({item}) => {
    return (
      <NewsListComponent
        title={item.title}
        stockName={item.stockName}
        price={item.price}
        change={item.change}
        time={item.time}
      />
    );
  };
  return (
    <View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingRight: 15,
        }}>
        <Text style={styles.scrollHead}>News & Announcements</Text>
        <TouchableOpacity>
          <MaterialIcons
            name="search"
            size={26}
            color={'black'}
            style={styles.newsSearchButton}
          />
        </TouchableOpacity>
      </View>
      <View>
        <FlatList
          data={newsData}
          renderItem={renderNewsItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          ListFooterComponent={() => {
            return <View style={{width: 16}}></View>;
          }}
        />
        <View>
          <FlatList
            data={newsListData?.slice(0, 4)}
            renderItem={renderNewsListItem}
            keyExtractor={(_, index) => `item-${index}`}
          />
          <TouchableOpacity
            onPress={() => {
              // navigation.navigate('ViewAllNews');
              Alert.alert('Under Development');
            }}>
            <Text style={styles.allNewsText}>
              View All News & Announcements
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default NewsAndAnnouncement;

import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {styles} from '../styles/styles';
import {newProductData} from './SampleData';
import NewProductComponent from '../../../components/MarketScreen/NewProductComponent';

const NewProducts = () => {
  const renderNewProductItem = ({item}) => {
    return <NewProductComponent title={item.title} />;
  };
  return (
    <View>
      <Text style={styles.scrollHead}>New products</Text>
      <View>
        <FlatList
          data={newProductData}
          renderItem={renderNewProductItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          style={{marginLeft: 16}}
        />
      </View>
    </View>
  );
};
export default NewProducts;

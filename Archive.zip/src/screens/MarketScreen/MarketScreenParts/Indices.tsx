import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {styles} from '../styles/styles';
import {indicesData} from './SampleData';
import IndicesComponent from '../../../components/MarketScreen/IndicesCoponent';
const Indices = () => {
  const renderIndicesItem = ({item}) => {
    return (
      <IndicesComponent
        title={item.title}
        price={item.price}
        changes={item.changes}
        date={item.date}
      />
    );
  };
  return (
    <View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingRight: 15,
        }}>
        <Text style={styles.scrollHead}>Indices</Text>
        <TouchableOpacity>
          <Text style={styles.viewAllButton}>View All</Text>
        </TouchableOpacity>
      </View>
      <View>
        <FlatList
          data={indicesData}
          renderItem={renderIndicesItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          style={{marginLeft: 16}}
        />
      </View>
    </View>
  );
};
export default Indices;

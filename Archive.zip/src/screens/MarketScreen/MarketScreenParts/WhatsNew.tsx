import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {styles} from '../styles/styles';
import {whatsNewData} from './SampleData';
import WhatsNewComponent from '../../../components/MarketScreen/WhatsNewComponent';

const WhatsNew = () => {
  const renderWhatsNewItem = ({item}) => {
    return <WhatsNewComponent title={item.title} subTitle={item.subTitle} />;
  };
  return (
    <View>
      <Text style={[styles.scrollHead, {marginTop: 12}]}>What's New_1404</Text>
      <View>
        <FlatList
          data={whatsNewData}
          renderItem={renderWhatsNewItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          ListFooterComponent={() => {
            return <View style={{width: 16}}></View>;
          }}
          contentContainerStyle={{marginLeft: 16}}
        />
      </View>
    </View>
  );
};
export default WhatsNew;

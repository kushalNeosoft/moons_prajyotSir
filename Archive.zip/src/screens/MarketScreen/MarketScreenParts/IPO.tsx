import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {styles} from '../styles/styles';
import {ipoData} from './SampleData';
import IPOComponent from '../../../components/MarketScreen/IpoComponent';
const IPO = () => {
  const renderIpoItem = ({item}) => {
    return (
      <IPOComponent
        title={item.title}
        range={item.range}
        date={item.date}
        minQty={item.minQty}
        minAmount={item.minAmount}
      />
    );
  };
  return (
    <View>
      <Text style={styles.scrollHead}>IPO</Text>
      <View>
        <FlatList
          data={ipoData}
          renderItem={renderIpoItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          contentContainerStyle={{marginLeft: 13}}
        />
      </View>
      <View style={{height: 175}}></View>
    </View>
  );
};
export default IPO;

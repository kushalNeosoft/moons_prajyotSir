import {StyleSheet} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
export const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    borderBottomColor: root.color_primary,
  },
  header: {
    width: '100%',
    height: 58,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: root.color_primary,
    paddingLeft: 17,
    paddingRight: 16,
  },
  headerText: {
    color: root.color_text,
    fontSize: 18,
    marginLeft: 20,
    fontFamily: Cfont.rubik_medium,
  },
  headerIcon: {
    marginLeft: 16,
  },
  topBar: {
    flexDirection: 'row',
    borderRadius: 25,
    // alignItems:"center",
    // justifyContent:"center",
  },
  topBarText: {
    fontSize: 12,
    marginHorizontal: 9,
    fontFamily: Cfont.rubik_medium,
  },
  topBarOpacity: {
    paddingHorizontal: 10,
    height: 35,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
  },
  scrollHead: {
    color: root.color_text,
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 16,
  },
  viewAllButton: {
    color: root.color_textual,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
  },
  newsSearchButton: {
    color: root.color_text,
    paddingTop: 7,
  },
  allNewsText: {
    color: root.color_textual,
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 40,
  },
  eventDateView: {
    backgroundColor: root.calendar_bg,
    height: 60,
    width: '100%',
    marginTop: 13,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  currentDate: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 16,
    fontSize: 16,
  },
  emptyEventText: {
    color: root.color_subtext,
    fontSize: 15,
    marginBottom: 50,
    marginTop: 15,
    fontFamily: Cfont.rubik_regular,
  },
});

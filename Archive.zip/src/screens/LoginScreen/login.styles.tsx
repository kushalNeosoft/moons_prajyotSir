import {Dimensions, StatusBar, StyleSheet, useColorScheme} from 'react-native';
import {TColors} from '../../styles/colors';
import { root } from '../../styles/colors';
import { Font , Cfont } from '../../styles/colors';

const height = Dimensions.get('window').height;
// console.log(height);
const statusHeight = StatusBar?.currentHeight ? StatusBar?.currentHeight : 0;

export const createLoginStyles = (colors: TColors) => {
  return StyleSheet.create({
    scrollContainer: {
      flex: 1,
    },
    container: {
      flexGrow: 1,
      flex: 1,
      height: height,
      backgroundColor: colors.background,
      
    },
    block1: {
      flex: 1,
      flexGrow: 1,
      flexDirection: 'column',
      padding: 16,
    },
    block1ButtonContainer: {
      flexDirection: 'row',
      marginTop: 48,
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    buttonContainer: {
      flexDirection: 'row',
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: Font.font_normal_three,
      alignSelf: 'center',
    },
    buttonTextone: {
      color: root.color_text,
      fontSize: Font.font_normal_three,
      alignSelf: 'center',
      fontFamily:Cfont.rubik_medium,
    },
    buttonImage: {
      color: root.color_active,
      width: Font.font_normal_three,
      marginLeft: 16,
    },
    buttonImageone: {
      color: root.color_text,
      width: Font.font_normal_three,
      marginLeft: 16,
    },
    forgettxt:{
      color: root.color_textual,
      fontSize:Font.font_normal_one,
      fontFamily:Cfont.rubik_medium,

    },
    haventtxt:{
      fontSize:Font.font_normal_one,
      color:root.color_text,
      fontFamily:Cfont.rubik_light,


    },
    registertxt:{
      color: root.client_background,
      fontSize: Font.font_normal_one,
      fontFamily:Cfont.rubik_medium,
    },
    signupContainer: {
      flexDirection: 'row',
      marginTop: 32,
      alignItems: 'center',
      backgroundColor: 'black',
      paddingVertical: 16,
      paddingHorizontal: 24,
      borderRadius: 16,
    },
    signupContainerHeading: {
      color: root.color_active,
      fontFamily:Cfont.rubik_medium,
      fontSize:Font.font_normal_three,
    },
    signupContainerSubHeading: {
      color: root.signup_wrap_subtitle,
      fontSize: Font.font_normal_five,
      fontFamily:Cfont.rubik_regular,
      marginTop: 8,
    },
    Avaltxt:{
      fontSize:Font.font_normal_one,
      color:root.color_text,
      fontFamily:Cfont.rubik_light,
    },
    rowtxt:{
      fontSize:Font.font_normal_one,
      color:root.client_background,
      fontFamily:Cfont.rubik_medium,
    },
    exchtxt:{
      fontSize:Font.font_normal_six,
      color:root.client_background,
      fontFamily:Cfont.rubik_medium,
    },
    block2: {
      padding: 16,
    },
    heading: {
      fontSize:Font.font_title,
      color:root.color_text,
      fontFamily:Cfont.rubik_medium,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: 'lightgrey',
      borderWidth: 2,

      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: 'grey',
      margin: 12,
    },
    sectionContainer: {
      marginTop: 32,
      paddingHorizontal: 24,
    },
    sectionTitle: {
      fontSize: 24,
      fontWeight: '600',
    },
    sectionDescription: {
      marginTop: 8,
      fontSize: 18,
      fontWeight: '400',
    },
    highlight: {
      fontWeight: '700',
    },
    footerContainer: {
      marginTop: 8,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
  });
};

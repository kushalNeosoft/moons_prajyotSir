import React from 'react';
import {View, Text} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';

const ExchangeDialog = () => {
  return (
    <View style={{padding: 16}}>
      <Text
        style={{
          fontSize: Font.font_title,
          fontFamily: Cfont.rubik_medium,
          color: root.color_text,
        }}>
        Membership Details
      </Text>
      <View style={{marginTop: 16}}>
        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 1}}></View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              MEMBER ID
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              SEBI REG No
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              NSE
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              121212
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              111111
            </Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View style={{flex: 1}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_medium,}}>
              NSE
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              131313
            </Text>
          </View>
          <View style={{flex: 2}}>
            <Text
              style={{fontSize: Font.font_normal_one, color: root.color_text,fontFamily:Cfont.rubik_light,}}>
              222222
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};
export default ExchangeDialog;

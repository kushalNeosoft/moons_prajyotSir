import React from 'react';
import {View, Text} from 'react-native';

const MembershipDialog = () => {
  return (
    <View style={{padding: 16}}>
      <Text style={{fontSize: 30, fontWeight: 'bold', color: 'black'}}>
        Membership Details
      </Text>
      <View style={{marginTop: 16}}>
        <View style={{flexDirection: 'row'}}>
          <View style={{flex: 1}}></View>
          <View style={{flex: 2}}>
            <Text>MEMBER ID</Text>
          </View>
          <View style={{flex: 2}}>
            <Text>SEBI REG No</Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View style={{flex: 1}}>
            <Text>NSE</Text>
          </View>
          <View style={{flex: 2}}>
            <Text>121212</Text>
          </View>
          <View style={{flex: 2}}>
            <Text>111111</Text>
          </View>
        </View>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View style={{flex: 1}}>
            <Text>NSE</Text>
          </View>
          <View style={{flex: 2}}>
            <Text>131313</Text>
          </View>
          <View style={{flex: 2}}>
            <Text>222222</Text>
          </View>
        </View>
      </View>
    </View>
  );
};
export default MembershipDialog;

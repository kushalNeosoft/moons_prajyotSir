 import React, {useRef, useState} from 'react';
import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';


import useStyles from '../../styles/useStyles';

import {useTranslation} from 'react-i18next';

import {createProfileStyles} from './styles/profile.styles';
import MPinComponent from './components/MPinComponent';
import PasswordComponent from './components/PasswordComponent';
import DropDownIcon from '../../assets/DropDownIcon';
import Footer from '../../components/Footer/Footer';
import Dropdown from '../../components/Dropdown/Dropdown';
import BottomSheet, {
  BottomSheetProps,
} from '../../components/BottomSheet/BottomSheet';
// import SwitchDialog from './components/SwitchDialog';
import SwitchDialog from './components/SwitchDialog';
// import React, {useRef, useState} from 'react';
 

const options = ['Option 1', 'Option 2', 'Option 3'];
const ProfileScreen = ({navigation}: any) => {
  const switchSheetRef = useRef<BottomSheetProps>(null);

  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const handleSelect = (option: string) => {
    setSelectedOption(option);
  };
  const [selectedTab, setSelectedTab] = useState('MPIN');
  const {colors, styles} = useStyles(createProfileStyles);
  const {t} = useTranslation();
  return (
    // <ScrollView style={styles.scrollContainer}>
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <View style={styles.userContainer}>
          <View style={styles.userProfilePic} />
          <View style={styles.userInfoContainer}>
            <Text style={styles.userName}>OM</Text>
            <Text style={styles.userId}>
              UserId: <Text>OM</Text>
            </Text>
            <View
              style={{
                borderRadius: 16,
                // flex: 1,
                justifyContent: 'center',
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  // navigation.navigate('ForgotPasswordScreen');
                  // i18next.changeLanguage('en');
                  switchSheetRef.current?.open();
                }}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View style={styles.switchAccountContainer}>
                  <Text
                    style={{color: 'black', fontWeight: 'bold', fontSize: 14}}>
                    Switch Account
                  </Text>
                  <DropDownIcon style={styles.dropDownIcon} />
                </View>
              </TouchableNativeFeedback>
              </View>
          </View>
        </View>
        <View style={styles.tabContainer}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              console.log('Here');
              setSelectedTab('MPIN');
            }}>
            <View style={styles.tabItem}>
              <Text
                style={[
                  styles.itemText,
                  {
                    color: selectedTab === 'MPIN' ? colors.primary : 'gray',
                  },
                ]}>
                M-Pin
              </Text>
              <View style={styles.itemUnderlineContainer}>
                <View
                  style={[
                    styles.itemUnderline,
                    {
                      backgroundColor:
                        selectedTab === 'MPIN' ? colors.primary : 'transparent',
                    },
                  ]}
                />
              </View>
            </View>
          </TouchableNativeFeedback>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', false)}
            onPress={() => {
              setSelectedTab('PASSWORD');
            }}>
            <View style={styles.tabItem}>
              <Text
                style={[
                  styles.itemText,
                  {
                    color: selectedTab === 'PASSWORD' ? colors.primary : 'gray',
                  },
                ]}>
                Password
              </Text>
              <View style={styles.itemUnderlineContainer}>
                <View
                  style={[
                    styles.itemUnderline,
                    {
                      backgroundColor:
                        selectedTab === 'PASSWORD'
                          ? colors.primary
                          : 'transparent',
                    },
                  ]}
                />
              </View>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      
      <View style={styles.bodyContainer}>
        {selectedTab === 'MPIN' && <MPinComponent />}
        {selectedTab === 'PASSWORD' && (
          <PasswordComponent navigation={navigation} />
        )}
      </View>
      <Footer />
      <BottomSheet
        ref={switchSheetRef}
        height={208}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 16,
          },
        }}>
        <SwitchDialog />
      </BottomSheet>
      
    </View>
    // </ScrollView>
  );
};

export default ProfileScreen;

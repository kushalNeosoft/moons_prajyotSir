import {StyleSheet} from 'react-native';
import {TColors} from '../../../styles/colors';

export const createPasswordStyles = (colors: TColors) => {
  return StyleSheet.create({
    buttonContainer: {
      backgroundColor: 'darkblue',
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: 'white',
      fontSize: 20,
      alignSelf: 'center',
    },

    inputContainer: {
      flexDirection: 'row',
      borderColor: 'lightgrey',
      borderWidth: 2,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: 'grey',
      margin: 12,
    },
  });
};

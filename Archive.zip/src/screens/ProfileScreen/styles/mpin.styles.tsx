import {StyleSheet} from 'react-native';
import {TColors} from '../../../styles/colors';

export const createMpinStyles = (colors: TColors) => {
  return StyleSheet.create({
    titleContainer: {
      marginTop: 16,
    },
    title: {
      fontSize: 16,
      fontWeight: 'bold',
      color: 'black',
    },
    pinContainer: {
      flexDirection: 'row',
      marginTop: 16,
    },
    pinInput: {
      borderColor: 'lightgrey',
      borderWidth: 2,
      borderRadius: 4,
      margin: 0,
      paddingVertical: 8,
      paddingHorizontal: 16,
      height: 40,
      width: 40,
      textAlign: 'center',
    },
    buttonContainer: {
      backgroundColor: 'darkblue',
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: 'white',
      fontSize: 20,
      alignSelf: 'center',
    },

    inputContainer: {
      flexDirection: 'row',
      borderColor: 'lightgrey',
      borderWidth: 2,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: 'grey',
      margin: 12,
    },
    secondaryContainer: {
      marginTop: 32,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
  });
};

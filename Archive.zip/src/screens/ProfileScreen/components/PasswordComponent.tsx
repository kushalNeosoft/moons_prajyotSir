import {Text, TextInput, TouchableNativeFeedback, View} from 'react-native';
import VisibilityIcon from '../../../assets/VisibilityIcon';
import VisibilityOffIcon from '../../../assets/VisibilityOffIcon';
import {useState} from 'react';
import {createPasswordStyles} from '../styles/password.styles';
import useStyles from '../../../styles/useStyles';
import React from 'react';

const PasswordComponent = ({navigation}: any) => {
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const {colors, styles} = useStyles(createPasswordStyles);
  return (
    <View>
      <View style={[styles.inputContainer, {marginTop: 16}]}>
        <TextInput
          style={styles.input}
          placeholder={'Password'}
          secureTextEntry={!showPassword}
          onChangeText={text => {}}
        />
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            // onLogin();
            console.log('Here');
            setShowPassword(prev => !prev);
          }}>
          <View>
            {showPassword ? (
              <VisibilityIcon style={[styles.inputIcon, {flex: 1}]} />
            ) : (
              <VisibilityOffIcon style={[styles.inputIcon, {flex: 1}]} />
            )}
          </View>
        </TouchableNativeFeedback>
      </View>
      <View
        style={{
          borderRadius: 8,
          marginTop: 32,
        }}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('blue', true)}
          onPress={() => {
            // onLogin();
            // i18next.changeLanguage('hin');
          }}>
          <View style={styles.buttonContainer}>
            <Text style={styles.buttonText}>Verify</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
      <View
        style={{
          marginTop: 32,
          flexDirection: 'row',
          justifyContent: 'space-between',
        }}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <Text style={{fontSize: 12}}>Take Me To</Text>

          <View
            style={{
              borderRadius: 16,
            }}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('gray', true)}
              onPress={() => {}}>
              <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                <Text
                  style={{color: 'black', fontWeight: 'bold', fontSize: 12}}>
                  Watchlist
                </Text>
              </View>
            </TouchableNativeFeedback>
          </View>
        </View>
        <View
          style={{
            borderRadius: 16,
          }}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              navigation.navigate('ForgotPasswordScreen');
              // i18next.changeLanguage('en');
            }}
            // disabled={socketStatus === SocketStatus.CONNECTED}
          >
            <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
              <Text style={{color: 'black', fontWeight: 'bold', fontSize: 12}}>
                Forgot Password?
              </Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
    </View>
  );
};
export default PasswordComponent;

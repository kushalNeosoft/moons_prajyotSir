import {useState} from 'react';
import {View, Text, TouchableNativeFeedback} from 'react-native';

const WatchlistDialog = () => {
  const [selected, setSelected] = useState('WATCHLIST');
  return (
    <View style={{width: '100%'}}>
      <Text style={{fontSize: 32, color: 'black', padding: 16}}>
        Take Me To
      </Text>

      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('WATCHLIST');
        }}>
        <View style={{flexDirection: 'row', marginTop: 16, padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'WATCHLIST' && (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 16, fontWeight: 'bold', marginLeft: 16}}>
            Watchlist
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('MARKET');
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'MARKET' && (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 16, fontWeight: 'bold', marginLeft: 16}}>
            Market
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('ORDERS');
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'ORDERS' && (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 16, fontWeight: 'bold', marginLeft: 16}}>
            Orders
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('PORTFOLIO');
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'PORTFOLIO' && (
              <View
                style={{
                  height: 12,
                  width: 12,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 16, fontWeight: 'bold', marginLeft: 16}}>
            Portfolio
          </Text>
        </View>
      </TouchableNativeFeedback>
    </View>
  );
};
export default WatchlistDialog;

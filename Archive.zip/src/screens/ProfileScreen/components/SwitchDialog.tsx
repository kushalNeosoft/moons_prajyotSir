import React from 'react';
import {Text, TouchableNativeFeedback, View} from 'react-native';
import AccountIcon from '../../../assets/AccountIcon';
import { Font, root } from '../../../styles/colors';

const SwitchDialog = () => {
  return (
    <View
      style={{width: '100%'}}
      onLayout={event => {
        var {x, y, width, height} = event.nativeEvent.layout;
        console.log(height);
      }}>
      <Text style={{fontSize: Font.font_title, color: root.color_text, padding: 16}}>
        Switch Account
      </Text>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {}}>
        <View style={{flexDirection: 'row', marginTop: 16, padding: 16}}>
          <View
            style={[
              {
                height: 24,
                width: 24,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            <View
              style={{
                height: 12,
                width: 12,
                borderRadius: 6,
                backgroundColor: '#000',
              }}
            />
          </View>
          <Text style={{fontSize: Font.font_normal_one, fontWeight: 'bold', marginLeft: 16,color:root.color_text}}>
            OM
          </Text>
        </View>
      </TouchableNativeFeedback>
      <View style={{height: 2, backgroundColor: 'lightgray'}} />
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {}}>
        <View style={{flexDirection: 'row', padding: 16, alignItems: 'center'}}>
          <AccountIcon
            style={{
              height: 28,
              width: 28,
              color: 'black',
            }}
          />
          <Text style={{fontSize: Font.font_normal_one, fontWeight: 'bold', marginLeft: 16,color:root.color_text}}>
            Use Another Account
          </Text>
        </View>
      </TouchableNativeFeedback>
    </View>
  );
};

export default SwitchDialog;

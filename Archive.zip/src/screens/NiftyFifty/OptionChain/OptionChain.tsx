import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../../components/utils/alignment';

function OptionChain() {
  const [date, setDate] = useState('04');
  const data = [
    {
      date: '04',
      month: 'MAY',
      year: "'23",
    },
    {
      date: '11',
      month: 'MAY',
      year: "'23",
    },
    {
      date: '18',
      month: 'MAY',
      year: "'23",
    },
    {
      date: '25',
      month: 'MAY',
      year: "'23",
    },
  ];

  const renderDates = ({item, key}: any) => {
    return (
      <View style={{paddingLeft: 10, paddingTop: 15}}>
        <TouchableOpacity
          onPress={() => setDate(item.date)}
          style={
            date === item.date
              ? styles.dateContainerSelected
              : styles.dateContainerUnselected
          }>
          <Text
            style={
              date === item.date
                ? styles.dateTxtSelected
                : styles.dateTxtUnselected
            }>
            {item.date}
          </Text>
          <View style={{...alignment.row}}>
            <Text
              style={
                date === item.date
                  ? styles.monthTxtSelected
                  : styles.monthTxtUnselected
              }>
              {item.month}
            </Text>
            <Text
              style={
                date === item.date
                  ? styles.yearTxtSelected
                  : styles.yearTxtUnselected
              }>
              {item.year}
            </Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  };
  return (
    <View style={styles.container}>
      <View>
        <FlatList data={data} horizontal={true} renderItem={renderDates} />
      </View>
      <Text style={styles.expiryTxt}>*18 Expires available till dec'27</Text>
      <View
        style={{
          ...alignment.row_SpaceB,
          paddingHorizontal: 15,
          paddingTop: 15,
        }}>
        <Text style={styles.callsTxt}>Calls</Text>
        <Text style={styles.callsTxt}>Puts</Text>
      </View>
      <Text style={{alignSelf:'center',fontSize:20,color:'black'}}>Work in Progress</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
  },
  dateContainerUnselected: {
    borderWidth: 0.3,
    height: 50,
    width: 80,
    marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
  },
  dateContainerSelected: {
    borderWidth: 0.3,
    height: 50,
    width: 80,
    marginHorizontal: 5,
    borderRadius: 10,
    borderColor: 'grey',
    backgroundColor: root.client_background,
  },
  dateTxtUnselected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_three,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  dateTxtSelected: {
    paddingLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    paddingTop: 3,
  },
  monthTxtUnselected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  monthTxtSelected: {
    marginLeft: 10,
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
  },
  yearTxtUnselected: {
    fontSize: Font.font_normal_two,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
  },
  yearTxtSelected: {
    fontSize: Font.font_normal_two,
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
  },
  expiryTxt: {
    fontSize: Font.font_normal_seven,
    color: 'grey',
    fontFamily: Cfont.rubik_regular,
    paddingTop: 25,
    paddingLeft:15
  },
  callsTxt: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
});

export default OptionChain;

import React from 'react';
import {View, Text, StyleSheet, FlatList} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import LinearGradient from 'react-native-linear-gradient';

function OverView() {
  const data = [
    {
      title: 'Open',
      value: '17707.55',
    },
    {
      title: 'Close',
      value: '17624.05',
    },
    {
      title: 'Daily Price Range',
      value: '17620.05-17709.20',
    },
  ];

  return (
    <View style={{flexGrow: 1, backgroundColor: '#ffffff'}}>
      <View style={styles.keyStatsContainer}>
        <View style={styles.innerContainer}>
          <Text style={styles.keyStatsTxt}>Key Stats</Text>

          <View style={styles.keyStatsLowerContent}>
            {data.map(item => (
              <View>
                <Text style={styles.headingTxt}>{item.title}</Text>
                <Text style={styles.valuesTxt}>{item.value}</Text>
              </View>
            ))}
          </View>

          <View style={styles.horizontalLine} />

          <Text
            style={{
              fontSize: Font.font_normal_one,
              color: root.color_text,
              fontFamily: Cfont.rubik_medium,
              paddingTop: 16,
            }}>
            Today(Low - High)
          </Text>

          <LinearGradient
            colors={['#ff0d00', '#ffcc00', '#90ee90']}
            style={{height: 4, width: 135, borderRadius: 5, marginTop: 10}}
            useAngle={true}
            angle={90}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
  },
  keyStatsContainer: {
    backgroundColor: 'white',
    height: 166,
    marginTop: 10,
  },
  keyStatsTxt: {
    fontSize: Font.font_normal_four,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  innerContainer: {
    padding: 16,
  },
  keyStatsLowerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  headingTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  valuesTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_one,
    fontFamily: Cfont.rubik_regular,
  },
  horizontalLine: {
    borderWidth: 0.2,
    borderColor: 'grey',
    width: '100%',
    alignSelf: 'center',
    marginTop: 10,
  },
});

export default OverView;

import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../styles/colors';

export const createSignupStyles = (colors: TColors) => {
  return StyleSheet.create({
    scrollContainer: {
      flex: 1,
    },
    container: {
      flexGrow: 1,
      flex: 1,
      // height: height,
      backgroundColor: colors.background,
      padding: 16,
    },
    block1ButtonContainer: {
      flexDirection: 'row',
      marginTop: 48,
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    buttonContainer: {
      flexDirection: 'row',
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: Font.font_normal_three,
      alignSelf: 'center',
    },
    buttonImage: {
      color: root.color_active,
      width: 24,
      marginLeft: 16,
    },
    heading: {
      fontSize: Font.font_title,
      fontFamily:Cfont.rubik_medium,
      color: root.color_text,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: 'lightgrey',
      borderWidth: 2,

      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: 'grey',
    },
  });
};

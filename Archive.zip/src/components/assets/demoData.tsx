

export const demoData = [
  {
  price: 827.67,
  changes: '+3.65(+0.44%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 5000,
  plus: '[+77.06%]',
  minus: '',

},
{
  stockName: 'WIPRO',
  price: 977.7,
  changes: '+2.65(+0.54%)',
  portfolio: false,
  title:'Vol.Gainer',
  stockfrom:'NSE',

},
{
  stockName: 'HDFCBANK',
  price: 767.7,
  changes: '+5.67(+0.50%)',
  portfolio: false,
  title:'Vol.Gainer',
  stockfrom:'NSE',

},
{
  stockName: 'TCS',
  price: 890.5,
  changes: '+2.69(+0.55%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 1200,
  plus: '[+77.06%]',
  minus: '',

},
{

  stockName: 'SBIN',
  price: 890.89,
  changes: '+2.69(+0.55%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 1800,
  plus: '[+77.06%]',
  minus: '',

},
{

  stockName: 'BSE',
  price: 890.79,
  changes: '+2.69(+0.55%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 300,
  plus: '[+77.06%]',
  minus: '',
 
},
{
  stockName: 'SBIN',
  price: 1098.59,
  changes: '+4.69(+0.75%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 400,
  plus: '',
  minus: '[-12.90%]',

},
{
  stockName: 'NTPC',
  price: 655.52,
  changes: '+1.69(+0.35%)',
  portfolio: false,
  title:'Vol.Gainer',
  stockfrom:'NSE',
  
},
{
  stockName: 'INFY',
  price: 789.5,
  changes: '+1.69(+0.35%)',
  portfolio: false,
  title:'Vol.Gainer',
  stockfrom:'NSE',
  
},
{
  stockName: 'RELIANCE',
  price: 890.5,
  changes: '+5.69(+0.45%)',
  portfolio: false,
  title:'Pr.Loser',
  stockfrom:'NSE',
  
},
{
  stockName: 'BAJAJ',
  price: 870.5,
  changes: '+4.69(+0.55%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 500,
  plus: '',
  minus: '[-10.90%]',

},
{
  stockName: 'TATA',
  price: 560.5,
  changes: '+7.69(+0.90%)',
  portfolio: true,
  stockfrom:'NSE',
  value: 800,
  plus: '',
  minus: '[-14.70%]',

},

{
  stockName: 'INDUSLAND',
  price: 878.5,
  changes: '+1.69(+0.20%)',
  portfolio: false,
  title:'Pr.Loser',
  stockfrom:'NSE',

},
{
  stockName: 'ICICIBANK',
  price: 678.5,
  changes: '+4.69(+0.50%)',
  portfolio: false,
  title:'Pr.Loser',
  stockfrom:'NSE',

},
{
  stockName: 'SBI',
  price: 678.5,
  changes: '+4.89(+0.5%)',
  portfolio: false,
  title:'Pr.Loser',
  stockfrom:'NSE',

},
{
  stockName: 'AXIS',
  price: 767.5,
  changes: '+2.60(+0.30%)',
  portfolio: false,
  title:'Pr.Loser',
  stockfrom:'NSE',

},
];



export const courselDemodata = [
{
  title:'Open',
  value:'1213.45'
},
{
  title:'Close',
  value:'1207.35'
},
{
  title:'Daily Price Range',
  value:'1101.60-',
  valuetwo:'1346.40'
},

]

export const progressData = [
  {
    title:'Today (Low-High)',
    price:'1383.30',
    pricetwo:'1411.05'
  },
  {
    title:'52 Week (Low-High)',
    price:'1185.30',
    pricetwo:'1672.60'
  },
  ]

  export const endDemodata = [
    {
      title:'Avg Trading Price',
      value:'1394.82'
    },
    {
      title:'Value',
      value:'120797392.35'
    },
    {
      title:'Volume',
      value:'9844356',
      
    },
    {
      title:'Last Traded Time',
      value:'15:29:59',
      
    },
    {
      title:'Last Updated Time',
      value:'15:11:17',
      
    },
    
    ]

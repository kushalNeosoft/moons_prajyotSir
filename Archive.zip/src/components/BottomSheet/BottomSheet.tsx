import React, {useState, forwardRef, useImperativeHandle} from 'react';
import {
  View,
  KeyboardAvoidingView,
  Modal,
  TouchableOpacity,
  Animated,
  Platform,
  StyleProp,
  ViewStyle,
  TouchableNativeFeedback,
} from 'react-native';
import {createBottomsheetStyles} from './style';
import CloseIcon from '../../assets/CloseIcon';
import useStyles from '../../styles/useStyles';

export type BottomSheetProps = {
  animationType?: 'none' | 'fade' | 'slide';
  height?: number;
  minClosingHeight?: number;
  openDuration?: number;
  closeDuration?: number;
  closeOnDragDown?: boolean;
  dragFromTopOnly?: boolean;
  closeOnPressMask?: boolean;
  closeOnPressBack?: boolean;
  onClose?: () => void;
  onOpen?: () => void;
  customStyles?: {
    wrapper?: StyleProp<ViewStyle>;
    container?: StyleProp<ViewStyle>;
    draggableIcon?: StyleProp<ViewStyle>;
  };
  keyboardAvoidingViewEnabled?: boolean;
  children?: React.ReactNode;
  open?: any;
  close?: any;
};

const BottomSheet = forwardRef(
  (
    {
      animationType,
      height,
      minClosingHeight,
      openDuration,
      closeDuration,
      closeOnDragDown,
      dragFromTopOnly,
      closeOnPressMask,
      closeOnPressBack,
      onClose,
      onOpen,
      customStyles,
      keyboardAvoidingViewEnabled,
      children,
    }: BottomSheetProps,
    ref: any,
  ) => {
    const {colors, styles} = useStyles(createBottomsheetStyles);
    const [modalVisible, setModalVisible] = useState(false);
    const [animatedHeight, setAnimatedHeight] = useState(new Animated.Value(0));
    const [pan, setPan] = useState(new Animated.ValueXY());

    const setModalVisibility = (visible: boolean) => {
      if (visible) {
        setModalVisible(visible);
        onOpen!();
        Animated.timing(animatedHeight, {
          useNativeDriver: false,
          toValue: height!,
          duration: openDuration,
        }).start();
      } else {
        Animated.timing(animatedHeight, {
          useNativeDriver: false,
          toValue: minClosingHeight!,
          duration: closeDuration,
        }).start(() => {
          pan.setValue({x: 0, y: 0});
          setModalVisible(visible);
          setAnimatedHeight(new Animated.Value(0));
          onClose!();
        });
      }
    };

    useImperativeHandle(ref, () => ({
      open: () => {
        setModalVisibility(true);
      },
      close: () => {
        setModalVisibility(false);
      },
    }));

    const panStyle = {
      transform: pan.getTranslateTransform(),
    };

    return (
      <Modal
        transparent
        animationType={animationType}
        visible={modalVisible}
        supportedOrientations={['landscape']}
        onRequestClose={() => {
          if (closeOnPressBack) setModalVisibility(false);
        }}>
        <KeyboardAvoidingView
          enabled={keyboardAvoidingViewEnabled}
          behavior="padding"
          style={[styles.wrapper, customStyles?.wrapper]}>
          <TouchableOpacity
            style={styles.mask}
            activeOpacity={1}
            onPress={() =>
              closeOnPressMask ? setModalVisibility(false) : null
            }
          />
          <Animated.View
            style={[
              panStyle,
              styles.container,
              {height: animatedHeight},
              customStyles?.container,
            ]}>
            <View
              style={{
                alignSelf: 'flex-end',
                padding: 12,
                position: 'absolute',
                zIndex: 10,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  closeOnPressMask ? setModalVisibility(false) : null;
                }}>
                <View>
                  <CloseIcon style={styles.closeIcon} />
                </View>
              </TouchableNativeFeedback>
            </View>

            {children}
          </Animated.View>
        </KeyboardAvoidingView>
      </Modal>
    );
  },
);

BottomSheet.defaultProps = {
  animationType: 'none',
  height: 500,
  minClosingHeight: 0,
  openDuration: 500,
  closeDuration: 400,
  closeOnDragDown: true,
  dragFromTopOnly: true,
  closeOnPressMask: true,
  closeOnPressBack: true,
  keyboardAvoidingViewEnabled: Platform.OS === 'ios',
  customStyles: {},
  onClose: () => {},
  onOpen: () => {},
  children: <View />,
};
export default BottomSheet;

import {
  TouchableNativeFeedback,
  View,
  Text,
  Dimensions,
  ScrollView,
} from 'react-native';
import useStyles from '../../styles/useStyles';
import {useTranslation} from 'react-i18next';
import {createFooterStyles} from './footer.styles';
import React, {useRef, useState} from 'react';
import BottomSheet, {BottomSheetProps} from '../BottomSheet/BottomSheet';
import AboutUsDialog from '../../screens/LoginScreen/components/AboutUsDialog';
import MembershipDialog from '../../screens/LoginScreen/components/MembershipDialog';
import ExchangeDialog from '../../screens/LoginScreen/components/ExchangeDialog';

const Footer = () => {
  const {colors, styles} = useStyles(createFooterStyles);
  const {t} = useTranslation();
  const bottomSheetRef = useRef<BottomSheetProps>();
  const height = Dimensions.get('window').height;
  const [selectedDailog, setSelectedDialog] = useState('ABOUT_US');
  return (
    <>
      <View style={styles.footerContainer}>
        <View style={styles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              setSelectedDialog('EXCHANGE');
              bottomSheetRef.current?.open();
            }}>
            <View style={styles.itemContainer}>
              <Text style={styles.text}> {t('login.exchange_timings')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
        <View style={styles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              setSelectedDialog('ABOUT_US');
              bottomSheetRef.current?.open();
            }}>
            <View style={styles.itemContainer}>
              <Text style={styles.text}>{t('login.about_us')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
        <View style={styles.cliper}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('gray', true)}
            onPress={() => {
              setSelectedDialog('MEMBERSHIP');
              bottomSheetRef.current?.open();
            }}>
            <View style={styles.itemContainer}>
              <Text style={styles.text}>{t('login.membership_details')}</Text>
            </View>
          </TouchableNativeFeedback>
        </View>
      </View>
      <BottomSheet
        ref={bottomSheetRef}
        height={(height * 3) / 4}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 16,
          },
        }}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {selectedDailog === 'ABOUT_US' && <AboutUsDialog />}
          {selectedDailog === 'MEMBERSHIP' && <MembershipDialog />}
          {selectedDailog === 'EXCHANGE' && <ExchangeDialog />}
        </ScrollView>
      </BottomSheet>
    </>
  );
};
export default Footer;

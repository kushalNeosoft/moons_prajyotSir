import {Dimensions, StatusBar, StyleSheet, useColorScheme} from 'react-native';
import {TColors} from '../../styles/colors';

// console.log(height);

export const createFooterStyles = (colors: TColors) => {
  return StyleSheet.create({
    footerContainer: {
      padding: 16,
      marginTop: 8,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    itemContainer: {
      paddingHorizontal: 12,
      paddingVertical: 4,
    },
    text: {
      fontSize: 12,
    },
    cliper: {
      borderRadius: 16,
    },
  });
};

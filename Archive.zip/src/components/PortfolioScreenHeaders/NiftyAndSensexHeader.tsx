import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Animated,
  TouchableOpacity,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';

const NiftyAndSensexHeader = ({scrollValue}) => {
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);

  const navigation = useNavigation();
  return (
    <Animated.View
      style={{
        opacity: headerOpacity2,
      }}>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
          <View
            style={{
              width: 15,
              backgroundColor: '#303030',
              height: 1.8,
              marginVertical: 1.5,
            }}></View>
          <View
            style={{
              width: 12,
              backgroundColor: '#303030',
              height: 1.8,

              marginVertical: 1.5,
            }}></View>
          <View
            style={{
              width: 8,
              backgroundColor: '#303030',
              height: 1.8,
              marginVertical: 1.5,
            }}></View>
        </TouchableOpacity>
        <View style={{marginLeft: 40}}>
          <Text style={styles.title}>NIFTY 50</Text>
          <Text style={styles.price}>17739.15</Text>
          <Text style={styles.changes}>+115.10(+2.28%)</Text>
        </View>
        <View
          style={{
            height: 60,
            width: 0.8,
            backgroundColor: 'grey',
            marginLeft: 30,
            marginTop: 5,
            opacity: 0.2,
            alignSelf: 'center',
          }}></View>
        <View style={{marginLeft: 45}}>
          <Text style={styles.sensexTitle}>SENSEX</Text>
          <Text style={styles.sensexPrice}>474774.15</Text>
          <Text style={styles.sensexChanges}>+11533.10(+0.00%)</Text>
        </View>
        <View></View>
      </View>
      <View
        style={{
          flexDirection: 'row',
          marginTop: 7,
          justifyContent: 'space-between',
        }}>
        <View>
          <Text style={styles.currentValue}>Current value</Text>
          <Text style={styles.currentValueNumber}>₹ 18,73,38,879.00</Text>
          <Text style={styles.overAllPl}>Overall P/L</Text>
          <Text style={styles.overAllPlNumber}>₹ 83,73,660.00(98.36%)</Text>
        </View>
        <View style={{marginRight: 10}}>
          <Text style={styles.investedValue}>Invested value</Text>
          <Text style={styles.investedValueNumber}>₹ 18,73,38,879.00</Text>
          <Text style={styles.todaysPl}>Todays P/L</Text>
          <Text style={styles.todaysNumber}>₹ 83,73,660.00(98.36%)</Text>
        </View>
      </View>
    </Animated.View>
  );
};
export default NiftyAndSensexHeader;

const styles = StyleSheet.create({
  sensexTitle: {
    fontSize: 14,
    color: 'black',
    fontWeight: '600',
    marginTop: 5,
    marginLeft: 10,
  },
  sensexPrice: {
    fontSize: 14,
    color: 'black',
    fontWeight: '500',
    marginLeft: 5,
  },
  sensexChanges: {
    fontSize: 10,
    color: 'green',
    fontWeight: '500',
  },
  title: {
    fontSize: 14,
    color: 'black',
    fontWeight: '600',
    marginTop: 5,
  },
  price: {
    fontSize: 14,
    color: 'black',
    fontWeight: '500',
  },
  changes: {
    fontSize: 10,
    color: 'green',
    fontWeight: '500',
  },
  currentValue: {
    fontSize: 11,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  currentValueNumber: {
    fontSize: 18,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
  },
  overAllPl: {
    fontSize: 12,
    color: 'black',
    fontWeight: '500',
    marginLeft: 15,
    marginTop: 3,
  },
  overAllPlNumber: {
    fontSize: 12,
    color: 'green',
    fontWeight: '500',
    marginLeft: 15,
  },
  investedValue: {
    fontSize: 11,
    color: 'black',
    fontWeight: '500',
    paddingLeft: 55,
  },
  investedValueNumber: {
    fontSize: 15,
    color: 'black',
    fontWeight: '500',
  },
  todaysPl: {
    fontSize: 12,
    color: 'black',
    fontWeight: '500',
    marginTop: 9,
    paddingLeft: 65,
  },
  todaysNumber: {
    fontSize: 12,
    color: 'red',
    fontWeight: '500',
  },
});

import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {View, Text, StyleSheet, Animated, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';

const PortfolioHeader = ({scrollValue}) => {
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  // This useEffect is calling for FadeIn and fadeOut effect
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);
  const navigation = useNavigation();
  return (
    <Animated.View
      style={{
        opacity: headerOpacity,
        flexDirection: 'row',
        alignItems: 'center',
      }}>
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={{marginLeft: 16}}>
        <View
          style={{
            width: 15,
            backgroundColor: '#303030',
            height: 1.8,
            marginVertical: 1.5,
          }}></View>
        <View
          style={{
            width: 12,
            backgroundColor: '#303030',
            height: 1.8,

            marginVertical: 1.5,
          }}></View>
        <View
          style={{
            width: 8,
            backgroundColor: '#303030',
            height: 1.9,
            marginVertical: 1.5,
          }}></View>
      </TouchableOpacity>
      <View style={{marginLeft: 40}}>
        <Text style={styles.PortfolioText}>Portfolio</Text>
        <Text style={styles.PortfolioSubTitle}>1,70,81,763.00</Text>
        <Text style={styles.PortfolioChanges}>1,65,74,858(97.28%)</Text>
      </View>
    </Animated.View>
  );
};
export default PortfolioHeader;

const styles = StyleSheet.create({
  PortfolioText: {
    fontSize: 20,
    color: 'black',
    fontWeight: '600',
    marginTop: 3,
  },
  PortfolioSubTitle: {
    fontSize: 16,
    color: 'grey',
    fontWeight: '500',
  },
  PortfolioChanges: {
    fontSize: 14,
    color: 'green',
    fontWeight: '500',
  },
});

import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import {Font, root, Cfont} from '../../styles/colors';

const DateEventComponent = props => {
  return (
    <TouchableOpacity style={styles.container}>
      <View>
        <Text style={styles.title}>{props.title}</Text>
        <Text style={styles.subTitle}>{props.subTitle}</Text>
      </View>
      <SimpleLineIcons
        name="arrow-right-circle"
        size={21}
        color={'black'}
        style={{paddingRight: 15}}
      />
    </TouchableOpacity>
  );
};
export default DateEventComponent;

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: 15,
  },
  subTitle: {
    color: root.color_textual,
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#9AB3FF33',
    fontSize: 9,
    width: 45,
    height: 15,
    textAlign: 'center',
    borderRadius: 25,
    marginLeft: 15,
    marginTop: 6,
  },
});

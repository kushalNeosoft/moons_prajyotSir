import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';

const IndicesComponent = props => {
  return (
    <TouchableOpacity style={styles.container}>
      <Text style={styles.title}>{props.title}</Text>
      <Text style={styles.price}>{props.price}</Text>
      <Text style={styles.changes}>{props.changes}</Text>
      <Text style={styles.date}>{props.date}</Text>
    </TouchableOpacity>
  );
};
export default IndicesComponent;
const styles = StyleSheet.create({
  container: {
    backgroundColor: root.indices_red,
    height: 140,
    width: 145,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 12,
    marginTop: 10,
    paddingBottom: 23,
    fontSize: 14,
  },
  price: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    paddingBottom: 2,
    fontSize: 18,
  },
  changes: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_regular,
    marginLeft: 12,
    fontSize: 12,
  },
  date: {
    color: root.color_active_text,
    fontFamily: Cfont.rubik_light,
    marginLeft: 12,
    marginTop: 12,
    fontSize: 10,
  },
});

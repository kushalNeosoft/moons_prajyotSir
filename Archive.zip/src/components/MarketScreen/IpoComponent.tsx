import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import {Font, root, Cfont} from '../../styles/colors';

const IPOComponent = props => {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <View style={{marginLeft: 13}}>
        <View style={{flexDirection: 'row'}}>
          <View style={styles.imageView}>
            <Text
              style={{
                alignSelf: 'center',
                fontSize: 16,
                fontFamily: Cfont.rubik_medium,
                color: 'white',
              }}>
              LI
            </Text>
          </View>
          <Text style={styles.title}>{props.title}</Text>
        </View>
        <Text style={styles.subTitle}>ONGOING</Text>
        <Text style={styles.pricerRange}>{props.range}</Text>
        <Text style={styles.issueDate}>Issue Date</Text>
        <Text style={styles.date}>{props.date}</Text>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            marginRight: 25,
          }}>
          <View>
            <Text style={styles.minQty}>Min. Qty</Text>
            <Text style={styles.qty}>{props.minQty}</Text>
          </View>
          <View>
            <Text style={styles.minAmount}>Min. Amount</Text>
            <Text style={styles.amount}>{props.minAmount}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default IPOComponent;
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    height: 240,
    width: 210,
    borderRadius: 8,
    marginTop: 20,
    marginVertical: 10,
    marginRight: 13,
    marginLeft: 3,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  imageView: {
    backgroundColor: '#FF6700',
    height: 40,
    width: 40,
    borderRadius: 25,
    marginTop: 10,
    opacity: 0.7,
    justifyContent: 'center',
  },
  title: {
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
    width: '60%',
    marginTop: 10,
    marginLeft: 6,
  },
  subTitle: {
    color: 'white',
    fontFamily: Cfont.rubik_medium,
    backgroundColor: '#4CAF50',
    fontSize: 10,
    width: 65,
    height: 17,
    textAlign: 'center',
    borderRadius: 25,
    marginTop: 12,
  },
  pricerRange: {
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    marginTop: 30,
    fontSize: 12,
  },
  issueDate: {
    color: root.color_text,
    marginTop: 10,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
  },
  date: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
  },
  minQty: {
    color: root.color_text,
    marginTop: 10,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
  },
  qty: {
    color: '#303030',
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
  },
  minAmount: {
    color: root.color_text,
    marginTop: 10,
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
  },
  amount: {
    color: root.color_text,
    fontSize: 12,
    fontFamily: Cfont.rubik_regular,
  },
});

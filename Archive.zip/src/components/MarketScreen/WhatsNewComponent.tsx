import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {Cfont, Font, root} from '../../styles/colors';
const WhatsNewComponent = props => {
  const navigation = useNavigation();
  const title = props.title;
  return (
    <View
      style={[
        styles.container,
        {backgroundColor: title == 'IPO is incoming!!' ? '#EFF3FF' : '#B4EBCC'},
      ]}>
      <View>
        <Text style={styles.title}>{props.title}</Text>
        <Text style={styles.subTitle}>{props.subTitle}</Text>
        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            if (title == 'IPO is incoming!!') {
              navigation.navigate('IpoScreen');
            } else {
              Linking.openURL(
                'https://mobileuat.odinwave.com/Wave2BackOffice/outstanding-report?userId=OM',
              );
            }
          }}>
          <Text style={styles.buttonText}>Apply Now</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.image}>
        <Image
          resizeMode="contain"
          source={require('../../assets/demo.jpeg')}
          style={styles.image}
        />
      </View>
    </View>
  );
};
export default WhatsNewComponent;
const styles = StyleSheet.create({
  container: {
    // marginLeft: 16,
    height: 140,
    width: Dimensions.get('window').width / 1.3,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    flexDirection: 'row',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 3,
    overflow: 'hidden',
  },
  title: {
    color: '#303030',
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    marginLeft: 15,
    marginTop: 13,
  },
  subTitle: {
    color: '#303030',
    fontSize: 12,
    marginLeft: 15,
    marginTop: 8,
    fontFamily: Cfont.rubik_regular,
  },
  button: {
    backgroundColor: '#25325C',
    width: 100,
    height: 35,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 15,
    marginTop: 11,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
  },
  buttonText: {
    color: 'white',
    fontFamily: Cfont.rubik_medium,
    fontSize: 12,
  },
  image: {
    height: 100,
    width: 90,
    marginTop: 10,
    marginRight: 10,
    backgroundColor: 'white',
  },
});

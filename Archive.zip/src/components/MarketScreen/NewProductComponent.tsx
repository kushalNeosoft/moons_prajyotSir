import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Linking,
  Alert,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';

const NewProductComponent = props => {
  const navigation = useNavigation();
  return (
    <TouchableOpacity
      style={[
        styles.container,
        {backgroundColor: props.title === 'IPO' ? '#EFF3FF' : '#B4EBCC'},
      ]}
      onPress={() => {
        if (props.title === 'IPO') {
          navigation.navigate('IpoScreen');
        } else {
          Linking.openURL(
            'https://mobileuat.odinwave.com/Wave2BackOffice/outstanding-report?userId=OM',
          );
        }
      }}>
      <View style={styles.image}>
        <Image
          resizeMode="contain"
          source={require('../../assets/demo.jpeg')}
          style={styles.image}
        />
      </View>
      {/* <Text>{props.link}</Text> */}
    </TouchableOpacity>
  );
};
export default NewProductComponent;
const styles = StyleSheet.create({
  container: {
    backgroundColor: '#B6D0E2',
    height: 150,
    width: 160,
    marginVertical: 15,
    borderRadius: 8,
    marginRight: 13,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 3,
    overflow: 'hidden',
  },
  image: {
    height: 100,
    width: 90,
    marginTop: 15,
    backgroundColor: 'white',
  },
});

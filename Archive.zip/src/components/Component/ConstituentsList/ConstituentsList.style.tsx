import {StyleSheet} from 'react-native';
import {Cfont, Font, root} from '../../../styles/colors';
import alignment from '../../utils/alignment';

export const styles = StyleSheet.create({
  container: {
    borderBottomColor: 'grey',
    paddingHorizontal: 8,
    height: 37,
    paddingVertical: 3,
    ...alignment.row_SpaceB,
  },
  stockName: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily:Cfont.rubik_medium
  },
  bottonView: {
    borderColor: 'black',
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    marginHorizontal: 5,
    ...alignment.alignC_justifyC,
  },
  nseTxt: {
    fontSize: Font.font_normal_eight,
    marginTop: 3,
    marginLeft: 5,
    backgroundColor: root.backgroung_exchange_chip_color,
    marginBottom: 9,
    paddingHorizontal: 3,
    color: root.color_subtext,
    borderRadius: 1,
    borderColor: '#979797',
    borderWidth: 0.1,
    fontFamily:Cfont.rubik_medium
  },
  volGainerTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_positive,
    backgroundColor: '#4caf5026',
    fontFamily:Cfont.rubik_medium
  },
  prLoserTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    borderRadius: 10,
    paddingHorizontal: 5,
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_negative,
    backgroundColor: '#d32f2f26',
    fontFamily:Cfont.rubik_medium
  },
  defaultTxt: {
    marginLeft: 3,
    fontSize: Font.font_normal_one,
    borderRadius: 10,
    paddingHorizontal: 5,
    fontWeight: 'bold',
    alignSelf: 'center',
    justifyContent: 'center',
    color: root.color_active,
  },
  changes: {
    color: root.color_positive,
    fontSize: Font.font_normal_one,
    fontFamily:Cfont.rubik_regular
  },
  rightValuesView_200_300: {
    alignItems: 'flex-end',
    width: 120,
    marginRight: 15,
    backgroundColor: root.color_positive_rgb,
  },
  rightValuesView_300_500: {
    alignItems: 'flex-end',
    width: 120,
    marginRight: 15,
    backgroundColor: root.color_negative_rgb,
  },
  rightValuesDefault: {
    alignItems: 'flex-end',
    width: 120,
    marginRight: 15,
    backgroundColor: root.color_active,
  },
  currentPriceTxt: {
    color: root.color_text,
    fontSize: Font.font_normal_two,
    fontFamily:Cfont.rubik_medium
  },
});

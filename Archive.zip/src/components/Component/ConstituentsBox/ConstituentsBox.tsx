import React from 'react';
import {View, Text, Dimensions, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Cfont, Font} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';

const ConstituentsBoxList = props => {
  const num = 1400;
  return (
    <TouchableOpacity
      style={{paddingTop: 0, marginHorizontal: 5}}
      activeOpacity={1}
      onPress={async () => {}}>
      <View
        style={{
          flexDirection: 'row',
          backgroundColor: props.colors,
          borderRadius: 10,
          shadowOffset: {width: 1, height: 1},
          shadowColor: '#0000001A',
          shadowOpacity: 0.8,
          marginTop: 10,
          elevation: 5,
          width: (Dimensions.get('window').width - 20) / 2 - 10,
          marginLeft: 5,
          marginBottom: 5,
          height: 130,
          borderColor: '#F4F4F4',
          padding: 10,
          justifyContent: 'space-between',
        }}>
        <View>
          <Text
            style={{
              color: '#ffffff',
              fontFamily:Cfont.rubik_medium,
              fontSize: Font.font_normal_three,
            }}>
            {props.companyName}
          </Text>
          <MaterialCommunityIcons
            name="crown-circle"
            size={22}
            color="white"
            style={{marginVertical: 5}}
          />
          <Text
            style={{
              color: '#ffffff',
              fontFamily:Cfont.rubik_medium,
              fontSize: Font.font_normal_four,
            }}>
            {props.price}
          </Text>
          <Text
            style={{
              color: 'white',
              fontFamily:Cfont.rubik_medium,
              marginTop: 5,
              fontSize: Font.font_normal_two,
            }}>
            {props.changes.replace(props.changes[0], '+')}
          </Text>
        </View>
        <View>
          <TouchableOpacity>
            <View
              style={{
                width: 30,
                height: 30,
                borderRadius: 40,
                borderWidth: 2,
                borderColor: 'white',
                marginTop: 10,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <Text style={{color: 'white', fontWeight: '500', fontSize: 15}}>
                T
              </Text>
            </View>
          </TouchableOpacity>
          <AntDesign
          name="pluscircleo"
          size={29}
          color="#ffffff"
          style={{marginTop:15}}
        />
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default ConstituentsBoxList;

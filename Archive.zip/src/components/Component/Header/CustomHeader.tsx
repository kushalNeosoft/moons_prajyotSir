
import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

interface CustomHeaderProps {
  leftComponent?: React.ReactNode;
  title: string;
  rightComponent?: React.ReactNode;

  
}
// const navtonavigate=()=>{
// navtoback()

// }

const CustomHeader = ({
  title,
  leftComponent,
  rightComponent,
}: CustomHeaderProps) => {
  return (
    
    <View style={styles.container}>
      <View style={styles.left}>{leftComponent}</View>
      <View style={styles.center}>
        <Text style={styles.title}>{title}</Text>
      </View>
      <View style={styles.right}>{rightComponent}</View>
    </View>
     
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    height: 56,
    backgroundColor: 'white',
  },
  left: {
    flex: 0.7,
    justifyContent: 'center',
  },
  center: {
    flex: 3,
    alignItems: 'flex-start',
  },
  right: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
  },
  title: {
    fontWeight: 'bold',
    fontSize: 20,
    color: 'black',
  },
});

export default CustomHeader;

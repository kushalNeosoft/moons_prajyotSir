import React from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import {assets} from '../../assets';
// import {colors} from '../../constants/colors';
// import {texts} from '../../constants/text';
import alignment from '../../utils/alignment';

import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import colors, { Cfont, Font, root } from '../../../styles/colors';
import { texts } from '../../../constants/text';

function TrendModal(props:any) {
  const data = [
    {
      companyName: 'BSE',
      value: '1100.00',
      percentage: '(-2.00%)',
      gainer: 'Pr.Gainer',
      Losser: '',
    },
    {
      companyName: 'IDEA',
      value: '1100.00',
      percentage: '(-2.00%)',
      gainer: 'Vol.Gainer',
      Losser: '',
    },
    {
      companyName: 'SBIN',
      value: '1100.00',
      percentage: '(-2.00%)',
      gainer: 'Vol.Gainer',
      Losser: '',
    },
    {
      companyName: 'ZEEL',
      value: '1100.00',
      percentage: '(-2.00%)',
      gainer: '',
      Losser: 'Pr.Loser',
    },
    {
      companyName: 'ICICBANK',
      value: '1100.00',
      percentage: '(-2.00%)',
      gainer: 'Vol.Gainer',
      Losser: '',
    },
    {
      companyName: 'PAYTM',
      value: '1100.00',
      percentage: '(-2.00%)',
      text: 'SomeText',
      gainer: '',
      Losser: 'Pr.Loser',
    },
  ];
  console.log(data.length, 'DDDDDD------->');
  const Lenght = data.length;

  return (
    <Modal
      animationType="slide"
      visible={props.visible}
      transparent={true}
      onRequestClose={() => {
        props.onClose();
      }}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}></TouchableOpacity>
      <View style={styles.modalView}>
        <View style={{...alignment.row_alingC_SpaceB}}>
          <View style={styles.viewbox}>
            <Text
              style={{fontSize: Font.font_normal_four, color: root.color_text, fontFamily:Cfont.rubik_medium}}>
              {texts.DONT_MISS}
            </Text>
            <Text style={styles.lenght}>{Lenght}</Text>
          </View>
          <TouchableOpacity onPress={() => props.onClose()}>
            <Image source={assets.cross} style={styles.image} />
          </TouchableOpacity>
        </View>

        <FlatList
          showsHorizontalScrollIndicator={false}
          horizontal={true}
          data={data}
          renderItem={({item}) => (
            <View style={styles.itemBox}>
              <View style={styles.notificationView}>
                <MaterialIcons name="offline-bolt" color={'orange'} size={32} />
              </View>
              <Text style={styles.tradeText}>{texts.TRADE}</Text>
              <Text style={styles.companyNameText}>{item.companyName}</Text>
              <View style={{flexDirection: 'row', top: -20, left: 3}}>
                <Text style={{fontSize:Font.font_normal_seven,color:root.color_text,fontFamily:Cfont.rubik_regular}}>{item.value}</Text>

                <Text style={{color:root.color_negative,fontSize:Font.font_normal_seven,marginLeft:'3%',fontFamily:Cfont.rubik_regular}}>{item.percentage}</Text>
              </View>
              {item.gainer ? (
                <>
                  <View style={styles.gainer}>
                    <Text style={styles.gaTxt}>{item.gainer}</Text>
                  </View>
                </>
              ) : (
                <>
                  <View style={styles.Loser}>
                    <Text style={styles.Lotxt}>{item.Losser}</Text>
                  </View>
                </>
              )}
            </View>
          )}
        />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    // top: Dimensions.get('window').width * 0.99,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 20,
    paddingBottom:0,
    borderRadius: 10,
  },
  commonTimingView: {
    height: 300,
    width: 120,
    alignItems: 'flex-start',
  },
  notificationView: {
    height: 32,
    width: 32,
    borderRadius: 12.5,
    backgroundColor: 'white',
    alignSelf: 'flex-end',
    marginRight: 20,
    right: 0,
    top: -20,
  },
  itemBox: {
    // height: Dimensions.get('window').width * 0.35,
    // width: Dimensions.get('window').width * 0.33,
    height:112,
    width: 112,
    borderRadius: 20,
    justifyContent: 'space-around',
    marginHorizontal: 10,
     paddingHorizontal: 10,
    marginBottom:40,
    marginTop: 40,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 12,
    },
    shadowOpacity: 0.58,
    shadowRadius: 16.0,

    elevation: 24,
  },
  tradeText: {
    fontSize: Font.font_normal_four,
    fontFamily:Cfont.rubik_medium,
    color: root.color_text,
    marginBottom: 10,
    top: -20,
    left: 3,
  },
  image: {
    height: 15,
    width: 15,
  },
  companyNameText: {
    fontSize: Font.font_normal_five,
    fontFamily:Cfont.rubik_medium,
    color: root.color_text,
    top: -20,
    left: 3,
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  gainer: {
    backgroundColor: root.color_positive_rgb,
    height: 14,
    width: 52,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -12,
    left: 3,
  },
  gaTxt: {
    color: root.color_positive,
    fontSize: Font.font_normal_six,
    fontFamily:Cfont.rubik_medium,
    // fontWeight: '400',
  },
  Loser: {
    backgroundColor: root.color_negative_rgb,
    height: 14,
    width: 52,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 20,
    top: -12,
    left: 3,
  },
  Lotxt: {
    color: root.color_negative,
    fontSize: Font.font_normal_six,
    fontFamily:Cfont.rubik_medium
    // fontWeight: '400',
  },
  lenght: {
    color: root.color_active,
    fontSize: Font.font_normal_six,
    fontFamily:Cfont.rubik_medium,
    backgroundColor: root.color_negative,
    paddingLeft: '5%',
    paddingTop:'2%',
    marginLeft:'6%',
    height: 16,
    width: 20,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  viewbox: {
    flexDirection: 'row',
    width: '35%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});

export default TrendModal;

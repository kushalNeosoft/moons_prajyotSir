import React, {useEffect, useMemo, useReducer, useRef, useState,} from 'react';
import {
  Button,
  Dimensions,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';

import VisibilityIcon from '../../assets/VisibilityIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import {StatusBar} from 'react-native';
import Logo from '../../assets/Logo';
import Validator from '../../helpers/Validator';
import {LoginAction, loginReducer} from '../../redux/loginRedux';
import VisibilityOffIcon from '../../assets/VisibilityOffIcon';
import useStyles from '../../styles/useStyles';
import {createLoginStyles} from './login.styles';
import { useSelector, useDispatch } from 'react-redux'

import BottomSheet, {
  BottomSheetProps,
} from '../../components/BottomSheet/BottomSheet';
import AboutUsDialog from './components/AboutUsDialog';
import MembershipDialog from './components/MembershipDialog';
import ExchangeDialog from './components/ExchangeDialog';
import {useTranslation} from 'react-i18next';
import { newLog } from '../../redux/Action';
import { root } from '../../styles/colors';
import { Login } from '../../Globalstyles/Globalstyle';
// import { createLoginStyles } from '../../Globalstyles/Globalstyle';

const LoginScreen = ({navigation}: any) => {
  const {t} = useTranslation();

  const height = Dimensions.get('window').height;
  const snapPoints = useMemo(() => ['25%', '50%'], []);

  const bottomSheetRef = useRef<BottomSheetProps>();
  const [selectedDailog, setSelectedDialog] = useState('ABOUT_US');

  const {colors, styles} = useStyles(createLoginStyles);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [exhModalVisible, setExModalVisible] = useState(false);
  const [aboutModalVisible, setaboutModalVisible] = useState(false);
  const [memModalVisible, setmemModalVisible] = useState(false);

  const onNorClose = () => {
    setExModalVisible(prevState => !prevState);
    
  };
  const onNor1Close = () => {
    
    setaboutModalVisible(prevState => !prevState);
   
  };
  const onNor2Close = () => {
   
    setmemModalVisible(prevState => !prevState);
    
  };
  
  // const showDeleteModal = () => {
  //   setDeleteModal(prevState => !prevState);
  // };

  const [login, dispatch] = useReducer(loginReducer, {
    error: {},
    
  });


  const newdispatch=useDispatch()
  // inside of React Native component
  // const {colors} = useColors();
 
  // access to the color
  // console.log(colors.primary);

  const onLogin = () => {
    //const error = validate();
   // console.log(error);
   newdispatch(newLog({firsttime:true}))
    
  //   if (error) {
  //     dispatch({
  //       type: LoginAction.UPDATE_ERROR,
  //       payload: {
  //         error,
  //       },
  //     });
  //     navigation.navigate('ProfileScreen');
  //   } else {
      
  //     console.log('Do Something');
  //   }
  // };
  // const validate = (): any => {
  //   const error: any = {};
  //   if (!Validator.emailValidator(login.email)) {
  //     error.email = 'Invalid Email';
  //   }
  //   if (!Validator.passwordValidator(login.password)) {
  //     error.password = 'Invalid Password';
  //   }
  //   if (Object.keys(error).length === 0) {
  //     return null;
  //   }
  //   return error;
  };
  useEffect(() => {}, []);
  return (
    <ScrollView style={Login.scrollContainer}>
      <View style={Login.container}>
        <View style={Login.block1}>
          <Logo />

          <Text style={Login.heading}>{t('login.title')}</Text>

          <View style={[Login.inputContainer, {marginTop: 16}]}>
            <TextInput
              style={Login.input}
              placeholder={t('login.email')!}
              keyboardType="email-address"
              onChangeText={text =>
                dispatch({
                  type: LoginAction.UPDATE_EMAIL,
                  payload: {
                    email: text,
                  },
                })
              }
              placeholderTextColor={'gray'}
            />
          </View>
          {login.error.email && (
            <Text style={{color: 'red'}}>{login.error.email}</Text>
          )}

          <View style={[Login.inputContainer, {marginTop: 16}]}>
            <TextInput
              style={Login.input}
              placeholder={t('login.password')!}
              secureTextEntry={!showPassword}
              onChangeText={text =>
                dispatch({
                  type: LoginAction.UPDATE_PASSWORD,
                  payload: {
                    password: text,
                  },
                })
              }
              placeholderTextColor={'gray'}
            />
            <TouchableNativeFeedback
            
              background={TouchableNativeFeedback.Ripple('grey', true)}
              onPress={() => {
                // onLogin();
                console.log('Here');
                setShowPassword(prev => !prev);
              }}>
              <View>
                {showPassword ? (
                  <VisibilityIcon style={[Login.inputIcon, {flex: 1}]} />
                ) : (
                  <VisibilityOffIcon style={[Login.inputIcon, {flex: 1}]} />
                )}
              </View>
            </TouchableNativeFeedback>
          </View>
          {login.error.password && (
            <Text style={{color: root.color_negative}}>{login.error.password}</Text>
          )}
          <View style={Login.block1ButtonContainer}>
            <View
              style={{
                borderRadius: 8,
              }}>
              <TouchableNativeFeedback
               disabled={!(login.email && login.password)}
                // background={TouchableNativeFeedback.Ripple('blue', true)}
                onPress={() => {
                  onLogin();
                  navigation.navigate('TestScreen')
                  // i18next.changeLanguage('hin');
                }}>
                <View
                  style={[
                    Login.buttonContainer,
                    // {
                    //   backgroundColor:
                    //     login.email && login.password
                    //       ? root.client_background
                    //       : 'lightblue',
                    // },
                  ]}>
                  <Text style={[Login.buttonText,{
                    color:
                        login.email && login.password
                          ? root.color_active
                          : root.color_disable,
                        opacity: login.email && login.password
                        ? 1
                        : 0.3,
                  }]}>{t('login.title')}</Text>
                  <ArrowForwardIcon style={[Login.buttonImage,{
                    color:
                        login.email && login.password
                          ? root.color_active
                          : root.color_disable,
                        opacity: login.email && login.password
                        ? 1
                        : 0.3,
                  }]} />
                </View>
              </TouchableNativeFeedback>
            </View>

            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  // i18next.changeLanguage('en');
                  navigation.navigate('ForgotPasswordScreen');
                }}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                  <Text
                    style={Login.forgettxt}>
                    {t('login.forgot_password')}
                  </Text>
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          {/* <View
            style={{
              marginTop: 32,
            }}>
            <Text style={{color: 'grey', fontWeight: 'bold', fontSize: 16}}>
              Haven't registered yet? Click here to{' '}
              <Text style={{color: 'blue'}}>Register</Text>
            </Text>
          </View> */}
          <View
            style={{flexDirection: 'row', alignItems: 'center', marginTop: 32}}>
            <Text style={Login.haventtxt}>
              Haven't registered yet? Click here to
            </Text>

            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  navigation.navigate('SignupScreen');
                }}>
                <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                  <Text
                    style={Login.registertxt}>
                    Register
                  </Text>
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          <View style={Login.signupContainer}>
            <View style={{flex: 1}}>
              <Text style={Login.signupContainerHeading}>
                {t('login.new_user')}
              </Text>
              <Text style={Login.signupContainerSubHeading}>
                {t('login.trial_text')}
              </Text>
            </View>

            <View
              style={{
                borderRadius: 8,
                marginLeft: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('black', true)}
                onPress={() => {
                  console.log('Sample');
                  
                   navigation.navigate('PhoneVerificationScreen');
                }}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View
                  style={[Login.buttonContainer, {backgroundColor: 'white'}]}>
                  <Text style={[Login.buttonTextone]}>
                    {t('login.sign_up')}
                  </Text>
                  <ArrowForwardIcon
                    style={[Login.buttonImageone ]}
                  />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
        </View>
        <View style={Login.block2}>
          <Text style={Login.Avaltxt}>Available Exchanges</Text>
          <Text style={Login.rowtxt}>
            BSE | NSE | NCDEX | MCX | MCX-SX | MCX-EQ | MCX-FAO | DSE | NMCE |
            NSEL |
          </Text>
          <View style={Login.footerContainer}>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => setExModalVisible(true)}
                
                // onPress={() => {
                //   setSelectedDialog('EXCHANGE');
                  
                //   // bottomSheetRef.current?.open();
                // }}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                  <Text style={Login.exchtxt}>
                    {t('login.exchange_timings')}
                  </Text>
                </View>
              </TouchableNativeFeedback>
            </View>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => setaboutModalVisible(true)}
              //   onPress={() => {
              //     setSelectedDialog('ABOUT_US');
              //     bottomSheetRef.current?.open();
              //   }}
              //   // disabled={socketStatus === SocketStatus.CONNECTED}
               >
                <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                  <Text style={Login.exchtxt}>{t('login.about_us')}</Text>
                </View>
              </TouchableNativeFeedback>
            </View>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                // onPress={() => {
                //   setSelectedDialog('MEMBERSHIP');
                //   bottomSheetRef.current?.open();
                // }}
                onPress={() => setmemModalVisible(true)}
                // disabled={socketStatus === SocketStatus.CONNECTED}
              >
                <View style={{paddingHorizontal: 12, paddingVertical: 4}}>
                  <Text style={Login.exchtxt}>
                    {t('login.membership_details')}
                  </Text>
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
        </View>
      </View>
     
         
      {/* <BottomSheet
        ref={bottomSheetRef}
        height={(height * 3) / 5}
        customStyles={{
          container: {
            // justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 16,
          },
        }}> */}
        {/* <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {selectedDailog === 'ABOUT_US' && <AboutUsDialog />}
          {selectedDailog === 'MEMBERSHIP' && <MembershipDialog />}
          {selectedDailog === 'EXCHANGE' && <ExchangeDialog 
          visible={exhModalVisible}
        onClose={onNorClose}
        />}
        </ScrollView> */}
      {/* </BottomSheet> */}
      <AboutUsDialog 
          visible={aboutModalVisible}
        onClose={onNor1Close}
        />
         <ExchangeDialog 
          visible={exhModalVisible}
        onClose={onNorClose}
        />
         <MembershipDialog 
          visible={memModalVisible}
        onClose={onNor2Close}
        />
    </ScrollView>
  );
};

export default LoginScreen;

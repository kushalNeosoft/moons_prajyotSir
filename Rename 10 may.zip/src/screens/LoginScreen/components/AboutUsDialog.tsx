import React from 'react';
//import {View, Text} from 'react-native';
import { Cfont, Font, root } from '../../../styles/colors';
import {View, Text, TouchableOpacity} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import CommonModalone from '../../../components/Component/CommonModal/CommonModalone';

const AboutUsDialog = (props: any) => {
  return (
    <CommonModalone visible={props.visible} onClose={props.onClose} >
    <View style={{width: '100%',height:'80%'}}>
      <Text style={{fontSize: Font.font_title, fontFamily:Cfont.rubik_medium, color:root.color_text}}>
        About Us
      </Text>
      <View style={{marginTop: 18}}>
        <Text style={{fontFamily:Cfont.rubik_light,color:root.color_text,fontSize:Font.font_normal_two}}>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets containing Lorem Ipsum passages, and
          more recently with desktop publishing software like Aldus PageMaker
          including versions of Lorem Ipsum.
        </Text>
        {/* <Text style={{fontFamily:Cfont.rubik_light,color:root.color_text,fontSize:Font.font_normal_two}}>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets containing Lorem Ipsum passages, and
          more recently with desktop publishing software like Aldus PageMaker
          including versions of Lorem Ipsum.
        </Text> */}
        {/* <Text style={{fontFamily:Cfont.rubik_light,color:root.color_text,fontSize:Font.font_normal_two}}>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets containing Lorem Ipsum passages, and
          more recently with desktop publishing software like Aldus PageMaker
          including versions of Lorem Ipsum.
        </Text>
        <Text style={{fontFamily:Cfont.rubik_light,color:root.color_text,fontSize:Font.font_normal_two}}>
          Lorem Ipsum is simply dummy text of the printing and typesetting
          industry. Lorem Ipsum has been the industry's standard dummy text ever
          since the 1500s, when an unknown printer took a galley of type and
          scrambled it to make a type specimen book. It has survived not only
          five centuries, but also the leap into electronic typesetting,
          remaining essentially unchanged. It was popularised in the 1960s with
          the release of Letraset sheets containing Lorem Ipsum passages, and
          more recently with desktop publishing software like Aldus PageMaker
          including versions of Lorem Ipsum.
        </Text> */}
      </View>
    </View>
    </CommonModalone>
  );
};
export default AboutUsDialog;

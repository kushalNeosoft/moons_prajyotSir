import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import alignment from '../../../components/utils/alignment';
import { overViewScreen } from '../../../Globalstyles/Globalstyle';

function OverView() {
  const data = [
    {
      title: 'Open',
      value: '17707.55',
    },
    {
      title: 'Close',
      value: '17624.05',
    },
    {
      title: 'Daily Price Range',
      value: '17620.05-17709.20',
    },
  ];

  return (
    <View style={overViewScreen.container}>
      <View style={overViewScreen.keyStatsContainer}>
        <View style={overViewScreen.innerContainer}>
          <Text style={overViewScreen.keyStatsTxt}>Key Stats</Text>

          <View style={overViewScreen.keyStatsLowerContent}>
            {data.map(item => (
              <View>
                <Text style={overViewScreen.headingTxt}>{item.title}</Text>
                <Text style={overViewScreen.valuesTxt}>{item.value}</Text>
              </View>
            ))}
          </View>

          <View style={overViewScreen.horizontalLine} />

          <Text
            style={overViewScreen.lowToHighTxt}>
            Today(Low - High)
          </Text>

          <LinearGradient
            colors={['#ff0d00', '#ffcc00', '#90ee90']}
            style={overViewScreen.linearGradient}
            useAngle={true}
            angle={90}
          />
          <View style={{width:135,...alignment.row_SpaceB,marginTop:8}}>
            <Text style={overViewScreen.dailyPriceTxt}>17729.65</Text>
            <Text style={overViewScreen.dailyPriceTxt}>17827.85</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({

});

export default OverView;

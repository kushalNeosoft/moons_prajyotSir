import React from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { callModal } from '../../../../../Globalstyles/Globalstyle';
import Common from '../CallPutCommonModal/Common';

function CallModal(props: any) {
  const leftData = [
    {
      name: 'LTP',
      value: '0.0',
    },
    {
      name: 'LTP (%)',
      value: '0.0',
    },
    {
      name: 'OI',
      value: '0.0',
    },
    {
      name: 'OI (%)',
      value: '0.0',
    },
    {
      name: 'IV',
      value: 0,
    },
  ];

  const rightData = [
    {
      name: 'Delta',
      value: 0,
    },
    {
      name: 'Gamma',
      value: '-',
    },
    {
      name: 'Theta',
      value: 0,
    },
    {
      name: 'Vega',
      value: 0,
    },
    {
      name: 'Rho',
      value: 0,
    },
  ];

  const renderLeftData = ({item}: any) => {
    return (
      <View style={callModal.nameValueContainer}>
        <Text style={callModal.txt}>{item.name}</Text>
        <Text style={callModal.txt}>{item.value}</Text>
      </View>
    );
  };

  const renderRightData = ({item}: any) => {
    return (
      <View style={callModal.nameValueContainer}>
        <Text style={callModal.txt}>{item.name}</Text>
        <Text style={callModal.txt}>{item.value}</Text>
      </View>
    );
  };
  return (
    <Common onClose={props.onClose} visible={props.visible}>
      <View style={callModal.topTxtContainer}>
        <Text style={callModal.callValue}>Nifty 13590</Text>
        <Text style={callModal.callTxt}>Call</Text>
      </View>
      <View style={callModal.horizontalLine} />
      <View style={callModal.dataContainer}>
        <View style={callModal.singleDataContainer}>
          <FlatList data={leftData} renderItem={renderLeftData} />
        </View>
        <View style={callModal.singleDataContainer}>
          <FlatList data={rightData} renderItem={renderRightData} />
        </View>
      </View>
      <View
        style={callModal.btnContainer}>
        <View style={callModal.buyBtn}>
          <Text style={callModal.btnTxt}>Buy</Text>
        </View>
        <TouchableOpacity style={callModal.sellBtn}>
          <Text style={callModal.btnTxt}>Sell</Text>
        </TouchableOpacity>
      </View>
    </Common>
  );
}

export default CallModal;

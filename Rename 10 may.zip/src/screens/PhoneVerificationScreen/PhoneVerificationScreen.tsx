import React, {useState} from 'react';
import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';

import {useTranslation} from 'react-i18next';

import BackIcon from '../../assets/BackIcon';
import PhoneComponent from './components/PhoneComponent';
import useStyles from '../../styles/useStyles';
import {createPhoneVerificationStyles} from './styles/phoneVerification.styles';
import OtpComponent from './components/OtpComponent';
import { PhoneVerificationStyles } from '../../Globalstyles/Globalstyle';

const PhoneVerificationScreen = ({navigation}: any) => {
  const [selectedPage, setSelectedPage] = useState('PHONE');
  const {colors, styles} = useStyles(createPhoneVerificationStyles);
  
  const {t} = useTranslation();
  return (
    <View
      style={{
        flex: 1,
        flexDirection: 'column',
        padding: 16,
      }}>
      <View>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            console.log('Here');
            if (selectedPage === 'PHONE') navigation.goBack();
            else setSelectedPage('PHONE');
          }}>
          <View style={{width: 32, height: 32}}>
            <BackIcon style={{width: 32, height: 32, color: 'grey'}} />
          </View>
        </TouchableNativeFeedback>
      </View>
      <View>
        {selectedPage === 'PHONE' && (
          <PhoneComponent
            moveForward={setSelectedPage}
            navigation={'TestScreen'}
          />
        )}
        {selectedPage === 'OTP' && <OtpComponent navigation={navigation} />}
      </View>
    </View>
  );
};

export default PhoneVerificationScreen;

import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity, FlatList, Image} from 'react-native';
import {styles} from '../styles/styles';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Calendar, LocaleConfig} from 'react-native-calendars';
import DateEventComponent from '../../../components/MarketScreen/DateEventComponent';
import {root} from '../../../styles/colors';
import {marketScreen} from '../../../Globalstyles/Globalstyle';

LocaleConfig.locales['fr'] = {
  monthNames: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ],
  monthNamesShort: [
    'Jan',
    'Feb.',
    'Mar',
    'Aor',
    'May',
    'June',
    'Jul.',
    'Aug',
    'Sept.',
    'Oct',
    'Nov',
    'Dec',
  ],
  dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wensday', '', 'F', 'S'],
  dayNamesShort: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
};

LocaleConfig.defaultLocale = 'fr';

const Events = () => {
  const [showCalendar, setShowCalendar] = useState(false);

  const [monthChange, setMonthChange] = useState(false);

  const currentDate = new Date();

  const day = currentDate.getDate();

  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  const month = monthNames[currentDate.getMonth()];

  const year = currentDate.getFullYear();

  const formattedDate = `${day} ${month} ${year}`;

  var pDate = formattedDate;

  var newDate = new Date();

  newDate = newDate.toISOString().split('T')[0];

  useEffect(() => {}, [hDate]);

  const [hDate, sethDate] = useState();
  const [selectedDate, setSelectedDate] = useState('');
  const [markedDates, setMarkedDates] = useState({
    [newDate]: {
      selected: true,
      selectedColor: '#002D62',
    },
    '2023-05-15': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-16': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-14': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-17': {
      marked: true,
      dotColor: 'red',
    },
  });

  var markedD = {
    '2023-05-15': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-16': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-14': {
      marked: true,
      dotColor: 'red',
    },
    '2023-05-17': {
      marked: true,
      dotColor: 'red',
    },
  };
  const events = [
    {id: 1, title: 'NETFLIX', subTitle: 'bonus', date: '2023-05-14'},
    {id: 2, title: 'HDFC', subTitle: 'bonus', date: '2023-05-14'},
    {id: 3, title: 'NETFLIX', subTitle: 'bonus', date: '2023-05-14'},
    {id: 4, title: 'AMAZONE', subTitle: 'AGM', date: '2023-05-15'},
    {id: 5, title: 'AMAZONE', subTitle: 'AGM', date: '2023-05-15'},
    {id: 6, title: 'AXISNEO', subTitle: 'EGM', date: '2023-05-16'},
    {id: 7, title: 'SBIFUNDS', subTitle: 'BONUS', date: '2023-05-16'},
    {id: 8, title: 'HDFC', subTitle: 'BONUS', date: '2023-05-17'},
  ];
  let eventsForDate = events.filter(event => event.date === selectedDate);

  function handleMonthChange(date) {
    const selectedDate = new Date(date.dateString);
    const day = selectedDate.getDate();
    const monthIndex = selectedDate.getMonth();
    const year = selectedDate.getFullYear();
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const selectedDateString = `${day} ${monthNames[monthIndex]} ${year}`;
    markedD[date.dateString] = {
      ...markedD[date.dateString],
      selected: true,
      selectedColor: '#002D62',
      // marked: true,
      dotColor: markedD[date.dateString]?.dotColor == 'red' ? 'white' : '',
    };
    sethDate(selectedDateString);
    setMarkedDates(markedD);
    setSelectedDate(date.dateString);
  }

  const handleDayPress = date => {
    const selectedDate = new Date(date.dateString);
    const day = selectedDate.getDate();
    const monthIndex = selectedDate.getMonth();
    const year = selectedDate.getFullYear();
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const selectedDateString = `${day} ${monthNames[monthIndex]} ${year}`;
    markedD[date.dateString] = {
      ...markedD[date.dateString],
      selected: true,
      selectedColor: '#002D62',
      // marked: true,
      dotColor: markedD[date.dateString]?.dotColor == 'red' ? 'white' : '',
    };
    sethDate(selectedDateString);
    setMarkedDates(markedD);

    const eventsOnDate = events.filter(event => event.date === date.dateString);
    if (eventsOnDate.length > 0) {
      setSelectedDate(date.dateString);
    } else {
      setSelectedDate('');
    }
  };

  const renderEvents = ({item}) => {
    return <DateEventComponent title={item.title} subTitle={item.subTitle} />;
  };

  return (
    <View>
      <View style={marketScreen.eventHeadView}>
        <Text style={marketScreen.eventHeadText}>Events</Text>
        <View>
          <TouchableOpacity>
            <MaterialIcons
              name="search"
              size={24}
              color={'#303030'}
              style={marketScreen.eventSearchBtn}
            />
          </TouchableOpacity>
        </View>
      </View>
      <View>
        <View style={marketScreen.eventDateView}>
          <Text style={marketScreen.eventCurrentDate}>{hDate || pDate}</Text>
          <TouchableOpacity
            onPress={() => {
              setShowCalendar(!showCalendar);
            }}>
            <MaterialCommunityIcons
              name="calendar"
              size={24}
              color={root.color_text}
              style={marketScreen.eventCalendarIcon}
            />
          </TouchableOpacity>
        </View>
        {showCalendar === true ? (
          <Calendar
            style={marketScreen.eventCalendar}
            markedDates={markedDates}
            onDayPress={handleDayPress}
            theme={marketScreen.eventCalendarTheme}
            hideExtraDays={true}
            hideArrows={true}
            enableSwipeMonths={true}
            renderHeader={() => {}}
            onMonthChange={handleMonthChange}
          />
        ) : (
          []
        )}
        {eventsForDate.length > 0 ? (
          <FlatList
            data={eventsForDate}
            keyExtractor={event => event.id.toString()}
            renderItem={renderEvents}
            style={marketScreen.eventFlatList}
          />
        ) : (
          <View style={marketScreen.noEventView}>
            <Image
              resizeMode="contain"
              source={require('../../../assets/blank_file.jpeg')}
              style={marketScreen.noEventImage}
            />
            <Text style={marketScreen.emptyEventText}>No item available</Text>
          </View>
        )}
      </View>
    </View>
  );
};
export default Events;

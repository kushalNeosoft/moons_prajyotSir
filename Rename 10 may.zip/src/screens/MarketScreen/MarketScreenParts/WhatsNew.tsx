import React from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import {styles} from '../styles/styles';
import {whatsNewData} from './SampleData';
import WhatsNewComponent from '../../../components/MarketScreen/WhatsNewComponent';
import {marketScreen} from '../../../Globalstyles/Globalstyle';

const WhatsNew = () => {
  const renderWhatsNewItem = ({item}) => {
    return <WhatsNewComponent title={item.title} subTitle={item.subTitle} />;
  };
  return (
    <View>
      <Text style={marketScreen.whatsNewHeadText}>What's New_1404</Text>
      <View>
        <FlatList
          data={whatsNewData}
          renderItem={renderWhatsNewItem}
          horizontal={true}
          keyExtractor={(_, index) => `item-${index}`}
          ListFooterComponent={() => {
            return <View style={marketScreen.WhatsNewFlatlistFooter}></View>;
          }}
          contentContainerStyle={marketScreen.WhatsNewContentContainer}
          showsVerticalScrollIndicator={false}
          showsHorizontalScrollIndicator={false}
        />
      </View>
    </View>
  );
};
export default WhatsNew;

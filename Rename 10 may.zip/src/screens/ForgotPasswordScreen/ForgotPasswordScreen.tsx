import React, {useState} from 'react';
import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';

import useStyles from '../../styles/useStyles';

import {useTranslation} from 'react-i18next';

import {createForgotPasswordStyles} from './styles/forgotpassword.styles';
import BackIcon from '../../assets/BackIcon';
import { Cfont, Font, root } from '../../styles/colors';
import { ForgotPasswordStyles } from '../../Globalstyles/Globalstyle';

const ForgotPasswordScreen = ({navigation}: any) => {
  const {colors, styles} = useStyles(createForgotPasswordStyles);
  const {t} = useTranslation();
  return (
    <View style={ForgotPasswordStyles.container}>
      <View style={{flex: 1}}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', true)}
          onPress={() => {
            console.log('Here');
            navigation.goBack();
          }}>
          <View style={{width: 32, height: 32}}>
            <BackIcon style={ForgotPasswordStyles.backIcon} />
          </View>
        </TouchableNativeFeedback>
        <Text style={[ForgotPasswordStyles.heading, {marginTop: 32}]}>
          Reset Your Password
        </Text>
      
        <Text style={{marginTop: 16,fontSize:Font.font_normal_two,color:root.color_text,fontFamily:Cfont.rubik_light,}}>
          We will send OTP to your registered Mobile Number and Email
        </Text>
        <Text
          style={{
            fontSize: Font.font_normal_four,
            marginTop: 32,
            fontFamily:Cfont.rubik_medium,
            color: root.color_text,
          }}>
          User Information
        </Text>
        <View style={{flexDirection: 'row', marginTop: 8}}>
          <View>
            <Text
              style={{paddingVertical: 17, fontFamily:Cfont.rubik_medium, color: root.color_text,fontSize:Font.font_normal_five}}>
              User ID
            </Text>
            <Text
              style={{paddingVertical: 17, fontFamily:Cfont.rubik_medium, color:root.color_text }}>
              Email
            </Text>
            <Text
              style={{paddingVertical: 18, fontFamily:Cfont.rubik_medium, color:root.color_text }}>
              Mobile No.
            </Text>
          </View>
          <View style={{flex: 1, marginLeft: 38}}>
            <Text
              style={{paddingVertical: 17, fontFamily:Cfont.rubik_medium, color:root.color_text }}>
              OM
            </Text>
            <Text
              style={{paddingVertical: 17, fontFamily:Cfont.rubik_medium, color:root.color_text }}>
              ****h.dashore@63moons.com
            </Text>
            <Text
              style={{paddingVertical: 18, fontFamily:Cfont.rubik_medium, color:root.color_text }}>
              99XXXXXX58
            </Text>
          </View>
        </View>
      </View>
      <View
        style={{
          borderRadius: 8,
        }}>
        <TouchableNativeFeedback
          //  background={TouchableNativeFeedback.Ripple( root.,true)}
          onPress={() => {
            // onLogin();
            // i18next.changeLanguage('hin');
          }}>
          <View style={ForgotPasswordStyles.buttonContainer}>
            <Text style={ForgotPasswordStyles.buttonText}>Reset Password</Text>
          </View>
        </TouchableNativeFeedback>
      </View>
    </View>
  );
};

export default ForgotPasswordScreen;

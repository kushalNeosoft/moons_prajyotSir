import {StyleSheet} from 'react-native';
import {Cfont, Font, root, TColors} from '../../../styles/colors';

export const createPasswordStyles = (colors: TColors) => {
  return StyleSheet.create({
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: Font.font_normal_three,
      alignSelf: 'center',
    },

    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_text,
      borderWidth: 0.5,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      color:root.color_text,

      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: root.color_text,
     
      margin: 12,
    },
  });
};

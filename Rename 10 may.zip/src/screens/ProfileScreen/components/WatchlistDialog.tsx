import React from 'react';
import {useState} from 'react';
import {View, Text, TouchableNativeFeedback} from 'react-native';
import CommonModal from '../../../components/Component/CommonModal/CommonModal';
import { Cfont, root } from '../../../styles/colors';

const WatchlistDialog = (props: any) => {
  const [selected, setSelected] = useState('WATCHLIST');
  return (
    <CommonModal visible={props.visible} onClose={props.onClose} >
    <View style={{width: '100%'}}>
      <Text style={{fontSize: 30, color: root.color_text, padding: 16, fontFamily:Cfont.rubik_medium}}>
        Take Me To
      </Text>

      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('WATCHLIST');
        }}>
        <View style={{flexDirection: 'row', marginTop: 1, padding: 16}}>
          <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'WATCHLIST' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 16 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
            Watchlist
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('MARKET');
        }}>
       <View style={{flexDirection: 'row', marginTop: 1, padding: 16}}>
          <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'MARKET' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 16 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
            Market
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('ORDERS');
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
       <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'ORDERS' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 16 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
            Orders
          </Text>
        </View>
      </TouchableNativeFeedback>
      <TouchableNativeFeedback
        background={TouchableNativeFeedback.Ripple('gray', false)}
        onPress={() => {
          setSelected('PORTFOLIO');
        }}>
        <View style={{flexDirection: 'row', padding: 16}}>
        <View
            style={[
              {
                height: 18,
                width: 18,
                borderRadius: 12,
                borderWidth: 2,
                borderColor: '#000',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}>
            {selected === 'PORTFOLIO' && (
              <View
                style={{
                  height: 9,
                  width: 9,
                  borderRadius: 6,
                  backgroundColor: '#000',
                }}
              />
            )}
          </View>
          <Text style={{fontSize: 14, marginLeft: 16 ,color:root.color_text,fontFamily:Cfont.rubik_medium}}>
            Portfolio
          </Text>
        </View>
      </TouchableNativeFeedback>
    </View>
    </CommonModal>
  );
};
export default WatchlistDialog;

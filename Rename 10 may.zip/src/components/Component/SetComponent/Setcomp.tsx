import React, {useState} from 'react';
import {View, Text, FlatList, StyleSheet} from 'react-native';
import {ISetcom, Setcomtxt} from './Setcomtxt';
import Entypo from 'react-native-vector-icons/Entypo';
import SwitchButton from '../Switch/Switch';

const Setcomp = () => {
  const [isEnabled, setIsEnabled] = useState(false);
  const handleValueChange = (value: boolean) => {
    setIsEnabled(value);
  };

  const Item = ({data}: {data: ISetcom}) => (
    <View style={{flex: 1, padding: 10, backgroundColor: 'white'}}>
      {data?.title == 'Theme' ? (
        <View style={styles.Container}>
          <Text style={styles.titletxt}>{data?.title}</Text>
          <View>
            <Text style={styles.optiontxt}>{data?.nameOne}</Text>
            <SwitchButton value={isEnabled} onValueChange={handleValueChange} />
          </View>
          <View>
            <Text style={styles.optiontxt}>{data?.nameTwo}</Text>
          </View>
        </View>
      ) : data?.title == 'Order Preferences' ? (
        <>
          <View style={styles.Container}>
            <Text style={styles.titletxt}>{data?.title}</Text>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <Text style={styles.optiontxt}>{data?.nameOne}</Text>
              <Entypo name="chevron-small-right" size={30} color={'#000080'} />
            </View>
          </View>
        </>
      ) : data?.title == 'Chart Preferences' ? (
        <>
          <View style={styles.Container}>
            <Text style={styles.titletxt}>{data?.title}</Text>
            <View>
              <Text style={styles.optiontxt}>{data?.nameOne}</Text>
            </View>
            <View>
              <Text style={styles.optiontxt}>{data?.nameTwo}</Text>
            </View>
          </View>
        </>
      ) : data?.title == 'App Notifications' ? (
        <>
          <View style={styles.Container}>
            <Text style={styles.titletxt}>{data?.title}</Text>
            <View>
              <Text style={styles.optiontxt}>{data?.nameOne}</Text>
            </View>
            <View>
              <Text style={styles.optiontxt}>{data?.nameTwo}</Text>

            </View>
          </View>
        </>
      ) : data?.title == 'Security Setting' ? (
        <>
          <View style={[styles.Container, {height: 150}]}>
            <Text style={styles.titletxt}>{data?.title}</Text>
            <View>
              <Text style={styles.optiontxt}>{data?.nameOne}</Text>
            </View>
            <View>
              <Text style={styles.optiontxt}>{data?.nameTwo}</Text>
            </View>
            <View>
              <Text style={styles.optiontxt}>{data?.nameThree}</Text>
            </View>
            <View>
              <Text style={styles.optiontxt}>{data?.nameFour}</Text>
            </View>
          </View>
        </>
      ) : (
        <>
          <View style={styles.Container}>
            <Text style={styles.titletxt}>{data?.title}</Text>
            <View
              style={{flexDirection: 'row', justifyContent: 'space-between'}}>
              <Text style={styles.optiontxt}>{data?.nameOne}</Text>
              <Entypo name="chevron-small-right" size={30} color={'#000080'} />
            </View>
          </View>
        </>
      )}
    </View>
  );

  return (
    <FlatList
      data={Setcomtxt}
      renderItem={({item}) => <Item data={item} />}
      keyExtractor={(item: ISetcom) => item.index}
    />
  );
};

export default Setcomp;

const styles = StyleSheet.create({
  Container: {
    height: 100,
    flex: 1,
    justifyContent: 'space-around',
  },
  titletxt: {
    fontSize: 24,
    color: 'black',
    fontWeight: '600',
  },
  optiontxt: {
    color: 'black',
    fontSize: 15,
  },
});

import React, { useState } from 'react';
import { Switch } from 'react-native';

interface SwitchButtonProps {
    value: boolean;
    onValueChange: (value: boolean) => void;
  }

  const SwitchButton = ({ value, onValueChange }: SwitchButtonProps) => {
    const [isEnabled, setIsEnabled] = useState(value);
  
    const toggleSwitch = () => {
      setIsEnabled(!isEnabled);
      onValueChange(!isEnabled);
    };
  
    return (
      <Switch
        trackColor={{ false: '#767577', true: '#81b0ff' }}
        thumbColor={isEnabled ? '#f5dd4b' : '#f4f3f4'}
        ios_backgroundColor="#3e3e3e"
        onValueChange={toggleSwitch}
        value={isEnabled}
      />
    );
  };


export default SwitchButton;
import React from 'react';
import {
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  FlatList,
} from 'react-native';
import {assets} from '../../assets';
// import {colors} from '../../constants/colors';
import CommonModal from '../CommonModal/CommonModal';
import { DotModalStyle } from '../../../Globalstyles/Globalstyle';
import AntDesign from 'react-native-vector-icons/AntDesign'
import colors, { Cfont, Font, root } from '../../../styles/colors';

const DotModal = (props: any) => {
  const data = [
    {
      icon: assets.plus ,
      label: 'Add Script',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.minus,
      label: 'Remove Script',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.filter,
      label: 'Filter',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.menu,
      label: 'Reorder Scripts',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.pencil,
      label: 'Rename watchlist',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.delete,
      label: 'Delete watchlsit',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.plus,
      label: 'Create new watchlist',
      onPress: (item: any) => {
        console.log(item);
      },
    },
    {
      icon: assets.heart,
      label: 'Mark this default',
      onPress: (item: any) => {
        console.log(item);
      },
    },
  ];

  const renderView = (item: any) => {
    console.log(item.label);
    return (
      <TouchableOpacity
        style={DotModalStyle.dotmodalallign}
        onPress={() => item.onPress(item)}>
        <Image source={item.icon} style={DotModalStyle.imgsize} />
        <Text style={DotModalStyle.dotmain}>
          {item.label}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose}>
        <Image source={assets.cross} style={DotModalStyle.image} />
      </TouchableOpacity>
      <FlatList data={data} renderItem={({item}) => renderView(item)} />
    </CommonModal>
  );
};

const styles= StyleSheet.create({
  dotmodalallign:{
    flexDirection: 'row', height: 48, alignItems: 'center'
  },
  commonTimingView: {
    height: 300,
    width: 120,
    alignItems: 'flex-start',
  },
  image: {
    height: 14,
    width: 14,
    marginVertical: 10,
    alignSelf: 'flex-end',
  },
  dotmain:{
    color:root.color_text, paddingLeft: 20, fontSize: Font.font_normal_three ,paddingVertical:10
    ,fontFamily:Cfont.rubik_regular
  },
  imgsize:{
    height: 24, width: 24
  }
});

export default DotModal;

import React, {useState, useEffect} from 'react';
import {Easing} from 'react-native';
import {View, Text, StyleSheet, Animated, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import {Cfont} from '../../styles/colors';
import {portFolioScreen} from '../../Globalstyles/Globalstyle';
import {MenuIcon} from '../Component/Svg/Svg';

const PortfolioHeader = ({scrollValue, price, changes}) => {
  const [headerOpacity, setHeaderOpacity] = useState(new Animated.Value(0));
  const [headerOpacity2, setHeaderOpacity2] = useState(new Animated.Value(0));
  // This useEffect is calling for FadeIn and fadeOut effect
  useEffect(() => {
    if (scrollValue == 1) {
      Animated.timing(headerOpacity, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    } else {
      Animated.timing(headerOpacity, {
        toValue: 0,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
      Animated.timing(headerOpacity2, {
        toValue: 1,
        duration: 600,
        useNativeDriver: false,
        easing: Easing.linear,
      }).start();
    }
  }, [scrollValue]);
  const navigation = useNavigation();
  return (
    <Animated.View
      style={[portFolioScreen.portFolioHeaderView, {opacity: headerOpacity}]}>
      <TouchableOpacity
        onPress={() => navigation.toggleDrawer()}
        style={portFolioScreen.portFolioHeaderIconView}>
        <MenuIcon />
      </TouchableOpacity>
      <View style={portFolioScreen.portFolioHeader}>
        <Text style={portFolioScreen.PortfolioText}>Portfolio</Text>
        <Text style={portFolioScreen.PortfolioSubTitle}>{price}</Text>
        <Text style={portFolioScreen.PortfolioChanges}>{changes}</Text>
      </View>
    </Animated.View>
  );
};
export default PortfolioHeader;

import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {holdingListComp} from '../../Globalstyles/Globalstyle';

const HoldingList = props => {
  return (
    <View style={holdingListComp.container}>
      <View>
        <Text style={holdingListComp.stockName}>{props.stockName}</Text>
        <View>
          <Text style={holdingListComp.subTitle}>{props.stockTtile}</Text>
        </View>
      </View>
      <View>
        <Text></Text>
      </View>
    </View>
  );
};
export default HoldingList;

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import {myScreenerComp} from '../../Globalstyles/Globalstyle';

const MyScreenersComponent = props => {
  return (
    <TouchableOpacity
      style={myScreenerComp.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <Text style={myScreenerComp.title}>{props.title}</Text>
    </TouchableOpacity>
  );
};
export default MyScreenersComponent;
// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: root.color_active,
//     height: 115,
//     width: 112,
//     marginVertical: 10,
//     marginBottom: 18,
//     marginRight: 13,
//     marginLeft: 3,
//     borderRadius: 8,
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,

//     elevation: 3,
//   },
//   title: {
//     color: root.color_text,
//     fontFamily: Cfont.rubik_medium,
//     marginLeft: 12,
//     paddingTop: 12,
//     paddingRight: 18,
//     paddingBottom: 18,
//     fontSize: 13,
//   },
// });

import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  Linking,
} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {Cfont, Font, root} from '../../styles/colors';
import {whatsNewComp} from '../../Globalstyles/Globalstyle';
const WhatsNewComponent = props => {
  const navigation = useNavigation();
  const title = props.title;
  return (
    <View
      style={[
        whatsNewComp.whatsNewContainer,
        {backgroundColor: title == 'IPO is incoming!!' ? '#EFF3FF' : '#B4EBCC'},
      ]}>
      <View>
        <Text style={whatsNewComp.whatsNewTitle}>{props.title}</Text>
        <Text style={whatsNewComp.whatsNewSubTitle}>{props.subTitle}</Text>
        <TouchableOpacity
          style={whatsNewComp.whatsNewButton}
          onPress={() => {
            if (title == 'IPO is incoming!!') {
              navigation.navigate('IpoScreen');
            } else {
              Linking.openURL(
                'https://mobileuat.odinwave.com/Wave2BackOffice/outstanding-report?userId=OM',
              );
            }
          }}>
          <Text style={whatsNewComp.whatsNewButtonText}>Apply Now</Text>
        </TouchableOpacity>
      </View>
      <View style={whatsNewComp.whatsNewImage}>
        <Image
          resizeMode="contain"
          source={require('../../assets/demo.jpeg')}
          style={whatsNewComp.whatsNewImage}
        />
      </View>
    </View>
  );
};
export default WhatsNewComponent;
// const styles = StyleSheet.create({
//   container: {
//     // marginLeft: 16,
//     height: 127,
//     width: Dimensions.get('window').width / 1.25,
//     marginVertical: 15,
//     borderRadius: 8,
//     marginRight: 13,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,
//     elevation: 3,
//     overflow: 'hidden',
//   },
//   title: {
//     color: '#303030',
//     fontSize: 16,
//     fontFamily: Cfont.rubik_medium,
//     marginLeft: 15,
//     marginTop: 13,
//   },
//   subTitle: {
//     color: '#303030',
//     fontSize: 12,
//     marginLeft: 15,
//     marginTop: 8,
//     fontFamily: Cfont.rubik_regular,
//   },
//   button: {
//     backgroundColor: '#25325C',
//     width: 100,
//     height: 35,
//     borderRadius: 25,
//     alignItems: 'center',
//     justifyContent: 'center',
//     marginLeft: 15,
//     marginTop: 11,
//     shadowColor: '#000',
//     shadowOffset: {
//       width: 0,
//       height: 2,
//     },
//     shadowOpacity: 0.25,
//     shadowRadius: 3.84,

//     elevation: 3,
//   },
//   buttonText: {
//     color: 'white',
//     fontFamily: Cfont.rubik_medium,
//     fontSize: 12,
//   },
//   image: {
//     height: 85,
//     width: 90,
//     marginTop: 11,
//     marginRight: 15,
//     backgroundColor: 'white',
//   },
// });

import {createMaterialTopTabNavigator} from '@react-navigation/material-top-tabs';
import {NavigationContainer} from '@react-navigation/native';
import {View, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';
import Constituents from '../screens/IndicesScreen/Constituents/Constituents';
import Futures from '../screens/IndicesScreen/Futures/Futures';
import OptionChain from '../screens/IndicesScreen/OptionChain/OptionChain';
import OverView from '../screens/IndicesScreen/OverView/OverView';
import Feather from 'react-native-vector-icons/Feather';
import React from 'react';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {useNavigation} from '@react-navigation/native';
import { Cfont, root } from '../styles/colors';

const TopTab = createMaterialTopTabNavigator();

const topHeader = () => {
  const navigation = useNavigation();
  return (
    <View style={styles.topContainer}>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons
            size={24}
            name="arrow-back-sharp"
            style={{marginRight: 10, color: '#303030'}}
            color="#303030"
          />
        </TouchableOpacity>

        <View>
          <Text style={styles.nifty50Txt}>Nifty 50</Text>
          <View style={{flexDirection: 'row'}}>
            <Text style={styles.value}>17632.75</Text>
            <Text
              style={[
                styles.value,
                {color: '#4caf50', marginLeft: 3, fontSize: 14, paddingTop: 2},
              ]}>
              -30 (-0.00%)
            </Text>
          </View>
          <Text
            style={{fontSize: 11, color: root.color_text, fontFamily: Cfont.rubik_light}}>
            24 APR '23 10:10:10 AM
          </Text>
        </View>
      </View>

      <TouchableOpacity style={{borderWidth: 1.5, borderRadius: 25}}>
        <Feather name="bar-chart-2" size={20} color="black" />
      </TouchableOpacity>
    </View>
  );
};

function TopMaterialTab() {
  const navigation = useNavigation();
  return (
    <>
      {topHeader()}
      <TopTab.Navigator
        screenOptions={{
          tabBarScrollEnabled: true,
          tabBarStyle: {
            marginHorizontal: 0,
            height: 40,
            elevation: 10,
            paddingLeft:10
          },
          tabBarLabelStyle: {
            fontSize: 11.5,
            // fontWeight: 'bold',
            textTransform: 'none',
            fontFamily:Cfont.rubik_medium
          },
          tabBarItemStyle: {
            width: 'auto',
          },
          tabBarIndicatorStyle: {
            marginLeft: 10,
            backgroundColor:root.client_background
          },
          tabBarActiveTintColor:root.client_background,
          tabBarInactiveTintColor:'#979797',
        }}>
        <TopTab.Screen name="Constituents" component={Constituents} />
        <TopTab.Screen name="Overview" component={OverView} />
        <TopTab.Screen name="Futures" component={Futures} />
        <TopTab.Screen name="Option Chain" component={OptionChain} />
      </TopTab.Navigator>
    </>
  );
}

const styles = StyleSheet.create({
  topContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    paddingHorizontal: 15,
    backgroundColor: 'white',
  },
  image: {
    height: 25,
    width: 25,
    marginRight: 15,
  },
  nifty50Txt: {
    color: '#303030',
    fontSize: 20,
    fontFamily: Cfont.rubik_medium,
  },
  value: {
    color: '#303030',
    fontSize: 16,
    fontFamily: Cfont.rubik_regular
  },
});

export default TopMaterialTab;

import {NavigationContainer} from '@react-navigation/native';

import {createStackNavigator} from '@react-navigation/stack';
import LoginScreen from '../screens/LoginScreen/LoginScreen';

import {FC, useEffect} from 'react';
import React from 'react';
import {useColorScheme} from 'react-native';

import Colors from '../styles/colors';
import useColors from '../styles/useColors';
import LoginStack from './LoginStack';
import DashNavigator from './DashboardStack';
import { SideDrawerNavigation } from './SiderawerStack';
import SignupScreen from '../screens/SignupScreen/SignupScreen';
import ProfileScreen from '../screens/ProfileScreen/ProfileScreen';
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen/ForgotPasswordScreen';
import PhoneVerificationScreen from '../screens/PhoneVerificationScreen/PhoneVerificationScreen';

const RootStack = createStackNavigator();

const RootNavigator: FC = () => {
  const {colors, applyColors} = useColors();
  const colorScheme = useColorScheme();

  useEffect(() => {
    applyColors(colorScheme === 'dark' ? Colors.dark : Colors.light);
  }, [applyColors, colorScheme]);

  return (
    
      <RootStack.Navigator
        screenOptions={{headerShown: false}}
        >
        {/* <RootStack.Screen name="Loginstack" component={LoginStack} /> */}

        <RootStack.Screen name="Dash" component={SideDrawerNavigation} />
        
        
      </RootStack.Navigator>
  
  );
};

export default RootNavigator;

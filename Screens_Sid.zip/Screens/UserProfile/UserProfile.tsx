import React, {useState} from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {userProfile} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import EditImageModal from './Component/EditImageModal';
import {useSelector} from 'react-redux';

interface ListItem {
  id: string;
  title: string;
}

const data: ListItem[] = [
  {id: '1', title: 'NSE CASH'},
  {id: '2', title: 'NSE DERIVATIVES'},
  {id: '3', title: 'BSE CASH'},
  {id: '4', title: 'MCX FUTURES'},
  {id: '5', title: 'NCDEX FUTURES'},
  {id: '6', title: 'NSECDS'},
  {id: '7', title: 'BSECDS'},
  {id: '8', title: 'ICEX FUTURES'},
  {id: '9', title: 'NSE  FUTURES'},
  {id: '10', title: 'BSE FUTURES'},
  {id: '11', title: 'BASE CASH FUTURES'},
];

const UserProfile = () => {
  const navigation = useNavigation();
  const [visibleModal, setVisibleModal] = useState(false);
  const userImage = useSelector(state => state?.Reducer?.userImage);
  const userDetails = {
    userName: 'PRAGATI K',
    userId: 'PRAGATI',
    phone: '9893945645',
    email: ' react-native-poc@63moons.com',
    panNo: '******243A',
    bankName: 'HDFC BANK',
    accountNo: '*********',
  };

  return (
    <View style={userProfile.mainView}>
      <View style={userProfile.userProfileHeaderView}>
        <TouchableOpacity
          onPress={() => {
            navigation.goBack();
          }}>
          <Ionicons
            name="arrow-back"
            style={userProfile.userProfileHeaderBackIcon}
          />
        </TouchableOpacity>
        <Text style={userProfile.userProfileHeaderText}>Profile</Text>
      </View>
      <View style={userProfile.imageProfileView}>
        <Image
          style={userProfile.userProfileImage}
          resizeMode="contain"
          source={{uri: userImage}}
        />
        <TouchableOpacity
          style={userProfile.userProfileEditIconView}
          onPress={() => {
            setVisibleModal(true);
          }}>
          <MaterialIcons name="edit" style={userProfile.userProfileEditIcon} />
        </TouchableOpacity>
        <View>
          <Text style={userProfile.userName}>{userDetails.userName}</Text>
          <View style={userProfile.userIdTextNameView}>
            <Text style={userProfile.userIdText}>USER ID : </Text>
            <Text style={userProfile.userId}>{userDetails.userId}</Text>
          </View>
        </View>
      </View>
      <View style={userProfile.line}></View>

      <View style={userProfile.userInfoView}>
        <Text style={userProfile.userInformationText}>User Information</Text>
        <View style={userProfile.userDetailsView}>
          <Text style={userProfile.userDetailText}>Phone</Text>
          <Text style={userProfile.userDetailData}>{userDetails.phone}</Text>
        </View>
        <View style={userProfile.userDetailsView}>
          <Text style={userProfile.userDetailText}>Email</Text>
          <Text style={userProfile.userDetailData}>{userDetails.email}</Text>
        </View>
        <View style={userProfile.userDetailsView}>
          <Text style={userProfile.userDetailText}>Pan No.</Text>
          <Text style={userProfile.userDetailData}>{userDetails.panNo}</Text>
        </View>
        <View style={userProfile.segmetsAllowedView}>
          <Text style={userProfile.userDetailText}>Segments Allowed</Text>
          <View style={userProfile.segmentAllowedMap}>
            {data.map(data => {
              return (
                <View style={userProfile.segmentBgColor}>
                  <Text style={userProfile.segmentText}>{data.title}</Text>
                </View>
              );
            })}
          </View>
        </View>
        <Text style={userProfile.bankAcText}>Bank Accounts</Text>
        <View style={userProfile.userDetailsView}>
          <Text style={userProfile.userDetailText}>{userDetails.bankName}</Text>
          <Text style={userProfile.userDetailData}>
            {userDetails.accountNo}
          </Text>
        </View>
        <TouchableOpacity style={userProfile.closeAccountView}>
          <Text style={userProfile.closeAccountText}>Close Account</Text>
        </TouchableOpacity>
      </View>
      <EditImageModal
        visibleModal={visibleModal}
        setVisibleModal={setVisibleModal}
      />
    </View>
  );
};
export default UserProfile;

import React, {useState} from 'react';
import {View, Text, FlatList, TouchableOpacity} from 'react-native';
import ImagePicker from 'react-native-image-crop-picker';
import {profileEditModal} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';
import {useDispatch} from 'react-redux';
import {setUserImage, removeUserImage} from '../../../redux/Action';

const EditImageModal = props => {
  const dispatch = useDispatch();

  const onSelectCamera = () => {
    ImagePicker.openCamera({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      dispatch(setUserImage(image.path));
      props?.setVisibleModal(false);
    });
  };

  const onSelectGallery = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      cropping: true,
    }).then(image => {
      dispatch(setUserImage(image.path));
      props?.setVisibleModal(false);
    });
  };

  const onSelectRemove = () => {
    dispatch(removeUserImage());
    props?.setVisibleModal(false);
  };
  return (
    <CommonModal
      visible={props.visibleModal}
      onClose={() => {
        props?.setVisibleModal(false);
      }}>
      <View style={profileEditModal.modalMainView}>
        <Text style={profileEditModal.header}>Profile Picture Setting</Text>
        <TouchableOpacity
          style={profileEditModal.EditOption}
          onPress={() => {
            onSelectGallery();
          }}>
          <Text style={profileEditModal.EditOptionText}>Gallery</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={profileEditModal.EditOption}
          onPress={() => {
            console.log('clicked on camera');
            onSelectCamera();
          }}>
          <Text style={profileEditModal.EditOptionText}>Camera</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={profileEditModal.EditOption}
          onPress={() => {
            onSelectRemove();
          }}>
          <Text style={profileEditModal.EditOptionText}>Remove Profile</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={profileEditModal.EditOption}
          onPress={() => {
            props?.setVisibleModal(false);
          }}>
          <Text style={profileEditModal.EditOptionText}>Close</Text>
        </TouchableOpacity>
      </View>
    </CommonModal>
  );
};
export default EditImageModal;

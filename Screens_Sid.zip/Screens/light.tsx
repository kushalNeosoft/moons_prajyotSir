// user Profile screen styling

export const userProfile = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  userProfileHeaderView: {
    flexDirection: "row",
    alignItems: "center",
    height: 42,
    paddingHorizontal: 16,
  },
  userProfileHeaderText: {
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    paddingLeft: 20,
  },
  userProfileHeaderBackIcon: {
    fontSize: Font.font_normal_twenty_four,
    color: root.color_text,
  },
  imageProfileView: {
    paddingTop: 22,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 25,
  },
  userProfileImage: {
    height: 51,
    width: 51,
    borderRadius: 25,
    backgroundColor: "black",
  },
  userProfileEditIconView: {
    borderRadius: 25,
    // height: 18,
    // width: 18,
    backgroundColor: root.color_textual,
    justifyContent: "center",
    alignItems: "center",
    alignSelf: "flex-end",
    marginLeft: -17,
  },
  userProfileEditIcon: {
    color: root.color_active,
    size: 45,
    padding: 3,
  },
  userName: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginLeft: 30,
  },
  userIdTextNameView: {
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 30,
    paddingTop: 2,
  },
  userIdText: {
    fontSize: 12,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  userId: {
    fontSize: 12,
    fontFamily: Cfont.rubik_light,
    color: root.color_text,
  },
  line: {
    width: "100%",
    borderColor: root.color_subtext,
    borderWidth: 0.2,
    opacity: 0.3,
  },
  userInfoView: {
    paddingHorizontal: 16,
  },
  userInformationText: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 28,
  },
  userDetailsView: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 30,
  },
  userDetailText: {
    fontSize: 13,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  userDetailData: {
    fontSize: 13,
    fontFamily: Cfont.rubik_regular,
    color: root.color_text,
  },
  segmetsAllowedView: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 33,
  },
  segmentAllowedMap: {
    flexWrap: "wrap",
    // height: '100%',
    width: "50%",
    flexDirection: "row",
    justifyContent: "flex-end",
  },
  segmentBgColor: {
    backgroundColor: root.backgroung_exchange_chip_color,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    padding: 5,
    paddingLeft: 10,
    paddingRight: 10,
    margin: "1%",
  },
  segmentText: {
    fontSize: 8,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
  },
  bankAcText: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 42,
    paddingBottom: 3,
  },
  closeAccountView: {
    borderColor: root.color_text,
    borderRadius: 25,
    marginTop: 33,
    borderWidth: 0.8,
    width: 110,
    justifyContent: "center",
    alignItems: "center",
  },
  closeAccountText: {
    fontSize: 11,
    color: root.color_text,
    fontFamily: Cfont.rubik_medium,
    padding: 4,
  },
});

//profile Edit modal

export const profileEditModal = StyleSheet.create({
  modalMainView: {
    flex: 1,
    paddingLeft: 6,
    paddingBottom: 6,
  },
  header: {
    fontSize: 17,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    marginTop: 4,
  },
  EditOption: {
    marginTop: 34,
  },
  EditOptionText: {
    fontSize: 14,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
});


// ------ Add image crop picker package in application.
// ------ Add userProfile Screen in DashbaordStack and add navigation to drawer.
<DashboardStack.Screen name="UserProfile" component={UserProfile} />


// Redux Part -

// Add this line in Reducer.tsx

const initialState = {
  userImage: 'https://reactnative.dev/img/tiny_logo.png', // this line
};

case SET_USER_IMAGE: {
  return {
    ...state,
    userImage: action.payload,
  };
}
case REMOVE_USER_IMAGE: {
  return {
    ...state,
    userImage: 'https://reactnative.dev/img/tiny_logo.png',
  };
}

// Add this line in Action.tsx 

export const setUserImage = (url: string) => ({
  type: SET_USER_IMAGE,
  payload: url,
});
export const removeUserImage = () => ({
  type: REMOVE_USER_IMAGE,
});

// Add this line in actionTypes.tsx

export const SET_USER_IMAGE = 'SET_USER_IMAGE';
export const REMOVE_USER_IMAGE = 'REMOVE_USER_IMAGE';
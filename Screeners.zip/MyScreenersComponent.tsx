import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import {myScreenerComp} from '../../../theme/light';

const MyScreenersComponent = props => {
  return (
    <TouchableOpacity
      style={myScreenerComp.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <Text style={myScreenerComp.title}>{props.title}</Text>
      <View style={{position: 'absolute', bottom: 0, right: 0}}>
        <Image
          source={require('../../../assets/Broker.png')}
          style={{width: 32, height: 32}}
        />
      </View>
    </TouchableOpacity>
  );
};
export default MyScreenersComponent;

import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  ScrollView,
  TouchableNativeFeedback,
  ActivityIndicator,
} from 'react-native';
import {screenersData} from './SampleData';
import MyScreenersComponent from '../Component/MyScreenersComponent';
import {marketScreen} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';
const MyScreeners = () => {
  const [loading, setLoading] = useState(false);
  const navigation = useNavigation();

  const [list, setList] = useState([]);

  const loadData = async () => {
    setLoading(true);
    fetch(
      'https://devwaveapi.odinwave.com/nontransactional/1404/v1/getAppWaveScannerDetails',
      {
        method: 'GET',
      },
    )
      .then(response => response.json())
      .then((data): any => {
        setLoading(false);
        if (data.status) {
          console.log('hello', data.result);
          setList(data.result);
        }
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);

  const renderScreenersItem = ({item}) => {
    return <MyScreenersComponent title={item.GroupName} />;
  };
  return (
    <View style={{}}>
      <View style={marketScreen.myScreenerHeadView}>
        <Text style={marketScreen.myScreenerHeadText}>My Screeners</Text>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('gray', false)}
          onPress={() => {
            navigation.navigate('MyFavourites');
          }}>
          <Text style={marketScreen.myScreenerViewAllbtn}>View All</Text>
        </TouchableNativeFeedback>
      </View>
      {loading && list.length == 0 ? (
        <ActivityIndicator />
      ) : (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          directionalLockEnabled={true}
          alwaysBounceVertical={false}
          style={marketScreen.myScreenerScrollView}>
          <FlatList
            key={list.length}
            contentContainerStyle={{alignSelf: 'flex-start'}}
            numColumns={Math.ceil(list.length / 2)}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}
            data={list}
            renderItem={renderScreenersItem}
          />
        </ScrollView>
      )}
    </View>
  );
};
export default MyScreeners;

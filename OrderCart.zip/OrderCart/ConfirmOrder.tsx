import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  TouchableNativeFeedback,
} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {styles} from '../../navigators/Curverbottom';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import SquareOffModal from '../SquareOff/Component/SquareOffModal';
import SquareOffList from '../SquareOff/Component/SquareOffList';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import ShopCartIcon from '../../assets/ShopCartIcon';
import OrderCartItem from './components/OrderCartItem';
import OrderCountItem from './components/OrderCountItem';
// import SquareOffList from './Component/SquareOffList';
// import SquareOffModal from './Component/SquareOffModal';
import WebView from 'react-native-webview';
import {font_Family} from '../../styles/Common/FontFamily';
import FontSize from '../../styles/Common/FontSize';
import OrderSuccessDialog from '../BuySell/components/OrderSuccessDialog';
import OrderSuccessfulDialog from './components/OrderSuccessfulDialog';
import OrderCartStyle from '../../styles/Views/OrderCartStyle';

const ConfirmOrder = ({route}: any) => {
  const {scrips} = route.params;

  console.log(scrips);
  const [successModal, setSuccessModal] = useState(false);
  const {ConfirmOrderStyles} = OrderCartStyle();

  const navigation = useNavigation();

  return (
    <View style={squareOff.container}>
      <View style={squareOff.subContainer}>
        <View style={squareOff.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="close" style={squareOff.backIcon} />
          </TouchableOpacity>
        </View>

        <View style={ConfirmOrderStyles.MainView}>
          <Text style={ConfirmOrderStyles.ConfirmText}>Confirm Your Order</Text>
        </View>

        <View style={ConfirmOrderStyles.ApproxView}>
          <Text style={ConfirmOrderStyles.ApproxText}>
            Approx. Amount: <Text style={ConfirmOrderStyles.Amount}>1652</Text>
          </Text>
        </View>
        {/* <View style={squareOff.headerBorder}></View> */}
        {/* FlateList code */}
        <View
          style={ConfirmOrderStyles.View}>
          <View style={ConfirmOrderStyles.flex}>
            <Text
              style={ConfirmOrderStyles.TextScrip}>
              Scrip Name
            </Text>
          </View>
          <View style={ConfirmOrderStyles.flex1}>
            <Text
              style={ConfirmOrderStyles.TextScrip}>
              Qty
            </Text>
          </View>
          <View style={ConfirmOrderStyles.flex1}>
            <Text
              style={ConfirmOrderStyles.TextScrip}>
              B/S
            </Text>
          </View>
          <View style={ConfirmOrderStyles.flex2}>
            <Text
              style={ConfirmOrderStyles.ProductText}>
              Product Type
            </Text>
          </View>
        </View>
        <View
          style={ConfirmOrderStyles.flatlistView}></View>
        <FlatList
          data={scrips}
          renderItem={({item}) => {
            return (
              <View
                style={ConfirmOrderStyles.FlatlistMain}>
                <View style={ConfirmOrderStyles.flex}>
                  <Text
                    style={ConfirmOrderStyles.CompanyNameText}>
                    {item.companyName}
                  </Text>
                </View>
                <View style={ConfirmOrderStyles.flex1}>
                  <Text>1</Text>
                </View>
                <View style={ConfirmOrderStyles.flex1}>
                  <Text
                    style={[ConfirmOrderStyles.buy,{
                      color: item.operation === 'BUY' ? 'green' : 'red', 
                      // marginBottom: 5,
                    }]}>
                    {item.operation === 'BUY' ? 'Buy' : 'Sell'}
                  </Text>
                </View>
                <View style={ConfirmOrderStyles.flex2}>
                  <Text
                    style={ConfirmOrderStyles.Delivery}>
                    {item.type === 'DELIVERY' ? 'Delivery' : 'INTRDY'} @{' '}
                    {item.market}
                  </Text>
                </View>
              </View>
            );
          }}
          contentContainerStyle={ConfirmOrderStyles.containtContainer}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View
        style={ConfirmOrderStyles.View3}></View>
      <View style={{padding: 16}}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => {
            // setConfirmOrderVisible(true);
            setSuccessModal(true);
          }}>
          <Text
            style={ConfirmOrderStyles.ConfirmOrdertext}>
            Confirm Order
          </Text>
        </TouchableNativeFeedback>
      </View>
      <OrderSuccessfulDialog
        visible={successModal}
        onClose={() => {
          setSuccessModal(false);
        }}
        scrips={scrips}
      />
    </View>
  );
};
export default ConfirmOrder;

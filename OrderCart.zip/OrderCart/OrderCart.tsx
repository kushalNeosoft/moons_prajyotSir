import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {styles} from '../../navigators/Curverbottom';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import SquareOffModal from '../SquareOff/Component/SquareOffModal';
import SquareOffList from '../SquareOff/Component/SquareOffList';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import ShopCartIcon from '../../assets/ShopCartIcon';
import OrderCartItem from './components/OrderCartItem';
import OrderCartStyle from '../../styles/Views/OrderCartStyle';
// import SquareOffList from './Component/SquareOffList';
// import SquareOffModal from './Component/SquareOffModal';

const OrderCart = () => {
  const [selectedItems, setSelectedItems] = useState([]);

  const {CartStyles} = OrderCartStyle();

  const [render, setRender] = useState(false);

  const overallData = [
    {
      companyName: 'WIPRO',
      price: '4570.00',
      todaysPL: '-6.65(-0.28)',
      titleChip: 'NSE',
      id: 0,
      operation: 'BUY',
      type: 'DELIVERY',
      market: '100',
    },
    {
      companyName: 'RELIANCE',
      price: '4570.00',
      todaysPL: '-6.65(-0.28)',
      titleChip: 'NSE',
      id: 1,
      operation: 'BUY',
      type: 'DELIVERY',
      market: 'MKT',
    },
    {
      companyName: 'GOOGL',
      price: '4570.00',
      todaysPL: '-6.65(-0.28)',
      titleChip: 'NSE',
      id: 2,
      operation: 'BUY',
      type: 'INTRDY',
      market: '200',
    },
    {
      companyName: 'SARDAEN',
      price: '4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'NSE',
      id: 3,
      operation: 'SELL',
      type: 'DELIVERY',
      market: 'MKT',
    },
    {
      companyName: 'AASTAFIN',
      price: '4570.00',
      todaysPL: '-6.65(-0.28)',
      LTP: '3316.27',
      titleChip: 'NSE',
      id: 4,
      operation: 'BUY',
      type: 'DELIVERY',
      market: '500',
    },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
    // {
    //   companyName: 'Wipro',
    //   buy: '2 Qty @ ₹ 4570.00',
    //   todaysPL: '-6.65(-0.28)',
    //   LTP: '3316.27',
    //   titleChip: 'EQ Combined',
    //   bottomChip: 'MARGIN',
    // },
  ];
  const navigation = useNavigation();

  const onItemPress = (pressedItem: never) => {
    let arr = [...selectedItems];

    let idx = arr.findIndex((itm, index) => itm.id === pressedItem.id);
    if (idx == -1) {
      arr.push(pressedItem);
    } else {
      arr.splice(idx, 1);
    }
    setSelectedItems([...arr]);

    console.log(arr);
  };

  const renderItem = ({item}: any) => {
    return (
      <OrderCartItem
        onPress={onItemPress}
        item={item}
        selectedItems={selectedItems}
      />
    );
  };
  const onSelectAllPress = () => {
    if (selectedItems.length === overallData.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems([...overallData]);
    }
  };
  return (
    <View style={squareOff.container}>
      <View style={squareOff.subContainer}>
        <View style={squareOff.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="close" style={squareOff.backIcon} />
          </TouchableOpacity>
        </View>
        <Text
          style={CartStyles.ChooseText}>
          Choose Scrips for
        </Text>
        <View style={CartStyles.flex}>
          <Text
            style={CartStyles.OrderCartText}>
            Order Cart
          </Text>
          <ShopCartIcon style={CartStyles.ShopCartIcon} />
        </View>

        <View style={squareOff.orderHeadView}>
          <Text style={squareOff.orderText}>Order Cart</Text>
          <TouchableOpacity
            onPress={onSelectAllPress}
            style={squareOff.selectAllTextIconView}>
            {selectedItems.length > 0 ? (
              <Text style={squareOff.selectAllText}>
                Selected ({selectedItems.length + '/' + overallData.length})
              </Text>
            ) : (
              <Text style={squareOff.selectAllText}>Select All</Text>
            )}
            {selectedItems.length === 0 ? (
              <MaterialIcons
                name="check-box-outline-blank"
                style={squareOff.selectAllIcon}
              />
            ) : selectedItems.length === overallData.length ? (
              <AntDesign name="checksquare" style={squareOff.selectAllIcon} />
            ) : (
              <AntDesign name="minussquare" style={squareOff.selectAllIcon} />
            )}
          </TouchableOpacity>
        </View>
        <View style={squareOff.headerBorder}></View>
        {/* FlateList code */}
        <FlatList
          data={overallData}
          renderItem={renderItem}
          contentContainerStyle={{
            marginTop: 13,
            paddingBottom: 70,
          }}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View style={squareOff.bottomView}>
        <View style={squareOff.bottominnerView}>
          <View>
            <Text style={squareOff.bottomSquareOffText}>Add scrips to</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                // justifyContent: 'center',
              }}>
              <Text style={squareOff.bottomSelectedText}>Order Card</Text>
              {selectedItems.length > 0 ? (
                <View style={squareOff.bottomCountView}>
                  <Text style={squareOff.bottomCountText}>
                    {selectedItems.length}
                  </Text>
                </View>
              ) : (
                <></>
              )}
            </View>
          </View>
          <TouchableOpacity
            style={squareOff.bottomDoneBtn}
            onPress={() => {
              navigation.navigate('PlaceOrder', {
                scrips: selectedItems,
              });
            }}>
            <Text style={squareOff.bottomDoneText(selectedItems.length)}>
              Next
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};
export default OrderCart;

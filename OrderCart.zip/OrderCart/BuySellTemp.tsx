import {useState} from 'react';
import * as React from 'react';
// import React from 'react';
import {
  Image,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import CloseIcon from '../../assets/CloseIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';

import {Cfont, root} from '../../styles/colors';
import {OrderEntry} from '../../theme/light';
import Margin from '../BuySell/components/Margin';
import TransactionTypeDialog from '../BuySell/components/TransactionTypeDialog';
import MarginTemp from './components/MarginTemp';
import OrderCartStyle from '../../styles/Views/OrderCartStyle';

interface BuySellProps {
  navigation: any;
  route: any;
}

const notFuture = [
  {
    id: 'MARGIN',
    title: 'MARGIN',
    description: 'Buy & Sell Today',
  },
  {
    id: 'DELIVERY',
    title: 'DELIVERY',
    description: 'Hold Long Term',
  },
];

const BuySellTemp = ({navigation, route}: BuySellProps) => {
  const {item, tab} = route?.params;
  const [operation, setOperation] = useState<string>('BUY');
  const [selectedTab, setSelectedTab] = useState<string>(tab ? tab : 'MARGIN');
  const [transactionTypeVisible, setTransactionTypeVisible] = useState(false);
  const [transactionType, setTransactionType] = useState('Quantity');
  const {OrderEntryStyles} =OrderCartStyle();

  console.log(item);

  return (
    <View style={OrderEntryStyles.MainView}>
      <View style={OrderEntry.Top}>
        <View style={OrderEntryStyles.flex}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', true)}
            onPress={() => {
              navigation.goBack();
            }}>
            <View style={OrderEntryStyles.Close}>
              <CloseIcon style={OrderEntry.closeIcon} />
            </View>
          </TouchableNativeFeedback>

          <View style={OrderEntryStyles.Flex1}>
            <View style={OrderEntryStyles.Flex2}>
              <Text style={OrderEntry.stockName}>{item?.stockName}</Text>
              <View style={OrderEntry.nseView}>
                <Text style={OrderEntry.Nse}>NSE</Text>
                <View>
                  <Text style={OrderEntry.A}>A</Text>
                </View>
              </View>
              <Text style={OrderEntry.Asub}></Text>
            </View>
            <Text style={OrderEntry.price}>{item?.date?.day}</Text>
            <Text>
              <Text style={OrderEntry.price}>{item?.price}</Text>
              <Text
                style={[OrderEntryStyles.textChanges,{
                  color: item?.LTPTrend == 'color-positive' ? 'green' : 'red',
                }]}>
                {item?.changes}
              </Text>
            </Text>
          </View>

          <View>
            <View
              style={[OrderEntryStyles.SIP,{
                
                opacity: selectedTab == 'SIP_ORDER' ? 0.5 : 1,
              }]}>
              <View style={{borderRadius: 15, overflow: 'hidden'}}>
                <TouchableNativeFeedback
                  disabled={selectedTab == 'SIP_ORDER'}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    // navigation.goBack();
                    setOperation('BUY');
                  }}>
                  <View>
                    <Text
                      style={[OrderEntryStyles.BuyText,{
                        
                        backgroundColor:
                          operation == 'BUY'
                            ? root.color_positive
                            : 'transparent',
                       
                        color: operation == 'BUY' ? 'white' : root.color_text,
                      }]}>
                      BUY
                    </Text>
                  </View>
                </TouchableNativeFeedback>
              </View>

              <View
                style={OrderEntryStyles.View2}>
                <TouchableNativeFeedback
                  disabled={selectedTab == 'SIP_ORDER'}
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setOperation('SELL');
                    // navigation.goBack();
                  }}>
                  <View>
                    <Text
                      style={[OrderEntryStyles.SellText,{
                       
                        backgroundColor:
                          operation == 'SELL'
                            ? root.color_negative
                            : 'transparent',
                        color: operation == 'SELL' ? 'white' : root.color_text,
                      }]}>
                      SELL
                    </Text>
                  </View>
                </TouchableNativeFeedback>
              </View>
            </View>
          </View>
        </View>

        <View style={{flexDirection: 'row'}}>
          <View style={OrderEntry.BseView}>
            <View style={{minWidth: 91}}>
              <Text style={OrderEntry.BsePrice}>{item?.price}</Text>
              <Text style={OrderEntry.qty}>Qty -</Text>
            </View>
            <Text style={OrderEntry.Bse}>BSE</Text>
          </View>
          <View style={OrderEntry.Bsebox}>
            <View style={{minWidth: 91}}>
              <Text style={OrderEntry.BseBoxPrice}>{item?.price}</Text>
              <Text style={OrderEntry.qty}>Qty -</Text>
            </View>
            <Text style={OrderEntry.NSE}>NSE</Text>
          </View>
        </View>

        <View style={{flexDirection: 'row', marginTop: 7}}>
          <ScrollView
            horizontal={true}
            showsVerticalScrollIndicator={false}
            showsHorizontalScrollIndicator={false}>
            {notFuture.map(tab => {
              return (
                <View key={tab.id}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setSelectedTab(tab.id);
                    }}>
                    <View
                      style={OrderEntryStyles.TabView}>
                      <Text
                        style={{
                          color:
                            selectedTab == tab.id
                              ? root.client_background
                              : 'grey',
                          fontFamily: Cfont.rubik_medium,
                          fontSize: 13,
                        }}>
                        {tab.title}
                      </Text>
                      <Text
                        style={{
                          color:
                            selectedTab == tab.id ? root.color_text : 'grey',
                          fontFamily: Cfont.rubik_regular,
                          fontSize: 10,
                        }}>
                        {tab.description}
                      </Text>
                    </View>
                  </TouchableNativeFeedback>

                  <View
                    style={{
                      height: 2,
                      backgroundColor:
                        selectedTab == tab.id
                          ? root.client_background
                          : 'transparent',
                      borderRadius: 2,
                    }}
                  />
                </View>
              );
            })}
          </ScrollView>
        </View>
      </View>

      <MarginTemp
        operation={operation}
        item={item}
        transactionType={transactionType}
        setTransactionTypeVisible={setTransactionTypeVisible}
        selectedTab={notFuture.find(i => i.title == selectedTab)}
        onUpdate={route.params.onUpdate}
      />
      <TransactionTypeDialog
        visible={transactionTypeVisible}
        onClose={() => {
          setTransactionTypeVisible(false);
        }}
        onChange={(t: string) => {
          console.log(t);
          setTransactionType(t);
          setTransactionTypeVisible(false);
        }}
      />
    </View>
  );
};
export default React.memo(BuySellTemp);

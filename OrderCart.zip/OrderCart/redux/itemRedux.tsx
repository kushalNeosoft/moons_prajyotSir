export enum ItemAction {
  UPDATE_OPERATION = 'update_operation',
  UPDATE = 'update',
  UPDATE_TYPE = 'update_type',
}

interface ItemActionModel {
  payload: {
    operation?: string;
    type?: string;
    scripId: string;
  };
  type?: ItemAction;
}
export const itemReducer = (scrips: any, action: ItemActionModel) => {
  switch (action.type) {
    case ItemAction.UPDATE:
      return scrips.map((scrip: any) => {
        if (scrip.id === action.payload.scripId) {
          return {
            ...scrip,
            operation: action.payload.operation,
            type: action.payload.type,
          };
        } else {
          return scrip;
        }
      });
    case ItemAction.UPDATE_OPERATION:
      return scrips.map((scrip: any) => {
        if (scrip.id === action.payload.scripId) {
          return {
            ...scrip,
            operation: action.payload.operation,
          };
        } else {
          return scrip;
        }
      });
    case ItemAction.UPDATE_TYPE:
      return scrips.map((scrip: any) => {
        if (scrip.id === action.payload.scripId) {
          return {
            ...scrip,
            type: action.payload.type,
          };
        } else {
          return scrip;
        }
      });
  }
};

import * as React from 'react';
import {
  Text,
  TouchableOpacity,
  StyleSheet,
  Image,
  FlatList,
} from 'react-native';
import {assets} from '../../../assets';
import CommonModal from '../../../components/CommonModal/CommonModal';
import {DotModalStyle} from '../../../theme/light';
import {Cfont, font, root} from '../../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import {remodata, Reorderdata} from '../../../assets/demoData';
import {Delectwatchlistmodal} from '../../WatchList/WatchListComponent/ThreeDotDrawer/Delectwatchlistmodal';
import Done from '../../WatchList/Scrips/Removescrip/Done';
const DotModalOrder = (props: any) => {
  const [renameshow, setRenameshow] = React.useState(true);
  const [showdelete, setShowdelete] = React.useState(false);
  const [newone, setNewone] = React.useState(false);

  React.useEffect(() => {
    if (newone == true) {
      props.onClose();
      props.newDoneappear(newone);
      setTimeout(() => {
        setNewone(false);
      }, 2000);
    }
  }, [newone]);

  const navigation = useNavigation();
  const data = [
    {
      icon: assets.plus,
      label: 'Add Cart',
      onPress: (item: any) => {
        navigation.navigate('Addscrip', {
          watchlistname: props?.watchListname,
          watchlistdata: props?.stockDataList,
        });
      },
    },
    {
      icon: assets.minus,
      label: 'Remove Cart',
      onPress: (item: any) => {
        navigation.navigate('OrderCart', {
          item: remodata,
          stockdata: props?.stockDataList,
        });
      },
    },

    {
      icon: assets.pencil,
      label: 'Rename Cart',
      onPress: (item: any) => {
        props.onClose();
        props.callfun(renameshow);
      },
    },
    {
      icon: assets.delete,
      label: 'Delete Cart',
      onPress: (item: any) => {
        // console.log(item);
        // setShowdelete(true);
        props.onClose();
        props.delete();
      },
    },
  ];

  const onNorClose = () => {
    setShowdelete(prevState => !prevState);
    // setIsvisible(prevState => !prevState)
  };

  const renderView = (item: any) => {
    return (
      <TouchableOpacity
        style={DotModalStyle.dotmodalallign}
        onPress={() => item.onPress(item)}>
        <Image source={item.icon} style={DotModalStyle.imgsize} />
        {/* <Addsvg/> */}
        <Text style={DotModalStyle.dotmain}>{item.label}</Text>
      </TouchableOpacity>
    );
  };

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <TouchableOpacity onPress={props.onClose}>
        <Image source={assets.cross} style={DotModalStyle.image} />
      </TouchableOpacity>
      <FlatList data={data} renderItem={({item}) => renderView(item)} />
      <Delectwatchlistmodal
        visible={showdelete}
        onClose={onNorClose}
        showfun={(e: any) => {
          setNewone(e);
        }}
      />
    </CommonModal>
  );
};

export default DotModalOrder;

import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';
import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import {useEffect, useState} from 'react';
import React from 'react';
import {Cfont, root} from '../../../styles/colors';
import MarginPrice from '../../BuySell/components/MarginPrice';
import Limit from '../../BuySell/components/Limit';
import SLMarket from '../../BuySell/components/SLMarket';
import SLLimit from '../../BuySell/components/SLLimit';
import MarginConfirmPlaceOrderDialog from '../../BuySell/components/MarginConfirmPlaceOrderDialog';
import OrderSuccessDialog from '../../BuySell/components/OrderSuccessDialog';
import {useNavigation} from '@react-navigation/native';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const deliveryTypes = [
  {
    id: 'MARGIN_PRICE',
    title: 'Margin Price',
  },
  {
    id: 'LIMIT',
    title: 'Limit',
  },
  {
    id: 'SL_MARKET',
    title: 'SL Market',
  },
  {
    id: 'SL_LIMIT',
    title: 'SL Limit',
  },
];

const MarginTemp = ({
  operation,
  item,
  transactionType,
  setTransactionTypeVisible,
  selectedTab,
  onUpdate,
}: any) => {
  const [filled, setFilled] = useState(false);
  const [confirmOrderVisible, setConfirmOrderVisible] = useState(false);
  const [orderSuccessVisible, setOrderSuccessVisible] = useState(false);
  const [selectedDeliveryType, setSelectedDeliveryType] =
    useState<string>('MARGIN_PRICE');
  const navigation = useNavigation();

  const {marginTmpStyles} = OrderCartStyle();

  console.log('tab' + JSON.stringify(selectedTab));

  useEffect(() => {
    setFilled(false);
  }, [selectedDeliveryType]);

  return (
    <View style={marginTmpStyles.View}>
      <ScrollView style={marginTmpStyles.ScrollMain}>
        <View style={marginTmpStyles.MainView}>
          {deliveryTypes.map(type => {
            return (
              <View
                style={{
                  alignSelf: 'stretch',
                }}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setSelectedDeliveryType(type.id);
                  }}>
                  <Text
                    key={type.id}
                    style={[
                      marginTmpStyles.Type,
                      {
                        backgroundColor:
                          selectedDeliveryType == type.id
                            ? root.client_background
                            : 'transparent',
                        color:
                          selectedDeliveryType == type.id
                            ? 'white'
                            : root.client_background,
                      },
                    ]}>
                    {type.title}
                  </Text>
                </TouchableNativeFeedback>
              </View>
            );
          })}
        </View>
        <View style={{marginTop: 16}}>
          {selectedDeliveryType === 'MARGIN_PRICE' && (
            <MarginPrice
              item={item}
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
          {selectedDeliveryType === 'LIMIT' && <Limit setFilled={setFilled} />}
          {selectedDeliveryType === 'SL_MARKET' && (
            <SLMarket
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
          {selectedDeliveryType === 'SL_LIMIT' && (
            <SLLimit
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
        </View>
      </ScrollView>
      <View style={marginTmpStyles.View1}>
        <View style={marginTmpStyles.View2}>
          <Text style={marginTmpStyles.BrokrageTxt}>Brokerage and charges</Text>
          <ArrowForwardIcon style={marginTmpStyles.arrow} />
        </View>

        <TouchableNativeFeedback
          disabled={!filled}
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => {
            // setConfirmOrderVisible(true);
            navigation.goBack();
            onUpdate(operation, selectedTab.id);
          }}>
          <Text
            style={[
              marginTmpStyles.UpdateCart,
              {
                opacity: filled ? 1 : 0.5,
                backgroundColor:
                  operation == 'BUY' ? root.client_background : 'red',
              },
            ]}>
            Update Order Cart
          </Text>
        </TouchableNativeFeedback>
      </View>
      <MarginConfirmPlaceOrderDialog
        visible={confirmOrderVisible}
        onClose={() => {
          setConfirmOrderVisible(false);
        }}
        item={item}
        onConfirm={() => {
          setConfirmOrderVisible(false);
          setOrderSuccessVisible(true);
        }}
        selectedTab={selectedTab}
      />
      <OrderSuccessDialog
        visible={orderSuccessVisible}
        onClose={() => {
          setOrderSuccessVisible(false);
        }}
        item={item}
      />
    </View>
  );
};
export default MarginTemp;

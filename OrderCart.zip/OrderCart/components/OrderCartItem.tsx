import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {squareOffList} from '../../../theme/light';
import {Cfont, Font, root} from '../../../styles/colors';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const OrderCartItem = (props: any) => {
  // const [clicked, setClicked] = useState(false);

  const {OrderCartItemStyles} =OrderCartStyle();

  const clicked =
    props.selectedItems.findIndex((itm: any) => itm.id == props.item.id) != -1;
  return (
    <>
      <TouchableOpacity
        style={[OrderCartItemStyles.click,{
          backgroundColor:
            clicked === true ? 'rgba(47, 211, 47, 0.15)' : '#FFFFFF',
        }]}
        onPress={() => {
          props.onPress(props.item);
        }}>
        <View style={{}}>
          <View
            style={OrderCartItemStyles.View}>
            <Text
              style={OrderCartItemStyles.CompanyText}>
              {props.item.companyName}
            </Text>
            <View
              style={OrderCartItemStyles.ViewTitle}>
              <Text
                style={OrderCartItemStyles.TextTitke}>
                {props.item.titleChip}
              </Text>
            </View>
          </View>
          <View
            style={OrderCartItemStyles.viewItem}>
            <Text
              style={OrderCartItemStyles.Pricetext}>
              {props.item.price}
            </Text>
            <Text
              style={OrderCartItemStyles.TextPL}>
              {props.item.todaysPL}
            </Text>
          </View>
        </View>
        <View style={squareOffList(clicked).listPlLtpView}>
          {clicked === true ? (
            <AntDesign
              name="checksquare"
              style={squareOffList(clicked).selectAllIcon}
            />
          ) : (
            <MaterialIcons
              name="check-box-outline-blank"
              style={squareOffList(clicked).selectAllIcon}
            />
          )}
        </View>
      </TouchableOpacity>
    </>
    // </View>
  );
};
export default OrderCartItem;

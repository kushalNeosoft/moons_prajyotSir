import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Image,
  TouchableNativeFeedback,
  TouchableOpacity,
} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import {TextInput} from 'react-native';
import {Announce, NoMatch, messageSearchModal} from '../../../theme/light';
import BackIcon from '../../../assets/BackIcon';
import {Cfont, root} from '../../../styles/colors';
import DropDownIcon from '../../../assets/DropDownIcon';
import CloseIcon from '../../../assets/CloseIcon';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import FontSize from '../../../styles/Common/FontSize';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const OrderSuccessfulDialog = ({visible, onClose, scrips}: any) => {
  const navigation = useNavigation();


  const {OrderSuccessStyles} =OrderCartStyle();

  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={OrderSuccessStyles.Modal}
      // animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={() => {
        onClose();
      }}>
      <View style={OrderSuccessStyles.flex}>
        <View style={{}}>
          <TouchableOpacity
            style={messageSearchModal.crossIcon}
            onPress={() => {
              onClose();
            }}>
            <CloseIcon style={Announce.back} />
          </TouchableOpacity>
        </View>
        <View style={OrderSuccessStyles.flex2}>
          <View
            style={OrderSuccessStyles.View}>
            <AntDesign
              name="checkcircle"
              style={OrderSuccessStyles.Antdesign}
            />
            <Text
              style={OrderSuccessStyles.OrderText}>
              Order(s) Placed Successfully
            </Text>
            <View style={{marginTop: 16}}>
              {scrips.map((item: any, index: any) => {
                return (
                  <View>
                    <Text
                      style={OrderSuccessStyles.OrderID}>
                      Order ID: NWSYM000{index}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>
          <View style={{padding: 16}}>
            <TouchableOpacity
              onPress={() => {
                navigation.navigate('Positions');
                // onClose();
              }}>
              <Text
                style={OrderSuccessStyles.OrderStatus}>
                View Order Status
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default OrderSuccessfulDialog;

import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {squareOffList} from '../../../theme/light';
import {Cfont, Font, root} from '../../../styles/colors';
import {useNavigation} from '@react-navigation/native';
import {ItemAction} from '../redux/itemRedux';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const OrderCountItem = ({item, dispatch}: any) => {
  const [count, setCount] = useState(1);
  const navigation = useNavigation();
  // const [clicked, setClicked] = useState(false);


  const {OrderCountItemStyles} =OrderCartStyle();
  
  return (
    <View
      style={OrderCountItemStyles.MainView}>
      <View style={{}}>
        <View
          style={OrderCountItemStyles.ViewCompany}>
          <Text
            style={OrderCountItemStyles.CompanyText}>
            {item.companyName}
          </Text>
          <View
            style={OrderCountItemStyles.TitleView}>
            <Text
              style={OrderCountItemStyles.TextTitle}>
              {item.titleChip}
            </Text>
          </View>
        </View>
        <View
          style={OrderCountItemStyles.BuyView}>
          <Text
            style={{
              fontSize: Font.font_normal_one,
              fontFamily: Cfont.rubik_medium,

              color: item.operation === 'BUY' ? 'green' : 'red',
              // marginBottom: 5,
            }}>
            {item.operation === 'BUY' ? 'Buy' : 'Sell'}
          </Text>
          <Text
            style={OrderCountItemStyles.DelText}>
            {item.type === 'DELIVERY' ? 'Delivery' : 'INTRDY'} @ {item.market}
          </Text>
        </View>
      </View>
      <View style={{alignItems: 'flex-end'}}>
        <View style={{flexDirection: 'row', alignItems: 'center'}}>
          <TouchableOpacity
            onPress={() => {
              if (count > 0) setCount(prev => prev - 1);
            }}>
            <AntDesign
              name="minus"
              style={{
                color: root.color_text,
                fontSize: 16,
              }}
            />
          </TouchableOpacity>
          <View
            style={OrderCountItemStyles.countView}>
            <Text>{count}</Text>
          </View>
          <TouchableOpacity
            onPress={() => {
              setCount(prev => prev + 1);
            }}>
            <AntDesign
              name="plus"
              style={OrderCountItemStyles.AntDesign}
            />
          </TouchableOpacity>
        </View>
        <TouchableOpacity
          style={{marginTop: 4}}
          onPress={() => {
            navigation.navigate('BuySellTemp', {
              // scrips: selectedItems,
              tab: item.type == 'DELIVERY' ? 'DELIVERY' : 'MARGIN',
              item: {
                type: 'MARGIN_PRICE',
                price: 100,
              },
              onUpdate: (operation, type) => {
                console.log(operation);
                dispatch({
                  type: ItemAction.UPDATE,
                  payload: {
                    scripId: item.id,
                    operation: operation,
                    type: type == 'DELIVERY' ? 'DELIVERY' : 'INTRDY',
                  },
                });
              },
            });
          }}>
          <MaterialIcons
            name="edit"
            style={{
              color: root.color_text,
              fontSize: 16,
            }}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default OrderCountItem;

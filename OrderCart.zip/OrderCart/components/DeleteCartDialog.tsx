import {set} from 'immer/dist/internal';
import * as React from 'react';
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import Toast from 'react-native-toast-message';
import Entypo from 'react-native-vector-icons/Entypo';

import CommonModal from '../../../components/CommonModal/CommonModal';
import {Eventmodaistyle, Renamestyle} from '../../../theme/light';
import {Cfont, root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
// import OrderCartStyle from '../../../styles/Views/OrderCartStyle';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const DeleteCartDialog = (props: any) => {
 // const [rename, setRename] = React.useState(props?.changerename);
  const [show, setShow] = React.useState(false);
  const {DeleteCartStyles} =OrderCartStyle();




  const conditionalert = () => {
    Toast.show({
      type: 'tomatoToast',
      props: 'OrderCart Deleted Sucessfully',
      position: 'bottom',
    });
    props.confirm();
    props.onClose();
  };

  React.useEffect(() => {
    if (show == true) {
      setTimeout(() => {
        setShow(false);
      }, 2000);
    }
  }, [show]);

  return (
    <Modal
      // style={messageSearchModal.modal}
      animationType="fade"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        props.onClose();
      }}>
      <TouchableOpacity
        style={DeleteCartStyles.Onpress
        }
        onPress={() => props.onClose()}
        activeOpacity={1}>
        {props?.iconvisible ? (
          <AntDesign name="arrowleft" size={24} color={root.color_active} />
        ) : null}
      </TouchableOpacity>
      <View
        style={DeleteCartStyles.MainView}>
        <TouchableOpacity onPress={props.onClose} activeOpacity={1}>
          <View style={Eventmodaistyle.header}>
            <Entypo name="cross" size={24} color={root.color_text} />
          </View>

          <View style={DeleteCartStyles.Delete}>
            <Text style={Renamestyle.watchListText}>Delete {props.title}</Text>
          </View>
          
          <View style={DeleteCartStyles.View}>
            <Text
              style={DeleteCartStyles.SureDelete}>
              Are you sure you want to delete {props.title}?
            </Text>
          </View>
        </TouchableOpacity>
        <View style={DeleteCartStyles.View1} />
        <TouchableWithoutFeedback onPress={conditionalert}>
          <View
            style={DeleteCartStyles.Confirm}>
            <Text style={Renamestyle.txtstyle}>Confirm</Text>
          </View>
        </TouchableWithoutFeedback>
      </View>
    </Modal>
  );
};

export default DeleteCartDialog;

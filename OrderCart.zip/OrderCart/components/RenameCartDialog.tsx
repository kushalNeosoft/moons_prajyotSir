import {set} from 'immer/dist/internal';
import * as React from 'react';
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import Toast from 'react-native-toast-message';
import Entypo from 'react-native-vector-icons/Entypo';

import CommonModal from '../../../components/CommonModal/CommonModal';
import {Eventmodaistyle, Renamestyle} from '../../../theme/light';
import {root} from '../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const RenameCartDialog = (props: any) => {
  console.log(props.changerename);

  const [rename, setRename] = React.useState(props?.changerename);
  const [show, setShow] = React.useState(false);
  const {RenameCartStyles} =OrderCartStyle();

  const conditionalert = () => {
    if (props?.changerename === rename) {
      setShow(true);
    } else {
      Toast.show({
        type: 'tomatoToast',
        props: 'Order Cart rename sucessfully',
        position: 'bottom',
      });
      props.renamefun(rename);
      props.onClose();
    }
  };

  React.useEffect(() => {
    if (show == true) {
      setTimeout(() => {
        setShow(false);
      }, 2000);
    }
  }, [show]);

  return (
    <Modal
      // style={messageSearchModal.modal}
      animationType="fade"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        // props.onClose();
      }}>
      <TouchableOpacity
        style={RenameCartStyles.View}
        onPress={() => props.onClose()}
        activeOpacity={1}>
        {props?.iconvisible ? (
          <AntDesign name="arrowleft" size={24} color={root.color_active} />
        ) : null}
      </TouchableOpacity>
      <View
        style={RenameCartStyles.View2}>
        <TouchableOpacity onPress={props.onClose} activeOpacity={1} style={{}}>
          <View style={RenameCartStyles.ReanmeText}>
            <Text style={Renamestyle.watchListText}>
              Rename Your Order Cart
            </Text>
          </View>
          <TextInput
            style={RenameCartStyles.InputBox}
            onChangeText={setRename}
            defaultValue={props.changerename}
          />
        </TouchableOpacity>

        <TouchableWithoutFeedback onPress={conditionalert}>
          <View
            style={RenameCartStyles.RenameView}>
            <Text style={Renamestyle.txtstyle}>Rename</Text>
          </View>
        </TouchableWithoutFeedback>
        {show == true ? (
          <>
            <View style={Renamestyle.customcontaioner}>
              <Text style={Renamestyle.customtxt}>
                Look like this watchlist already exists. Try using different
                name.
              </Text>
            </View>
          </>
        ) : null}
      </View>
    </Modal>
  );
};

export default RenameCartDialog;

import {set} from 'immer/dist/internal';
import * as React from 'react';
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import Toast from 'react-native-toast-message';
import Entypo from 'react-native-vector-icons/Entypo';

import CommonModal from '../../../components/CommonModal/CommonModal';
import {Eventmodaistyle, Renamestyle} from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {root} from '../../../styles/colors';
import OrderCartStyle from '../../../styles/Views/OrderCartStyle';

const NameCartDialog = (props: any) => {
  const [name, setName] = React.useState<string>('');
  const {RenameCartStyles} =OrderCartStyle();

  const conditionalert = () => {
    if (name === '') {
    } else {
      Toast.show({
        type: 'tomatoToast',
        props: 'Order Cart Named sucessfully',
        position: 'bottom',
      });
      props.namefun(name);
      props.onClose();
    }
  };

  return (
    <Modal
      // style={messageSearchModal.modal}
      animationType="fade"
      transparent={true}
      visible={props.visible}
      onRequestClose={() => {
        // props.onClose();
      }}>
      <View
        style={RenameCartStyles.View}></View>
      <View
        style={RenameCartStyles.View2}>
        <View style={{}}>
          <View style={RenameCartStyles.ReanmeText}>
            <Text style={Renamestyle.watchListText}>Name Your Order Cart</Text>
          </View>
          <TextInput
            style={RenameCartStyles.InputBox}
            onChangeText={setName}
            value={name}
          />
        </View>

        <TouchableWithoutFeedback onPress={conditionalert}>
          <View
            style={RenameCartStyles.RenameView}>
            <Text style={Renamestyle.txtstyle}>Save</Text>
          </View>
        </TouchableWithoutFeedback>
      </View>
    </Modal>
  );
};

export default NameCartDialog;

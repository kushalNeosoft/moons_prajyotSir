// import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import {Cfont, Font, root} from '../../styles/colors';
import ShopCartIcon from '../../assets/ShopCartIcon';

import React, {useEffect, useReducer, useState} from 'react';
import EditIcon from '../../assets/EditIcon';
import moment from 'moment';
import OrderCartStyle from '../../styles/Views/OrderCartStyle';

const CreateNewOrder = ({route}: any) => {
  const navigation = useNavigation();
  const {NewOrderStyles} = OrderCartStyle();
  //const {scrips} = route.params ();

  //const [scripS, dispatch] = useReducer(itemReducer, scrips);


  const data = [
    {
      ordercartId: 1,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
    {
      ordercartId: 2,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
    {
      ordercartId: 3,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
    {
      ordercartId: 4,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
    {
      ordercartId: 5,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
    {
      ordercartId: 6,
      ordercartName: 'TESTABC',
      modifiedAt: new Date(),
    },
  ];
  return (
    <View
      style={NewOrderStyles.main}>
      <View style={squareOff.subContainer}>
        <View
          style={NewOrderStyles.MainView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="close" style={squareOff.backIcon} />
          </TouchableOpacity>
          <Text
            style={NewOrderStyles.OrdercartText}>
            {'Order Cart'}
          </Text>
          <ShopCartIcon style={NewOrderStyles.ShopCartIcon} />
        </View>
        <FlatList
          data={data}
          renderItem={({item}: any) => {
            return (
              <View
                style={NewOrderStyles.FlatListmain}>
                <View>
                  <Text style={NewOrderStyles.CartNameText}>
                    {item.ordercartName}
                  </Text>
                  <Text style={NewOrderStyles.TotalScrip}>Total Scrip: 9</Text>
                </View>
                <View>
                  <View
                    style={NewOrderStyles.PlaceOrderView}>
                    <Text
                      style={NewOrderStyles.PlaceOrderText}>
                      Place Order
                    </Text>
                    <TouchableOpacity
                onPress={() => {
                  navigation.navigate('OrderCart');
                }}>
                    <EditIcon style={NewOrderStyles.EditIcon} />

                    </TouchableOpacity>
                  </View>
                  <Text style={NewOrderStyles.date}>
                    Modified At: {moment(item.modifiedAt).format('DD/MM/yyyy')}
                  </Text>
                </View>
              </View>
            );
          }}
          contentContainerStyle={{
            paddingBottom: 70,
          }}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <TouchableOpacity
        style={NewOrderStyles.CreateNewOrderView}
        onPress={() => {
          navigation.navigate('OrderCart');
        }}>
        <Text
          style={NewOrderStyles.CreateNewOrderText}>
          Create New Order Cart
        </Text>
      </TouchableOpacity>
    </View>
  );
};
export default CreateNewOrder;

// import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, FlatList} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {styles} from '../../navigators/Curverbottom';
import {squareOff} from '../../theme/light';
import {useNavigation} from '@react-navigation/native';
import SquareOffModal from '../SquareOff/Component/SquareOffModal';
import SquareOffList from '../SquareOff/Component/SquareOffList';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import ShopCartIcon from '../../assets/ShopCartIcon';
import OrderCartItem from './components/OrderCartItem';
import OrderCountItem from './components/OrderCountItem';
import Entypo from 'react-native-vector-icons/Entypo';
import DotModal from '../WatchList/WatchListComponent/ThreeDotDrawer/ThreeDotDrawer';
// import SquareOffList from './Component/SquareOffList';
// import SquareOffModal from './Component/SquareOffModal';
import Addscript from '../WatchList/Scrips/Addscript/Addscript';
import DotModalOrder from './components/DotModalOrder';

import React, {useEffect, useReducer, useState} from 'react';
import {itemReducer} from './redux/itemRedux';
import Renamemodal from './components/RenameCartDialog';
import DeleteCartDialog from './components/DeleteCartDialog';
import RenameCartDialog from './components/RenameCartDialog';
import NameCartDialog from './components/NameCartDialog';
import OrderCartStyle from '../../styles/Views/OrderCartStyle';

const PlaceOrder = ({route}: any) => {
  const {scrips} = route.params;

  console.log(scrips);

  const navigation = useNavigation();
  const [dotModalVisible, setDotModalVisible] = useState(false);
  const [renamemodal, setRenamemodal] = useState(false);
  const [deleteCartDialog, setDeleteCartDialog] = useState(false);
  const [rename, setRename] = useState('');
  const [namemodal, setNamemodal] = useState(true);
  const {PlaceOrderStyles} = OrderCartStyle();
  const onDotModalClose = () => {
    setDotModalVisible(prevState => !prevState);
  };
  const [scripS, dispatch] = useReducer(itemReducer, scrips);
  const onRenameClose = () => {
    setRenamemodal(prevState => !prevState);
  };

  return (
    <View style={squareOff.container}>
      <View style={squareOff.subContainer}>
        <View style={squareOff.squareHeaderView}>
          <TouchableOpacity
            onPress={() => {
              navigation.goBack();
            }}>
            <AntDesign name="close" style={squareOff.backIcon} />
          </TouchableOpacity>
        </View>

        <View
          style={PlaceOrderStyles.flex}>
          <Text
            style={PlaceOrderStyles.Rename}>
            {rename ? rename : 'Order Card'}
          </Text>
          <ShopCartIcon style={PlaceOrderStyles.ShopCartIcon} />
        </View>

        <View
          style={PlaceOrderStyles.View1}>
          <View style={PlaceOrderStyles.flex1}>
            <Text
              style={PlaceOrderStyles.ScripText}>
              {scrips.length + ' Scrips'}
            </Text>

            <View
              style={PlaceOrderStyles.ViewAdd}>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate('Addscrip', {newlist: scrips.length});
                }}>
                <Text style={PlaceOrderStyles.AddText}>Add Scrips</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity onPress={() => setDotModalVisible(true)}>
            <Entypo
              name="dots-three-vertical"
              color={root.color_text}
              size={20}
            />
          </TouchableOpacity>
        </View>
        <View style={squareOff.headerBorder}></View>
        {/* FlateList code */}
        <FlatList
          data={scripS}
          renderItem={({item}) => {
            return <OrderCountItem item={item} dispatch={dispatch} />;
          }}
          contentContainerStyle={PlaceOrderStyles.Containt}
          keyExtractor={(_, index) => `item-${index}`}
        />
      </View>
      <View style={squareOff.bottomView}>
        <View style={squareOff.bottominnerView}>
          <View>
            <Text style={squareOff.bottomSquareOffText}>Approx. Amount</Text>
            <View
              style={PlaceOrderStyles.flex2}>
              <Text style={squareOff.bottomSelectedText}>1312</Text>
            </View>
          </View>
          <TouchableOpacity
            style={PlaceOrderStyles.ConfirmText}
            onPress={() => {
              console.log('print');

              if (rename)
                navigation.navigate('ComfirmOrder', {
                  scrips,
                });
              else {
                setRenamemodal(true);
              }
            }}>
            <Text
              style={PlaceOrderStyles.SaveText}>
              Save & Place Order
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <DotModalOrder
        visible={dotModalVisible}
        onClose={onDotModalClose}
        stockDataList={scrips}
        //onopenbottomsheet={onPress}
        watchListname={rename}
        callfun={(e: any) => {
          setRenamemodal(e);
        }}
        delete={() => {
          setDeleteCartDialog(true);
        }}
        // newDoneappear={(e: any) => {
        //   setNewdone(e);
      />
       <NameCartDialog
        visible={namemodal}
        onClose={() => {
          setNamemodal(false);
        }}
        namefun={(e: any) => {
          setRename(e);
        }}
      />
      <RenameCartDialog
        visible={renamemodal}
        onClose={onRenameClose}
        changerename={rename}
        renamefun={(e: any) => {
          setRename(e);
        }}
      />
      <DeleteCartDialog
        visible={deleteCartDialog}
        onClose={() => {
          setDeleteCartDialog(false);
        }}
        title={rename}
        confirm={() => {
          navigation.navigate('CreateNewOrder');
        }}
        // changerename={rename}
        // renamefun={(e: any) => {
        //   setRename(e);
        // }}
      />
    </View>
  );
};
export default PlaceOrder;

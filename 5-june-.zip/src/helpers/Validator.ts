export default class Validator {
  static genericValidator(email: any): boolean {
    if (!email) {
      return false;
    }
    return true;
  }
  static phoneValidator(email: any): boolean {
    if (!email) {
      return false;
    }
    const phoneRegex =
      /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/;
    if (!phoneRegex.test(email)) {
      return false;
    }
    return true;
  }
  static emailValidator(email: any): boolean {
    if (!email) {
      return false;
    }
    const emailRegex =
      /^[-!#$%&'*+\/0-9=?A-Z^_a-z{|}~](\.?[-!#$%&'*+\/0-9=?A-Z^_a-z`{|}~])*@[a-zA-Z0-9](-*\.?[a-zA-Z0-9])*\.[a-zA-Z](-?[a-zA-Z0-9])+$/;
    if (!emailRegex.test(email)) {
      return false;
    }
    return true;
  }
  static passwordValidator(password: any): boolean {
    if (!password) {
      return false;
    }
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
    if (!passwordRegex.test(password)) {
      return false;
    }
    return true;
  }
}

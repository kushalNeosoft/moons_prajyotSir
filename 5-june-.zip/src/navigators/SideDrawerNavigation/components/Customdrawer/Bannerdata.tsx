export const BannerData =
        [{
                title: 'Title Slide1', url: 'https://i.ytimg.com/vi/A7fZp9dwELo/maxresdefault.jpg',
                description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
                id: 1

        },
        {
                title: 'Title slide 2', url: 'https://cdn.educba.com/academy/wp-content/uploads/2016/07/Stock-Market-Trading.jpg.webp',
                description: "Lorem Ipsum is simply dummy text of the printing and typesetting industry.",
                id: 2
        },
        ]

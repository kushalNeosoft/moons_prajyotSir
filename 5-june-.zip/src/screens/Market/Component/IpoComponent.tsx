import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity, Alert} from 'react-native';
import {Font, root, Cfont} from '../../../styles/colors';
import {ipoComp} from '../../../theme/light';

const IPOComponent = props => {
  return (
    <TouchableOpacity
      style={ipoComp.container}
      onPress={() => {
        Alert.alert('Under Development');
      }}>
      <View style={ipoComp.innerView}>
        <View style={ipoComp.titleAndImgView}>
          <View style={ipoComp.imageView}>
            <Text style={ipoComp.imageText}>LI</Text>
          </View>
          <Text style={ipoComp.title}>{props.title}</Text>
        </View>
        <Text style={ipoComp.subTitle}>ONGOING</Text>
        <Text style={ipoComp.pricerRange}>{props.range}</Text>
        <Text style={ipoComp.issueDate}>Issue Date</Text>
        <Text style={ipoComp.date}>{props.date}</Text>
        <View style={ipoComp.minQtyAndAmmountView}>
          <View>
            <Text style={ipoComp.minQty}>Min. Qty</Text>
            <Text style={ipoComp.qty}>{props.minQty}</Text>
          </View>
          <View>
            <Text style={ipoComp.minAmount}>Min. Amount</Text>
            <Text style={ipoComp.amount}>{props.minAmount}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};
export default IPOComponent;

import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {BuySellBtn} from '../../../../theme/light';

const BuySellButton = props => {
  return (
    <TouchableOpacity
      style={{...BuySellBtn.conatiner(props.title), ...props.style}}
      onPress={props.onPress}>
      <Text style={BuySellBtn.btnText}>{props.title}</Text>
    </TouchableOpacity>
  );
};
export default BuySellButton;

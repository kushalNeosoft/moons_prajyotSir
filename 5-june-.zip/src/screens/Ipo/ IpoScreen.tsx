import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';

const IpoScreen = props => {
  return (
    <View style={styles.conatiner}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => {
            props.navigation.goBack();
          }}
          style={styles.backBotton}>
          <AntDesign name="arrowleft" size={26} color="black" />
        </TouchableOpacity>
        <Text style={styles.headerTitile}>IPO is Incoming!!</Text>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  conatiner: {},
  header: {
    width: '100%',
    height: 50,
    backgroundColor: 'white',
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitile: {
    color: 'black',
    fontSize: 18,
    fontWeight: '600',
    marginLeft: 10,
  },
  backBotton: {
    marginHorizontal: 17,
  },
});
export default IpoScreen;

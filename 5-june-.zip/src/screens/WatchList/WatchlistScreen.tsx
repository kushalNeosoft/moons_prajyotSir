import React, { useEffect, useState, useCallback, useRef, useContext, Suspense, useMemo, lazy } from 'react';
import { Alert, BackHandler, Image, LogBox } from 'react-native';
import { View, Text, FlatList, TouchableOpacity, Dimensions } from 'react-native';




// import DotModal from '../../components/Component/DotModal/DotModal';
// import Header from '../../components/Component/Header/Header';
// // import NorModal from '../../Component/NorModal/NorModal';
// import NorModal from '../../components/Component/NorModal/NorModal';
// // import TrendModal from '../../Component/TrendModal/TrendModal';
// import TrendModal from '../../components/Component/TrendModal/TrendModal';
// import { colors } from '../../constants/colors';
// import { texts } from '../../constants/text';
// import { GestureHandlerRootView } from 'react-native-gesture-handler';
// // import { assets } from '../../assets';
// // import alignment from '../../utils/alignment';
// import { styles } from './StockDetailsStyle';

// import DeleteModal from '../../components/Component/DeleteModal/DeleteModal';
// // import BottomSheet, { BottomSheetRefProps } from '../../Component/BottomSheet/BottomSheet';
// import BottomSheet from '../../components/BottomSheet/BottomSheet';
// import { CommonActions, useFocusEffect, useNavigation } from '@react-navigation/native';
// // import CarouselList from '../../Component/CarouselList/CarouselList';
// import CarouselList from '../../components/Component/CarouselList/CarouselList';
// // import { ListItemProps } from '../../Component/CarouselList/type';
// import { ListItemProps } from '../../components/Component/CarouselList/type';
// import RNExitApp from 'react-native-exit-app';



// const screenHeight = Dimensions.get('window').height;
// interface StockListProps {
//   navigation: any;
// }

LogBox.ignoreAllLogs();




const StockLazy = lazy(() => import('./WatchListComponent/WatchListLazy'));

const WatchlistScreen = () => {

    const stolazyrender =useMemo(()=>{
        return <StockLazy/>
    },[]);
    return (
        <View style={{flex: 1}}>

            <Suspense fallback={<Text>Loading</Text>}>
                {stolazyrender}
                {/* <StockLazy /> */}
            </Suspense>
            {/* <ActivityIndicator size="large" color="#00ff00" />  */}
        </View>


    )
}

export default React.memo(WatchlistScreen);





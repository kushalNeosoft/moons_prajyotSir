import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  Image,
  FlatList,
  TouchableHighlight,
  Dimensions,
} from 'react-native';
import {ScrollView} from 'react-native-gesture-handler';
import {assets} from '../../../../assets';
// import { assets } from '../../../../components/replacement-svg';
// import {colors} from '../../constants/colors';
// import {texts} from '../../constants/text';
import alignment from '../../../../components/utils/alignment';
import CommonModal from '../../../../components/CommonModal/CommonModal';
import Feather from 'react-native-vector-icons/Feather';
import Entypo from 'react-native-vector-icons/Entypo';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {texts} from '../CommonText/text';
import {Cfont, root, Font} from '../../../../styles/colors';
import {NormodalStyle} from '../../../../theme/light';

const NorModal = (props: any) => {
  const [checked, setChecked] = useState(0);
  console.log(props, '===>Isvisble');

  const data = [
    'NOR',
    'GOLDM',
    'CURRENCY',
    'ONE SCRIPT',
    'TT',
    'Default',
    'NOR',
    'GOLDM',
    'CURRENCY',
    'ONE SCRIPT',
    'TT',
    'Default',
  ];

  useEffect(() => {}, [checked]);

  return (
    <CommonModal visible={props.visible} onClose={props.onClose}>
      <View style={NormodalStyle.Normain}>
        <View style={NormodalStyle.Normaininner}>
          <Text style={NormodalStyle.watchListText}>
            {texts.SELECT_WATCHLIST}
          </Text>
          {/* <TouchableOpacity style={NormodalStyle.btntxtx}>
            <Text style={NormodalStyle.txtstyle}>Equity & Others</Text>
          </TouchableOpacity> */}
        </View>
        <View style={NormodalStyle.closestyle}>
          <TouchableOpacity onPress={props.onClose}>
            <Entypo name="cross" size={29} color={'black'} />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={NormodalStyle.NorMaxheight}>
        {data.map((data, key) => (
          <View key={key} style={NormodalStyle.NorBanner}>
            {checked == key ? (
              <View style={NormodalStyle.btn}>
                <TouchableOpacity
                  style={{
                    ...alignment.row,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image
                    style={NormodalStyle.img}
                    source={assets.radio_checked}
                  />
                  <Text style={NormodalStyle.norModtxt}>{data}</Text>
                </TouchableOpacity>
                {props.isvisible == true && (
                  <View style={NormodalStyle.binheart}>
                    <FontAwesome5 name="trash" size={20} color={'black'} />
                    <AntDesign name="heart" size={20} color={'red'} />
                  </View>
                )}
              </View>
            ) : (
              <View style={NormodalStyle.btn}>
                <TouchableOpacity
                  onPress={() => setChecked(key)}
                  style={NormodalStyle.norbannertwo}>
                  <Image
                    style={NormodalStyle.img}
                    source={assets.radio_unchecked}
                  />
                  <Text style={NormodalStyle.norModdis}>{data}</Text>
                </TouchableOpacity>
                {props.isvisible==true&&(
                  <View style={NormodalStyle.binheart}>
                  <TouchableOpacity onPress={() => props.showDeleteModal()}>
                    <FontAwesome5 name="trash" size={20} color={'black'} />
                  </TouchableOpacity>
                  <AntDesign name="hearto" size={20} color={'black'} />
                </View>

                )}
                
              </View>
            )}
          </View>
        ))}
      </ScrollView>
      <TouchableOpacity style={NormodalStyle.footallign}>
        <Feather name="plus" size={25} color={'black'} />
        <Text style={NormodalStyle.createWatchListText}>
          {texts.CREATE_WATCHLIST} (6/10)
        </Text>
      </TouchableOpacity>
    </CommonModal>
  );
};

export default NorModal;

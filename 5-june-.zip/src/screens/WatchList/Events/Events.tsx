import React, {useState} from 'react';
import {FlatList, GestureResponderEvent, TouchableOpacity} from 'react-native';
import {ScrollView, Text, View} from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import {eventdata, Newsdata} from '../../../assets/demoData';
import {root} from '../../../styles/colors';
import {Eventstylecom} from '../../../theme/light';
import {DateModal, NewsModal} from './EventsComponent/EventsModal';

const Events: React.FC = ({route}: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [selectedItem, setSelectedItem] = useState(0);
  const [datemodalvisible, setDatemodalvisibl] = useState(false);
  const [newsmodalvisible, setNewsmodalvisibl] = useState(false);

  const [datainfo, setDatainfo] = useState([]);
  const [newsinfo, setNewsinfo] = useState([]);

  const [day, setDay] = useState();
  const [year, setYear] = useState();
  const [name, setName] = useState('Board Meeting');

  const onDotModalClose = () => {
    setDatemodalvisibl(prevState => !prevState);
  };
  const onNewsModalClose = () => {
    setNewsmodalvisibl(prevState => !prevState);
  };

  const dateDetailopen = (item: any) => {
    console.log(item, 'setting data main==>');
    setDatainfo(item);
    setDatemodalvisibl(true);
    setDay(item.day);
    setYear(item.year);
  };

  const renderItem = ({item, index}: any) => (
    <TouchableOpacity
      onPress={() => {
        setSelectedItem(index);
        setName(item.title);
      }}>
      {selectedItem === index ? (
        <>
          <View style={Eventstylecom.menuitem}>
            <Text style={Eventstylecom.titletxt}>{item.title}</Text>
          </View>
        </>
      ) : (
        <>
          <View style={Eventstylecom.menuitemtwo}>
            <Text style={Eventstylecom.titletxttwo}>{item.title}</Text>
          </View>
        </>
      )}
    </TouchableOpacity>
  );

  const renderItemtwo = ({item, index}: any) => (
    <TouchableOpacity
      activeOpacity={1}
      onPress={() => {
        setNewsmodalvisibl(true);
        setNewsinfo(item);
      }}>
      <View style={Eventstylecom.Newcontainer}>
        <View>
          <Text style={Eventstylecom.headlinetxt}>{item.headLine}</Text>
          <Text style={Eventstylecom.bottomLine}>{item.bottomline}</Text>
        </View>
        <View style={{flexDirection: 'row'}}>
          <Text style={Eventstylecom.newdate}>{item.newsdate}</Text>
          <Text style={Eventstylecom.newdate}>{item.time}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
  return (
    <ScrollView
      style={Eventstylecom.mainconatiner}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Eventstylecom.innerconatiner} key={1}>
        <View style={Eventstylecom.innertwo}>
          <Text style={Eventstylecom.cortxt}>News & Announcements</Text>
        </View>
      </View>
      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}
        style={Eventstylecom.shadow}>
        <FlatList
          style={{paddingLeft: 16}}
          data={Newsdata}
          renderItem={renderItemtwo}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>

      <View style={Eventstylecom.innerconatiner} key={1}>
        <View style={Eventstylecom.innertwo}>
          <Text style={Eventstylecom.cortxt}>Corporate Action</Text>
        </View>
      </View>

      <ScrollView
        horizontal
        key={2}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <FlatList
          style={{paddingLeft: 16}}
          data={eventdata}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal
          nestedScrollEnabled
          showsHorizontalScrollIndicator={false}
        />
      </ScrollView>
      <ScrollView
        horizontal
        key={3}
        nestedScrollEnabled
        showsHorizontalScrollIndicator={false}>
        <View style={Eventstylecom.oneflex}>
          {eventdata.map((events, i) => {
            if (selectedItem == i) {
              return (
                <FlatList
                  showsHorizontalScrollIndicator={false}
                  data={events.data.date}
                  style={{paddingLeft: 17}}
                  horizontal
                  nestedScrollEnabled
                  renderItem={({item, index}) => {
                    return (
                      <>
                        <View style={Eventstylecom.dateconatiner}>
                          <View style={Eventstylecom.dateconatinerinner}>
                            {item?.Final == 'Final' ? (
                              <Text
                                style={[
                                  Eventstylecom.txtdate,
                                  {marginBottom: 15},
                                ]}>
                                {item.percentage}
                              </Text>
                            ) : item?.Recorded_Date == 'Recorded Date' ? (
                              <>
                                <Text
                                  style={[
                                    Eventstylecom.txtdate,
                                    {marginBottom: 15},
                                  ]}>
                                  Tender Offer
                                </Text>
                              </>
                            ) : (
                              <>
                                <Text style={Eventstylecom.txtdate}>
                                  {item.day}
                                </Text>
                                <Text style={Eventstylecom.txtdatetwo}>
                                  {item.year}
                                </Text>
                              </>
                            )}
                          </View>
                          <View>
                            {item?.Final == 'Final' ? (
                              <>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Final}
                                </Text>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Fdate}
                                </Text>
                              </>
                            ) : item?.Recorded_Date == 'Recorded Date' ? (
                              <>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Recorded_Date}
                                </Text>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Recorded_Date_value}
                                </Text>
                              </>
                            ) : (
                              <>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Gm}
                                </Text>
                                <Text style={Eventstylecom.gmstyle}>
                                  {item.Gmvalue}
                                </Text>
                              </>
                            )}
                          </View>
                          <TouchableOpacity
                            onPress={() => dateDetailopen(item)}
                            activeOpacity={1}>
                            <View style={Eventstylecom.iconallign}>
                              <Feather
                                name="arrow-right-circle"
                                size={24}
                                color={root.color_text}
                              />
                            </View>
                          </TouchableOpacity>
                        </View>
                      </>
                    );
                  }}
                />
              );
            }
          })}
        </View>
      </ScrollView>
      <DateModal
        visible={datemodalvisible}
        onClose={onDotModalClose}
        day={day}
        year={year}
        name={name}
        datainfo={datainfo}
      />
      <NewsModal
        visible={newsmodalvisible}
        onClose={onNewsModalClose}
        newsinfo={newsinfo}
      />
      <View style={Eventstylecom.emptyview} />
    </ScrollView>
  );
};

export default Events;

import React, {useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  TouchableHighlight,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import alignment from '../../../components/utils/alignment';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {Cfont, Font, root} from '../../../styles/colors';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {radioSelected, radioUnSelected} from './components/RadioButton/Radio';
import FundsModal from './components/Modal/Modal';
import ChooseBankModal from './components/Modal/ChooseBankModal';
import UpiModal from './components/Modal/UpiModal';

function AddFunds(props: any) {
  const [amount, setAmount] = useState(props?.route?.params?.amount);
  const [paymentMethod, setPaymentMethod] = useState('Net Banking');
  const [showFundsModal, setShowFundsModal] = useState(false);
  const [account, setAccount] = useState<string>('TEST123');
  const [methods, setMethods] = useState(2);
  const [modalAccountName, setModalAccountName] = useState('HDFC DIRECT');
  const [bankModalVisible, setBankModalVisible] = useState(false);
  const [upiModalVisible, setUpiModalVisible] = useState(false);

  const money = ['10,000', '50,000', '1,00,000'];

  const setBankAccount = (value: string) => {
    setModalAccountName(value);
  };

  const upiModalClose = () => {
    setUpiModalVisible(prevState => !prevState);
  };

  const data = [
    {nmapping: 0, name: 'TEST123'},
    {nmapping: 0, name: 'BSE EQUITIES'},
    {nmapping: 0, name: 'NSE DERIVATIVE'},
    {nmapping: 1, name: 'NSE EQUITIES'},
  ];

  const banks = ['HDFC DIRECT', 'ATOMPG-HDFC Bank'];

  const closeModal = () => {
    setShowFundsModal(prevState => !prevState);
  };

  const setCurrentAccount = (value: string) => {
    setAccount(value);
  };

  const renderPaymentData = (account: string) => {
    switch (account) {
      case 'TEST123':
        return [{method: 'Net Banking'}];
      case 'BSE EQUITIES':
        return [{method: 'Net Banking'}];
      case 'NSE DERIVATIVE':
        return [{method: 'Net Banking'}];
      case 'NSE EQUITIES':
        return [{method: 'UPI Apps'}, {method: 'Net Banking'}];
    }
  };

  const closeBankModal = () => {
    setBankModalVisible(prevState => !prevState);
  };

  const renderPaymentsMethods = ({item}: any) => {
    return (
      <TouchableOpacity
        onPress={() => setPaymentMethod(item.method)}
        activeOpacity={1}
        style={
          paymentMethod === item.method
            ? addFunds.paymentCardSelected
            : addFunds.paymentCardUnselected
        }>
        {paymentMethod === item.method ? radioSelected() : radioUnSelected()}
        <Text
          style={
            paymentMethod === item.method
              ? addFunds.paymentTypeTxtSelected
              : addFunds.paymentTypeTxtUnselected
          }
          numberOfLines={2}>
          {item.method}
        </Text>
      </TouchableOpacity>
    );
  };

  const checkPaymentMethod=()=>{
    if(paymentMethod==='UPI Apps'){
     return setUpiModalVisible(prevState=>!prevState)
    }else{
      return console.log('Hello')
    }
  }

  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={addFunds.container}>
        <View style={addFunds.header}>
          <Ionicons name="arrow-back" size={24} color={'black'} />
          <TouchableOpacity
            style={addFunds.name}
            onPress={() => setShowFundsModal(prevState => !prevState)}>
            <Text style={addFunds.title}>{account}</Text>
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={addFunds.caretDown}
            />
          </TouchableOpacity>
        </View>
        <View style={addFunds.amountContainer}>
          <View style={addFunds.addFundsTxtContainer}>
            <Text style={addFunds.addFundsTxt}>Add</Text>
            <Text style={addFunds.addFundsTxt}>Funds</Text>
          </View>
          <View style={addFunds.enterAmountContainer}>
            <View style={addFunds.txtIpContainer}>
              <FontAwesome name="rupee" size={30} color={'black'} />
              <TextInput
                keyboardType="numeric"
                placeholder="0"
                style={addFunds.txtIp}
                value={amount}
                onChangeText={amount => setAmount(amount)}
              />
            </View>
          </View>
        </View>
        <View style={addFunds.addMoneyContainer}>
          {money.map(item => (
            <View style={{marginTop: 5}}>
              <TouchableHighlight
                onPress={() => setAmount(item)}
                underlayColor={'grey'}
                activeOpacity={1}>
                <Text style={addFunds.constMoneyTxt}>{`₹ ${item}`}</Text>
              </TouchableHighlight>
            </View>
          ))}
        </View>
        <View style={addFunds.linkedAccountContainer}>
          <Text style={addFunds.linkedAccountsTxt}>Linked Accounts</Text>
          <Text style={addFunds.linkedAccounts}>HDFC</Text>
        </View>
        <View style={addFunds.paymentGatewayContainer}>
          <Text style={addFunds.linkedAccountsTxt}>Payment Gateway</Text>
          {methods === 2 &&
          paymentMethod === 'Net Banking' &&
          account === 'NSE EQUITIES' ? (
            <TouchableOpacity
              style={addFunds.changeBank}
              activeOpacity={1}
              onPress={() => setBankModalVisible(prevState => !prevState)}>
              <Text style={addFunds.linkedAccounts}>{modalAccountName}</Text>
              <AntDesign
                name="caretdown"
                size={10}
                color={'black'}
                style={addFunds.caretDown}
              />
            </TouchableOpacity>
          ) : (
            <Text style={addFunds.linkedAccounts}>HDFC</Text>
          )}
        </View>
        <FlatList
          style={addFunds.paymentContainer}
          data={renderPaymentData(account)}
          renderItem={renderPaymentsMethods}
          horizontal={true}
        />
        <TouchableOpacity
          style={addFunds.addFundsBtn}
          activeOpacity={1}
          onPress={checkPaymentMethod}
          disabled={amount === '' || amount === undefined}>
          <Text
            style={
              amount === '' || amount === undefined
                ? addFunds.addFundsBtnTxtDisabled
                : addFunds.addFundsBtnTxt
            }>
            Add Funds
          </Text>
        </TouchableOpacity>
        <FundsModal
          onClose={closeModal}
          visible={showFundsModal}
          data={data}
          setCurrentAccount={setCurrentAccount}
          account={account}
        />
        <ChooseBankModal
          onClose={closeBankModal}
          visible={bankModalVisible}
          data={banks}
          setBankAccount={setBankAccount}
          modalAccountName={modalAccountName}
        />
        <UpiModal onClose={upiModalClose} visible={upiModalVisible} />
      </View>
    </TouchableWithoutFeedback>
  );
}

const addFunds = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  header: {
    ...alignment.row,
    alignItems: 'center',
    paddingVertical: '4%',
  },
  name: {
    ...alignment.row,
    alignItems: 'center',
    paddingLeft: 15,
  },
  caretDown: {
    paddingLeft: 10,
  },
  title: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_two,
  },
  amountContainer: {
    ...alignment.row_SpaceB,
    alignItems: 'flex-end',
    paddingTop: '7%',
  },
  addFundsTxtContainer: {
    width: '40%',
    alignItems: 'flex-start',
  },
  enterAmountContainer: {
    width: '50%',
  },
  addFundsTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_title,
  },
  txtIpContainer: {
    borderBottomWidth: 1,
    ...alignment.row,
    alignItems: 'center',
  },
  txtIp: {
    flexGrow: 1,
    fontSize: Font.font_title,
    fontFamily: Cfont.rubik_medium,
  },
  addMoneyContainer: {
    width: '50%',
    alignSelf: 'flex-end',
    ...alignment.row_SpaceB,
  },
  constMoneyTxt: {
    fontSize: Font.font_normal_eight,
    color: root.color_text,
    fontFamily: Cfont.rubik_regular,
    borderWidth: 0.3,
    alignSelf: 'flex-start',
    borderRadius: 20,
    paddingHorizontal: 5,
    paddingVertical: 1,
  },
  linkedAccountContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '7%',
  },
  linkedAccounts: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_six,
    paddingLeft: '6%',
  },
  linkedAccountsTxt: {
    fontFamily: Cfont.rubik_light,
    fontSize: Font.font_normal_six,
    color: root.color_text,
  },
  paymentGatewayContainer: {
    ...alignment.row,
    alignItems: 'center',
    paddingTop: '9%',
  },
  addFundsBtn: {
    height: 40,
    backgroundColor: root.client_background,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  addFundsBtnTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  addFundsBtnTxt: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  paymentCardUnselected: {
    height: 112,
    width: 112,
    marginRight: 18,
    padding: 12,
    backgroundColor: root.color_active,
    borderRadius: 10,
    elevation: 1,
  },
  paymentCardSelected: {
    height: 112,
    width: 112,
    marginRight: 18,
    padding: 12,
    backgroundColor: root.client_background,
    borderRadius: 10,
    elevation: 1,
  },
  paymentTypeTxtUnselected: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    height: '100%',
    paddingTop: 3,
  },
  paymentTypeTxtSelected: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_active,
    fontSize: Font.font_normal_four,
    height: '100%',
    paddingTop: 3,
  },
  unSelectedRadioDark: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerUnSelectedRadioDark: {
    height: 11,
    width: 11,
    borderRadius: 5.5,
    borderColor: root.color_text,
    backgroundColor: root.color_text,
  },
  selectedRadioLight: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerSelectedRadioLight: {
    height: 11,
    width: 11,
    borderRadius: 5.5,
    borderColor: root.color_text,
    backgroundColor: root.color_text,
  },
  paymentContainer: {
    paddingTop: '9%',
  },
  changeBank: {
    ...alignment.row,
    alignItems: 'center',
  },
});

export default AddFunds;

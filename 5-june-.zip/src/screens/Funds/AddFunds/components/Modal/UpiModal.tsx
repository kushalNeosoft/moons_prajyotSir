import React from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';

const UpiModal = (props: any) => {
  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={styles.modalView}>
        <View style={styles.headerView}>
          <Text style={styles.accountsTxt}>Enter UPI ID</Text>
          <AntDesign name="close" size={24} color={'black'} />
        </View>
        <TextInput placeholder="" style={styles.txtIp} />
        <TouchableOpacity style={styles.proceedBtn}>
          <Text style={styles.proceedTxtEnabled}>Proceed</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: '25%',
    justifyContent: 'space-between',
    width:'100%'
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  headerView: {
    ...alignment.row_SpaceB,
  },
  accountsTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  proceedBtn: {
    height: 40,
    backgroundColor: root.client_background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  proceedTxtDisabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    opacity: 0.3,
  },
  proceedTxtEnabled: {
    color: root.color_active,
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
  },
  txtIp: {
    borderWidth: 0.5,
    borderRadius: 10,
    // marginTop: '6%',
  },
});

export default UpiModal;

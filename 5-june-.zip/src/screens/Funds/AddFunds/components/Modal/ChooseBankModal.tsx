import React, {useState} from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {RadioButton} from 'react-native-paper';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';

const ChooseBankModal = (props: any) => {
  const [bank, setBank] = useState<string>(props.modalAccountName);

  const setBankAndClose = (value: string) => {
    props.setBankAccount(value);
    setBank(value);
    props.onClose();
  };

  const renderBanks = ({item}: any) => {
    return (
      <TouchableOpacity
        style={styles.accountsContainer}
        onPress={() => setBankAndClose(item)}>
        <View style={styles.selectAccount}>
          <RadioButton
            color={root.color_text}
            value={item}
            onPress={() => setBankAndClose(item)}
            status={bank == item ? 'checked' : 'unchecked'}
          />
          <Text style={styles.name}>{item}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      transparent={true}
      onRequestClose={() => props.onClose()}
      visible={props.visible}>
      <TouchableOpacity
        style={styles.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={styles.modalView}>
      <View style={styles.headerView}>
          <Text style={styles.accountsTxt}>Mapped Banks</Text>
          <AntDesign name="close" size={24} color={'black'} />
        </View>
        <FlatList
          data={props.data}
          renderItem={renderBanks}
          style={styles.accountList}
          showsVerticalScrollIndicator={false}
          scrollEnabled={false}
        />
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalView: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
    height: '25%',
  },
  centeredView: {
    flex: 1,
    backgroundColor: 'rgba(52, 52, 52, 0.8)',
    position: 'relative',
  },
  headerView: {
    ...alignment.row_SpaceB,
  },
  accountList: {
    marginTop: 24,
  },

  accountsTxt: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_title,
    color: root.color_text,
  },
  accountsContainer: {
    ...alignment.row_SpaceB,
    height: 48,
    alignItems: 'center',
  },
  selectAccount: {
    ...alignment.row,
    alignItems: 'center',
  },
  name: {
    fontFamily: Cfont.rubik_medium,
    fontSize: Font.font_normal_three,
    color: root.color_text,
  },
});

export default ChooseBankModal;

module.exports = {
    project: {
        ios:{},
        android:{}
    },
    assets:['../scr/assets/fonts/'],
}
import React from 'react';
import {useSelector} from 'react-redux';
const Theme = () => {
  const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const root = {
    color_primary: '#fffffff',
    color_active: colorMode === 'light' ? '#FFFFFF' : '#1f1f1f',
    color_active_botten: '#FFFFFF',
    client_background: colorMode === 'light' ? '#25335c' : '#2f4ca2',
    ipo_btn_backgrougd: '#f6f6f6',
    color_text: colorMode === 'light' ? '#303030' : '#FFFFFF',
    color_subtext: '#979797',
    color_active_text: '#ffffff',
    color_signup_rap_background: '#1f1f1f',
    signup_wrap_subtitle: '#999999',
    color_textual: colorMode === 'light' ? '#25335C' : '#7797f7',
    ion_rb_2: '#000000',
    color_border: '#ebebeb',
    backgroung_exchange_chip_color: '#9797971A',
    color_disable: '#ffffff',
    choose_indices_background: '#1E1E1E',
    dropdown_background: 'rgba(151,151,151,0.1)',
    chip_primary: '#9AB3FF33',
    color_positive_step_100: '#3DB943',
    color_positive_step_50: '#408E41',
    color_chipFilter: '#F5F7FA',
    color_orderPreference_bg: '#FAFAFA',
    color_border_bg: '#ebebeb',
    indices_red: '#FE0000',
    calendar_bg: '#F5F7FA',
    color_positive: '#4caf50',
    color_positive_rgb: 'rgba(76,175,80,0.15)',
    color_negative: '#d32f2f',
    color_negative_rgb: 'rgba(211,47,47,0.15)',
    chip_background_positive_cotrast: '#4CAF5026',
    //New added
    color_black: colorMode === 'light' ? '#1f1f1f' : '#FFFFFF',
    color_dark_black: colorMode === 'light' ? '#FFFFFF' : '#000',
    color_textual_tab: colorMode === 'light' ? '#25335C' : '#FFFFFF',
    color_text_icon:
      colorMode === 'light' ? '#303030' : 'rgba(255,255,255,0.8)',
    color_watchlist_chip:
      colorMode === 'light'
        ? '#rgba(151,151,151,0.1)'
        : 'rgba(235,235,235,0.16)',
    Bottom_tab_icon: '#979797',
    Bottom_tab_icon_focused: colorMode === 'light' ? '#25335c' : '#FFFFFF',
    Bottom_tab_search:
      colorMode === 'light' ? '#FFFFFF' : 'rgba(255,255,255,0.8)',
    Bottom_tab_text: colorMode === 'light' ? '#25335c' : '#FFFFFF',
    Bottom_tab_bg: colorMode === 'light' ? '#FFFFFF' : 'rgba(235,235,235,0.16)',
  };

  return {root};
};

export default Theme;

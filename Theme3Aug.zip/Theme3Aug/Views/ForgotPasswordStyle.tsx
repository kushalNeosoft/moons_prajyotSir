import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function ForgotPasswordStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const ForgotPasswordStyles = StyleSheet.create({
    container: {
      flex: 1,
      flexDirection: 'column',
      padding: 16,
      backgroundColor: root.color_active,
    },
    heading: {
      fontSize: font.size_30,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    Sendotp: {
      marginTop: 16,
      fontSize: font.size_14,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    user: {
      fontSize: font.size_18,
      marginTop: 32,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },

    userId: {
      paddingVertical: 17,
      fontFamily: font_Family.medium,
      color: root.color_text,
      fontSize: font.size_13,
    },
    email: {
      paddingVertical: 17,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    mobile: {
      paddingVertical: 18,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    om: {
      paddingVertical: 17,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    moons: {
      paddingVertical: 17,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },

    99: {
      paddingVertical: 18,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 22,
      color: root.color_text_icon,
    },
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 11,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active_botten,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      alignSelf: 'center',
    },
  });
  return {ForgotPasswordStyles};
}

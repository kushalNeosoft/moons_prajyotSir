import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
import alignment from '../../components/utils/alignment';
const height = Dimensions.get('window').height;

export default function ConstituentsListComponentStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const constituentsListComponent = StyleSheet.create({
    container: {
      // borderBottomColor: 'grey',
      paddingHorizontal: 16,
      backgroundColor: 'yellow',

      // paddingVertical: 3,
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    future: {
      fontSize: font.size_13,
      fontFamily: font_Family.regular,
      color: root.color_text,
      marginLeft: 2,
    },
    stockName: {
      color: root.color_text,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      top: -2,
    },
    bottonView: {
      borderColor: root.color_text,
      borderWidth: 1.5,
      width: 26,
      height: 26,
      borderRadius: 26 / 2,
      marginHorizontal: 5,
      ...alignment.alignC_justifyC,
    },
    nseTxt: {
      fontSize: font.size_9,
      // marginTop: 3,
      marginLeft: 5,
      backgroundColor: root.color_watchlist_chip,
      marginBottom: 9,
      paddingHorizontal: 3,
      color: root.color_subtext,
      borderRadius: 1,
      // borderColor: '#979797',
      // borderWidth: 0.1,
      fontFamily: font_Family.medium,
    },
    volGainerTxt: {
      marginLeft: 3,
      fontSize: font.size_10,
      borderRadius: 10,
      paddingHorizontal: 5,
      top: -3,
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_positive,
      backgroundColor: '#4caf5026',
      fontFamily: font_Family.medium,
    },
    prLoserTxt: {
      marginLeft: 3,
      fontSize: font.size_10,
      borderRadius: 10,
      paddingHorizontal: 5,
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_negative,
      backgroundColor: '#d32f2f26',
      fontFamily: font_Family.medium,
    },
    defaultTxt: {
      marginLeft: 3,
      fontSize: font.size_12,
      borderRadius: 10,
      paddingHorizontal: 5,
      fontWeight: 'bold',
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_active,
    },
    changes: {
      color: root.color_positive,
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
    },
    rightValuesView_200_300: {
      alignItems: 'flex-end',
      width: '100%',
      height: '100%',
      // marginRight: 15,
      backgroundColor: root.color_positive_rgb,
    },
    rightValuesView_300_500: {
      alignItems: 'flex-end',
      width: '100%',
      height: '100%',

      // width: 120,
      // marginRight: 15,
      backgroundColor: root.color_negative_rgb,
    },
    rightValuesDefault: {
      alignItems: 'flex-end',
      width: '100%',
      height: '100%',

      // width: 120,
      // marginRight: 15,
      backgroundColor: root.color_active,
    },
    currentPriceTxt: {
      color: root.color_text,
      fontSize: font.size_14,
      fontFamily: font_Family.medium,
    },
  });
  return {constituentsListComponent};
}

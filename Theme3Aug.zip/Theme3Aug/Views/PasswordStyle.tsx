import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PasswordStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PasswordStyles = StyleSheet.create({
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    buttonText: {
      color: root.color_active,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      alignSelf: 'center',
    },

    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_subtext,
      borderWidth: 0.5,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      color: root.color_text,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
    },
    inputIcon: {
      width: 24,
      color: root.color_subtext,
      margin: 12,
    },
    takeme: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    watchList: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
      paddingVertical: 4,
    },
    dropdownIcon: {
      height: 22,
      width: 24,
      color: root.color_text,
    },
    forgotPassword: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
    },
  });

  return {PasswordStyles};
}

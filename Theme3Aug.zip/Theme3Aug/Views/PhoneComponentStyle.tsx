import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function PhoneComponentStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const PhoneComponentStyles = StyleSheet.create({
    heading: {
      fontSize: font.size_30,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 32,
      color: root.color_text_icon,
    },
    buttonContainer: {
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 8,
      paddingHorizontal: 16,
      flexDirection: 'row',
    },
    buttonText: {
      // color: root.color_active,
      fontSize: font.size_16,
      // alignSelf: 'center',
    },
    buttonImage: {
      color: root.color_active,
      width: 24,
      marginLeft: 16,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_subtext,
      borderWidth: 0.8,
      color: root.color_text,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
      color: root.color_text,
    },
    tryitnowText: {
      color: root.color_text,
      fontSize: font.size_14,
      marginTop: 14,
      fontFamily: font_Family.medium,
    },
    alreadyRegisterText: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    clickHereText: {
      color: root.color_textual,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
    },
    havenotregisterText: {
      fontSize: font.size_12,
      color: root.color_text,
      fontFamily: font_Family.light,
    },
    loginText: {
      color: root.color_textual,
      fontFamily: font_Family.medium,
      fontSize: font.size_12,
    },
  });

  return {PhoneComponentStyles};
}

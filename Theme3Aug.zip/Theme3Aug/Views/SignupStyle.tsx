import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function SignupStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const SignupStyles = StyleSheet.create({
    scrollContainer: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    container: {
      //   flexGrow: 1,
      //   flex: 1,
      // height: height,
      //   backgroundColor: root.color_active,
      padding: 16,
    },
    block1ButtonContainer: {
      flexDirection: 'row',
      marginTop: 7,
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    buttonContainer: {
      flexDirection: 'row',
      backgroundColor: root.client_background,
      borderRadius: 8,
      paddingVertical: 9,
      paddingHorizontal: 18,
    },
    buttonText: {
      color: root.color_active_botten,
      fontSize: font.size_16,
      alignSelf: 'center',
    },
    buttonImage: {
      color: root.color_active,
      width: 24,
      marginLeft: 22,
    },
    heading: {
      fontSize: font.size_30,
      fontFamily: font_Family.medium,
      color: root.color_text,
    },
    inputContainer: {
      flexDirection: 'row',
      borderColor: root.color_subtext,
      borderWidth: 0.5,
      borderRadius: 8,
    },
    input: {
      margin: 0,
      flex: 1,
      paddingVertical: 8,
      paddingHorizontal: 16,
      color: root.color_text,
    },
    backIcon: {
      width: 32,
      height: 25,
      color: root.color_text_icon,
      fontFamily: font_Family.medium,
    },
  });
  return {SignupStyles};
}

import {forNoAnimation} from '@react-navigation/stack/lib/typescript/src/TransitionConfigs/HeaderStyleInterpolators';
import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import globalStyleClass from '../../theme/globalStyleClass';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;
const screenWidth = Dimensions.get('window').width;

export default function WatchlistdataStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const watchlistdata = StyleSheet.create({
    stock: {
      height: 60,
      flex: 1.5,
      borderBottomWidth: 1,
      borderBottomColor: '#E0E0E0',
      flexDirection: 'row',
      paddingHorizontal: 16,
      paddingTop: 2,
      backgroundColor: 'white',
    },
    stockcomp: {
      flex: 4,
      height: 36,
    },
    Nsetxt: {
      marginLeft: '3%',
      marginTop: '3%',
      height: '50%',
      width: '13%',
      backgroundColor: root.backgroung_exchange_chip_color,
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 2,
    },
    index: {
      color: root.color_subtext,
      fontSize: font.size_9,
      fontFamily: font_Family.medium,
    },
    Atxt: {
      marginLeft: '2%',
      fontSize: font.size_10,
      color: root.color_text,
      fontFamily: font_Family.medium,
      // marginTop: 3,
    },
    nertxt: {
      flexDirection: 'row',
      alignItems: 'center',
      width: '55%',
      justifyContent: 'space-between',
    },
    valtxt: {
      fontSize: font.size_10,
      color: root.client_background,
      marginLeft: '4%',
    },
    plustxt: {
      color: root.color_positive,
      fontWeight: '300',
      fontSize: font.size_10,
    },
    minustxt: {
      color: root.color_negative,
      fontWeight: '300',
      fontSize: font.size_10,
    },
    volGainerTxt: {
      marginLeft: 3,
      fontSize: 10,
      fontFamily: font_Family.medium,
      borderRadius: 10,
      paddingHorizontal: 5,
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_positive,
      backgroundColor: root.color_positive_rgb,
    },
    prLoserTxt: {
      marginLeft: 3,
      fontSize: font.size_10,
      fontFamily: font_Family.medium,
      borderRadius: 10,
      paddingHorizontal: 5,
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_negative,
      backgroundColor: root.color_negative_rgb,
    },
    defaultTxt: {
      marginLeft: 3,
      fontSize: font.size_12,
      fontFamily: font_Family.medium,
      borderRadius: 10,
      paddingHorizontal: 5,
      fontWeight: 'bold',
      alignSelf: 'center',
      justifyContent: 'center',
      color: root.color_active,
    },
    stockContainerPositive: {
      alignItems: 'flex-end',
      // justifyContent: 'center',
      // backgroundColor: '#e6ffe6',
    },
    stockContainerNegative: {
      alignItems: 'flex-end',
      // backgroundColor: '#ffe6e6',
    },
    stockPriceText: {
      fontFamily: font_Family.medium,
      color: root.color_text,
      fontSize: font.size_16,
    },
    endcom: {
      flex: 0.85,
      alignItems: 'center',
      paddingTop: 5,
      paddingLeft: '1%',
    },
    endT: {
      borderWidth: 1.5,
      height: 26,
      width: 26,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'white',
    },
    endTtext: {
      fontWeight: 'bold',
      color: 'black',
    },
    perchantxt: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
    },
    stocktxt: {
      color: root.color_text,
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
    },
    felxrow: {
      flexDirection: 'row',
    },
    flatallign: {
      // height: '85%',
      // height:screenHeight*0.95,
      flex: 0.92,
      backgroundColor: 'white',
    },
    secondinner: {
      height: screenWidth * 0.117,
      flexDirection: 'row',
      alignItems: 'center',
    },
    flexallign: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    fittrtxt: {
      left: 0,
      backgroundColor: 'white',
      height: 20,
      paddingHorizontal: 10,
      fontFamily: font_Family.regular,
      fontSize: font.size_14,
    },
  });

  return {watchlistdata};
}

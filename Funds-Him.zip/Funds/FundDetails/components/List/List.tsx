import React from 'react';
import {View, Text, StyleSheet} from 'react-native';
import { fundList } from '../../../../../theme/light';
const List = (props: any) => {
  const renderItem = item => {
    let Texts = [];
    if (item.indicator === props.keyword) {
      if (
        props.keyword === 'Funds Transferred Today' ||
        props.keyword === 'Funds Withdrawal/Allocation'
      ) {
        return (
          <View style={fundList.detailsContainer}>
            <Text style={fundList.singleIndicatorTxt}>{item.indicator}</Text>
            <Text style={fundList.singleIndicatorValue}>{item.value}</Text>
          </View>
        );
      } else {
        Texts.push(
          <View style={fundList.detailsContainer}>
            <Text style={fundList.titleTxt}>{item.title}</Text>
            <Text style={fundList.valueTxt}>{item.value}</Text>
          </View>,
        );
      }
    }
    return Texts;
  };

  return (
    <>
      {props.data.map((item: any) => (
        <>{renderItem(item)}</>
      ))}
    </>
  );
};


export default List;

import React from 'react';
import {
  View,
  Text,
  Modal,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { upiModal } from '../../../../../theme/light';

const UpiModal = (props: any) => {
  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={upiModal.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={upiModal.modalView}>
        <View style={upiModal.headerView}>
          <Text style={upiModal.accountsTxt}>Enter UPI ID</Text>
          <AntDesign name="close" size={24} color={'black'} />
        </View>
        <TextInput placeholder="" style={upiModal.txtIp} />
        <TouchableOpacity style={upiModal.proceedBtn}>
          <Text style={upiModal.proceedTxtEnabled}>Proceed</Text>
        </TouchableOpacity>
      </View>
    </Modal>
  );
};

export default UpiModal;

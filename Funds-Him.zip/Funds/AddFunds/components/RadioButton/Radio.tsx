import React from 'react';
import {StyleSheet, View} from 'react-native';
import {root} from '../../../../../styles/colors';

export const radioUnSelected = () => {
  return <View style={styles.outerUnSelected}></View>
};

export const radioSelected = () => {
  return (
    <View style={styles.outerSelected}>
      <View style={styles.innerSelected} />
    </View>
  );
};

const styles = StyleSheet.create({
  outerUnSelected: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_text,
    alignItems: 'center',
    justifyContent: 'center',
  },
  outerSelected: {
    height: 20,
    width: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: root.color_active,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerSelected: {
    height: 11,
    width: 11,
    borderRadius: 5.5,
    backgroundColor: root.color_active,
  },
});

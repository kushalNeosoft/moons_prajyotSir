import React, {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  TouchableHighlight,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {radioSelected, radioUnSelected} from './components/RadioButton/Radio';
import FundsModal from './components/Modal/Modal';
import ChooseBankModal from './components/Modal/ChooseBankModal';
import UpiModal from './components/Modal/UpiModal';
import {addFunds} from '../../../theme/light';
import {useNavigation} from '@react-navigation/native';

function AddFunds(props: any) {
  const [amount, setAmount] = useState(props?.route?.params?.amount);
  const [paymentMethod, setPaymentMethod] = useState('Net Banking');
  const [showFundsModal, setShowFundsModal] = useState(false);
  const [account, setAccount] = useState<string>(
    props?.route.params?.fundName ? props.route.params.fundName : 'TEST123',
  );
  const [methods, setMethods] = useState(2);
  const [modalAccountName, setModalAccountName] = useState('HDFC DIRECT');
  const [bankModalVisible, setBankModalVisible] = useState(false);
  const [upiModalVisible, setUpiModalVisible] = useState(false);
  const navigation = useNavigation();

  const money = ['10,000', '50,000', '1,00,000'];

  const setBankAccount = (value: string) => {
    setModalAccountName(value);
  };

  const upiModalClose = () => {
    setUpiModalVisible(prevState => !prevState);
  };

  const data = [
    {nmapping: 0, name: 'TEST123', available: 10000},
    {nmapping: 0, name: 'BSE EQUITIES', available: 10000},
    {nmapping: 0, name: 'NSE DERIVATIVE', available: 10000},
    {nmapping: 1, name: 'NSE EQUITIES', available: 10000},
  ];

  const banks = ['HDFC DIRECT', 'ATOMPG-HDFC Bank'];

  const closeModal = () => {
    setShowFundsModal(prevState => !prevState);
  };

  const setCurrentAccount = (value: string) => {
    setAccount(value);
  };

  const renderPaymentData = (account: string) => {
    switch (account) {
      case 'TEST123':
        return [{method: 'Net Banking'}];
      case 'BSE EQUITIES':
        return [{method: 'Net Banking'}];
      case 'NSE DERIVATIVE':
        return [{method: 'Net Banking'}];
      case 'NSE EQUITIES':
        return [{method: 'UPI Apps'}, {method: 'Net Banking'}];
    }
  };

  const closeBankModal = () => {
    setBankModalVisible(prevState => !prevState);
  };

  const renderPaymentsMethods = ({item}: any) => {
    return (
      <TouchableOpacity
        onPress={() => setPaymentMethod(item.method)}
        activeOpacity={1}
        style={
          paymentMethod === item.method
            ? addFunds.paymentCardSelected
            : addFunds.paymentCardUnselected
        }>
        {paymentMethod === item.method ? radioSelected() : radioUnSelected()}
        <Text
          style={
            paymentMethod === item.method
              ? addFunds.paymentTypeTxtSelected
              : addFunds.paymentTypeTxtUnselected
          }
          numberOfLines={2}>
          {item.method}
        </Text>
      </TouchableOpacity>
    );
  };

  const checkPaymentMethod = () => {
    if (paymentMethod === 'UPI Apps') {
      return setUpiModalVisible(prevState => !prevState);
    } else {
      return console.log('Hello');
    }
  };

  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={addFunds.container}>
        <View style={addFunds.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={24} color={'black'} />
          </TouchableOpacity>
          <TouchableOpacity
            style={addFunds.name}
            onPress={() => setShowFundsModal(prevState => !prevState)}>
            <Text style={addFunds.title}>{account}</Text>
            <AntDesign
              name="caretdown"
              size={10}
              color={'black'}
              style={addFunds.caretDown}
            />
          </TouchableOpacity>
        </View>
        <View style={addFunds.amountContainer}>
          <View style={addFunds.addFundsTxtContainer}>
            <Text style={addFunds.addFundsTxt}>Add</Text>
            <Text style={addFunds.addFundsTxt}>Funds</Text>
          </View>
          <View style={addFunds.enterAmountContainer}>
            <View style={addFunds.txtIpContainer}>
              <FontAwesome name="rupee" size={30} color={'black'} />
              <TextInput
                keyboardType="numeric"
                placeholder="0"
                style={addFunds.txtIp}
                value={amount}
                onChangeText={amount => setAmount(amount)}
              />
            </View>
          </View>
        </View>
        <View style={addFunds.addMoneyContainer}>
          {money.map(item => (
            <View style={{marginTop: 5}}>
              <TouchableHighlight
                onPress={() => setAmount(item)}
                underlayColor={'grey'}
                activeOpacity={1}>
                <Text style={addFunds.constMoneyTxt}>{`₹ ${item}`}</Text>
              </TouchableHighlight>
            </View>
          ))}
        </View>
        <View style={addFunds.linkedAccountContainer}>
          <Text style={addFunds.linkedAccountsTxt}>Linked Accounts</Text>
          <Text style={addFunds.linkedAccounts}>HDFC</Text>
        </View>
        <View style={addFunds.paymentGatewayContainer}>
          <Text style={addFunds.linkedAccountsTxt}>Payment Gateway</Text>
          {methods === 2 &&
          paymentMethod === 'Net Banking' &&
          account === 'NSE EQUITIES' ? (
            <TouchableOpacity
              style={addFunds.changeBank}
              activeOpacity={1}
              onPress={() => setBankModalVisible(prevState => !prevState)}>
              <Text style={addFunds.linkedAccounts}>{modalAccountName}</Text>
              <AntDesign
                name="caretdown"
                size={10}
                color={'black'}
                style={addFunds.caretDown}
              />
            </TouchableOpacity>
          ) : (
            <Text style={addFunds.linkedAccounts}>HDFC</Text>
          )}
        </View>
        <FlatList
          style={addFunds.paymentContainer}
          data={renderPaymentData(account)}
          renderItem={renderPaymentsMethods}
          horizontal={true}
        />
        <TouchableOpacity
          style={addFunds.addFundsBtn}
          activeOpacity={1}
          onPress={checkPaymentMethod}
          disabled={amount === '' || amount === undefined}>
          <Text
            style={
              amount === '' || amount === undefined
                ? addFunds.addFundsBtnTxtDisabled
                : addFunds.addFundsBtnTxt
            }>
            Add Funds
          </Text>
        </TouchableOpacity>
        <FundsModal
          onClose={closeModal}
          visible={showFundsModal}
          data={data}
          setCurrentAccount={setCurrentAccount}
          account={account}
        />
        <ChooseBankModal
          onClose={closeBankModal}
          visible={bankModalVisible}
          data={banks}
          setBankAccount={setBankAccount}
          modalAccountName={modalAccountName}
        />
        <UpiModal onClose={upiModalClose} visible={upiModalVisible} />
      </View>
    </TouchableWithoutFeedback>
  );
}

export default AddFunds;

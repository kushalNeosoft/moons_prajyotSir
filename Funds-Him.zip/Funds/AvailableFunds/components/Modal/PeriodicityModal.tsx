import React from 'react';
import {View, Text, Modal, StyleSheet, TouchableOpacity} from 'react-native';
import alignment from '../../../../../components/utils/alignment';
import {Cfont, Font, root} from '../../../../../styles/colors';
import Entypo from 'react-native-vector-icons/Entypo';
import {RadioButton} from 'react-native-paper';
import { periodicityModal } from '../../../../../theme/light';

const PeriodicityModal = (props: any) => {
  return (
    <Modal
      transparent={true}
      onRequestClose={() => props.onClose()}
      visible={props.visible}>
      <TouchableOpacity
        style={periodicityModal.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}></TouchableOpacity>
      <View style={periodicityModal.modalContainer}>
        <View style={periodicityModal.header}>
          <Text style={periodicityModal.titleTxt}>Periodicities</Text>
          <Entypo name="cross" size={24} color={'black'} />
        </View>
        <View style={periodicityModal.item}>
          <RadioButton color={root.color_text} status={'checked'} value={''} />
          <Text style={periodicityModal.itemTxt}>All Exchnage Combined</Text>
        </View>
      </View>
    </Modal>
  );
};

export default PeriodicityModal;

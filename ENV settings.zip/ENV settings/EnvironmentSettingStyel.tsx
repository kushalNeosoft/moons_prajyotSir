import React from 'react';
import {Dimensions, StyleSheet} from 'react-native';
import {useSelector} from 'react-redux';
import Theme from '../../theme/Theme';
import FontSize from '../Common/FontSize';
import {font_Family} from '../Common/FontFamily';
const height = Dimensions.get('window').height;

export default function EnvironmentSettingStyle() {
  // const colorMode = useSelector(state => state?.Reducer?.colorMode);
  const fontSize = useSelector(state => state?.Reducer?.fontSize);
  const {root} = Theme();
  const {font} = FontSize(fontSize);
  const EnvironmentSettingStyles = StyleSheet.create({
    conatainer: {
      flex: 1,
      backgroundColor: root.color_active,
    },
    headText: {
      color: root.color_text,
      fontSize: font.size_18,
      fontFamily: font_Family.medium,
      marginLeft: 40,
      marginTop: 10,
      marginBottom: 28,
    },
    title: {
      fontSize: font.size_12,
      fontFamily: font_Family.regular,
      marginTop: 7,
      marginLeft: 18,
    },
    textInput: {
      fontSize: 16,
      marginLeft: 18,
      paddingTop: 0,
      paddingBottom: 3,
      color: root.color_text,
    },
    line: {
      width: '100%',
    },
    botton: {
      borderColor: root.color_textual,
      borderRadius: 25,
      borderWidth: 1,
      alignSelf: 'flex-start',
      marginTop: 17,
      marginLeft: 30,
    },
    bottonText: {
      fontSize: font.size_16,
      fontFamily: font_Family.medium,
      color: root.color_textual,
      padding: 3,
      paddingHorizontal: 10,
    },
    detailsBox: {
      borderColor: root.color_text,
      borderWidth: 1,
      marginTop: 10,
      paddingTop: 4,
    },
    detailsText: {
      fontSize: font.size_16,
      fontFamily: font_Family.regular,
      color: root.color_text,
      paddingHorizontal: 6,
    },
    detailsTextPadding: {
      fontSize: font.size_16,
      fontFamily: font_Family.regular,
      color: root.color_text,
      paddingHorizontal: 6,
      paddingVertical: 3,
    },
    border: {
      backgroundColor: root.color_text,
      height: 1.3,
    },
    borderCrossView: {
      borderRightColor: root.color_text,
      borderRightWidth: 2,
      paddingBottom: 0,
      paddingTop: 0,
      flex: 0.5,
    },
  });

  return {EnvironmentSettingStyles};
}

import React, {useState} from 'react';
import {
  SafeAreaView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import EnvironmentSettingStyle from '../../styles/Views/EnvironmentSettingStyel';
import Theme from '../../theme/Theme';

const EnvironmentSetting = () => {
  const [tenantId, setTenantId] = useState();
  const [subTenantId, setSubTenantId] = useState();
  const [environmentUrl, setEnvironmentUrl] = useState(
    'https://devwaveapi.odinwave.com',
  );
  const [environmentPort, setEnvironmentPort] = useState();
  const {EnvironmentSettingStyles} = EnvironmentSettingStyle();
  const {root} = Theme();
  const [focusedInput, setFocusedInput] = useState(null);

  const handleFocus = inputName => {
    setFocusedInput(inputName);
  };

  const handleBlur = () => {
    setFocusedInput(null);
  };

  const isInputFocused = inputName => {
    return focusedInput === inputName;
  };

  return (
    <SafeAreaView style={EnvironmentSettingStyles.conatainer}>
      <View style={{flex: 1}}>
        <Text style={EnvironmentSettingStyles.headText}>
          UAT Environment Setting's
        </Text>
        <View>
          <View>
            <Text
              style={[
                EnvironmentSettingStyles.title,
                {
                  color: isInputFocused('tenantId')
                    ? root.color_ENV_blue
                    : root.color_text,
                },
              ]}>
              Tenant Id
            </Text>
            <TextInput
              placeholder="i.e. com.wave.dev,1524,1404"
              value={tenantId}
              onChangeText={val => setTenantId(val)}
              placeholderTextColor={root.color_subtext}
              onFocus={() => handleFocus('tenantId')}
              onBlur={handleBlur}
              style={EnvironmentSettingStyles.textInput}
            />
            <View
              style={[
                EnvironmentSettingStyles.line,
                {
                  backgroundColor: isInputFocused('tenantId')
                    ? root.color_ENV_green
                    : root.color_subtext,
                  height: isInputFocused('tenantId') ? 1.2 : 1.2,
                },
              ]}></View>
          </View>
          <View>
            <Text
              style={[
                EnvironmentSettingStyles.title,
                {
                  color: isInputFocused('subtenantId')
                    ? root.color_ENV_blue
                    : root.color_text,
                },
              ]}>
              Sub Tenant Id
            </Text>
            <TextInput
              placeholder="Used for tenants who want separate app"
              value={subTenantId}
              onChangeText={val => setSubTenantId(val)}
              placeholderTextColor={root.color_subtext}
              onFocus={() => handleFocus('subtenantId')}
              onBlur={handleBlur}
              style={EnvironmentSettingStyles.textInput}
            />
            <View
              style={[
                EnvironmentSettingStyles.line,
                {
                  backgroundColor: isInputFocused('subtenantId')
                    ? root.color_ENV_green
                    : root.color_subtext,
                  height: isInputFocused('subtenantId') ? 1.2 : 1.2,
                },
              ]}></View>
          </View>
          <Text
            style={[
              EnvironmentSettingStyles.title,
              {
                color: isInputFocused('envUrl')
                  ? root.color_ENV_blue
                  : root.color_text,
              },
            ]}>
            Environment URL(Without / in end.)
          </Text>
          <TextInput
            placeholder="i.e http://"
            value={environmentUrl}
            onChangeText={val => setEnvironmentUrl(val)}
            placeholderTextColor={root.color_subtext}
            onFocus={() => handleFocus('envUrl')}
            onBlur={handleBlur}
            style={EnvironmentSettingStyles.textInput}
          />
          <View
            style={[
              EnvironmentSettingStyles.line,
              {
                backgroundColor: isInputFocused('envUrl')
                  ? root.color_ENV_green
                  : root.color_subtext,
                height: isInputFocused('envUrl') ? 1.2 : 1.2,
              },
            ]}></View>
          <Text
            style={[
              EnvironmentSettingStyles.title,
              {
                color: isInputFocused('envPort')
                  ? root.color_ENV_blue
                  : root.color_text,
              },
            ]}>
            Environment PORT (Without :)
          </Text>
          <TextInput
            placeholder="If no value keep it blank"
            value={environmentPort}
            onChangeText={val => setEnvironmentPort(val)}
            onFocus={() => handleFocus('envPort')}
            onBlur={handleBlur}
            placeholderTextColor={root.color_subtext}
            style={EnvironmentSettingStyles.textInput}
          />
          <View
            style={[
              EnvironmentSettingStyles.line,
              {
                backgroundColor: isInputFocused('envPort')
                  ? root.color_ENV_green
                  : root.color_subtext,
                height: isInputFocused('envPort') ? 1.2 : 1.2,
              },
            ]}></View>
        </View>
        <TouchableOpacity style={EnvironmentSettingStyles.botton}>
          <Text style={EnvironmentSettingStyles.bottonText}>
            Set Environment
          </Text>
        </TouchableOpacity>

        <View style={EnvironmentSettingStyles.detailsBox}>
          <Text style={EnvironmentSettingStyles.detailsTextPadding}>
            Note : Once set,this setting can removed, only after app
            cache/device storage removed. make sure URL for Production and UAT.
          </Text>

          <View style={EnvironmentSettingStyles.border} />

          <Text style={EnvironmentSettingStyles.detailsTextPadding}>
            Current auto sync environment is : UAT
          </Text>

          <View style={EnvironmentSettingStyles.border} />

          <Text style={EnvironmentSettingStyles.detailsText}>
            Sample URL for UAT :
          </Text>
          <Text style={EnvironmentSettingStyles.detailsText}>
            https://uatwaveapi.odinwave.com
          </Text>

          <View style={EnvironmentSettingStyles.border} />

          <Text style={EnvironmentSettingStyles.detailsText}>
            Sample URL for Production :
          </Text>
          <Text style={EnvironmentSettingStyles.detailsText}>
            https://waveapi.odinwave.com
          </Text>
          <View style={EnvironmentSettingStyles.border} />
          <View style={{flexDirection: 'row', width: '100%'}}>
            <View style={EnvironmentSettingStyles.borderCrossView}>
              <Text style={EnvironmentSettingStyles.detailsTextPadding}>
                Build Date :
              </Text>
              <View style={EnvironmentSettingStyles.border} />
              <Text style={EnvironmentSettingStyles.detailsTextPadding}>
                Build Ver :
              </Text>
            </View>
            <View style={{flex: 0.5}}>
              <Text style={EnvironmentSettingStyles.detailsTextPadding}>
                2023.05.23
              </Text>
              <View style={EnvironmentSettingStyles.border} />
              <Text style={EnvironmentSettingStyles.detailsTextPadding}>
                23.05.23
              </Text>
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};
export default EnvironmentSetting;

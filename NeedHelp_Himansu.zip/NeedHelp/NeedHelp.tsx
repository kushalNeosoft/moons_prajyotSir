import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  Button,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import {useIsFocused} from '@react-navigation/native';
import alignment from '../../components/utils/alignment';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useNavigation} from '@react-navigation/native';
import { needHelpStyle } from '../../theme/light';

const NeedHelp = (props: any) => {
  const [scrollToIndex, setScrollToIndex] = useState<any>(
    props?.route?.params?.index ? props.route.params.index : 0,
  );
  const [dataSource, setDataSource] = useState<any>([]);
  const [ref, setRef] = useState<any>(null);
  const [dataSourceCords, setDataSourceCords] = useState<any>([]);
  const [runScrollHandler, setRunScrollHandler] = useState(false);
  const navigation = useNavigation();

  const data = [
    {
      name: 'How to add scripts to watch list?',
      details:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    },
    {
      name: 'How to trade?',
      details:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    },
    {
      name: 'How to add funds?',
      details:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    },
    {
      name: 'How to withdraw funds?',
      details:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    },
    {
      name: 'How to change mpin',
      details:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
    },
  ];

  const ItemView = (item: any, key: any) => {
    return (
      <View
        key={key}
        onLayout={event => {
          dataSource[key] = event.nativeEvent.layout.y;
          setDataSourceCords(dataSource);
        }}>
        <Text
          style={needHelpStyle.typeTxt}>
          {item.name}
        </Text>
        <Text
          style={needHelpStyle.detailsTxt}>
          {item.details}
        </Text>
      </View>
    );
  };

  const isFocused = useIsFocused();

  useEffect(() => {
    const timer = setTimeout(() => {
      setRunScrollHandler(prevState => !prevState);
    }, 200);

    return () => clearTimeout(timer);
  }, [isFocused]);

  useEffect(() => {
    scrollHandler();
  }, [runScrollHandler]);

  const scrollHandler = () => {
    if (dataSourceCords.length >= scrollToIndex) {
      ref.scrollTo({
        x: 0,
        y: dataSourceCords[scrollToIndex - 1],
        animated: true,
      });
    }
  };

  useEffect(() => {
    setScrollToIndex(parseInt(scrollToIndex !== '' ? scrollToIndex : 0));
  }, []);

  return (
    <View style={{flex: 1,paddingHorizontal:16,backgroundColor:root.color_active}}>
      <View style={needHelpStyle.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign name="arrowleft" size={24} color={root.color_text} />
        </TouchableOpacity>
        <Text style={needHelpStyle.titleTxt}>Need Help</Text>
      </View>
      <ScrollView
      showsVerticalScrollIndicator={false}
        ref={ref => {
          setRef(ref);
        }}>
        {data.map(ItemView)}
      </ScrollView>
    </View>
  );
};

export default NeedHelp;

import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import { Grid, LineChart, XAxis, YAxis,Path,AreaChart } from 'react-native-svg-charts'
import { ScrollView, Text, TouchableOpacity, View } from 'react-native';
import { Analysisstyle } from '../../../theme/light';
import * as shape from 'd3-shape'
import { root } from '../../../styles/colors';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';


const Analysis: React.FC = ({ route }: any) => {
  const setScrollValue = route.params.setScrollValue;
  const [checked, setChecked] = useState(false);
  const [selectedItem, setSelectedItem] = useState(0);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [stockData, setStockData] = useState([]);
  const [handleRefresh, setHandleRefresh] = useState(false);
  const navigation = useNavigation();
  

  const data = [50, 10, 40, 95, -4, -24, 85, 91, 35, 53, -53, 24, 50, -20, -80]

  const axesSvg = { fontSize: 10, fill: 'grey' };
  const verticalContentInset = { top: 10, bottom: 10, }
  const xAxisHeight = 10

  const Line = ({ line }) => (
    <Path
        key={ 'line ' }
        d={ line }
        stroke={ 'rgb(134, 65, 244)' }
        fill={ 'none' }
    />
)


  return (
    <ScrollView
      style={Analysisstyle({ selectedIndex }).maincon}
      nestedScrollEnabled
      onScroll={evt => {
        if (evt?.nativeEvent?.contentOffset.y == 0) {
          setScrollValue(0);
        } else {
          if (evt?.nativeEvent?.contentOffset.y > 100) {
            setScrollValue(1);
          }
        }
      }}>
      <View style={Analysisstyle({ selectedIndex }).switchButtonView}>
        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(0);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({ selectedIndex }).todaysView}>
          <Text style={Analysisstyle({ selectedIndex }).todayText}>
            Technicals
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setSelectedIndex(1);
          }}
          activeOpacity={0.5}
          style={Analysisstyle({ selectedIndex }).overallView}>
          <Text style={Analysisstyle({ selectedIndex }).overallText}>
            Fundamentals
          </Text>
        </TouchableOpacity>
      </View>
      {selectedIndex === 0 ?
        <>
        <View style={Analysisstyle({ selectedIndex }).containerone}>
          <View style={Analysisstyle({ selectedIndex }).containertwo}>

          <Text style={Analysisstyle({ selectedIndex }).txtstyle} >Charts</Text>
          <View style={Analysisstyle({ selectedIndex }).iconcon}>

          <SimpleLineIcons name='frame' size={15} color={root.color_active}/>
          </View>
          </View>
        </View>
          <View style={{ height: 200, padding: 20, flexDirection: 'row' }}>
           
            <View style={{ flex: 1, marginLeft: 10 }}>
              <LineChart
                style={{ flex: 1}}
                data={data}
                contentInset={verticalContentInset}
                svg={{ stroke: root.color_text }}
              >
                <Grid />
              </LineChart>
              <XAxis
                style={{ marginHorizontal: -10, height: xAxisHeight }}
                data={data}
                formatLabel={(value, index) => value}
                contentInset={{ left: 10, right: 10 }}
                svg={axesSvg}
              />
            </View>
            <YAxis
              data={data}
              style={{ marginBottom: xAxisHeight,}}
              contentInset={verticalContentInset}
              svg={axesSvg}
            />
          </View>
          <View style={Analysisstyle({ selectedIndex }).supportcon}>
            <Text style={Analysisstyle({ selectedIndex }).txtstyle}>Support & Resistance</Text>

          </View>
          <View style={{flexDirection:'row', flex:1,height:30,width:'100%'}}>
            <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
            <Text>Support</Text>
            </View>
            <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
              <Text>Resistance</Text>

            </View>


          </View>
          
        </>
        :
        <>
          <View style={{ height: 60, width: 50, backgroundColor: 'yellow' }}></View>
        </>
      }
      <View style={Analysisstyle({ selectedIndex }).innercon} />
    </ScrollView>
  );
}

export default Analysis;
import React, {useState} from 'react';
import {View, Text, Modal, TouchableOpacity, FlatList} from 'react-native';
import {root} from '../../../../styles/colors';
import {RadioButton} from 'react-native-paper';
import Entypo from 'react-native-vector-icons/Entypo';
import {addToWatchListModal} from '../../../../theme/light';
import {useNavigation} from '@react-navigation/native';

function AddToWatchListModal(props: any) {
  const [checked, setChecked] = useState(false);
  const navigation = useNavigation();
  const data = [
    'BSE',
    'TEST11',
    'MISSSCRIP',
    'TEST',
    'SUMTG',
    'GLOBAL',
    'NEWLISTED',
    'COMMODITY',
    'PRE-SALES',
  ];

  const renderItem = ({item}: any) => {
    return (
      <View style={addToWatchListModal.itemContainer}>
        <RadioButton
          color={root.color_text}
          value={item}
          onPress={() => setChecked(item)}
          status={checked == item ? 'checked' : 'unchecked'}
        />
        <Text style={addToWatchListModal.watchlistNameTxt}>{item}</Text>
      </View>
    );
  };

  const closeModalAndNavigate = () => {
    const closeModal = setTimeout(() => {
      props.onClose();
    }, 100);
    navigation.navigate('AddToWatchList');
    return () => clearTimeout(closeModal);
  };

  return (
    <Modal
      visible={props.visible}
      onRequestClose={() => props.onClose()}
      transparent={true}>
      <TouchableOpacity
        style={addToWatchListModal.centeredView}
        onPress={() => props.onClose()}
        activeOpacity={1}
      />
      <View style={addToWatchListModal.container}>
        <View style={addToWatchListModal.innerContainer}>
          <View style={addToWatchListModal.titleTxtContainer}>
            <Text style={addToWatchListModal.select_watchList_Txt}>Select</Text>
            <Text style={addToWatchListModal.select_watchList_Txt}>
              WatchList
            </Text>
          </View>
          <View style={addToWatchListModal.listViewContainer}>
            <FlatList
              data={data}
              renderItem={renderItem}
              showsVerticalScrollIndicator={false}
            />
          </View>
          <View style={addToWatchListModal.createWatchListContainer}>
            <Entypo name="plus" size={25} color={root.client_background} />
            <TouchableOpacity onPress={closeModalAndNavigate}>
              <Text style={addToWatchListModal.createWatchListTxt}>
                Create WatchList({data.length}/10)
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

export default AddToWatchListModal;

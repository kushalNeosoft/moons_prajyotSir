import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
} from 'react-native';
import {Calendar} from 'react-native-calendars';
import DateEventComponent from './DateEventComponent';
// import {events} from '../../Screens/NiftyFifty/Market/SampleData';
// import {markedDates} from '../../Screens/NiftyFifty/Market/SampleData';

const CalendarComponent = props => {
  const [selectedDate, setSelectedDate] = useState('');
  const [markedDates, setMarkedDates] = useState({
    '2023-04-14': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-15': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-16': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
    '2023-04-17': {
      marked: true,
      dotColor: 'red',
      //   selected: true,
      //   selectedColor: '#002D62',
    },
  });
  const events = [
    {id: 1, title: 'NETFLIX', subTitle: 'bonus', date: '2023-04-14'},
    {id: 2, title: 'NETFLIX', subTitle: 'bonus', date: '2023-04-14'},
    {id: 3, title: 'NETFLIX', subTitle: 'bonus', date: '2023-04-14'},
    {id: 4, title: 'AMAZONE', subTitle: 'AGM', date: '2023-04-15'},
    {id: 5, title: 'AMAZONE', subTitle: 'AGM', date: '2023-04-15'},
    {id: 6, title: 'AXISNEO', subTitle: 'EGM', date: '2023-04-16'},
    {id: 7, title: 'SBIFUNDS', subTitle: 'BONUS', date: '2023-04-17'},
  ];
  const eventsForDate = events.filter(event => event.date === selectedDate);

  const handleDayPress = date => {
    const eventsOnDate = events.filter(event => event.date === date.dateString);
    if (eventsOnDate.length > 0) {
      setSelectedDate(date.dateString);
    } else {
      setSelectedDate('');
    }
  };
  const renderEvents = ({item}) => {
    return <DateEventComponent title={item.title} subTitle={item.subTitle} />;
  };
  return (
    <View style={{width: '100%'}}>
      <Calendar
        style={{
          width: '100%',
        }}
        markedDates={markedDates}
        onDayPress={handleDayPress}
      />
      {eventsForDate.length > 0 ? (
        <FlatList
          data={eventsForDate}
          keyExtractor={event => event.id.toString()}
          renderItem={renderEvents}
          style={{marginTop: 25, marginBottom: 30}}
        />
      ) : null}
    </View>
  );
};

export default CalendarComponent;

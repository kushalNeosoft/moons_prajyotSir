import React, {useState} from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {boxComponentIndices} from '../../.././../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useDispatch, useSelector} from 'react-redux';
import {addRemoveStock} from '../../../../redux/Action';

const BoxIndicesComponent = (props: any) => {
  const dispatch = useDispatch();
  const [selected, setSelected] = useState(false);
  const data = useSelector(state => state?.Reducer?.favouritesStock);
  var foundItem;
  const onClicked = () => {
    dispatch(addRemoveStock(props));
  };

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      style={boxComponentIndices({price: props?.price}).container}>
      <View style={boxComponentIndices().titleHeartView}>
        <Text style={boxComponentIndices().title}>{props?.title}</Text>
        <TouchableOpacity onPress={onClicked}>
          {
            (foundItem = data.some(item => item.indexId == props.indexId) ? (
              <AntDesign name="heart" style={boxComponentIndices().heartIcon} />
            ) : (
              <AntDesign
                name="hearto"
                style={boxComponentIndices().heartIcon}
              />
            ))
          }
        </TouchableOpacity>
      </View>

      <Text style={boxComponentIndices().price}>{props?.price}</Text>
      <Text style={boxComponentIndices().changes}>{props?.changes}</Text>
      <Text style={boxComponentIndices().date}>{props?.date}</Text>
    </TouchableOpacity>
  );
};
export default BoxIndicesComponent;

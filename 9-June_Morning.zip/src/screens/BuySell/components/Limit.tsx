import {useEffect, useState} from 'react';
import {
  Image,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Popable} from 'react-native-popable';
import CloseIcon from '../../../assets/CloseIcon';
import MinusIcon from '../../../assets/MinusIcon';
import AddIcon from '../../../assets/AddIcon';
import InfoIcon from '../../../assets/InfoIcon';
import ExpandIcon from '../../../assets/ExpandIcon';
import ValidityDialog from './ValidityDialog';
import DropDownIcon from '../../../assets/DropDownIcon';
import React from 'react';
import MarketDepthDialog from './MarketDepthDialog';
import {Cfont, root} from '../../../styles/colors';
import CheckBox from '@react-native-community/checkbox';

const Limit = ({setFilled}: any) => {
  const [lot, setLot] = useState(0);
  const [slLimit, setSlLimit] = useState(0);
  const [marketOrder, setMarketOrder] = useState(false);
  const [validityDailogVisible, setValidityDialogVisible] = useState(false);
  const [validity, setValidity] = useState('EOSESS');
  const [openDisclosedQty, setOpenDisclosedQty] = useState(false);
  const [disclosedQty, setDisclosedQty] = useState(0);

  useEffect(() => {
    setFilled(lot > 0 && slLimit > 0);
  }, [lot, slLimit, setFilled]);

  function setMarketDepthDialogVisible(arg0: boolean) {
    throw new Error('Function not implemented.');
  }

  return (
    <View>
      <View style={{flexDirection: 'row'}}>
        <View style={{flex: 1}}>
          <Text style={{color: 'black', fontWeight: 'bold', fontSize: 14}}>
            Lot
          </Text>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                if (lot > 0) setLot(prev => prev - 1);
              }}>
              <View style={{padding: 4}}>
                <MinusIcon style={{width: 16, height: 16, color: 'black'}} />
              </View>
            </TouchableNativeFeedback>
            <TextInput
              style={{
                flex: 1,
                marginHorizontal: 8,
                borderBottomWidth: 2,
                borderColor: 'lightgrey',
                paddingVertical: 0,
                paddingHorizontal: 8,
                textAlign: 'center',
                fontSize: 16,
              }}
              keyboardType="number-pad"
              defaultValue={lot.toString()}
            />
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                setLot(prev => prev + 1);
              }}>
              <View style={{padding: 4}}>
                <AddIcon style={{width: 16, height: 16, color: 'black'}} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <Text style={{marginTop: 8, textAlign: 'center', fontSize: 12}}>
            [1lot=100]
          </Text>
        </View>
        <View style={{width: 16}} />
        <View style={{flex: 1}}>
          <Text style={{color: 'black', fontWeight: 'bold', fontSize: 14}}>
            Limit (Tick 0.05)
          </Text>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                if (slLimit > 0) setSlLimit(prev => prev - 0.05);
              }}>
              <View style={{padding: 4}}>
                <MinusIcon style={{width: 16, height: 16, color: 'black'}} />
              </View>
            </TouchableNativeFeedback>
            <TextInput
              style={{
                flex: 1,
                marginHorizontal: 8,
                borderBottomWidth: 2,
                borderColor: 'lightgrey',
                paddingVertical: 0,
                paddingHorizontal: 8,
                textAlign: 'center',
                fontSize: 16,
              }}
              keyboardType="number-pad"
              defaultValue={slLimit.toString()}
            />
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={() => {
                setSlLimit(prev => prev + 0.05);
              }}>
              <View style={{padding: 4}}>
                <AddIcon style={{width: 16, height: 16, color: 'black'}} />
              </View>
            </TouchableNativeFeedback>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: 8,
            }}>
            <Popable
              style={{
                width: 300,
                padding: 11,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              content="Your order will be executed at then available market price  when the trigger price is reached"
              position="bottom">
              <InfoIcon style={{width: 16, height: 16, color: 'black'}} />
            </Popable>

            <Text style={{marginLeft: 8, fontSize: 12}}>Range :</Text>
            <Text
              style={{
                marginLeft: 8,
                fontSize: 12,
                color: root.color_text,
                fontFamily: Cfont.rubik_medium,
              }}>
              200 - 1234
            </Text>
          </View>
        </View>
      </View>
      <View style={{marginTop: 26}}>
        <Text
          style={{
            fontSize: 12,
            color: root.color_text,
            fontFamily: Cfont.rubik_regular,
          }}>
          Click here to update Approx. Margin
        </Text>

        <Text
          style={{
            marginTop: 8,
            fontSize: 12,
            color: root.color_text,
            fontFamily: Cfont.rubik_regular,
          }}>
          Approx. Margin:{' '}
          <Text style={{fontFamily: Cfont.rubik_medium}}> ₹ 0</Text>
        </Text>

        <Text
          style={{
            marginTop: 4,
            fontSize: 12,
            color: root.color_text,
            fontFamily: Cfont.rubik_regular,
          }}>
          Available Margin:
          <Text style={{fontFamily: Cfont.rubik_medium}}> ₹ 0</Text>
        </Text>
        <View
          style={{marginTop: 16, flexDirection: 'row', alignItems: 'center'}}>
          <View
            style={{
              flex: 1,
            }}>
            <Text
              style={{
                fontSize: 14,
                color: root.color_text,
                fontFamily: Cfont.rubik_bold,
                //fontWeight: 'bold',
              }}>
              "{'>'}Limit your loss or set target for profit
            </Text>
            <Text
              style={{
                fontSize: 12,
                color: root.color_text,
                flex: 1,
                fontFamily: Cfont.rubik_medium,
                marginLeft: 12,
              }}>
              Cover order, Bracket Order
            </Text>
            <AddIcon
              style={{width: 24, height: 24, marginLeft: 2, color: 'black'}}
            />
          </View>
          <CloseIcon style={{width: 28, height: 28, marginLeft: 8}} />
        </View>
        <View
          style={{
            marginTop: 20,
            flexDirection: 'row',
            alignItems: 'center',
            flex: 1,
          }}>
          <Text
            style={{
              fontSize: 14,
              color: root.color_text,
              fontFamily: Cfont.rubik_medium,
            }}>
            Disclosed Qty
          </Text>
          <TouchableNativeFeedback
            style={{marginLeft: 8}}
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => {
              setOpenDisclosedQty(true);
            }}>
            <View>
              <AddIcon
                style={{
                  width: 28,
                  height: 28,
                  color: root.color_text,
                }}
              />
            </View>
          </TouchableNativeFeedback>
        </View>
        {openDisclosedQty && (
          <View>
            <View
              style={{flexDirection: 'row', alignItems: 'center', width: 150}}>
              <TextInput
                style={{
                  flex: 1,
                  marginHorizontal: 8,
                  borderBottomWidth: 2,
                  borderColor: 'lightgrey',
                  paddingVertical: 0,
                  paddingHorizontal: 8,
                  textAlign: 'center',
                  fontSize: 16,
                }}
                keyboardType="number-pad"
                placeholder="0"
                defaultValue={disclosedQty.toString()}
              />
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                onPress={() => {
                  setDisclosedQty(prev => prev + 1);
                }}>
                <View style={{padding: 4}}>
                  <AddIcon style={{width: 16, height: 16, color: 'black'}} />
                </View>
              </TouchableNativeFeedback>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: 8,
              }}>
              <Popable
                style={{
                  width: 300,
                  padding: 11,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
                content="Something"
                position="bottom">
                <InfoIcon style={{width: 16, height: 16, color: 'black'}} />
              </Popable>

              <Text style={{marginLeft: 8, fontSize: 12}}>Min Disc Qty:</Text>
              <Text
                style={{
                  marginLeft: 8,
                  fontSize: 12,
                  color: root.color_text,
                  fontFamily: Cfont.rubik_medium,
                }}>
                0
              </Text>
            </View>
          </View>
        )}

        <View style={{flexDirection: 'row'}}>
          <View
            style={{
              marginTop: 16,
              flexDirection: 'row',
              alignItems: 'center',
              flex: 1,
            }}>
            <Text
              style={{
                fontSize: 14,
                color: root.color_text,
                fontFamily: Cfont.rubik_medium,
              }}>
              Validity
            </Text>
            <View
              style={{
                borderRadius: 16,
              }}>
              <TouchableNativeFeedback
                background={TouchableNativeFeedback.Ripple('gray', true)}
                onPress={() => {
                  setValidityDialogVisible(true);
                  // navigation.navigate('SignupScreen');
                }}>
                <View
                  style={{
                    paddingHorizontal: 10,
                    paddingVertical: 2,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_regular,
                      color: root.color_text,
                    }}>
                    {validity}
                  </Text>
                  <ExpandIcon
                    style={{
                      width: 16,
                      height: 16,
                      color: 'black',
                      alignSelf: 'center',
                      marginLeft: 4,
                    }}
                  />
                </View>
              </TouchableNativeFeedback>
            </View>
          </View>
          <View
            style={{
              marginTop: 16,
              flexDirection: 'row',
              alignItems: 'center',
              flex: 1,
            }}>
            <CheckBox
              value={marketOrder}
              onValueChange={setMarketOrder}
              style={{}}
            />
            <Text
              style={{
                fontSize: 14,
                color: root.color_text,
                fontFamily: Cfont.rubik_medium,
                marginLeft: 8,
              }}>
              After Market Order
            </Text>
          </View>
        </View>
      </View>
      <ValidityDialog
        visible={validityDailogVisible}
        onClose={() => {
          setValidityDialogVisible(false);
        }}
        onChange={(v: any) => {
          setValidity(v);
          setValidityDialogVisible(false);
        }}
      />
      <MarketDepthDialog
        visible={MarketDepthDialog}
        onClose={() => {
          setMarketDepthDialogVisible(false);
        }}
      />
    </View>
  );
};
export default Limit;

import {ScrollView, Text, TouchableNativeFeedback, View} from 'react-native';
import ArrowForwardIcon from '../../../assets/ArrowForwardIcon';
import {useEffect, useState} from 'react';
import MarginPrice from './MarginPrice';
import Limit from './Limit';
import SLMarket from './SLMarket';
import SLLimit from './SLLimit';
import React from 'react';
import {Cfont, root} from '../../../styles/colors';
import MarginConfirmPlaceOrderDialog from './MarginConfirmPlaceOrderDialog';
import OrderSuccessDialog from './OrderSuccessDialog';

const deliveryTypes = [
  {
    id: 'MARGIN_PRICE',
    title: 'Margin Price',
  },
  {
    id: 'LIMIT',
    title: 'Limit',
  },
  {
    id: 'SL_MARKET',
    title: 'SL Market',
  },
  {
    id: 'SL_LIMIT',
    title: 'SL Limit',
  },
];

const Margin = ({
  operation,
  item,
  transactionType,
  setTransactionTypeVisible,
}: any) => {
  const [filled, setFilled] = useState(false);
  const [confirmOrderVisible, setConfirmOrderVisible] = useState(false);
  const [orderSuccessVisible, setOrderSuccessVisible] = useState(false);
  const [selectedDeliveryType, setSelectedDeliveryType] =
    useState<string>('MARGIN_PRICE');

  useEffect(() => {
    setFilled(false);
  }, [selectedDeliveryType]);

  return (
    <View style={{flexDirection: 'column', flex: 1}}>
      <ScrollView style={{flex: 1, padding: 24}}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            borderWidth: 1,
            borderRadius: 4,
            borderColor: root.client_background,
          }}>
          {deliveryTypes.map(type => {
            return (
              <View
                style={{
                  alignSelf: 'stretch',
                }}>
                <TouchableNativeFeedback
                  background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
                  onPress={() => {
                    setSelectedDeliveryType(type.id);
                  }}>
                  <Text
                    key={type.id}
                    style={{
                      fontSize: 12,
                      paddingVertical: 6,
                      paddingHorizontal: 12,
                      backgroundColor:
                        selectedDeliveryType == type.id
                          ? root.client_background
                          : 'transparent',
                      color:
                        selectedDeliveryType == type.id
                          ? 'white'
                          : root.client_background,
                    }}>
                    {type.title}
                  </Text>
                </TouchableNativeFeedback>
              </View>
            );
          })}
        </View>
        <View style={{marginTop: 16}}>
          {selectedDeliveryType === 'MARGIN_PRICE' && (
            <MarginPrice
              item={item}
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
          {selectedDeliveryType === 'LIMIT' && <Limit setFilled={setFilled} />}
          {selectedDeliveryType === 'SL_MARKET' && (
            <SLMarket
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
          {selectedDeliveryType === 'SL_LIMIT' && (
            <SLLimit
              setFilled={setFilled}
              transactionType={transactionType}
              setTransactionTypeVisible={setTransactionTypeVisible}
            />
          )}
        </View>
      </ScrollView>
      <View
        style={{
          shadowColor: '#000',
          shadowOffset: {
            width: 0,
            height: 4,
          },
          shadowOpacity: 0.3,
          shadowRadius: 4.65,
          backgroundColor: 'white',
          elevation: 8,
          padding: 16,
        }}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <Text
            style={{
              fontSize: 12,
              color: root.client_background,
              fontFamily: Cfont.rubik_medium,
            }}>
            Brokerage and charges
          </Text>
          <ArrowForwardIcon
            style={{width: 28, height: 24, color: root.client_background}}
          />
        </View>

        <TouchableNativeFeedback
          disabled={!filled}
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => {
            setConfirmOrderVisible(true);
          }}>
          <Text
            style={{
              paddingHorizontal: 16,
              paddingVertical: 10,
              backgroundColor:
                operation == 'BUY' ? root.client_background : 'red',
              fontSize: 16,
              color: 'white',
              borderRadius: 8,
              textAlign: 'center',
              marginTop: 16,
              fontFamily: Cfont.rubik_semibold,
              opacity: filled ? 1 : 0.5,
            }}>
            Place Order
          </Text>
        </TouchableNativeFeedback>
      </View>
      <MarginConfirmPlaceOrderDialog
        visible={confirmOrderVisible}
        onClose={() => {
          setConfirmOrderVisible(false);
        }}
        item={item}
        onConfirm={() => {
          setConfirmOrderVisible(false);
          setOrderSuccessVisible(true);
        }}
        type={selectedDeliveryType}
      />
      <OrderSuccessDialog
        visible={orderSuccessVisible}
        onClose={() => {
          setOrderSuccessVisible(false);
        }}
        item={item}
      />
    </View>
  );
};
export default Margin;

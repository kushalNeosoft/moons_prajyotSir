import React from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import alignment from '../../../components/utils/alignment';
import { singleScriptCard } from '../../../theme/light';
import AntDesign from 'react-native-vector-icons/AntDesign'

const SingleScriptCard = (props: any) => {
  return (
    <View
      style={singleScriptCard.container}>
      <View style={singleScriptCard.companyNameContainer}>
        <View style={{justifyContent: 'space-around'}}>
          <View style={{...alignment.row}}>
            <Text style={singleScriptCard.companyNameTxt}>{props.name}</Text>
            <Text style={singleScriptCard.nseTxt}>NSE</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={singleScriptCard.buyTxt}>Buy : </Text>
            <Text style={singleScriptCard.buyQty}>{props.buy}</Text>
          </View>
          <View style={{...alignment.row, alignItems: 'center',paddingTop:10}}>
            <Text style={singleScriptCard.frequenctTxt}>{props.time}</Text>
            <Text style={singleScriptCard.delivery}>DELIVERY</Text>
          </View>
          <View style={{...alignment.row,paddingTop:10}}>
            <Text>Bought : </Text>
          <Text>{props.bought}</Text>
          </View>
        </View>
        <View style={{alignItems:"flex-end"}}>
          <View style={{...alignment.row,alignItems:'center',paddingTop:10}}>
          <Text style={singleScriptCard.completedTxt}>Completed</Text>
          <AntDesign 
          name='checkcircle'
          size={15}
          color={'#4caf50'}
          />
          </View>
          <Text style={singleScriptCard.installMent}>{props.quantity}</Text>
          <Text style={singleScriptCard.ltp}>{`LTP : ${props.ltp}`}</Text>
        </View>
      </View>
    </View>
  );
};

export default SingleScriptCard;

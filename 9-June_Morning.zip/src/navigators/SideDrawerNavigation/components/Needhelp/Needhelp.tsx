export interface INeed {

    title: string,
    index: string,
    drawerType: string,
    url: string,
}

export const Needhelp = [
    {
        title: 'How To Add Scrips To Watch List',
        index: '1',
        drawerType: 'Slide',
        url: 'https://reactnative.dev/',

    },
    {
        title: 'How To Trade',
        index: '2',
        drawerType: 'Slide',
        url: 'https://www.google.com/'

    }, {
        title: 'How To Add Funds',
        index: '3',
        drawerType: 'Slide',
        url: 'https://www.google.com/'

    }, {
        title: 'How To Withdraw Funds',
        index: '4',
        drawerType: 'glide',
        url: 'https://www.google.com/'

    }, {
        title: 'How To Change Mpin',
        index: '5',
        drawerType: 'glide',
        url: 'https://www.google.com/'

    },

]

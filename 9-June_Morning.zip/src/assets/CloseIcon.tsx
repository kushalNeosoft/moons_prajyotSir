import * as React from 'react';
import Svg, {Path} from 'react-native-svg';
const CloseIcon = (props: any) => (
  <Svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 96 960 960"
    fill={'currentColor'}
    {...props}>
    <Path d="m249 849-42-42 231-231-231-231 42-42 231 231 231-231 42 42-231 231 231 231-42 42-231-231-231 231Z" />
  </Svg>
);
export default CloseIcon;

import React from 'react';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import alignment from '../utils/alignment';
import {Cfont, Font, root} from '../../styles/colors';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {useSelector} from 'react-redux';
import FontAwesome5 from 'react-native-vector-icons/FontAwesome5';

function Header(props: any) {
  const getScriptName = useSelector(state => state.Reducer.scriptName);
  const getBottomSheetData = useSelector(
    state => state.Reducer.bottomSheetData,
  );

  const renderHeaderTitle = () => {
    switch (getScriptName) {
      case 'Single Script Orders':
        return (
          <Text style={styles.companyNameTop}>{getBottomSheetData?.name}</Text>
        );
      case 'Spread Orders':
        return (
          <Text style={styles.companyNameTop}>{getBottomSheetData?.name}</Text>
        );
      case 'Multileg Orders':
        return <Text style={styles.companyNameTop}>MultiLeg</Text>;
      case 'Good Till Date':
        return (
          <Text style={styles.companyNameTop}>{getBottomSheetData?.name}</Text>
        );
      case 'Equity SIP':
        return (
          <Text style={styles.companyNameTop}>{getBottomSheetData?.name}</Text>
        );
      case 'Net Position':
        return <Text style={styles.netPosition}>Net Position</Text>;
      default:
        return null;
    }
  };

  return (
    <View style={{overflow: 'hidden'}}>
      <View
        style={{
          ...alignment.row,
          backgroundColor: 'white',
          height: 35,
          alignItems: 'center',
          elevation: 2,
        }}>
        <TouchableOpacity onPress={() => props.closeSheet()}>
          <Ionicons name="arrow-back" size={20} color={'black'} />
        </TouchableOpacity>
        {renderHeaderTitle()}
        <View
          style={{
            right: 0,
            position: 'absolute',
          }}>
          {getScriptName === 'Net Position' ? (
            <>
              <FontAwesome5 name="sliders-h" color={'black'} size={20} />
            </>
          ) : (
            <>
              {props.scriptName === 'Equity SIP' ? (
                <View style={{...alignment.row}}>
                  <Text style={styles.activeTxt}>Active</Text>
                  <Ionicons name="md-at-circle-outline" size={15} />
                </View>
              ) : (
                <View style={{...alignment.row}}>
                  <Text style={styles.activeTxt}>Completed</Text>
                  <AntDesign name="checkcircle" size={15} color={'#4caf50'} />
                </View>
              )}
            </>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  companyNameTop: {
    color: root.color_text,
    fontSize: Font.font_normal_three,
    fontFamily: Cfont.rubik_medium,
    paddingLeft: 10,
  },
  activeTxt: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_one,
  },
  netPosition: {
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
    fontSize: Font.font_normal_four,
    paddingLeft: 10,
  },
});

export default Header;

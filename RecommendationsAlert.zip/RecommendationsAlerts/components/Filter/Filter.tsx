import {useNavigation} from '@react-navigation/native';
import React, {useEffect, useState} from 'react';
import {
  FlatList,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  TextInput,
} from 'react-native';
import { ordersFilter } from '../../../../theme/light';

const OrdersFilter = (props:any) => {
  const [order, setOrder] = useState('');
  const [broker,setBroker]=useState('');
  const orders = ['1', '2'];
  const brokerTags=['All1','Bracket']

useEffect(()=>{
    setOrder(props.order)
    setBroker(props.brokerTags)
},[props.order,props.filterTags])

const setFilter=()=>{
  if(order!==''){
    props.setOrderFilter(order)
  }
  if(broker!==''){
    props.setBrokerTagFilter(broker)
  }
  props.closeSheet()
}

  return (
    <View style={ordersFilter.Maincon}>
      <View style={ordersFilter.contentView}>
        <View>
          <Text style={ordersFilter.titleTxt}>Order</Text>
          <FlatList
            data={orders}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setOrder(item)}
                style={
                  item === order
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={ordersFilter.item}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
        <View>
          <Text style={ordersFilter.titleTxt}>Broker Tags</Text>
          <FlatList
            data={brokerTags}
            horizontal={true}
            renderItem={({item}) => (
              <TouchableOpacity
                onPress={() => setBroker(item)}
                style={
                  item === broker
                    ? ordersFilter.blockSelected
                    : ordersFilter.blockUnSelected
                }>
                <Text
                  style={ordersFilter.item}>
                  {item}
                </Text>
              </TouchableOpacity>
            )}
          />
        </View>
      </View>
      <TouchableOpacity style={ordersFilter.applyBtn} onPress={setFilter}>
        <Text style={ordersFilter.applyBottonText}>Apply</Text>
      </TouchableOpacity>
    </View>
  );
};

export default OrdersFilter;

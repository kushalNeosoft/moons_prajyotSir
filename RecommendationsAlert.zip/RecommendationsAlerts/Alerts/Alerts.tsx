import React from "react";
import {View,Text, TouchableOpacity} from 'react-native';
import { recommendations } from "../../../theme/light";
import Fontisto from "react-native-vector-icons/Fontisto";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import alignment from "../../../components/utils/alignment";
import { Cfont, Font, root } from "../../../styles/colors";
import { useNavigation } from "@react-navigation/native";

function Alerts(){
  const navigation=useNavigation();
    return(
        <View style={recommendations.header}>
        <View style={{...alignment.row,alignItems:'center'}}>
        <Fontisto
              name="bell"
              size={20}
              color={root.client_background}
              style={{paddingRight: 25}}
            />
            <Text style={recommendations.alertsTxt}>Manage Alerts</Text>
        </View>
        <View style={recommendations.filterSearchContainer}>
          <TouchableOpacity onPress={()=>navigation.navigate('TextToSpeech')}>
            <Fontisto
              name="search"
              size={20}
              color={'black'}
              style={{paddingRight: 25}}
            />
            </TouchableOpacity>
            <FontAwesome5 name="sliders-h" color={'black'} size={20} />
        </View>
      </View>
    )
}

export default Alerts;
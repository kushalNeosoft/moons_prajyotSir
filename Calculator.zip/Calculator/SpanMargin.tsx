import {
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import MinusIcon from '../../assets/MinusIcon';
import {Popable} from 'react-native-popable';
import InfoIcon from '../../assets/InfoIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import CloseIcon from '../../assets/CloseIcon';
import {useState} from 'react';
import React from 'react';
import {useNavigation} from '@react-navigation/native';
import {Span} from '../../theme/light';

const SpanMargin = () => {
  const navigation = useNavigation();
  return (
    <View style={Span.main}>
      <View style={{padding: 16}}>
        <TouchableNativeFeedback
          background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
          onPress={() => navigation.goBack()}>
          <View style={Span.bar}>
            <CloseIcon style={Span.closeIcon} />
          </View>
        </TouchableNativeFeedback>
        <Text style={Span.span}>Span Margin</Text>
        <Text style={Span.calculator}>Calculator</Text>
        <View>
          <Text
            style={Span.blank}></Text>
        </View>
        <View>
          <View style={{marginTop: 16}}>
            <Text
              style={Span.txt}>
              Search Contracts
            </Text>
            <View
              style={Span.txt1}>
              <TextInput
                style={Span.textInput}
                placeholder="Type here"
              />
              <AddIcon
                style={Span.AddIcon}
              />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};
export default SpanMargin;

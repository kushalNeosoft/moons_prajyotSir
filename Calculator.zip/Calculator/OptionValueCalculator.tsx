import {
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  TouchableOpacity,
  View,
} from 'react-native';
import {Cfont, Font, root} from '../../styles/colors';
import AddIcon from '../../assets/AddIcon';
import MinusIcon from '../../assets/MinusIcon';
import {Popable} from 'react-native-popable';
import InfoIcon from '../../assets/InfoIcon';
import ArrowForwardIcon from '../../assets/ArrowForwardIcon';
import CloseIcon from '../../assets/CloseIcon';
import {useState} from 'react';
import React from 'react';
import {useNavigation} from '@react-navigation/native';
import { Options, options } from '../../theme/light';

const OptionValueCalculator = () => {
  const [search, setSearch] = useState<string>('');
  const [optionType, setOptionType] = useState('CALL');
  const navigation = useNavigation();
  const [expiry, setExpiry] = useState<string>();
  const [expiryDays, setExpiryDays] = useState<number>(0);
  const [spotPrice, setSpotPrice] = useState<number>();
  const [strikePrice, setStrikePrice] = useState<number>();
  const [interestRate, setInterestRate] = useState<number>(0);
  const [volatility, setVolatility] = useState<number>();
  const [dividend, setDividend] = useState<string>('');

  const [calculationMethod, setCalculationMethod] = useState('CRRBM');

  const clear = () => {
    setSearch('');
    setOptionType('CALL');
    setExpiry('');
    setExpiryDays(0);
    setSpotPrice(0);
    setStrikePrice(0);
    setInterestRate(0);
    setVolatility(0);
    setDividend('');
  };
  return (
    <View
      style={options.main}>
      <ScrollView>
        <View style={{padding: 16}}>
          <TouchableNativeFeedback
            background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
            onPress={() => navigation.goBack()}>
            <View style={{padding: 4, width: 32, height: 32}}>
              <CloseIcon
                style={{width: 24, height: 24, color: root.color_text}}
              />
            </View>
          </TouchableNativeFeedback>
          <Text
            style={{
              fontSize: Font.font_title,
              fontFamily: Cfont.rubik_medium,
              color: root.color_text,

              marginTop: 28,
            }}>
            Option Value
          </Text>
          <Text
            style={{
              fontSize: Font.font_title,
              fontFamily: Cfont.rubik_medium,
              color: root.color_text,
            }}>
            Calculator
          </Text>
          <View style={{flexDirection: 'row', justifyContent: 'flex-end'}}>
            <TouchableNativeFeedback
              background={TouchableNativeFeedback.Ripple('#90CAF9', false)}
              onPress={clear}>
              <View style={{paddingVertical: 4, paddingHorizontal: 8}}>
                <Text
                  style={{
                    fontFamily: Cfont.rubik_medium,
                    color: root.color_text,
                  }}>
                  Clear
                </Text>
              </View>
            </TouchableNativeFeedback>
          </View>
          <View>
            <View style={{marginTop: 16}}>
              <Text
                style={{
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                }}>
                Search Equity Or Future
              </Text>
              <View
                style={{
                  marginTop: 8,
                  borderRadius: 8,
                  borderWidth: 0.5,
                  borderColor: root.color_text,

                  flexDirection: 'row',
                  alignItems: 'center',
                }}>
                <TextInput
                  style={{
                    flex: 1,
                    paddingVertical: 6,
                    paddingHorizontal: 16,
                    fontSize: 16,
                  }}
                  placeholder="Enter Expiry"
                  value={search}
                  onChangeText={value => setSearch(value)}
                />
                <AddIcon
                  style={{
                    width: 24,
                    height: 24,
                    color: root.color_text,
                    marginRight: 12,
                  }}
                />
              </View>
            </View>
            <View
              style={{
                marginTop: 16,
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
              <Text
                style={{
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                }}>
                Option Type
              </Text>
              <View
                style={{
                  flexDirection: 'row',
                  borderWidth: 0.1,
                  borderColor: root.color_text,
                  borderRadius: 16,
                }}>
                <View style={{borderRadius: 15, overflow: 'hidden'}}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      // navigation.goBack();
                      setOptionType('CALL');
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 12,
                          backgroundColor:
                            optionType == 'CALL'
                              ? root.client_background
                              : 'transparent',
                          borderRadius: 16,
                          color:
                            optionType == 'CALL' ? 'white' : root.color_text,
                        }}>
                        Call
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>

                <View
                  style={{
                    borderRadius: 15,
                    overflow: 'hidden',
                  }}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setOptionType('PUT');
                      // navigation.goBack();
                    }}>
                    <View>
                      <Text
                        style={{
                          fontSize: 11,
                          fontFamily: Cfont.rubik_medium,
                          paddingVertical: 6,
                          paddingHorizontal: 10,
                          borderRadius: 16,
                          backgroundColor:
                            optionType == 'PUT'
                              ? root.client_background
                              : 'transparent',
                          color:
                            optionType == 'PUT' ? 'white' : root.color_text,
                        }}>
                        Put
                      </Text>
                    </View>
                  </TouchableNativeFeedback>
                </View>
              </View>
            </View>
            <View style={{marginTop: 16}}>
              <Text
                style={{
                  fontFamily: Cfont.rubik_medium,
                  color: root.color_text,
                }}>
                Contract Days
              </Text>
              <View
                style={{
                  marginTop: 8,
                  borderRadius: 8,
                  borderWidth: 0.5,
                  borderColor: root.color_text,
                  flexDirection: 'row',
                  alignItems: 'center',
                }}>
                <TextInput
                  style={{
                    flex: 1,
                    paddingVertical: 6,
                    paddingHorizontal: 16,
                    fontSize: 16,
                  }}
                  placeholder="Enter Expiry"
                  value={expiry}
                  onChangeText={(value: any) => setExpiry(value)}
                />
                <View style={{flex: 1, flexDirection: 'row'}}>
                  <View style={{}}>
                    <TouchableNativeFeedback
                      background={TouchableNativeFeedback.Ripple(
                        '#90CAF9',
                        false,
                      )}
                      onPress={() => {
                        setExpiryDays(prev => prev - 1);
                      }}>
                      <View>
                        <MinusIcon
                          style={{
                            width: 24,
                            height: 24,
                            color: root.color_text,
                          }}
                        />
                      </View>
                    </TouchableNativeFeedback>
                  </View>
                  <View style={{flex: 1}}>
                    <Text style={{textAlign: 'center'}}>{expiryDays}</Text>
                  </View>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                      marginRight: 12,
                    }}>
                    Days
                  </Text>
                  <View
                    style={{
                      marginHorizontal: 12,
                    }}>
                    <TouchableNativeFeedback
                      background={TouchableNativeFeedback.Ripple(
                        '#90CAF9',
                        false,
                      )}
                      onPress={() => {
                        setExpiryDays(prev => prev + 1);
                      }}>
                      <View>
                        <AddIcon
                          style={{
                            width: 24,
                            height: 24,
                            color: root.color_text,
                          }}
                        />
                      </View>
                    </TouchableNativeFeedback>
                  </View>
                </View>
              </View>
            </View>

            <View style={{flexDirection: 'row', marginTop: 16}}>
              <View style={{flex: 1, marginRight: 8}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                  }}>
                  Spot Price
                </Text>
                <View>
                  <TextInput
                    style={{
                      marginTop: 8,
                      borderRadius: 8,
                      borderWidth: 0.5,
                      borderColor: root.color_text,
                      paddingVertical: 6,
                      paddingHorizontal: 16,
                      fontSize: 16,
                    }}
                    placeholder="Search Scrip"
                    value={spotPrice?.toString()}
                    onChangeText={(value: any) => setSpotPrice(value)}
                  />
                </View>
              </View>
              <View style={{flex: 1, marginLeft: 8}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                  }}>
                  Strike Price
                </Text>
                <View>
                  <TextInput
                    style={{
                      marginTop: 8,
                      borderRadius: 8,
                      borderWidth: 0.5,
                      borderColor: root.color_text,
                      paddingVertical: 6,
                      paddingHorizontal: 16,
                      fontSize: 16,
                    }}
                    keyboardType="number-pad"
                    placeholder="Enter Value"
                    value={strikePrice?.toString()}
                    onChangeText={(value: any) => setStrikePrice(value)}
                  />
                </View>
              </View>
            </View>
            <View style={{flexDirection: 'row', marginTop: 16}}>
              <View style={{flex: 1, marginRight: 8}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                  }}>
                  Interest Rate [%]
                </Text>
                <View
                  style={{
                    marginTop: 8,
                    borderRadius: 8,
                    borderWidth: 0.5,
                    borderColor: root.color_text,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setInterestRate(prev => prev - 0.1);
                    }}>
                    <View style={{padding: 8}}>
                      <MinusIcon
                        style={{
                          width: 18,
                          height: 18,
                          color: root.color_text,
                        }}
                      />
                    </View>
                  </TouchableNativeFeedback>

                  <TextInput
                    style={{
                      flex: 1,
                      paddingVertical: 6,
                      paddingHorizontal: 16,
                      fontSize: 16,
                      textAlign: 'center',
                    }}
                    placeholder="0"
                    value={interestRate?.toString()}
                    onChangeText={(value: any) => setInterestRate(value)}
                    keyboardType="number-pad"
                  />
                  <TouchableNativeFeedback
                    background={TouchableNativeFeedback.Ripple(
                      '#90CAF9',
                      false,
                    )}
                    onPress={() => {
                      setInterestRate(prev => prev + 0.1);
                    }}>
                    <View style={{padding: 8}}>
                      <AddIcon
                        style={{
                          width: 18,
                          height: 18,
                          color: root.color_text,
                        }}
                      />
                    </View>
                  </TouchableNativeFeedback>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: 8,
                  }}>
                  <Popable
                    style={{
                      width: 300,
                      padding: 11,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{width: 16, height: 16, color: root.color_text}}
                    />
                  </Popable>

                  <Text style={{marginLeft: 8, fontSize: 12}}>Range:</Text>
                  <Text
                    style={{
                      marginLeft: 8,
                      fontSize: 12,
                      color: root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    0-99%
                  </Text>
                </View>
              </View>
              <View style={{flex: 1, marginLeft: 8}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                  }}>
                  Volatility [%]
                </Text>
                <View>
                  <TextInput
                    style={{
                      marginTop: 8,
                      borderRadius: 8,
                      borderWidth: 0.5,
                      borderColor: root.color_text,

                      paddingVertical: 6,
                      paddingHorizontal: 16,
                      fontSize: 16,
                    }}
                    keyboardType="number-pad"
                    placeholder="Enter Value"
                    value={volatility?.toString()}
                    onChangeText={(value: any) => setVolatility(value)}
                  />
                </View>

                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: 8,
                  }}>
                  <Popable
                    style={{
                      width: 300,
                      padding: 11,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{width: 16, height: 16, color: root.color_text}}
                    />
                  </Popable>

                  <Text style={{marginLeft: 8, fontSize: 12}}>Range:</Text>
                  <Text
                    style={{
                      marginLeft: 8,
                      fontSize: 12,
                      color: root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    0-99%
                  </Text>
                </View>
              </View>
            </View>
            <View style={{flexDirection: 'row', marginTop: 16}}>
              <View style={{flex: 1}}>
                <Text
                  style={{
                    color: root.color_text,
                    fontFamily: Cfont.rubik_medium,
                  }}>
                  Dividend
                </Text>
                <View>
                  <TextInput
                    style={{
                      marginTop: 8,
                      borderRadius: 8,
                      borderWidth: 0.5,
                      borderColor: root.color_text,

                      paddingVertical: 6,
                      paddingHorizontal: 16,
                      fontSize: 16,
                    }}
                    keyboardType="number-pad"
                    placeholder="Enter Value"
                    value={dividend}
                    onChangeText={value => setDividend(value)}
                  />
                </View>

                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: 8,
                  }}>
                  <Popable
                    style={{
                      width: 300,
                      padding: 11,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                    content="Something"
                    position="bottom">
                    <InfoIcon
                      style={{width: 16, height: 16, color: root.color_text}}
                    />
                  </Popable>

                  <Text style={{marginLeft: 8, fontSize: 12}}>Range:</Text>
                  <Text
                    style={{
                      marginLeft: 8,
                      fontSize: 12,
                      color: root.color_text,
                      fontFamily: Cfont.rubik_medium,
                    }}>
                    0-99%
                  </Text>
                </View>
              </View>
              <View style={{flex: 1}} />
            </View>

            <View style={{marginTop: 16}}>
              <Text
                style={{
                  color: root.color_text,
                  fontFamily: Cfont.rubik_medium,
                  fontSize: 16,
                }}>
                Choose Calculate Method
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setCalculationMethod('CRRBM');
                }}>
                <View
                  style={{
                    flex: 1,
                    flexDirection: 'row',
                    paddingVertical: 8,
                    marginTop: 8,
                  }}>
                  <View
                    style={{
                      borderWidth: 2,
                      width: 20,
                      height: 20,
                      borderRadius: 10,
                    }}>
                    {calculationMethod === 'CRRBM' && (
                      <View
                        style={{
                          width: 12,
                          height: 12,
                          backgroundColor: root.color_text,
                          margin: 2,
                          borderRadius: 6,
                        }}
                      />
                    )}
                  </View>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                      marginLeft: 8,
                      fontSize: 16,
                    }}>
                    Cox-Ross-Runinstein Binomial Method
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  setCalculationMethod('BSPM');
                }}>
                <View
                  style={{flex: 1, flexDirection: 'row', paddingVertical: 8}}>
                  <View
                    style={{
                      borderWidth: 2,
                      width: 20,
                      height: 20,
                      borderRadius: 10,
                    }}>
                    {calculationMethod === 'BSPM' && (
                      <View
                        style={{
                          width: 12,
                          height: 12,
                          backgroundColor: root.color_text,
                          margin: 2,
                          borderRadius: 6,
                        }}
                      />
                    )}
                  </View>
                  <Text
                    style={{
                      fontFamily: Cfont.rubik_medium,
                      color: root.color_text,
                      marginLeft: 8,
                      fontSize: 16,
                    }}>
                    Black and Scholes Pricing Model
                  </Text>
                </View>
              </TouchableOpacity>
            </View>

            <View
              style={{
                flexDirection: 'row',
                paddingHorizontal: 16,
                paddingVertical: 8,
                backgroundColor: root.client_background,
                marginTop: 36,
                borderRadius: 8,
                alignItems: 'center',
                width: '40%',
              }}>
              <Text
                style={{
                  color: root.color_active,
                  fontSize: 18,
                  marginRight: 22,
                }}>
                Calculate
              </Text>
              <ArrowForwardIcon
                style={{width: 24, height: 24, color: root.color_active}}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};
export default OptionValueCalculator;

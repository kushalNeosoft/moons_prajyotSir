import {useEffect, useState} from 'react';
import React from 'react';
import {
  Image,
  Linking,
  ScrollView,
  Text,
  TextInput,
  TouchableNativeFeedback,
  View,
} from 'react-native';
import {Cfont, root} from '../../styles/colors';
import BackIcon from '../../assets/BackIcon';
import {TouchableOpacity} from 'react-native';
import { linkOne } from '../../theme/light';
import {useNavigation} from '@react-navigation/native';

const Report = () => {
  const [report, setReport] = useState([]);
  const navigation = useNavigation();


  const loadData = async () => {
    fetch('https://d2e9hg2sdzxiwf.cloudfront.net/1404/v1/SSOLinks.json', {
      method: 'GET',
    })
      .then(response => response.json())
      .then((result): any => {
        setReport(result);
      })
      .catch(error => console.log('error', error));
  };
  useEffect(() => {
    loadData();
  }, []);
  return (
    <View
      style={linkOne.main}>
      <View
        style={linkOne.shadowone}>
       <TouchableOpacity onPress={() => navigation.goBack()}>
          <BackIcon style={linkOne.backicon} />
        </TouchableOpacity>

        <Text
          style={linkOne.header}>
         Reports
        </Text>
      </View>
      <View style={{flex: 1}}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          style={{width: '100%'}}>
          {report.map((link: any, index: any) => {
            return (
              <TouchableNativeFeedback
                key={index}
                background={TouchableNativeFeedback.Ripple('gray', false)}
                onPress={() => {
                  console.log(link.action?.url);
                  Linking.openURL(link.action?.url);
                }}>
                <View
                  style={linkOne.shadowtwo}>
                  <Text
                    style={linkOne.cardtext}>
                    {link.menuname}
                  </Text>
                  <Image
                source={require('../../assets/Broker.png')}
                style={linkOne.image}
              />
                </View>
              </TouchableNativeFeedback>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );
};
export default Report;

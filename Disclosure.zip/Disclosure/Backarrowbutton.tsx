import {useNavigation} from '@react-navigation/native';
import React, {useState} from 'react';
import {Pressable} from 'react-native';

import Ionicons from 'react-native-vector-icons/Ionicons';
import {root} from '../../styles/colors';

const Backarrowbutton = (props: any) => {
  const [disabled, setDisabled] = useState(false);

  const handlePress = () => {
    if (!disabled) {
      setDisabled(true);
      if (props.onClose == undefined) {
        navigation.goBack();
      } else {
        props.onClose();
      }
      setTimeout(() => setDisabled(false), 1000); // Adjust the debounce time as needed
    }
  };

  const navigation = useNavigation();

  return (
    <Pressable
      onPress={
        handlePress
      }
      disabled={disabled}>
      <Ionicons
        name="arrow-back"
        size={props.size}
        color={root.color_text}
        {...props}
      />
    </Pressable>
  );
};

export default Backarrowbutton;

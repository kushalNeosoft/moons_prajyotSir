import React from "react";
import { View,Text, TouchableOpacity, Pressable, Dimensions, Modal, } from "react-native";
import AntDesign from "react-native-vector-icons/AntDesign";
import { CloseModal } from "../../theme/light";

const Addendnummodal=(props:any)=>{
    return(
        <Modal
        visible={props.visible}
        onRequestClose={props.onClose}
        transparent={true}>
        <TouchableOpacity
          style={CloseModal.centeredView}
          onPress={props.onClose}
          activeOpacity={1}>
          <View style={[CloseModal.modalView,{
             height: Dimensions.get('window').height * 0.27,

          }]}>
            <View style={CloseModal.innermain}>
              <Text style={CloseModal.Wavetitle}>Wave 2</Text>
              <AntDesign name="exclamationcircle" size={40} color="grey" />
            </View>
            <View style={CloseModal.leftallign}>
              <Text style={CloseModal.modalText}>
                You are about to log off as you have not accepted the Risk Disclosure. Kindly confirm
              </Text>

              <View
                style={{flexDirection: 'row', justifyContent: 'space-around'}}>
                <Pressable style={[CloseModal.button]} onPress={props.onPressconfirm}>
                  <Text style={CloseModal.textStyle}>Confirm</Text>
                </Pressable>
                <Pressable
                  style={[CloseModal.buttontwo]}
                  onPress={props.onClose}>
                  <Text style={CloseModal.textStyletwo}>Cancle</Text>
                </Pressable>
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </Modal>
        
   
    )
}

export default Addendnummodal;
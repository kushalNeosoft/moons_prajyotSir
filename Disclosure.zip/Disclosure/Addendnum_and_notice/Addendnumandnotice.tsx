import { useNavigation } from '@react-navigation/native';
import React, {useCallback, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Dimensions,
  Touchable,
  TouchableOpacity,
} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {addnumdata} from '../../assets/demoData';
import {Cfont, root} from '../../styles/colors';
import Addendnummodal from './Addendnummodal';

const Addendnumandnotice = () => {
    const navigation =useNavigation()
  const [removemodal, setRemovemodal] = useState(false);
  const onRemoveClose = () => {
    setRemovemodal(prevState => !prevState);
  };
  const onPressconfirm=()=>{
    navigation.navigate('ProfileScreen')
    
  }

  const renderListView = useCallback(
    ({item, index}: any) => (
      <View style={styles.flatmaincontainer}>
        <View style={{flex: 0.157, alignItems: 'center'}}>
          <Entypo name="dot-single" size={20} color={'black'} />
        </View>
        <View style={{flex: 2}}>
          <Text style={styles.txtstyletwo}>{item.item}</Text>
        </View>
      </View>
    ),
    [],
  );
  return (
    <View style={styles.mainconatainer}>
      <View style={styles.header}>
        <Text style={styles.txtstyle}>Risk Disclosure</Text>
      </View>

      <FlatList
        data={addnumdata}
        renderItem={renderListView}
        style={{marginTop: 18}}
      />
      <View style={styles.bottom}>
        <View style={styles.accept}>
          <TouchableOpacity
          onPress={()=>{navigation.navigate('TestScreen')}}
            style={styles.acceptcontainer}>
            <Text style={styles.accepttxt}>Accept</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.reject}>
          <TouchableOpacity
          onPress={()=>setRemovemodal(true)}
            style={styles.rejectcontainer}>
            <Text style={styles.Rejecttxt}>Reject</Text>
          </TouchableOpacity>
        </View>
      </View>
      <Addendnummodal
        visible={removemodal}
        onClose={onRemoveClose}
        onPressconfirm={onPressconfirm}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  mainconatainer: {
    flex: 1,
    backgroundColor: root.color_active,
  },
  header: {
    width: '100%',
    height: Dimensions.get('window').width * 0.11,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  txtstyle: {
    fontSize: 18,
    fontFamily: Cfont.rubik_medium,
    color: root.color_text,
  },
  flatmaincontainer: {
    flex: 1,
    flexDirection: 'row',
    marginVertical: 10,
  },
  txtstyletwo: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
    color: root.color_text,
    textAlign: 'left',
  },
  txtstylethree: {
    fontFamily: Cfont.rubik_regular,
    fontSize: 18,
    color: root.color_text,
  },
  bottom: {
    paddingHorizontal: 2,
    paddingVertical: 8,
    height: 64,
    width: '100%',
    // position: 'absolute',
    bottom: 0,
    flexDirection: 'row',
  },
  accept: {
    height: 40,
    flex: 1,
  },
  reject: {
    height: 40,
    flex: 1,
  },
  acceptcontainer: {
    width: '97.5%',
    height: '100%',
    marginLeft: 2,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: root.client_background,
  },
  rejectcontainer:{
    width: '99%',
    height: '100%',
    marginRight: 2,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth:1
  },
  accepttxt:{
    color:root.color_active,
    fontFamily:Cfont.rubik_regular,
    fontSize:14,
  },
  Rejecttxt:{
    color:root.client_background,
    fontFamily:Cfont.rubik_regular,
    fontSize:14,
  }
});

export default React.memo(Addendnumandnotice) ;

import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {Pressable} from 'react-native';
import Entypo from 'react-native-vector-icons/Entypo';
import {root} from '../../styles/colors';

const Crossbutton = (props: any) => {
  const navigation = useNavigation();
  const [disabled, setDisabled] = useState(false);

  const handlePress = () => {
    if (!disabled) {
      setDisabled(true);
      if (props.onClose == undefined) {
        navigation.goBack();
      } else {
        props.onClose();
      }
      setTimeout(() => setDisabled(false), 1000); // Adjust the debounce time as needed
    }
  };
  return (
    <Pressable onPress={
      handlePress
    }
    disabled={disabled}>
      <Entypo
        name="cross"
        size={props.size}
        color={root.color_text}
        {...props}
      />
    </Pressable>
  );
};

export default Crossbutton;

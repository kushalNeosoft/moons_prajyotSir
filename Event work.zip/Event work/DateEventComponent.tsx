import React, {useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import SimpleLineIcons from 'react-native-vector-icons/SimpleLineIcons';
import EventDetailsModal from '../Events/EventDetailsModal';
import {dateEventComp} from '../../../theme/light';

const DateEventComponent = props => {
  const [modalVisible, setModalVisible] = useState(false);
  return (
    <TouchableOpacity
      activeOpacity={1}
      style={dateEventComp.container}
      onPress={() => {
        setModalVisible(true);
      }}>
      <View>
        <Text style={dateEventComp.companyName}>{props.data?.companyName}</Text>
        <View style={dateEventComp.event}>
          <Text style={dateEventComp.eventText}>{props.data?.event}</Text>
        </View>
      </View>
      <SimpleLineIcons name="arrow-right-circle" style={dateEventComp.icon} />
      <EventDetailsModal
        data={props.data}
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
    </TouchableOpacity>
  );
};
export default DateEventComponent;

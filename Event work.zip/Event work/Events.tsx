import React, {useState, useEffect} from 'react';
import {View, Text, TouchableOpacity, FlatList, Image} from 'react-native';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Calendar, LocaleConfig} from 'react-native-calendars';
import DateEventComponent from '../Component/DateEventComponent';
import {root} from '../../../styles/colors';
import {marketScreen} from '../../../theme/light';
import EventSearchModal from '../Events/EventSearchModal';
import EventFilterModal from '../Events/EventFilterModal';

LocaleConfig.locales['fr'] = {
  monthNames: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ],
  monthNamesShort: [
    'Jan',
    'Feb.',
    'Mar',
    'Aor',
    'May',
    'June',
    'Jul.',
    'Aug',
    'Sept.',
    'Oct',
    'Nov',
    'Dec',
  ],
  dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wensday', '', 'F', 'S'],
  dayNamesShort: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],
};

LocaleConfig.defaultLocale = 'fr';

const Events = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [filterData, setFilterData] = useState('');
  const [showCalendar, setShowCalendar] = useState(false);

  const [monthChange, setMonthChange] = useState(false);

  const currentDate = new Date();

  const day = currentDate.getDate();

  const monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  const month = monthNames[currentDate.getMonth()];

  const year = currentDate.getFullYear();

  const formattedDate = `${day} ${month} ${year}`;

  var pDate = formattedDate;

  var newDate = new Date();

  newDate = newDate.toISOString().split('T')[0];

  useEffect(() => {}, [hDate]);

  const [hDate, sethDate] = useState();
  const [selectedDate, setSelectedDate] = useState('');
  const [markedDates, setMarkedDates] = useState({
    [newDate]: {
      selected: true,
      selectedColor: '#002D62',
    },
    '2023-07-15': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-16': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-14': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-17': {
      marked: true,
      dotColor: 'red',
    },
  });

  var markedD = {
    '2023-07-15': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-16': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-14': {
      marked: true,
      dotColor: 'red',
    },
    '2023-07-17': {
      marked: true,
      dotColor: 'red',
    },
  };
  const events = [
    {
      id: 1,
      companyName: 'NETFLIX',
      event: 'Bonus',
      date: '2023-07-14',
      chip: 'NSE',
      price: '150.50',
      changes: '+2.70(+1.60%)',
      eventDate: `14 JUL '23`,
      memo: '3P Land Holdings Limited has informed the Exchange about Copy of Newspaper Publication.  We have enclosed the copies of the Notice of the 58th Annual General Meeting of the Company to be held on Saturday, 05th August, 2023 at 10:00 a.m. (IST) through Video Conferencing (VC) / Other Audio Visual Means (OAVM) without physical presence of the Members at Common Venue, published in The Financial Express, in English language and in Loksatta, in Marathi language on 06th July, 2023  for your information and records. The above advertisements are also available on the website of the Company atwww.3pland.com.',
    },
    {
      id: 2,
      companyName: 'HDFC',
      event: 'AGM',
      date: '2023-07-14',
      chip: 'BSE',
      price: '146.50',
      changes: '+2.30(+1.60%)',
      eventDate: `14 JUL '23`,
      Memo: '3P Land Holdings Limited has informed the Exchange about Copy of Newspaper Publication.  We have enclosed the copies of the Notice of the 58th Annual General Meeting of the Company to be held on Saturday, 05th August, 2023 at 10:00 a.m. (IST) through Video Conferencing (VC).',
    },
    {
      id: 3,
      companyName: 'NETFLIX',
      event: 'EGM',
      date: '2023-07-14',
      chip: 'NSE',
      price: '136.50',
      changes: '+1.30(+1.20%)',
      eventDate: `14 JUL '23`,
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
    {
      id: 4,
      companyName: 'AMAZONE',
      event: 'SPLIT',
      date: '2023-07-15',
      chip: 'BSE',
      price: '186.50',
      changes: '+0.30(+0.60%)',
      eventDate: `15 JUL '23`,
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
    {
      id: 5,
      companyName: 'AMAZONE',
      event: 'AGM',
      date: '2023-07-15',
      chip: 'NSE',
      price: '167.50',
      changes: '+1.30(+1.40%)',
      eventDate: '15 JUL 23',
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
    {
      id: 6,
      companyName: 'AXISNEO',
      event: 'EGM',
      date: '2023-07-16',
      chip: 'BSE',
      price: '148.50',
      changes: '+1.30(+1.70%)',
      eventDate: `16 JUL '23`,
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
    {
      id: 7,
      companyName: 'SBIFUNDS',
      event: 'BONUS',
      date: '2023-07-16',
      chip: 'NSE',
      price: '147.50',
      changes: '+2.30(+1.60%)',
      eventDate: `16 JUL '23`,
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
    {
      id: 8,
      companyName: 'HDFC',
      event: 'BONUS',
      date: '2023-07-17',
      chip: 'BSE',
      price: '149.50',
      changes: '+1.30(+1.60%)',
      eventDate: `17 JUL '23`,
      memo: 'Disclosure of defaults on payment of interest/ repayment of principal amount on loans from banks / financial institutions and unlisted debt securities',
    },
  ];
  let eventsForDate = events.filter(event => event.date === selectedDate);

  const renderEvents = ({item}) => {
    return <DateEventComponent data={item} />;
  };

  function handleMonthChange(date) {
    const selectedDate = new Date(date.dateString);
    const day = selectedDate.getDate();
    const monthIndex = selectedDate.getMonth();
    const year = selectedDate.getFullYear();
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const selectedDateString = `${day} ${monthNames[monthIndex]} ${year}`;
    markedD[date.dateString] = {
      ...markedD[date.dateString],
      selected: true,
      selectedColor: '#002D62',
      // marked: true,
      dotColor: markedD[date.dateString]?.dotColor == 'red' ? 'white' : '',
    };
    sethDate(selectedDateString);
    setMarkedDates(markedD);
    setSelectedDate(date.dateString);
  }

  const handleDayPress = date => {
    const selectedDate = new Date(date.dateString);
    const day = selectedDate.getDate();
    const monthIndex = selectedDate.getMonth();
    const year = selectedDate.getFullYear();
    const monthNames = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    const selectedDateString = `${day} ${monthNames[monthIndex]} ${year}`;
    markedD[date.dateString] = {
      ...markedD[date.dateString],
      selected: true,
      selectedColor: '#002D62',
      // marked: true,
      dotColor: markedD[date.dateString]?.dotColor == 'red' ? 'white' : '',
    };
    sethDate(selectedDateString);
    setMarkedDates(markedD);

    const eventsOnDate = events.filter(event => event.date === date.dateString);
    if (eventsOnDate.length > 0) {
      setSelectedDate(date.dateString);
    } else {
      setSelectedDate('');
    }
  };
  const [filterArr, setFilterArr] = useState([]);
  useEffect(() => {
    let arr = [...eventsForDate];
    arr = arr.filter((item, index) => {
      return item.event.toLowerCase() == filterData.toLowerCase();
    });
    setFilterArr(arr);
  }, [filterData]);
  return (
    <View>
      <View style={marketScreen.eventHeadView}>
        <Text style={marketScreen.eventHeadText}>Events</Text>
        <View style={marketScreen.eventBtnView}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(true);
            }}>
            <MaterialIcons name="search" style={marketScreen.eventSearchBtn} />
          </TouchableOpacity>
          {eventsForDate.length > 0 ? (
            <TouchableOpacity
              onPress={() => {
                setFilterModalVisible(true);
              }}>
              <Ionicons
                name="options-outline"
                style={marketScreen.eventFilterBtn}
              />
            </TouchableOpacity>
          ) : (
            <></>
          )}
        </View>
      </View>
      <View>
        {filterData != '' ? (
          <View style={marketScreen.filterMainView}>
            <Text style={marketScreen.filterText}>Filters: </Text>
            <View style={marketScreen.filterDataView}>
              <Text style={marketScreen.filterTagData}>{filterData}</Text>
              <TouchableOpacity
                onPress={() => {
                  setFilterData('');
                }}>
                <Ionicons
                  name="md-close-outline"
                  style={marketScreen.closeIcon}
                />
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <></>
        )}
        <View style={marketScreen.eventDateView}>
          <Text style={marketScreen.eventCurrentDate}>{hDate || pDate}</Text>
          <TouchableOpacity
            onPress={() => {
              setShowCalendar(!showCalendar);
            }}>
            <MaterialCommunityIcons
              name="calendar"
              size={24}
              color={root.color_text}
              style={marketScreen.eventCalendarIcon}
            />
          </TouchableOpacity>
        </View>

        {showCalendar === true ? (
          <Calendar
            style={marketScreen.eventCalendar}
            markedDates={markedDates}
            onDayPress={handleDayPress}
            theme={marketScreen.eventCalendarTheme}
            hideExtraDays={true}
            hideArrows={true}
            enableSwipeMonths={true}
            renderHeader={() => {}}
            onMonthChange={handleMonthChange}
          />
        ) : (
          []
        )}
        {eventsForDate.length > 0 ? (
          <FlatList
            data={filterData === '' ? eventsForDate : filterArr}
            // keyExtractor={event => event.id.toString()}
            renderItem={renderEvents}
            style={marketScreen.eventFlatList}
          />
        ) : (
          <View style={marketScreen.noEventView}>
            <Image
              resizeMode="contain"
              source={require('../../../assets/blank_file.jpeg')}
              style={marketScreen.noEventImage}
            />
            <Text style={marketScreen.emptyEventText}>No item available</Text>
          </View>
        )}
      </View>
      <EventSearchModal
        data={events}
        modalVisible={modalVisible}
        setModalVisible={setModalVisible}
      />
      <EventFilterModal
        setFilterData={setFilterData}
        data={eventsForDate}
        filterModalVisible={filterModalVisible}
        setFilterModalVisible={setFilterModalVisible}
      />
    </View>
  );
};
export default Events;

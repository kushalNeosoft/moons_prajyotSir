import React, {useState} from 'react';
import {FlatList, TouchableOpacity} from 'react-native';
import {View, Text, Modal, Dimensions} from 'react-native';
import AntIcon from 'react-native-vector-icons/AntDesign';
import Feather from 'react-native-vector-icons/Feather';
import {TextInput} from 'react-native';
import {SafeAreaView} from 'react-native';
import {eventSearchModal} from '../../../theme/light';
import DateEventComponent from '../Component/DateEventComponent';
const EventSearchModal = ({modalVisible, setModalVisible, data}) => {
  const [filterData, setFilterData] = useState<any>(); // remeber for open it is props.data.data
  const [textInputValue, setTextInputValue] = useState('');

  const searchFilterOnList = (value: string) => {
    if (value && value.length > 0) {
      var mainList = [];
      mainList = data;
      const filterTempList = mainList.filter(
        item =>
          item.companyName.toLowerCase().includes(value.toLowerCase()) ||
          item.event.toLowerCase().includes(value.toLowerCase()),
      );
      setFilterData(filterTempList);
    } else {
      setFilterData([]);
    }
  };
  const renderEvents = ({item}) => {
    return <DateEventComponent data={item} />;
  };
  return (
    // <SafeAreaView style={HoldingSearchModal.container}>
    <Modal
      style={eventSearchModal.modal}
      animationType="slide"
      transparent={false}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(!modalVisible);
      }}>
      <View>
        <View style={eventSearchModal.headerView}>
          <TouchableOpacity
            onPress={() => {
              setModalVisible(false);
              setTextInputValue('');
              setFilterData([]);
            }}>
            <AntIcon name="close" style={eventSearchModal.crossIcon} />
          </TouchableOpacity>
          <TextInput
            style={eventSearchModal.textInput}
            placeholder="Search Scrips or Events"
            placeholderTextColor={'#979797'}
            value={textInputValue}
            onChangeText={val => {
              searchFilterOnList(val);
              setTextInputValue(val);
            }}
          />
          <TouchableOpacity
            onPress={() => {
              setTextInputValue('');
              setFilterData([]);
            }}>
            <Text style={eventSearchModal.cleanBtn}>Clear</Text>
          </TouchableOpacity>
        </View>

        <View>
          {textInputValue === '' ? (
            <View>
              <View style={eventSearchModal.row}>
                <Feather
                  name="trending-up"
                  style={eventSearchModal.upcomingEventIcon}
                />
                <Text style={eventSearchModal.upcomingEventText}>
                  Upcoming Events
                </Text>
              </View>
              <View style={eventSearchModal.eventsView}>
                {data.slice(0, 4).map(data => {
                  return (
                    <TouchableOpacity
                      style={eventSearchModal.eventBgColor}
                      onPress={() => {
                        setTextInputValue(data.event);
                        searchFilterOnList(data.event);
                      }}>
                      <Text style={eventSearchModal.eventText}>
                        {data.event}
                      </Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          ) : filterData.length != 0 ? (
            <FlatList
              data={filterData}
              keyExtractor={event => event.id.toString()}
              renderItem={renderEvents}
              // style={marketScreen.eventFlatList}
            />
          ) : (
            <Text style={eventSearchModal.noDataText}>No Data Available</Text>
          )}
        </View>
      </View>
    </Modal>
    // </SafeAreaView>
  );
};
export default EventSearchModal;

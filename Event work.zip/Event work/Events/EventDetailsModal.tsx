import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Entypo from 'react-native-vector-icons/Entypo';
import {eventDetailModal} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';
import {root} from '../../../styles/colors';
import {ScrollView} from 'react-native-gesture-handler';

const EventDetailsModal = props => {
  return (
    <CommonModal visible={props.modalVisible} onClose={() => {}}>
      <View style={eventDetailModal.modalMainView}>
        <TouchableOpacity
          onPress={() => {
            props.setModalVisible(false);
          }}>
          <AntDesign name="close" style={eventDetailModal.modalCloseIcon} />
        </TouchableOpacity>
        <View style={eventDetailModal.topView}>
          <View>
            <Text style={eventDetailModal.companyName}>
              {props.data?.companyName}
            </Text>
            <View style={eventDetailModal.chipPriceView}>
              <View style={eventDetailModal.chip}>
                <Text style={eventDetailModal.chipText}>
                  {props.data?.chip}
                </Text>
              </View>
              <Text style={eventDetailModal.price}>{props.data?.price}</Text>
              <Text
                style={[
                  eventDetailModal.changes,
                  {
                    color: (props.data?.changes).includes('+')
                      ? root.color_positive
                      : root.color_negative,
                  },
                ]}>
                {props.data?.changes}
              </Text>
            </View>
          </View>
          <View style={eventDetailModal.rowView}>
            <TouchableOpacity style={eventDetailModal.tBottonView}>
              <Text style={eventDetailModal.tText}>T</Text>
            </TouchableOpacity>
            <TouchableOpacity style={eventDetailModal.plusBottonView}>
              <Entypo name="plus" style={eventDetailModal.plusText} />
            </TouchableOpacity>
          </View>
        </View>
        <Text style={eventDetailModal.eventText}> {props.data?.event}</Text>

        <Text style={eventDetailModal.eventDate}>{props.data?.eventDate}</Text>

        <ScrollView style={eventDetailModal.memoScrollView}>
          <Text style={eventDetailModal.memo}> {props.data?.memo}</Text>
        </ScrollView>
      </View>
    </CommonModal>
  );
};
export default EventDetailsModal;

import React, {useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {eventFilterModal} from '../../../theme/light';
import CommonModal from '../../../components/CommonModal/CommonModal';
import {root} from '../../../styles/colors';

const EventFilterModal = props => {
  const [filter, setFilter] = useState('');
  return (
    <CommonModal visible={props.filterModalVisible} onClose={() => {}}>
      <View style={eventFilterModal.modalMainView}>
        <View style={eventFilterModal.headerAndIconView}>
          <Text style={eventFilterModal.modalTitle}>Sort & Filter</Text>
          <TouchableOpacity
            onPress={() => {
              props.setFilterModalVisible(false);
            }}>
            <AntDesign name="close" style={eventFilterModal.modalCloseIcon} />
          </TouchableOpacity>
        </View>
        <View>
          <Text style={eventFilterModal.eventText}>Events</Text>
          <View style={eventFilterModal.eventsView}>
            {props.data.map(data => {
              return (
                <TouchableOpacity
                  style={[
                    eventFilterModal.eventBgColor,
                    {
                      backgroundColor:
                        data.event === filter
                          ? root.color_chipFilter
                          : root.color_active,
                      borderColor:
                        data.event === filter
                          ? root.client_background
                          : root.color_subtext,
                    },
                  ]}
                  onPress={() => {
                    setFilter(data.event);
                  }}>
                  <Text style={eventFilterModal.eventChipText}>
                    {data.event}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
        <TouchableOpacity
          style={eventFilterModal.botton}
          onPress={() => {
            props.setFilterData(filter);
            props.setFilterModalVisible(false);
          }}>
          <Text
            style={[
              eventFilterModal.bottonText,
              {
                color: filter === '' ? root.color_subtext : root.color_active,
              },
            ]}>
            Apply
          </Text>
        </TouchableOpacity>
      </View>
    </CommonModal>
  );
};
export default EventFilterModal;

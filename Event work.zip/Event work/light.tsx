// Replace Style

export const dateEventComp = StyleSheet.create({
  container: {
    ...m.v_20,
    ...alignment.row_alingC_SpaceB,
  },
  companyName: {
    ...size_family.rm_13,
    ...color.text,
    ...m.m_l_15,
  },
  event: {
    backgroundColor: "#9AB3FF33",
    ...p.p_3,
    ...p.h_6,
    borderRadius: 8,
    ...m.m_l_15,
    ...m.t_6,
    alignSelf: "flex-start",
  },
  eventText: {
    color: root.color_textual,
    ...size_family.rm_8,
  },
  icon: {
    fontSize: 24,
    ...color.text,
    ...p.r_15,
  },
});

//Add New Style

// Event details Modal
export const eventDetailModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...m.t_13,
  },
  companyName: {
    ...size_family.rm_12,
    ...color.text,
  },
  chip: {
    backgroundColor: "rgba(151,151,151,0.1)",
    borderColor: "rgba(151,151,151,0.1)",
    borderWidth: 0.5,
    borderRadius: 2,
    ...alignment.alignC_justifyC,
    ...p.p_3,
    alignSelf: "flex-start",
  },
  chipText: {
    ...size_family.rm_9,
    ...color.subtext,
  },
  price: {
    ...size_family.rr_13,
    ...color.text,
    ...m.m_l_4,
  },
  changes: {
    ...size_family.rr_10,
    ...m.m_l_6,
  },
  eventText: {
    ...size_family.rm_16,
    ...color.text,
    ...m.t_22,
  },
  eventDate: {
    ...size_family.rm_16,
    ...color.text,
    ...m.t_21,
  },
  memo: {
    ...size_family.rr_11,
    ...color.text,
  },
  memoScrollView: {
    ...m.t_23,
    ...m.b_35,
  },
  plusBottonView: {
    borderColor: root.color_text,
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    ...alignment.alignC_justifyC,
  },
  tBottonView: {
    borderColor: root.color_text,
    borderWidth: 1.5,
    width: 26,
    height: 26,
    borderRadius: 26 / 2,
    ...alignment.alignC_justifyC,
    ...m.r_25,
  },
  topView: {
    ...alignment.row_alingC_SpaceB,
    ...m.t_17,
  },
  chipPriceView: {
    ...alignment.row_alignC,
    ...m.t_10,
  },
  rowView: {
    ...alignment.row,
  },
  tText: {
    fontFamily: Cfont.rubik_medium,
    ...color.text,
  },
  plusText: {
    ...color.text,
    fontSize: 21,
  },
});

// Event Filter Modal

export const eventFilterModal = StyleSheet.create({
  modalMainView: {
    ...bgColor.color_active,
    ...p.h_10,
  },
  modalTitle: {
    ...color.text,
    ...size_family.rm_26,
    ...p.t_10,
  },
  modalCloseIcon: {
    fontSize: Font.font_normal_twenty_two,
    color: root.color_text,
    ...p.t_3,
  },
  headerAndIconView: {
    ...alignment.row_SpaceB,
  },
  eventText: {
    ...color.text,
    ...size_family.rm_11,
    ...m.t_25,
  },
  eventsView: {
    flexWrap: "wrap",
    width: "100%",
    ...alignment.row,
    justifyContent: "flex-start",
    ...m.t_11,
  },
  eventBgColor: {
    borderRadius: 7,
    ...alignment.alignC_justifyC,
    ...p.p_5,
    ...p.h_20,
    ...p.v_10,
    borderColor: root.color_border_bg,
    borderWidth: 1,
    ...m.r_10,
    ...m.b_12,
  },
  eventChipText: {
    ...size_family.rr_12,
    ...color.text,
  },
  botton: {
    width: "100%",
    ...alignment.alignC_justifyC,
    ...bgColor.client_background,
    borderRadius: 7,
    ...p.p_10,
    ...m.t_14,
    ...m.b_7,
  },
  bottonText: {
    ...size_family.rm_14,
  },
});

export const eventSearchModal = StyleSheet.create({
  container: {
    flex: 1,
    ...bgColor.color_active,
  },
  modal: {
    width: Dimensions.get("window").width,
    height: 300,
    ...alignment.alignC_justifyC,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: root.color_active,
  },
  headerView: {
    ...alignment.row_alignC,
    ...bgColor.color_active,
    shadowColor: "#000",
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
  },
  crossIcon: {
    ...m.h_13,
    fontSize: 21,
    ...color.text,
  },
  textInput: {
    flex: 1,
    ...size_family.rr_13,
    ...color.text,
  },
  cleanBtn: {
    ...size_family.rm_13,
    ...m.h_13,
    ...color.text,
  },
  upcomingEventText: {
    ...size_family.rm_14,
    ...color.text,
    ...m.m_l_10,
  },
  upcomingEventIcon: {
    ...color.text,
    fontSize: 22,
  },
  row: {
    ...alignment.row_alignC,
    ...m.t_16,
    ...m.m_l_15,
  },
  eventsView: {
    flexWrap: "wrap",
    width: "100%",
    ...alignment.row,
    justifyContent: "flex-start",
    ...p.h_15,
    ...m.t_14,
  },
  eventBgColor: {
    ...color.active,
    borderRadius: 5,
    ...alignment.alignC_justifyC,
    ...p.p_6,
    ...p.h_10,
    borderColor: root.color_border_bg,
    borderWidth: 1,
    ...m.r_10,
  },
  eventText: {
    ...size_family.rm_10,
    ...color.text,
  },
  noDataText: {
    ...color.subtext,
    ...size_family.rm_13,
    alignSelf: "center",
    ...m.t_50,
  },
});

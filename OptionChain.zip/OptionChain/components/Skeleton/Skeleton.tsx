import React from 'react';
import {View, Text, StyleSheet, FlatList} from 'react-native';
import {optionChainSkeleton} from '../../../../../theme/light';
import LinearGradient from 'react-native-linear-gradient';
import {Skeleton} from '@rneui/themed';

const OptionChainSkeleton = () => {
  const number = [1, 2, 3, 4, 5, 6, 7, 8];
  const skeletonView = () => {
    return (
      <LinearGradient
        colors={['#e0e0e0', '#ededed', '#f9f9f9']}
        style={optionChainSkeleton.linearGradient}
      />
    );
  };
  return (
    <FlatList
      data={number}
      renderItem={({item}) => (
        <View style={optionChainSkeleton.overAllCard}>
          <View style={optionChainSkeleton.topView}>
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={60}
              height={10}
              style={{backgroundColor: '#ededed'}}
            />
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={100}
              height={10}
              style={optionChainSkeleton.style}
            />
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={80}
              height={10}
              style={optionChainSkeleton.style}
            />
          </View>
          <View style={optionChainSkeleton.middleView}>
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={90}
              height={10}
              style={{backgroundColor: '#ededed'}}
            />
          </View>
          <View style={optionChainSkeleton.topView}>
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={100}
              height={10}
              style={{backgroundColor: '#ededed'}}
            />
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={60}
              height={10}
              style={optionChainSkeleton.style}
            />
            <Skeleton
              LinearGradientComponent={skeletonView}
              animation="wave"
              width={80}
              height={10}
              style={optionChainSkeleton.style}
            />
          </View>
        </View>
      )}
    />
  );
};

export default OptionChainSkeleton;
